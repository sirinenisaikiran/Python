#Set anaconda in path 
#spark-submit --master local[4] cosine_similarity.py

from __future__ import print_function

from pyspark import SparkContext

import numpy as np


from pyspark.mllib.stat import Statistics
from pyspark.mllib.linalg.distributed import *
from pyspark.mllib.linalg import Vectors

if __name__ == "__main__":
    sc = SparkContext(appName="CosineSimilarity")  # SparkContext
    threshold = 0.1 
    inputFile = r"D:\Desktop\PPT\spark\data\sample_svm_data.txt"

    def  mapFun(line):
        values = [float(x) for x in line.split(' ')]
        return Vectors.dense(values)


    # Load and parse the data file.
    rows = sc.textFile(inputFile).map(mapFun).cache()
    mat = RowMatrix(rows)

    # Compute similar columns perfectly, with brute force.
    exact = mat.columnSimilarities() #CoordinateMatrix 

    # Compute similar columns with estimation using DIMSUM
    approx = mat.columnSimilarities(threshold) #CoordinateMatrix 

    #RDD[MatrixEntry] => RDD[((Int,Int), Double)]
    exactEntries = exact.entries.map(lambda mx: ((mx.i, mx.j), mx.value) )
    approxEntries = approx.entries.map (lambda mx : ((mx.i, mx.j), mx.value) )

    #from PairRDDFunctions via implicit conversions of [K,V] pair
    # For each element (k, v) in this, the resulting RDD will either contain all pairs (k, (v, w)) for w in other, 
    #or the pair (k, (v, None)) if no elements in other have key k.
    MAE = exactEntries.leftOuterJoin(approxEntries).values() \
                                .map( lambda t : abs(t[0]) if not t[1] else abs(t[0] - t[1])) \
                                .mean()


    print("Average absolute error in estimate is: "+ str(MAE))

    sc.stop()