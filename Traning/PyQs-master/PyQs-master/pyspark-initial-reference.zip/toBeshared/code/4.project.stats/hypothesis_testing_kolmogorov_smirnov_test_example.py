#Set anaconda in path 
#spark-submit --master local[4] hypothesis_testing_kolmogorov_smirnov_test_example.py

from __future__ import print_function

from pyspark import SparkContext

from pyspark.mllib.stat import Statistics
from pyspark.mllib.random import RandomRDDs

if __name__ == "__main__":
    sc = SparkContext(appName="HypothesisTestingKolmogorovSmirnovTestExample")

    # $example on$
    parallelData = sc.parallelize([0.1, 0.15, 0.2, 0.3, 0.25])

    # run a KS test for the sample versus a standard normal distribution
    testResult = Statistics.kolmogorovSmirnovTest(parallelData, "norm", 0, 1)
    # summary of the test including the p-value, test statistic, and null hypothesis
    # if our p-value indicates significance, we can reject the null hypothesis
    
    
    # Note that the Scala functionality of calling Statistics.kolmogorovSmirnovTest with
    # a lambda to calculate the CDF is not made available in the Python API
    print(testResult)

    #Generate a random double RDD that contains 1 million i.i.d. values drawn from the
    #standard normal distribution `N(0, 1)`, evenly distributed in 10 partitions.
    u = RandomRDDs.normalRDD(sc, 1000L, 10)
    #Apply a transform to get a random double RDD following `N(1, 4)`.
    v = u.map(lambda x : 1.0 + 2.0 * x)
    
    testResult3 = Statistics.kolmogorovSmirnovTest(u, "norm", 0, 1)
    print(testResult3)

    sc.stop()
