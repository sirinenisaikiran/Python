#spark-submit --conf spark.ui.showConsoleProgress=false --jars ..\spark-streaming-flume-assembly_2.11-2.1.0.jar flume_wordcount_v2.py localhost 12345    
#in another cmd 
#bin\flume-ng.cmd agent --classpath "lib\ext\*" --conf conf --conf-file conf\spark2.conf.properties --name agent -property "flume.root.logger=INFO,console"


#in another cmd 
#telnet localhost 44444

from __future__ import print_function

import sys

from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.flume import FlumeUtils

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: flume_wordcount.py <hostname> <port>", file=sys.stderr)
        exit(-1)

    sc = SparkContext(appName="PythonStreamingFlumeWordCount")
    ssc = StreamingContext(sc,10)

    hostname, port = sys.argv[1:]
    kvs = FlumeUtils.createPollingStream(ssc, [(hostname, int(port)),] )

    lines = kvs.map(lambda x: x[1])
    counts = lines.flatMap(lambda line: line.split(" ")) \
        .map(lambda word: (word, 1)) \
        .reduceByKey(lambda a, b: a+b)
    counts.pprint()

    ssc.start()
    ssc.awaitTermination()
