#Set anaconda before py3.5 in path
#spark-submit  --master local[4] gaussian_mixture_example.py


from __future__ import print_function


from pyspark.ml.clustering import GaussianMixture

from pyspark.sql import SparkSession

"""
A simple example demonstrating Gaussian Mixture Model (GMM).
"""

if __name__ == "__main__":
    spark = SparkSession\
        .builder\
        .appName("GaussianMixtureExample")\
        .getOrCreate()

    # $example on$
    # loads data
    dataset = spark.read.format("libsvm").load(r"d:\desktop\ppt\spark\data\sample_kmeans_data.txt")

    gmm = GaussianMixture().setK(2).setSeed(538009335)
    model = gmm.fit(dataset)

    print("Gaussians shown as a DataFrame: ")
    model.gaussiansDF.show(truncate=False)
    # $example off$

    spark.stop()
