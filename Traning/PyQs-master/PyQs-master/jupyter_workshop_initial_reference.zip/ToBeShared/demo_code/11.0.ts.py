import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 
import statsmodels.api as sm 

PAUSE='N'
def pause_d():
    if PAUSE == 'Y':
        print("pausing...")
        input()

print("--------------TimeSeries analysis on Nifty data")
dft = pd.read_excel(r"data\Nifty-17_Years_Data-V1.xlsx", parseDates=True, freq='D', index_col=0, header=0, date_parser=lambda x: pd.to_datetime(x, format="%d-%b-%y"))

#from pandas.tseries.offsets import *
#dft.index.freq = Day() #set freq as D 
#dft.index.freq = pd.tseries.frequencies.to_offset(Day())
#as of now below works, but note that, this is used for resampling 
#dft = dft.asfreq('D')


print(dft.head())
print("Accessing '2013-1':'2013-2'...")




import datetime
print(dft['2013-1':'2013-2'].head() )    #slice, end inclusive 

pause_d()
print("plotting close...")

#complex plot 
#4x4 gridspecs, specification for 0,0 cell , row spanning 3 rows, column spanning 4 columns 
top = plt.subplot2grid((4,4), (0, 0), rowspan=3, colspan=4)
top.plot(dft.index, dft["Close"])
plt.title('Nifty close from 2000 - 2018')

#4x4 gridspecs, specification for 3,0 cell , row spanning 1 rows, column spanning 4 columns 
bottom = plt.subplot2grid((4,4), (3,0), rowspan=1, colspan=4)
bottom.bar(dft.index, dft['Day Wise Variation ( points) '])
plt.title('Nifty Day wise variations ')

plt.show()

pause_d()
print("Other plots...")
fig, ((ax1,ax2,ax3),(ax4,ax5,ax6), (ax7,ax8,ax9)) = plt.subplots(3, 3)

dft.Close.plot(kind='line', ax=ax1)

#with subplots 
#multiple in one plot 
dft.plot(kind='line', y=['Open', 'Day Wise Variation ( points) '] , ax=ax2)
#with subplots 
#dft.plot(kind='line', y=['Open', 'Day Wise Variation ( points) '], subplots=True )
#plt.show()





##Groupby (for Time series, equivalent to aggregation)
#Calculate moving avarages 
#window : int,Size of the moving window. 
#This is the number of observations used for calculating the statistic.
dft_r = dft.rolling(30)  #rolling 30 samples 
dir(dft_r)
#plot rolling average 
print(dft_r.mean()['Open'].head()) #DF 
dft_r.mean()['Open'].dropna().plot(kind='line', ax=ax3) #DF
#plt.show()
#

dft_e = dft.ewm(com=0.5)#Returns Exponentially-weighted moving window(EWM) class ,com=decay in terms of center of mass
dft_e.mean()['Open'].dropna().plot(kind='line', ax=ax4) #DF
#
dft_x = dft.expanding(2) #Expanding window, Minimum number of observations in window required to have a value         (otherwise result is NA)
dft_x.mean()['Open'].dropna().plot(kind='line', ax=ax5) #DF

#or downsampling at month 
dft_s = dft.resample('M')
#dir(dft_s)
#month value would be mean()
dft_s.mean() #DF 
dft_s['Open'].mean() #Series
dft_s['Open'].agg([np.sum, np.mean, np.std])
dft_s.agg({'Open':'mean', 'Close':'std'})
dft_s.agg({'Open':['mean',np.std], 'Close':['std','sum']})

dft_s.mean()['Open'].dropna().plot(kind='line', ax=ax6) #DF

#KDE plot
dft_s.Close.plot(kind='kde', ax=ax7)
#plt.show()


#lagplot -Lag plots are used to check if a data set or time series is random. 
#Random data should not exhibit any structure in the lag plot. 
#Non-random structure implies that the underlying data are not random.
from pandas.plotting import lag_plot
lag_plot(dft.Close, ax=ax8)
#plt.show()


##Autocorrelation plots are often used for checking randomness in time series
#If time series is random, such autocorrelations should be near zero for  all time-lag separations(other than lag=0)
from pandas.plotting import autocorrelation_plot
autocorrelation_plot(dft.Close, ax=ax9)

plt.show()



##Time Series analysis - statsmodel 
import statsmodels.api as sm
import statsmodels.tsa.api as smt
##Checking stationary 
#constant mean
#constant variance
#an autocovariance that does not depend on time
 
pause_d()

print("""
clearly Close shows overall increasing trend 
further checking of stationary 
rolling statistics plots - ever increasing 
and  Dickey-Fuller test - adfuller
H0: TS is non-stationary
""")

def test_stationarity(timeseries):    
    #Determing rolling statistics
    rolmean = timeseries.rolling(window=12, center=False).mean()
    rolstd = timeseries.rolling(window=12, center=False).std()
    #Plot rolling statistics:
    orig = plt.plot(timeseries, color='blue',label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.title('Rolling Mean & Standard Deviation')
    plt.show(block=False)
    #Perform Dickey-Fuller test:
    print('Results of Dickey-Fuller Test:')
    dftest = smt.adfuller(timeseries, autolag='AIC')
    dfoutput = pd.Series(dftest[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
    for key,value in dftest[4].items():
        dfoutput['Critical Value (%s)'%key] = value
    print(dfoutput)
    
ts = dft.Open 
print(test_stationarity(ts) )
#variation in standard deviation is small, mean is clearly increasing with time 
#p-value>0.05, hence accept H0(=TS is non-stationary)
# Results of Dickey-Fuller Test:
# Test Statistic                    0.411488
# p-value                           0.981920
#Lags Used                       14.000000
# Number of Observations Used    4370.000000
# Critical Value (10%)             -2.567122
# Critical Value (5%)              -2.862202
# Critical Value (1%)              -3.431847
# dtype: float64

pause_d()

print("""
How to make a Time Series Stationary?
(stable mean and variance)
#Reasons for nonstionary 
#1. Trend - varying mean over time. 
#    In this case, average mean increasing over time 
#2. Seasonality - variations at specific time-frames
#    (changing variance over time,)
#    eg people might have a tendency to buy cars in a particular month 
#    because of pay increment or festivals.


First option - Tranformation 
eg log, sqrt or cube root to dampen the trend 
for decreasing trend use  exp, square, cube etc 
""")
ts_log = np.log(ts)
plt.plot(ts_log)
plt.plot(ts)
plt.show()
pause_d()
print("""
Second option 
Differencing - taking the differece with a particular time lag
""")
print("Eliminating both Trend and Seasonality - Differencing")
ts_log_diff = ts_log - ts_log.shift(1)
#or 
ts_log_diff = ts_log.diff(periods=1) #Periods to shift for forming difference

ts_log_diff.dropna(inplace=True)
print("ts_log_diff\n", test_stationarity(ts_log_diff))
# Results of Dickey-Fuller Test:
# Test Statistic                -1.445462e+01
# p-value                        7.006666e-27
#Lags Used                     1.900000e+01
# Number of Observations Used    4.364000e+03
# Critical Value (10%)          -2.567123e+00
# Critical Value (5%)           -2.862203e+00
# Critical Value (1%)           -3.431849e+00
# dtype: float64
pause_d()
print("Note 2nd differencing is extremly rare , DOn't use ")
ts_log_diff2 = ts_log_diff - ts_log_diff.shift(1)
#or 
ts_log_diff2 = ts_log_diff.diff(1) #Note, it is not ts_log.diff(periods=2), which is diff with every 2nd period 

ts_log_diff2.dropna(inplace=True)
print("ts_log_diff2\n",test_stationarity(ts_log_diff2))
# Results of Dickey-Fuller Test:
# Test Statistic                -8.196629e+00
# p-value                        7.419305e-13
#Lags Used                     1.300000e+01
# Number of Observations Used    1.280000e+02
# Critical Value (1%)           -3.482501e+00
# Critical Value (10%)          -2.578960e+00
# Critical Value (5%)           -2.884398e+00
# dtype: float64
pause_d()

print("""
Third option 
Decomposing
In this approach, both trend and seasonality are modeled separately 
and the remaining part of the series is returned
One nneds to fit then residuals 
""")

'''
Arg freq : int, optional
        Frequency of the series. Must be used if x is not a pandas object. 
        Overrides default periodicity of x 
        if x is a pandas object with a timeseries index.
            #freqstr      Seasonal period    # of datapoints for aggregation
            A              1                 aggregate yearly 
            Q              4                 aggregate yearly 
            M              12                aggregate yearly
            W              52                aggregate yearly
            D              7                 aggregate weekly 
            B              5                 aggregate weekly 
            H              24                aggregate daily 
'''

from statsmodels.tsa.seasonal import seasonal_decompose

#default is additive model 
decomposition = seasonal_decompose(ts_log, freq=7) 
trend = decomposition.trend
seasonal = decomposition.seasonal
residual = decomposition.resid   #this needs modeling  
#plot all 
decomposition.plot()
plt.show()

pause_d()

#Get stats 
ts_log_decompose = residual
ts_log_decompose.dropna(inplace=True)
print("ts_log_decompose\n", test_stationarity(ts_log_decompose))
# Test Statistic                  -18.851623
# p-value                           0.000000
#Lags Used                       30.000000
# Number of Observations Used    4348.000000
# Critical Value (10%)             -2.567124
# Critical Value (5%)              -2.862205
# Critical Value (1%)              -3.431855
# dtype: float64

##Forecasting a Time Series
print("we would use  differencing for making stationary ")
pause_d()
print("""
ACF and PACF plots:
p - The lag value where the PACF chart crosses the upper confidence interval for the first time. 
     If you notice closely, in this case p=1.
q - The lag value where the ACF chart crosses the upper confidence interval for the first time. 
     If you notice closely, in this case q=1.
""")

#below line must, must not contain NaN 
ts_log_diff.dropna(inplace=True)

fig = plt.figure(figsize=(12,8))
ax1 = fig.add_subplot(211)
sm.graphics.tsa.plot_acf(ts_log_diff, lags=40, ax=ax1,alpha=0.05) #confidence level 95%
ax2 = fig.add_subplot(212)
sm.graphics.tsa.plot_pacf(ts_log_diff, lags=40, ax=ax2,alpha=0.05)
plt.show()

pause_d()

#or 
print("select order by x13 - Only monthly and quarterly periods are supported")
import pandas as pd
df = pd.DataFrame(ts_log, index=dft.index)
#Requires x13as.exe in PATH , Only monthly and quarterly periods are supported
#download from https://www.census.gov/srd/www/winx13/winx13_down.html
import statsmodels
res = statsmodels.tsa.x13.x13_arima_select_order(df.resample('M').mean())
print(res.order)
#(0, 1, 1)

#or 
print("select order by AIC, BIC ")
ts_log_diff.dropna(inplace=True) #note if input contains nan, Error would happen 
res = sm.tsa.arma_order_select_ic(ts_log_diff, ic=['aic', 'bic'], trend='nc') #nc - no constant term
res.aic_min_order #(p,q) = (3, 2)
res.bic_min_order #(0, 1)
print(res)
# {'bic_min_order': (0, 1), 'bic':               0             1             2
# 0           NaN -24712.161789 -24711.432984
# 1 -24709.468202 -24709.834026 -24703.079027
# 2 -24711.557674 -24703.279453 -24696.956015
# 3 -24703.333590 -24696.489131 -24696.783230
# 4 -24695.555535 -24687.204379           NaN, 'aic':               0
# 1             2
# 0           NaN -24724.933223 -24730.590135
# 1 -24722.239636 -24728.991176 -24728.621895
# 2 -24730.714824 -24728.822320 -24728.884599
# 3 -24728.876458 -24728.417715 -24735.097531
# 4 -24727.484119 -24725.518680           NaN, 'aic_min_order': (3, 2)}

pause_d()



print("Fit now on ts_log")
ts = dft.Open 
ts_log = np.log(ts)
ts_log_diff = ts_log.diff(periods=1)
ts_log_diff.dropna(inplace=True)


#since 1st order differntiation is done, hence d= 1
from statsmodels.tsa.arima_model import ARIMA

fig = plt.figure(figsize=(12,8))
#AR Model
model = ARIMA(ts_log, order=(1, 1, 0))  
results_AR = model.fit(disp=-1)   #disp:If True, convergence information is output.
ax1 = fig.add_subplot(311)
ax1.plot(ts_log_diff)
ax1.plot(results_AR.fittedvalues, color='red')
ax1.set_title('RSS:order=(1, 1, 0) %.4f'% sum((results_AR.fittedvalues-ts_log_diff)**2))

#MA Model
model = ARIMA(ts_log, order=(0, 1, 1))  
results_MA = model.fit(disp=-1)  
ax2 = fig.add_subplot(312)
ax2.plot(ts_log_diff)
ax2.plot(results_MA.fittedvalues, color='red')
ax2.set_title('RSS: order=(0, 1, 1) %.4f'% sum((results_MA.fittedvalues-ts_log_diff)**2), x=0.4)

#ARIMA 
model = ARIMA(ts_log, order=(1, 1, 1))  
results_ARIMA = model.fit(disp=-1)  
ax3 = fig.add_subplot(313)
ax3.plot(ts_log_diff)
ax3.plot(results_ARIMA.fittedvalues, color='red') #fittedvalues  is after differencing, d=1
ax3.set_title('RSS: order=(1, 1, 1) %.4f'% sum((results_ARIMA.fittedvalues-ts_log_diff)**2), x=0.4)

plt.show()

pause_d()
print("Note - all below are after differencing d=1")
print("ts_log_diff\n",ts_log_diff[1:5])  #with d=1 
# Date
# 2000-06-02    0.029400
# 2000-06-05    0.010989
# 2000-06-06    0.012136
# 2000-06-07    0.006031
# Name: Close, dtype: float64
print("results_ARIMA.fittedvalues\n",results_ARIMA.fittedvalues[0:4])  #with d=1 
# Date
# 2000-06-02    0.000470
# 2000-06-05    0.002797
# 2000-06-06    0.000337
# 2000-06-07    0.001505
# dtype: float64
print("results_ARIMA.predict\n", results_ARIMA.predict(start=1,end=4))  #in place , with d=1 
# Date
# 2000-06-02    0.000470
# 2000-06-05    0.002797
# 2000-06-06    0.000337
# 2000-06-07    0.001505
# dtype: float64
print("out of sample prediction ")
print("results_ARIMA.predict\n",results_ARIMA.predict(start=len(ts_log)-1, end=len(ts_log)+5))
# 4384    0.001018
# 4385    0.000623
# 4386    0.000416
# 4387    0.000488
# 4388    0.000463
# 4389    0.000472
# 4390    0.000469
# dtype: float64

print("results_ARIMA.forecast\n",results_ARIMA.forecast(steps=5)[0]) 
#without d=1 , returns forecast,stderr, confInterval
#array([9.26534234, 9.26575853, 9.26624702, 9.2667102 , 9.26718224])
#>>> ts_log[-1]
#9.2647196498149

#get summary 
print(results_ARIMA.summary())
#predict , next 20 values 
steps=20
predict_arima = results_ARIMA.forecast(steps=steps) #without d=1 , returns forecast,stderr, confInterval
print("20 predicted values(forecast,stderr, confInterval)\n", predict_arima)


pause_d()
##Taking it back to original scale
index = pd.date_range(ts.index[-1], periods=steps+1)[-steps:]
predictions_ARIMA_log = pd.Series(predict_arima[0], copy=True, index=index)
predictions_ARIMA_diff_orig = pd.Series(results_ARIMA.fittedvalues, copy=True)


#we took a lag by 1  for differencing 
#To undo, first determine the cumulative sum at index 
#add it to first value 
predictions_ARIMA_log_orig = predictions_ARIMA_diff_orig.cumsum() + ts_log[0]


#and then anti-log 
predictions_ARIMA = np.exp(predictions_ARIMA_log)
predicted = np.exp(predictions_ARIMA_log_orig.append(predictions_ARIMA_log) ) 

plt.plot(ts)
plt.plot(predicted)
#use ts[1:] because predictions_ARIMA_log_orig does not initial d samples 
plt.title('RMSE: %.4f'% np.sqrt(sum((np.exp(predictions_ARIMA_log_orig)-ts[1:])**2)/len(ts[1:])))
plt.show()

