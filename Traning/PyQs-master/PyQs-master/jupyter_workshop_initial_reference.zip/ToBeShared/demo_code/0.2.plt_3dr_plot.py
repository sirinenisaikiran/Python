import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

print("""
Other 3D plots 
https://matplotlib.org/mpl_toolkits/mplot3d/api.html
""")

##3D plots 
#3D plots require x,y (create from meshgrid) and Z 
#Z points are mapped to color  from ColorMap 


from matplotlib import cm 
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.axes3d import Axes3D
import numpy as np

X = np.arange(-5, 5, 0.25)
Y = np.arange(-5, 5, 0.25)
X, Y = np.meshgrid(X, Y)
R = np.sqrt(X**2 + Y**2)
Z = np.sin(R)
fig = plt.figure(figsize=(10,6))
ax1 = fig.add_subplot(141, projection='3d')  #requires Axes3D
#rstride 	Array row stride (step size)
#cstride 	Array column stride (step size)
surf = ax1.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm, linewidth=0, antialiased=False)
ax1.set_zlim(-1.01, 1.01)
ax1.set_title("Surface plot")
# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=10)

##Mesh graph 
ax2 = fig.add_subplot(142) 
surf2 = ax2.pcolormesh(X, Y, Z, cmap=cm.ocean, alpha=0.2)
ax2.set_title("Color Mesh")

##Contour graph 
#contourf() differs from the MATLAB version in that it does not draw the polygon edges. 
#To draw edges, add line contours with calls to contour().


#If an int n, use n data intervals; i.e. draw n+1 contour lines. 
#The level heights are automatically chosen.
ax3 = fig.add_subplot(143) 
surf3 = ax3.contourf(X, Y, Z, levels=[-.25,0,.25], cmap=cm.Dark2, alpha=0.2)
ax3.set_ylim(-5,5)
ax3.set_xlim(-5,5)
ax3.set_title("Contour- filled contours")

ax4 = fig.add_subplot(144) 
surf3 = ax4.contour(X, Y, Z, levels=[-.25,0,.25], cmap=cm.Dark2, alpha=0.2)
ax4.set_title("Contour- contour lines")
plt.show()

input()

##Polar plot 
r = np.arange(0, 2, 0.01)
theta = 2 * np.pi * r

ax = plt.subplot(111, projection='polar')
ax.plot(theta, r)
ax.set_rmax(2)
ax.set_rticks([0.5, 1, 1.5, 2])  # less radial ticks
ax.set_rlabel_position(-22.5)  # get radial labels away from plotted line
ax.grid(True)

ax.set_title("A line plot on a polar axis", va='bottom')
plt.show()

input()

#https://matplotlib.org/mpl_toolkits/mplot3d/tutorial.html#wireframe-plots

#Example wireframe plot 


def get_test_data(delta=0.05):
    '''
    Return a tuple X, Y, Z with a test data set.
    '''
    x = y = np.arange(-3.0, 3.0, delta)
    X, Y = np.meshgrid(x, y)
    #bivariate_normal
    Z1 = np.exp(-(X**2 + Y**2) / 2) / (2 * np.pi)
    Z2 = (np.exp(-(((X - 1) / 1.5)**2 + ((Y - 1) / 0.5)**2) / 2) /
          (2 * np.pi * 0.5 * 1.5))
    Z = Z2 - Z1

    X = X * 10
    Y = Y * 10
    Z = Z * 500
    return X, Y, Z

from mpl_toolkits.mplot3d import axes3d
import matplotlib.pyplot as plt
import numpy as np

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
x, y, z = get_test_data(0.05)
ax.plot_wireframe(x,y,z, rstride=2, cstride=2)
ax.set_title("Wireframe plot", va='bottom')
plt.show()
