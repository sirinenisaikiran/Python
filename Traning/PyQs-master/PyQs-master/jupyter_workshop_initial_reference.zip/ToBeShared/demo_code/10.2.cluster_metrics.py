print("""
The Silhouette Coefficient is used when the ground-truth 
about the dataset is unknown and computes the density of clusters 
computed by the model. 

The score is computed by averaging the silhouette coefficient 
for each sample, computed as the difference 
between the average intra-cluster distance 
and the mean nearest-cluster distance for each sample, 
normalized by the maximum value. 

This produces a score between 1 and -1, 
where 1 is highly dense clusters and -1 is completely incorrect 
clustering.

The Silhouette Visualizer displays the silhouette coefficient 
for each sample on a per-cluster basis, 
visualizing which clusters are dense and which are not. 

This is particularly useful for determining cluster imbalance, 
or for selecting a value for K
by comparing multiple visualizers.
""")

PAUSE='Y'
def pause_d():
    if PAUSE == 'Y':
        print("pausing...")
        input()

from sklearn.datasets import make_blobs

# Make 8 blobs dataset
X, y = make_blobs(centers=8)

from sklearn.cluster import MiniBatchKMeans

from yellowbrick.cluster import *

# Instantiate the clustering model and visualizer
model = MiniBatchKMeans(6)
visualizer = SilhouetteVisualizer(model)

visualizer.fit(X) # Fit the training data to the visualizer
visualizer.poof() # Draw/show/poof the data

pause_d()

print("""
Intercluster distance maps display an embedding of the cluster centers 
in 2 dimensions with the distance to other centers preserved. 
E.g. the closer to centers are in the visualization, 
the closer they are in the original feature space. 

The clusters are sized according to a scoring metric. 
By default, they are sized by membership, 
e.g. the number of instances that belong to each center. 
This gives a sense of the relative importance of clusters. 

Note however, that because two clusters overlap in the 2D space, 
it does not imply that they overlap in the original feature space.
""")

from sklearn.datasets import make_blobs

# Make 12 blobs dataset
X, y = make_blobs(centers=12, n_samples=1000, n_features=16, shuffle=True)

from sklearn.cluster import KMeans
from yellowbrick.cluster import InterclusterDistance

# Instantiate the clustering model and visualizer
visualizer = InterclusterDistance(KMeans(9))

visualizer.fit(X) # Fit the training data to the visualizer
visualizer.poof() # Draw/show/poof the data

