import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

#Creation 
print("""DF creation
pd.DataFrame([{'A':1, 'B':1},{'A':2, 'B':2}]) #list of dict, columnName:value,.. for each row
pd.DataFrame( np.array([[1,2],[3,4]]), columns=['A', 'B']) #numpy 2D, columns
pd.DataFrame([[1,2],[3,4]], columns=['a','b']) #list of list(rows), columns
pd.DataFrame({'A': [1,2,3], 'B':[1,2,3]})  #columnName:list of col values
""")
df = pd.DataFrame({'A': [1,2,3], 'B':[1,2,3]})
print("eg df.head()\n", df.head())

print("""For conversion use, 
pd.to_numeric(arg), 
pd.to_datetime(arg, ,format='%Y %m %d'), 
pd.to_timedelta(arg, unit='ns')""")

df1 = pd.DataFrame({'A': ['1', '2'], 'B':['20181231', '20180304'],
                     'C': [10000, 10000]})

print("eg df.head()", df1.head(), sep="\n")                 #new column creation and accessing 
df1['AA'] = pd.to_numeric(df1.A)
df1['BB'] = pd.to_datetime(df1.B ,format='%Y%m%d')
df1['CC'] = pd.to_timedelta(df1.C, unit='ns')
print("""after conversion
df1['AA'] = pd.to_numeric(df1.A)
df1['BB'] = pd.to_datetime(df1.B ,format='%Y%m%d')
df1['CC'] = pd.to_timedelta(df1.C, unit='ns')
""", df1.head(), sep="\n")


print("""
#drop a column 
df1.drop('C', inplace=True, axis=1) #axis=0, for row, axis=1 for column 
df1.drop(0,  axis=0)  #0th row 
""")
#drop a column 
"1>>>",df1.drop('C', inplace=True, axis=1) #axis=0, for row, axis=1 for column , default is row 
"2>>>",df1.drop(0,  axis=0)  #0th row 

print("""
#rename 
df1.rename(columns={'CC': 'C'}, inplace=True)
#rename index 
df1.index 
df1.index  = [10,20]
#or
df1.index = [0,1]
df1r = df1.rename({0:20, 1:30}, axis='index')
""")
#rename 
df1.rename(columns={'CC': 'C'}, inplace=True)
#rename index 
df1.index 
df1.index  = [10,20]
#or
df1.index = [0,1]
df1r = df1.rename({0:20, 1:30}, axis='index')

#creation of new row and column, if existing in earlier, get value from earlier 
#else, put Nan or fill_value 
#>>> df1
#   A         B  AA               C         BB
#0  1  20181231   1 00:00:00.000010 2018-12-31
#1  2  20180304   2 00:00:00.000010 2018-03-04
#creation of two new row, 10,20 and one column 'a'
print("", "DF=", df1, sep="\n")
df1.reindex(index=[10,20,0,1], columns=['A', 'B', 'a'])
df1.reindex(index=[10,20,0,1], columns=['A', 'B', 'a'], fill_value=0)
print("", "df1.reindex(index=[10,20,0,1], columns=['A', 'B', 'a'])=", df1.reindex(index=[10,20,0,1], columns=['A', 'B', 'a']), sep="\n")
print("", "df1.reindex(index=[10,20,0,1], columns=['A', 'B', 'a'], fill_value=0)=", df1.reindex(index=[10,20,0,1], columns=['A', 'B', 'a'], fill_value=0), sep="\n")

#rename all columns names
cols = df1.columns.tolist()
n_cols = {c: c + "1" for c in cols}
df11 = df1.rename(columns=n_cols)

print("""
#rename all columns names
cols = df1.columns.tolist()
n_cols = {c: c + "1" for c in cols}
df11 = df1.rename(columns=n_cols)
""", df11, sep="\n")

#copy and append 
df2 = df1.copy()
df3 = pd.concat([df1,df2], axis=0) #rowwise stack 
df3 = pd.concat([df1,df2], axis=0).reset_index() #reseting index 
df3 = pd.concat([df1,df2], axis=0, ignore_index=True) #reseting index 
#or 
df31 = df2.append(df1)    #index copied 
df31 = df2.append(df1, ignore_index=True) #equivlent to reset_index

df4 = pd.concat([df1,df11], axis=1)  #columnwise stack for same index
df5 = pd.concat([df1,df1r], axis=1) #creates Nan
df5.columns =list( "ABCDEFGHIJ") #change column names(earlier has duplicates)

print("", """
#copy and append 
df2 = df1.copy()
df3 = pd.concat([df1,df2], axis=0) #rowwise stack 
df3 = pd.concat([df1,df2], axis=0).reset_index() #reseting index 
df3 = pd.concat([df1,df2], axis=0, ignore_index=True) #reseting index 
#or 
df31 = df2.append(df1)    #index copied 
df31 = df2.append(df1, ignore_index=True) #equivlent to reset_index

df4 = pd.concat([df1,df11], axis=1)  #columnwise stack for same index
df5 = pd.concat([df1,df1r], axis=1) #creates Nan
df5.columns =list( "ABCDEFGHIJ") #change column names(earlier has dumplicates)
""", "df2=", df2, "df3=", df3, "df31=", df31, "df4=", df4, "df5=", df5, sep="\n")


print("","""
#dropna, fillna , inplace=False 
df5.dropna(axis=0, how='all') #row wise, if row consists of 'all' or 'any' Nan
df5.dropna(axis=0, how='any')
df5.dropna(axis=1, how='any')  #columnwise 

df5.fillna(0)          #nan by 0 
df5.fillna({'A': 0})   #only A
""", 
"1>>>", df5.dropna(axis=0, how='all'), #row wise, if row consists of 'all' or 'any' Nan
"2>>>", df5.dropna(axis=0, how='any'),
"3>>>", df5.dropna(axis=1, how='any'),  #columnwise 
"4>>>", df5.fillna(0),          #nan by 0 
"5>>>", df5.fillna({'A': 0}) ,  #only A
sep="\n")



print("","""
#replace 
df1.replace('1', 20)            #one valye by one value 
df1.replace({'A':'1'}, 20)      #only for A 
df1.replace({'A':{'1':20}})     #Only for A, '1'
df1.replace({'A':'1'}, {'A':20}) #Another way 
df1.replace(['1','2'], 20)      #multiple values 
df1.replace(['1','2'], [20,30])
""", 
"1>>>", df1.replace('1', 20),  #one valye by one value 
"2>>>", df1.replace({'A':'1'}, 20), #only for A 
"3>>>", df1.replace({'A':{'1':20}}),  #Only for A, '1'
"4>>>", df1.replace({'A':'1'}, {'A':20}), #Another way 
"5>>>", df1.replace(['1','2'], 20), #multiple values 
"6>>>",df1.replace(['1','2'], [20,30]),
sep="\n")


print("","""
#map(only for series, convert one value to other)
df1.A.map({'1': 'cat', '2':'dog'}) #missing  = Nan 
#or takes a fun (each element)
df1.A.map(lambda e: 'cat', na_action='ignore') #NaN values would not be passed to fn 
""", 
#map(only for series, convert one value to other)
"1>>>", df1.A.map({'1': 'cat', '2':'dog'}), #missing  = Nan 
#or takes a fun (each element)
"2>>>",df1.A.map(lambda e: 'cat', na_action='ignore'), #NaN values would not be passed to fn 
sep="\n")

print("","""
#apply for Series(fn takes each element) 
df1.A.apply(lambda e: len(e))
#or fn takes an ufunc 
df1.AA.apply(np.log)

#with conversion 
df1.AA.apply(str)
#or
df1.AA.astype('str')
df1.A.astype(np.float64) #conversion 
df1[['A', 'A']].astype(np.float64) #works with DF as well 
""",
#apply for Series(fn takes each element) 
"1>>>",df1.A.apply(lambda e: len(e)),
#or fn takes an ufunc 
"2>>>", df1.AA.apply(np.log),

#with conversion 
"3>>>", df1.AA.apply(str),
#or
"4>>>", df1.AA.astype('str'),
"5>>>", df1.A.astype(np.float64), #conversion 
"6>>>", df1[['A', 'A']].astype(np.float64), #works with DF as well 
sep="\n")

print("","""
#applymap:DF (fn takes each element)
df1[['A','B']].applymap(lambda e: len(e))

#apply: DF(fn = ufunc takes full Series/columns)
df1[['A','B']].apply(lambda col : len(col)) #column wise , ie get each column value
df1[['A','B']].apply(lambda col : len(col), axis=1) #rowwise, ie get each row value 

df1[['AA', 'AA']].apply(np.sum)  #columnwise 
df1[['AA', 'AA']].apply(np.sum, axis=1) #rowwise  
""",
#applymap:DF (fn takes each element)
"1>>>", df1[['A','B']].applymap(lambda e: len(e)),
#apply: DF(fn = ufunc takes full Series/columns)
"2>>>", df1[['A','B']].apply(lambda col : len(col)), #column wise , ie get each column value
"3>>>", df1[['A','B']].apply(lambda col : len(col), axis=1), #rowwise, ie get each row value 
"4>>>", df1[['AA', 'AA']].apply(np.sum),  #columnwise 
"5>>>", df1[['AA', 'AA']].apply(np.sum, axis=1),#rowwise  
sep="\n")


df5 = pd.DataFrame({'A':[0, np.nan, 0, np.nan], 'B':[np.nan, 0, np.nan, 0]})
print("","""
#threeways - replace 
df5 = pd.DataFrame({'A':[0, np.nan, 0, np.nan], 'B':[np.nan, 0, np.nan, 0]})
df5.fillna({'A': 0})
df5.replace({'A':{np.nan:0}})
df5.loc[df5.A.isnull(), 'A'] = 0 #df5.A.isnull() returns True/False for each row 
""",
#threeways - replace 
"1>>>", df5.fillna({'A': 0}),
"2>>>", df5.replace({'A':{np.nan:0}}),
sep="\n")
df5.loc[df5.A.isnull(), 'A'] = 0
print("3>>>", "df5=",df5, sep="\n")


print("","""
##Lets check complex Operations 
##DF - Database-style DataFrame merging
pandas.merge(left, right, how='inner', on=None, left_on=None, right_on=None,      
        left_index=False, right_index=False, sort=True,      
        suffixes=('_x', '_y'), copy=True, indicator=False)
DataFrame.merge(right, how='inner', on=None, left_on=None, right_on=None, 
        left_index=False, right_index=False, sort=False, suffixes=('_x', '_y'), copy=True, indicator=False, validate=None)
    column name - on (same in both), left_on, right_on 
    or with index , left_index, right_index. Note index must have same value of key column
    how : {'left', 'right', 'outer', 'inner'}, default 'inner'
    indicator : bool or str, default False
    If True, adds a column to output DataFrame called '_merge' with 
    information on the source of each row    
DataFrame.join(other, on=None, how='left', lsuffix='', rsuffix='', sort=False)
    Join : this DF's index or column(if 'on' given) with 'other' index 
    Note, other index must be having same value of 'this' index/'on'
    lsuffix, rsuffix are used if both contain same columns 
    Merge is versatile than Join 
    
pd.merge(ydf, zdf)
    Rows that appear in both ydf and zdf
    (Intersection).
pd.merge(ydf, zdf, how='outer')
    Rows that appear in either or both ydf and zdf(Union).
pd.merge(ydf, zdf, how='outer',indicator=True)
.query('_merge == "left_only"')
.drop(columns=['_merge'])
    Rows that appear in ydf but not zdf (Setdiff).
""")

# >>> A              >>> B
#     lkey value        rkey value
# 0   foo  1            foo  5
# 1   bar  2            bar  6
# 2   baz  3            qux  7
# 3   foo  4            bar  8
# #read above and split 
# df = pd.read_clipboard() #lkey  value rkey  value.1
# >>> df
#   lkey  value rkey  value.1
# 0  foo      1  foo        5
# 1  bar      2  bar        6
# 2  baz      3  qux        7
# 3  foo      4  bar        8
# >>> df.dtypes
# lkey       object
# value       int64
# rkey       object
# value.1     int64
# dtype: object

df = pd.DataFrame( 
[['foo',1 , 'foo', 5],['bar',2,'bar',6],['baz',3,'qux',7],['foo',4,'bar',8]],
columns=['lkey',  'value', 'rkey',  'value.1'])

A = df.iloc[:,[0,1]]
B = df.iloc[:, [2,3]]
B.columns= [ B.columns[0], 'value'] #rename 
print("", "A=",A,"B=",B, sep="\n")

# >>> A
#   lkey  value
# 0  foo      1
# 1  bar      2
# 2  baz      3
# 3  foo      4
# >>> B
#   rkey  value
# 0  foo      5
# 1  bar      6
# 2  qux      7
# 3  bar      8
print("","""
#default inner , means both key column/index value must be same 
#note for below index-column joining, one can use 'join' as well 
>>> pd.merge(A, B,  left_on='value',right_index = True) #left column 'value' == right index
""",
pd.merge(A, B,  left_on='value',right_index = True), #left column 'value' == right index
sep="\n")
#    value lkey  value_x rkey  value_y
# 0      1  foo        1  bar        6
# 1      2  bar        2  qux        7
# 2      3  baz        3  bar        8

print("","""
>>> A.merge(B, left_index=True, right_index=True) #index joining 
""",
A.merge(B, left_index=True, right_index=True), #index joining 
sep="\n")
#   lkey  value_x rkey  value_y
# 0  foo        1  foo        5
# 1  bar        2  bar        6
# 2  baz        3  qux        7
# 3  foo        4  bar        8
print("","""
>>> A.merge(B, left_index=True, right_index=True, how='outer')#does not matter 
""",
A.merge(B, left_index=True, right_index=True, how='outer'),
sep="\n")
#   lkey  value_x rkey  value_y
# 0  foo        1  foo        5
# 1  bar        2  bar        6
# 2  baz        3  qux        7
# 3  foo        4  bar        8
print("","""
>>> A.merge(B, left_on='lkey', right_on='rkey', how='outer') #column joining 
""",
A.merge(B, left_on='lkey', right_on='rkey', how='outer'), #column joining 
sep="\n")
#   lkey  value_x  rkey  value_y
#0  foo   1        foo   5
#1  foo   4        foo   5
#2  bar   2        bar   6
#3  bar   2        bar   8
#4  baz   3        NaN   NaN
#5  NaN   NaN      qux   7
print("","""
>>> A.merge(B, left_on='lkey', right_on='rkey', how='inner')
""",
A.merge(B, left_on='lkey', right_on='rkey', how='inner'),
sep="\n")
#   lkey  value_x rkey  value_y
# 0  foo        1  foo        5
# 1  foo        4  foo        5
# 2  bar        2  bar        6
# 3  bar        2  bar        8
print("","""
>>> A.merge(B, left_on='lkey', right_on='rkey', how='left')
""",
A.merge(B, left_on='lkey', right_on='rkey', how='left'),
sep="\n")
#   lkey  value_x rkey  value_y
# 0  foo        1  foo      5.0
# 1  bar        2  bar      6.0
# 2  bar        2  bar      8.0
# 3  baz        3  NaN      NaN
# 4  foo        4  foo      5.0
print("","""
>>> A.merge(B, left_on='lkey', right_on='rkey', how='right')
""",
A.merge(B, left_on='lkey', right_on='rkey', how='right'),
sep="\n")
#   lkey  value_x rkey  value_y
# 0  foo      1.0  foo        5
# 1  foo      4.0  foo        5
# 2  bar      2.0  bar        6
# 3  bar      2.0  bar        8
# 4  NaN      NaN  qux        7


print("","""
##Transform 
DataFrame.transform(func, *args, **kwargs)
    func : callable, string, dictionary, or list of string/callables    
        Function would take each column (as Series) one by one 
        so inside function, you can not access other columns of the df 
        args and kwargs would be passed to function 
        Accepted Combinations are:
            *string function name
            *function
            *list of functions
            *dict of column names -> functions (or list of functions)
""")

#Examples
df = pd.DataFrame(np.random.randn(10, 3), columns=['A', 'B', 'C'],
            index=pd.date_range('1/1/2000', periods=10))
            
df1 = df.copy()      
df.iloc[3:7] = np.nan
print("", "for DF=", df, """
>>> df.transform(lambda x: (x - x.mean()) / x.std()) #x is each column 
""", 
df.transform(lambda x: (x - x.mean()) / x.std()), #x is each column
sep="\n")
#                    A         B         C
# 2000-01-01  0.579457  1.236184  0.123424
# 2000-01-02  0.370357 -0.605875 -1.231325
# 2000-01-03  1.455756 -0.277446  0.288967
# 2000-01-04       NaN       NaN       NaN
# 2000-01-05       NaN       NaN       NaN
# 2000-01-06       NaN       NaN       NaN
# 2000-01-07       NaN       NaN       NaN
# 2000-01-08 -0.498658  1.274522  1.642524
# 2000-01-09 -0.540524 -1.012676 -0.828968
# 2000-01-10 -1.366388 -0.614710  0.005378

print("", """
df1.transform(np.log) #each column by np.log 
(-df1).transform('abs')  #string function , must exist on Series/column 
df1.transform({'A': np.log, 'B': 'abs'})
#with arg 
df1.transform(lambda c, b : c-b , b=3)  #lambda function gets Series 
""",
"1>>>", df1.transform(np.log), #each column by np.log 
"2>>>", (-df1).transform('abs'),  #string function , must exist on Series/column 
"3>>>", df1.transform({'A': np.log, 'B': 'abs'}),
#with arg 
"4>>>", df1.transform(lambda c, b : c-b , b=3),  #lambda function gets Series
sep="\n")

df22 = df1.transform([np.log, 'abs']) #column is now multiindex, A,(log,abs)
print("", """
df22 = df1.transform([np.log, 'abs']) #column is now multiindex, A,(log,abs)
>>> df22.loc[:, ('A', 'log')]
""", 
df22.loc[:, ('A', 'log')], 
sep="\n")

