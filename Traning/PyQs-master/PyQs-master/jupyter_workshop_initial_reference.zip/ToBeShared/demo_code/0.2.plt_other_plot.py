import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

print("""
use with prefix plt. or ax.
https://matplotlib.org/3.1.0/api/pyplot_summary.html

acorr(x)                    
    Plot the autocorrelation of  x.
xcorr(x,y)                  
    Plot the cross correlation between x and y.


bar(left, height)           
    Make a bar plot with x=left array and y=height array
barbs(...)                  
    Plot a 2-D field of barbs.
barh(bottom, width)         
    Make a horizontal bar plot with bottom and width array
boxplot(x)                  
    Make a box plot

cohere(x,y)                 
    Plot the coherence between x and  y
contour(x,y,z,N)            
    Plot contours, with egde
contourf(x,y,z,N)           
    Plot contours without edges

stem(x, y, linefmt, markerfmt, basefmt=)        
    plots vertical lines (using linefmt) at each x location from the baseline to y, 
    and places a marker there using markerfmt. 
    A horizontal line at 0 is is plotted using basefmt
errorbar(x, y, yerr, xerr, fmt)                 
    Plot an errorbar grap h.
eventplot(positions, orientation='horizontal')  
    Plot identical parallel lines at specific positio ns

fill(x,y,fmt)               
    Plot filled polygons
fill_between(x, y1, y2=0, where=None, fmt)
    Fill the area between two horizontal curves.
    The curves are defined by the points (x, y1) and (x, y2). 
    where x,y1,y2 is array of N and 'where' is N bools
    defining  where to exclude some horizontal regions from being filled    
    
hexbin(x,y,C)               
    Make a hexagonal binning plot,  C specifies values at the coordinate (x[i],y[i] ).
hist(x, bins=10)            
    Plot a histogra m.
hist2d(x, y, bins=10)       
    Make a 2D histogram plot.
    
fill(sequence of x, y, [color], data=None, **kwargs)
    Plot filled polygons.
    
hlines(y, xmin, xmax)       
    Plot horizontal lines at each y from xmin to xmax.
vlines(x, ymin,ymax)        
    Plot vertical lines at each x from ymin to ymax
    
axvline(x=0, ymin=0, ymax=1, **kwargs)
    Add a vertical line across the axes.
axhline( y=0, xmin=0, xmax=1, **kwargs)
    Add a horizontal line across the axis.
    
axhspan( ymin, ymax, xmin=0, xmax=1, **kwargs)
    Add a horizontal span (rectangle) across the axis.
axvspan( xmin, xmax, ymin=0, ymax=1, **kwargs)
    Add a vertical span (rectangle) across the axes.
    
loglog(x,y)                 
    Make a plot with log scaling on both the x and y axi s.
semilogx(x,y)               
    Make a plot with log scaling on x
semilogy(x,y)               
    Make a plot with log scaling on  y

pcolor(x2d,y2d,Color1D)     
    Create a pseudocolor plot of a 2-D arra y.
pcolormesh(x2d,y2d,Color1D) 
    Plot a quadrilateral mesh of 2D array

magnitude_spectrum(x,Fs=2, Fc=0)  
    Plot the magnitude spectrum. Fs= sampling frequency, Fc=center frequency
angle_spectrum(x,Fs=2, Fc=0)      
    Plot the angle spectrum.
phase_spectrum(x,Fs=2, Fc=0)      
    Plot the phase spectrum.
psd(x,Fs=2, Fc=0)                 
    Plot the power spectral densit y.
specgram(x, NFFT=256, Fs=2, Fc=0) 
    Plot a spectrogr m.
csd(x,y)                          
    Plot the cross-spectral density.

pie(x)                          
    Plot a pie char t.
plot(x,y,fmt)                   
    Plot lines and/or markers to the Axe s.
plot_date(x,y,fmt)              
    Plot with data with dates in either x,y or bo th
spy(Z)                          
    Plot the sparsity pattern on a 2-D array,Z.
polar(theta, r)                 
    Make a polar plo t.
quiver(x,y,C)                   
    Plot a 2-D field of arrow s.

step(x,y)                       
    Make a step plo t.
streamplot(x,y,u,v)             
    Draws streamlines of a vector flow. x,y=1d array u, 
    v : 2d arrays = x and y-velocities. Number of rows should match 
    length of y, and the number of columns should match x.
stackplot(x,y)                  
    Draws a stacked area plot. x : 1d array of dimension N 
    y : 2d array of dimension MxN
scatter(x,y)                    
    Make a scatter plot of x vs y, where x and y are sequence like 
    objects of the same lengt hs


violinplot(dataset)             
    Make a violin plot for each column of data

""")

names = ['group_a', 'group_b', 'group_c']
values = [1, 10, 100]

plt.figure(figsize=(9, 3))

plt.subplot(131)
plt.bar(names, values)
plt.subplot(132)
plt.scatter(names, values)
plt.subplot(133)
plt.plot(names, values)
plt.suptitle('Categorical Plotting')
plt.show()