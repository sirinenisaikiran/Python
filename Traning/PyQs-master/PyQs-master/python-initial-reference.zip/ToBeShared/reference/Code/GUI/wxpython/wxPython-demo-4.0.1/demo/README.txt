To run the main demo in this directory, execute demo.py.  In other
words, one of the following commands should do it:

       demo.py
       python demo.py
       pythonw demo.py

