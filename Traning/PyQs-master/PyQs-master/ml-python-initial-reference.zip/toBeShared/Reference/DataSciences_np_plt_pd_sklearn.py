###Learn Jupeter notebook 
#https://www.dataquest.io/blog/jupyter-notebook-tutorial/

Code cell 
    contains code to be executed in the kernel and displays its output below.
Markdown cell 
    contains text formatted using Markdown and displays its output in-place 
    when it is run. 
Markdown
    Markdown  syntax has a one-to-one correspondance with HTML tags
    # This is a level 1 heading
    ## This is a level 2 heading
    This is some plain text that forms a paragraph.
    Add emphasis via **bold** and __bold__, or *italic* and _italic_.

    Paragraphs must be separated by an empty line.

    * Sometimes we want to include lists.
     * Which can be indented.

    1. Lists can also be numbered.
    2. For ordered lists.

    [It is possible to include hyperlinks](https://www.example.com)

    Inline code uses single backticks: `foo()`, and code blocks use triple backticks:

    ```
    bar()
    ```

    Or can be intented by 4 spaces:

        foo()

    And finally, adding images is easy: ![Alt text](https://www.example.com/image.jpg)

    
##Command 
Toggle between edit and command mode with Esc and Enter, respectively.
Once in command mode:
    Scroll up and down your cells with your Up and Down keys.
    Press A or B to insert a new cell above or below the active cell.
    M will transform the active cell to a Markdown cell.
    Y will set the active cell to a code cell.
    D + D (D twice) will delete the active cell.
    Z will undo cell deletion.
    Hold Shift and press Up or Down to select multiple cells at once.
        With multple cells selected, Shift + M will merge your selection.
Ctrl + Shift + -, in edit mode, will split the active cell at the cursor.
You can also click and Shift + Click in the margin to the left of your cells to select them.

##Magic 
#https://ipython.readthedocs.io/en/stable/interactive/magics.html
%lsmagic
    Help on magic commands 
%alias?
%alias??
    Open a window about the 'alias' command (minimum, maximum help).
%matplotlib inline
    instruct Jupyter to capture Matplotlib plots and render them in the cell output

'''
    Quick Python refreshers 
    Python oop/class concepts 
    Advanced data structure using Json and csv 
'''   
    
###*** Example file: example.json  
[
 { "empId: 1, "details": 
                        {                       
                          "firstName": "John",
                          "lastName": "Smith",
                          "isAlive": true,
                          "age": 25,
                          "salary": 123.5,
                          "address": {
                            "streetAddress": "21 2nd Street",
                            "city": "New York",
                            "state": "NY",
                            "postalCode": "10021-3100"
                          },
                          "phoneNumbers": [
                            {
                              "type": "home",
                              "number": "212 555-1234"
                            },
                            {
                              "type": "office",
                              "number": "646 555-4567"
                            },
                            {
                              "type": "mobile",
                              "number": "123 456-7890"
                            }
                          ],
                          "children": [],
                          "spouse": null
                        }
  } , { "empId: 20, "details": 
                            {                       
                              "firstName": "Johns",
                              "lastName": "Smith",
                              "isAlive": true,
                              "age": 25,
                              "salary": 123.5,
                              "address": {
                                "streetAddress": "21 2nd Street",
                                "city": "New York",
                                "state": "NY",
                                "postalCode": "10021-3100"
                              },
                              "phoneNumbers": [
                                {
                                  "type": "home",
                                  "number": "212 555-1234"
                                },
                                {
                                  "type": "office",
                                  "number": "646 555-4567"
                                },
                                {
                                  "type": "mobile",
                                  "number": "123 456-7890"
                                }
                              ],
                              "children": [],
                              "spouse": null
                            }
    }
]

#Example reading file 
import json 
import pprint 
fp = open("data/example.json", "r")
obj = json.load(fp)
fp.close()
pprint.pprint(obj)  #check size 
[{'details': {'address': {'city': 'New York',
                          'postalCode': '10021-3100',
                          'state': 'NY',
                          'streetAddress': '21 2nd Street'},
              'age': 25,
              'children': [],
              'firstName': 'John',
              'isAlive': True,
              'lastName': 'Smith',
              'phoneNumbers': [{'number': '212 555-1234', 'type': 'home'},
                               {'number': '646 555-4567', 'type': 'office'},
                               {'number': '123 456-7890', 'type': 'mobile'}],
              'salary': 123.5,
              'spouse': None},
  'empId': 1},
 {'details': {'address': {'city': 'New York',
                          'postalCode': '10021-3100',
                          'state': 'NY',
                          'streetAddress': '21 2nd Street'},
              'age': 25,
              'children': [],
              'firstName': 'Johns',
              'isAlive': True,
              'lastName': 'Smith',
              'phoneNumbers': [{'number': '212 555-1234', 'type': 'home'},
                               {'number': '646 555-4567', 'type': 'office'},
                               {'number': '123 456-7890', 'type': 'mobile'}],
              'salary': 123.5,
              'spouse': None},
  'empId': 20}]

#manipulations 
len(obj)        #2
type(obj)       #<class 'list'>
type(obj[0])    #<class 'dict'>
with open("data/example1.json", "w") as fp1:
    json.dump(obj, fp1, indent='\t')
  
#Obj is array , all array manipulations can be used 
[emp['details']['address']['state']   for emp in obj if emp['empId'] > 10] 






###*** Example: country_data.xml file 
  
<?xml version="1.0"?>
<data>
    <country name="Liechtenstein">
        <rank>1</rank>
        <year>2008</year>
        <gdppc>141100</gdppc>
        <neighbor name="Austria" direction="E"/>
        <neighbor name="Switzerland" direction="W"/>
    </country>
    <country name="Singapore">
        <rank>4</rank>
        <year>2011</year>
        <gdppc>59900</gdppc>
        <neighbor name="Malaysia" direction="N"/>
    </country>
    <country name="Panama">
        <rank>68</rank>
        <year>2011</year>
        <gdppc>13600</gdppc>
        <neighbor name="Costa Rica" direction="W"/>
        <neighbor name="Colombia" direction="E"/>
    </country>
</data>


#code 


import xml.etree.ElementTree as ET
tree = ET.parse('example.xml')
root = tree.getroot()

print(ET.tostring(root))  #give element 

#Or directly from a string:
root = ET.fromstring(country_data_as_string)

#Every element has a tag and a dictionary of attributes

>>> root.tag
'data'
>>> root.attrib
{}


#It also has children nodes over which we can iterate

for child in root:
    print(child.tag, child.attrib)
#Output 
country {'name': 'Liechtenstein'}
country {'name': 'Singapore'}
country {'name': 'Panama'}


#Children are nested, 
#access specific child nodes by index:

>>> root[0][1].text

#Finding interesting elements

#use Element.iter()
#any tag can be given, then it would return list of those 
for neighbor in root.iter('neighbor'):
		print(neighbor.attrib)

#Use Element.findall() finds only elements with a tag which are direct children of the current element. 
#Element.find() finds the first child with a particular tag, 
#Element.text accesses the element�s text content. 
#Element.get() accesses the element�s attributes


for country in root.findall('country'):
		rank = country.find('rank').text
		name = country.get('name')
		print(name, rank)

##XPath support - limited support via findall() and find()
#findall always return list of ELement 
#find always return single Element 

import xml.etree.ElementTree as ET

# Top-level elements
root.findall(".")

# All 'neighbor' grand-children of 'country' children of the top-level
# elements
root.findall("./country/neighbor")

# Nodes with name='Singapore' that have a 'year' child
root.findall(".//year/..[@name='Singapore']")
ET.tostring(x[0])

# 'year' nodes that are children of nodes with name='Singapore'
root.findall(".//*[@name='Singapore']/year")

# All 'neighbor' nodes that are the second child of their parent
root.findall(".//neighbor[2]")

#Modifying an XML File
#to update attribute,  use Element.set()
#to update text, just assign to text 

for rank in root.iter('rank'):
		new_rank = int(rank.text) + 1
		rank.text = str(new_rank)
		rank.set('updated', 'yes')

tree.write('output.xml')


#remove elements using Element.remove(). 

>>> for country in root.findall('country'):
		rank = int(country.find('rank').text)
		if rank > 50:
			root.remove(country)

>>> tree.write('output.xml')


















###*** Requests 

#Get - use 'params'
import requests 
payload1 = {'key1': 'value1', 'key2': 'value2'}
r = requests.get("http://httpbin.org/get", params=payload1)
print(r.url)  #http://httpbin.org/get?key2=value2&key1=value1
r.headers
r.text
r.json()  # it's a python dict

#For Request debugging,
>>> r.request.url
'http://httpbin.org/forms/post?delivery=12&topping=onion&custtel=123&comments=ok&custname=das&custemail=ok%40com&size=small'
>>> r.request.headers
{'Content-Length': '0', 'User-Agent': 'Mozilla/5.0', 'Connection': 'keep-alive', 'Accept': '*/*', 'Accept-Encoding': 'gzip, deflate'}
>>> r.request.body


##POST, use 'data'
headers = {'User-Agent': 'Mozilla/5.0'}
payload = {'custname':'das', 'custtel': '123', 'custemail' : 'ok@com', 'size':'small',  'topping':'bacon',  'topping': 'onion',  'delivery':'12', 'comments': 'ok'}
r = requests.post("http://httpbin.org/post", data=payload, headers=headers)
r.text
r.headers
r.json()

r.request.headers
r.request.body #custname=das&custtel=123&custemail=ok@com&size=small&topping=bacon&topping=onion&delivery=12&comments=ok

##Content
r.text
r.content  # as bytes
r.json()  # json content

##Download file 
url = 'http://google.com/favicon.ico'
r = requests.get(url, allow_redirects=True)
open('google.ico', 'wb').write(r.content)



##Custom Headers and body 
import json
payload = {'some': 'data'}
headers = {'content-type': 'application/json'}
r = requests.post(url, data=json.dumps(payload), headers=headers)

##POST a Multipart-Encoded File
files = {'file': open('report.xls', 'rb')}
r = requests.post(url, files=files)


##Streaming file 
import requests
import shutil

def download_file(url):
    local_filename = url.split('/')[-1]
    with requests.get(url, stream=True) as r
        with open(local_filename, 'wb') as f:
            shutil.copyfileobj(r.raw, f)
    return local_filename


 
    
    

'''
    Linear algebra using numpy, 
    Plotting using matplotlib 
    Dataframe manipulation using pandas 
    Types of machine learning
    Basic terminology & notations
'''    
    
###*** Numpy  

import numpy as np

a = np.array([1, 2, 3])  # Create a rank 1 array
print(type(a))            # Prints "<type 'numpy.ndarray'>"
print(a.shape)            # Prints "(3,)"
print(a.ndim) 			 # 1
print(a[0], a[1], a[2])   # Prints "1 2 3"
a[0] = 5                 # Change an element of the array
print(a)                  # Prints "[5, 2, 3]"

b = np.array([[1,2,3],[4,5,6]])   # Create a rank 2 array
print(b.shape)                     # Prints "(2, 3)"
print(b[0, 0], b[0, 1], b[1, 0])   # Prints "1 2 4"
b[0,]	#or b[0,:]   			  # array([1, 2, 3])  
b[:,0]                            #array([1, 4])



#Note the difference of below, one is vector and another is 1x3
>>> x = np.array([[1,2,3]])        
>>> x.shape                         #rank 2 as two dimension 
(1, 3)

>>> x = np.array([1,2,3])           # rank 1, generally called vector 
>>> x.shape
(3,)

##Creation of array - these methods take (m,n,...) dimensions 
# similar methods (zeros/ones/full)_like(another_array) which creates based on another_array.shape
import numpy as np

a = np.zeros((2,2))  # Create an array of all zeros 

    
b = np.ones((1,2))   # Create an array of all ones

c = np.full((2,2), 7) # Create a constant array
print(c)               # Prints "[[ 7.  7.]
                      #          [ 7.  7.]]"

d = np.eye(2)        # Create a 2x2 identity matrix

#random 
e = np.random.random((2,2)) # Create an array filled with random values
print(e)                     # Might print("[[ 0.91940167  0.08143941])
                            #               [ 0.68744134  0.87236687]]"
#array range 
>>> np.arange(10).reshape(2,5)
array([[0, 1, 2, 3, 4],
       [5, 6, 7, 8, 9]])
       
>>> np.arange(10)[:8].reshape(2,2,2)
array([[[0, 1],
        [2, 3]],

       [[4, 5],
        [6, 7]]])
        
#numpy.linspace(start, stop, num=50, endpoint=True, retstep=False, dtype=None)
>>> np.linspace(2.0, 3.0, num=5)
array([ 2.  ,  2.25,  2.5 ,  2.75,  3.  ])
#numpy.arange([start, ]stop, [step, ]dtype=None)
>>> np.arange(3.0)
array([ 0.,  1.,  2.])
#numpy.logspace(start, stop, num=50, endpoint=True, base=10.0, dtype=None)
#base ** start is the starting value of the sequence.
>>> np.logspace(2.0, 3.0, num=4)
array([  100.        ,   215.443469  ,   464.15888336,  1000.        ])


#meshgrid- It is used to vectorise functions of two variables, so that you can write
x = np.array([1, 2, 3])
y = np.array([10, 20, 30]) 
XX, YY = np.meshgrid(x, y)  #XX is row stack of x, YY is column stack of y 
XX                          #
=> array([[1, 2, 3],
       [1, 2, 3],
       [1, 2, 3]])
YY
=> array([[10, 10, 10],
       [20, 20, 20],
       [30, 30, 30]])


ZZ = XX + YY    #all the combinations of x and y put into the function
ZZ => array([[11, 12, 13],
             [21, 22, 23],
             [31, 32, 33]])
       
        
        
##Array indexing - Slice Indexing (can be mutated)
#index can be single number, or start:stop:step (stop exclusive)
#or :(means all elements of that dimension) or array of indexes
#or boolean array(where True indexes are selected)
import numpy as np

# Create the following rank 2 array with shape (3, 4)
a = np.array([[1,2, 3, 4], 
              [5,6, 7, 8], 
              [9,10,11,12]])

# index 0 to 1 and columns 1 and 2; 
#b is the following array of shape (2, 2):
# [[2 3]
#  [6 7]]
b = a[:2, 1:3]

# A slice of an array is a view into the same data, so modifying it
# will modify the original array.
print(a[0, 1])   # Prints "2"
b[0, 0] = 77    # b[0, 0] is the same piece of data as a[0, 1]
print(a[0, 1])   # Prints "77"


#Mixing integer indexing with slice indexing.
#yields an array of lower rank than the original array. 

row_r1 = a[1, :]    # Rank 1 view of the second row of a  
row_r2 = a[1:2, :]  # Rank 2 view of the second row of a
print(row_r1, row_r1.shape)  # Prints "[5 6 7 8] (4,)"
print(row_r2, row_r2.shape)  # Prints "[[5 6 7 8]] (1, 4)"

# We can make the same distinction when accessing columns of an array:
col_r1 = a[:, 1]
col_r2 = a[:, 1:2]
print(col_r1, col_r1.shape)  # Prints "[ 2  6 10] (3,)"
print(col_r2, col_r2.shape)  # Prints "[[ 2]
                            #          [ 6]
                            #          [10]] (3, 1)"

##Boolean array indexing - a[bool], bool and a are of same dimension 

import numpy as np

a = np.array([[1,2], [3, 4], [5, 6]])

bool_idx = (a > 2)  
            
print(bool_idx)      # Prints "[[False False]
                    #          [ True  True]
                    #          [ True  True]]"

print(a[bool_idx])  # Prints "[3 4 5 6]", 

# We can do all of the above in a single concise statement:
print(a[a > 2])     # Prints "[3 4 5 6]"

>>> a[ (a > 2) & (a<5)]    #Use &, | and ~ for boolean operation , ==, !=, > >= etc for comparison
array([3, 4])
>>> a[ (a > 2) | (a<5)]
array([1, 2, 3, 4, 5, 6])
>>> a[ ~(a > 2) ]
array([1, 2])

>>> a[ a == 2]
array([2])
>>> a[ a != 2]
array([1, 3, 4, 5, 6])


##Numpy - Array indexing - using ... (means all remaining dimensions)
>>> from numpy import arange
>>> a = arange(16).reshape(2,2,2,2)

#you have a 4-dimensional matrix of order 2x2x2x2. 
#To select all first elements in the 4th dimension, you can use the ellipsis notation
>>> a[..., 0].flatten()
array([ 0,  2,  4,  6,  8, 10, 12, 14])

#which is equivalent to
>>> a[:,:,:,0].flatten()
array([ 0,  2,  4,  6,  8, 10, 12, 14])


##Numpy - numpy.newaxis
#Either ndarray.reshape or numpy.newaxis can be used to add a new dimension to an array. 
#the newaxis is used to increase the dimension of the existing array 
#by one more dimension, when used once. 
�1D array will become 2D array
�2D array will become 3D array
�3D array will become 4D array


#Example
# 1D array
arr = np.arange(4)
>>> arr.shape
(4,)

# make it as row vector by inserting an axis along first dimension
row_vec = arr[np.newaxis, :]
row_vec.shape
#(1, 4)

# make it as column vector by inserting an axis along second dimension
col_vec = arr[:, np.newaxis]
col_vec.shape
#(4, 1)

A = np.ones((3,4,5,6)) #shape 
B = np.ones((4,6))   #shape 
(A + B[:, np.newaxis, :]).shape
#(3, 4, 5, 6)





##Array math and all np.methods - operates elementwise on array 
#check by 
dir(np)

#Basic mathematical functions operate elementwise on arrays, 
#and are available both as operator overloads and as functions in the numpy module

import numpy as np

x = np.array([[1,2],[3,4]], dtype=np.float64)
y = np.array([[5,6],[7,8]], dtype=np.float64)

# Elementwise sum; both produce the array
# [[ 6.0  8.0]
#  [10.0 12.0]]
print(x + y)
print(np.add(x, y))
# Elementwise
print(x - y)    #print np.subtract(x, y)
print(x * y)    #print np.multiply(x, y)
print(x / y)    #print np.divide(x, y)
print(np.sqrt(x))  #other math methods eg np.sin(), np.log() ....

##Use .dot  for inner product of vector or matrix multiplication 
v = np.array([9,10])
w = np.array([11, 12])

# Inner product of vectors; both produce 219
print(v.dot(w))
print(np.dot(v, w))
# Matrix / vector product; both produce the rank 1 array [29 67]
print x.dot(v)
print(np.dot(x, v))
# Matrix / matrix product; both produce the rank 2 array
# [[19 22]
#  [43 50]]
print x.dot(y)
print(np.dot(x, y))


##Sum -  for performing computations on arrays 
# For , np.sum(axis=n),  then dimension n is collapsed and deleted, 
#For example, if b has shape (5,6,7,8), and c = b.sum(axis=2), 
#then axis 2 (dimension with size 7) is collapsed, and the result has shape (5,6,8). 
#c[x,y,z] is equal to the sum of all elements c[x,y,:,z].

import numpy as np

x = np.array([[1,2],[3,4]])

print(np.sum(x))  # Compute sum of all elements; prints "10"
print(np.sum(x, axis=0))  # Compute sum of each column; prints "[4 6]"
print(np.sum(x, axis=1))  # Compute sum of each row; prints "[3 7]"


##Transposing  an array 
import numpy as np

x = np.array([[1,2], [3,4]])
print(x)    # Prints "[[1 2]
           #          [3 4]]"
print(x.T)  # Prints "[[1 3]
           #          [2 4]]"

# Note that taking the transpose of a rank 1 array does nothing:
v = np.array([1,2,3])
print(v)    # Prints "[1 2 3]"
print(v.T)  # Prints "[1 2 3]"


##Conversion
x = np.array([1, 2, 2.5])
>>> x
array([ 1. ,  2. ,  2.5])

>>> x.astype(int)
array([1, 2, 2])
>>> x.astype(str)
array(['1.0', '2.0', '2.5'],
      dtype='|S32')

##r_ , c_ , stack etc 
#In general use concatenate for row(vertical) stacking or column(horizontal) stacking
#Many other functions do the same activity, 
#Use .r_[] or .c_[] if you want to use integer slice 

#rowwise append    
>>> np.concatenate( [[1,2],[3,4]])   #[array1,array2,..] , only 1 positional arg 
array([1, 2, 3, 4])

#vertically stacking array - note each is 2D 
>>> np.concatenate(( [[1,2],[3,4]] , [[5,6]]  ), axis=0)
array([[1, 2],
       [3, 4],
       [5, 6]])
#2nd array appended columnwise - note each is 2D 
>>> np.concatenate(( [[1,2],[3,4]] , [[5],[6]]  ), axis=1)
array([[1, 2, 5],
       [3, 4, 6]])

##Otherways 
np.r_  
    By default: create a array(1D) from comma seperated many slices start:stop:step (stop exclusive)
    or comman seperated numbers (along the first axis ie row)
    it has many other functonalities - check Reference 

np.c_ 
    create a array(2D) from comma seperated many 1D arrays or start:stop:step (stop exclusive)
    but  along the second axis(ie column) -> Column stack 


#note used with []   not ()

>>> np.c_[np.array([1,2,3]), np.array([4,5,6])]
array([[1, 4],
       [2, 5],
       [3, 6]])
>>> np.c_[np.array([[1,2,3]]), 0, 0, np.array([[4,5,6]])]
array([[1, 2, 3, 0, 0, 4, 5, 6]])


>>> x = np.r_[-2:3, 0,0, 3:9]
>>> x
array([-2, -1,  0,  1,  2,  0,  0,  3,  4,  5,  6,  7,  8]

#columnwise append 
>>> np.column_stack( [[1,2], [1,2]] ) #[array1,array2,..] , only 1 positional arg 
array([[1, 1],
       [2, 2]])
       
#rowwise append       
>>> np.hstack( [[1,2],[1,2]] ) #[array1,array2,..] , only 1 positional arg 
array([1, 2, 1, 2])

#vertically stacking array*
>>> np.vstack( [[1,2],[1,2]] ) #[array1,array2,..] , only 1 positional arg 
array([[1, 2],
       [1, 2]])
#vertically stacking array*
>>> np.stack( [[1,2],[10,11]] )
array([[ 1,  2],
       [10, 11]])
       
#columnwise append 
>>> np.stack( [[1,2],[10,11]] , axis=1)
array([[ 1, 10],
       [ 2, 11]])    
       




##Record Array(numpy.recarray) vs Structured array(numpy.ndarray with complex dtype)
#Arrays may have a data-types containing fields
#An example is [(x, int), (y, float)], where each entry in the array is a pair of (int, float). 
#Normally, access is eg  arr['x'] and arr['y']. 
#Record arrays allows access using arr.x and arr.y

#Structured Array 
x = np.array([(1.0, 2), (3.0, 4)], dtype=[('x', float), ('y', int)])
>>> x
array([(1.0, 2), (3.0, 4)],
      dtype=[('x', '<f8'), ('y', '<i4')])

>>> x['x']  #all 'x'
array([ 1.,  3.])

#Convert to  record array:
>>> x = x.view(np.recarray)
>>> x.x  #all 'x'
array([ 1.,  3.])

>>> x.y
array([2, 4])

##Datetimes and Timedeltas - subclass of numpy.ndarray 
#Starting in NumPy 1.7, there are core array data types which natively support datetime functionality. 
#The data type is called 'datetime64'

#A simple ISO date: YYY-MM-DD
>>> np.datetime64('2005-02-25')
numpy.datetime64('2005-02-25')


#Using months for the unit:
>>> np.datetime64('2005-02')
numpy.datetime64('2005-02')


#Specifying just the month, but forcing a 'days unit:
>>> np.datetime64('2005-02', 'D')
numpy.datetime64('2005-02-01')


#From a date and time:
>>> np.datetime64('2005-02-25T03:30')
numpy.datetime64('2005-02-25T03:30')


>>> np.array(['2007-07-13', '2006-01-13', '2010-08-13'], dtype='datetime64')
array(['2007-07-13', '2006-01-13', '2010-08-13'], dtype='datetime64[D]')

>>> np.array(['2001-01-01T12:00', '2002-02-03T13:56:03.172'], dtype='datetime64')
array(['2001-01-01T12:00:00.000-0600', '2002-02-03T13:56:03.172-0600'], dtype='datetime64[ms]')


#Using arange - All the dates for one month:
>>> np.arange('2005-02', '2005-03', dtype='datetime64[D]')


##numpy Matrix 
x = np.array([[1, 2], [3, 4]])
m = np.asmatrix(x)
x[0,0] = 5
>>> m
matrix([[5, 2],
        [3, 4]])
#matrix multiplication 
print(m * m) 

#3. Matrices have special attributes which make calculations easier. 
matrix.T 
    Returns the transpose of the matrix. 
matrix.H 
    Returns the (complex) conjugate transpose of self. 
matrix.I 
    Returns the (multiplicative) inverse of invertible self. 
matrix.A 
    Return self as an ndarray object. 


    
    
    
    
    
    
    
    
    
    
    
    
    
###*** Pandas  
#DF is composed of list of Series with one column is designated by Index 
#Dataframe can be created from 
#Along with the below data, pass 'index' (row labels) and 'columns' (column labels) arguments
#By default row, column labels are integer, 0 to n ,For time series, index is datetime based 
    1.Dict , where key is column name and value is column data  of 1D ndarrays, lists, Series
     OR list of dicts, where each element of list is one row, and dict's key is column name, value is cell value 
    2.2D numpy.ndarray
    3.Structured or record ndarray
    4.A Series
    5.Another DataFrame
    5.Any pandas IO read_* methods 
#For conversion use, pd.to_numeric(arg), pd.to_datetime(arg, ,format='%Y %m %d'), pd.to_timedelta(arg, unit='ns')
#where arg could be single or list or Series of values 
#For generating daterange, use pd.date_range(start, end, periods, freq)

#Freq 
#check http://pandas.pydata.org/pandas-docs/stable/timeseries.html#offset-aliases for offset aliases, 
#note for multiple, you can give '5H' ie every 5th hour 
#check https://github.com/pandas-dev/pandas/blob/master/doc/source/timeseries.rst#id11        
#eg '2Q'  denotes two quarterly, '30min' means 30 min

#Weekly can take day to denote which day of week eg 'W-MON' means Monday of week
#Q can take Month eg 'Q-Feb' means every 2nd month of Q

#B,D,H,Min,S,MS,U,N can be combined eg '30min20s' means 30 min 20 second
#eg '2H20min30s' , '2D12H20Min30s'

#Example 
import numpy as np
import pandas as pd

df1 = pd.DataFrame(np.random.randn(6,4),index=list('abcdef'),columns=list('ABCD'))

#datetime based freq= 'M', 'D'(default), 'Y','YS','Q','W','H','T'(min),'S'(sec),'ms','us', or n muliples eg "nH" or combination "xD yH zT"
#start is generally "yyymmdd" or "yyyDELIMmmDELIMdd" where DELIM is some deliminator 
dft = pd.DataFrame(np.random.randn(100000,1),columns=['A'],index=pd.date_range('20130101',periods=100000,freq='T')) 

ts = pd.Series(np.random.randn(100000), index=pd.date_range('20130101',periods=100000,freq='T'))
>>> dft.head()
                            A
2013-01-01 00:00:00  2.375359
2013-01-01 00:01:00  0.663875
2013-01-01 00:02:00 -0.534566
2013-01-01 00:03:00  0.172524
2013-01-01 00:04:00  0.502204

    
##DataFrame Accessing 
df[column]
    column can be 
        Single column label eg 'City'
        Array of column lables eg ['City', 'City']
        A boolean eg df[df.City == 'Chicago']
        A callable, fn(df):returns_any_from_above eg. df[lambda d: d.City == 'Chicago']
    Can be used for update dfi['C'] = dfi['A']
df.column_name
    when column_name is string
    Only for accessing or update 
    Not for creation of new column, use df['column_name'] style 
    For index column, access always like df.index 
df[row_slice]
    row_slice can be 
        start:stop:step, stop exclusive 
        where start,stop are row index 
    there is no way to get row based on index label
    But for DatetimeIndex, it's possible to access based on datetime index 
df.loc[row,column] 
    label based(both row and column)
    row,column takes 
        A single label, e.g. 5 or 'a', 
        A list or array of labels ['a', 'b', 'c']
        A slice object with labels 'a':'f' (end inclusive)
        A boolean array eg df.A > 0 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
        For DatetimeIndex, row can be as given in above example 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']
df.loc[row]
    equivalent to df.loc[row,:]
df.iloc[row,column] 
    index based(both row, column)
    row,column takes 
        An integer e.g. 5
        A list or array of integers [4, 3, 0]
        A slice object with ints 1:7:1 , end exclusive 
        A boolean array *** NOT IMPLEMENTED *** 
        :  means all 
        A Callable fn(df):returns_any_from_above eg. lambda d: d.A > 0 
    Can be used for update eg dfi.loc[:,'C'] = dfi.loc[:,'A']    
df.iloc[row]
    equivalent to df.iloc[row,:]
df.ix[row,column] 
    For each of row,column ,at first tries label based like df.loc[] 
    if Fails, then tries index based like df.iloc[]
    If the index or column does not have label,then behaves like df.iloc[] always 
    For DatetimeIndex, row can be as given in above example 
df.ix[row]
    equivalent to df.ix[row,:]
    For DatetimeIndex, row can be as given in above example
df.iat[row_index,column_index]
df.at[row_label, column_label] 
    for accessing a cell 

    
##Example 
#special index based access only for DatetimeIndex 
from datetime import datetime

#For specific exact index for Only DF , use .loc[] 
dft['2013-01-01 00:00:00'] #ERROR 
dft[datetime(2013, 1, 1)] #equivalent to exact  #ERROR 
#use below 
dft.loc['2013-01-01 00:00:00']
dft.loc[datetime(2013, 1, 1)] 
#note for Series, below works 
ts['2013-01-01 00:00:00']
ts[datetime(2013, 1, 1)]
ts.loc[datetime(2013, 1, 1)]

#for both DF and Series- any partial date string or slice of exact index works 
dft['2013-01-01 00:00:00':'2013-01-01 00:04:00']
dft['2013-1-1']             #from 2013-01-01 00:00:00 till upto 2013-01-01 23:59:00
dft['2013']                 #Year based , from 2013-01-01 00:00:00 till upto 2013-03-11 10:39:00
dft['2013-1':'2013-2']      #slice, end inclusive 
dft['2013-1':'2013-2-28']   # stop time that includes all of the times on the last day
dft['2013-1':'2013-2-28 00:00:00'] #exact stop time     
dft[datetime(2013, 1, 1):datetime(2013,2,28)] #exact start and stop time 
dft[datetime(2013, 1, 1, 10, 12, 0):datetime(2013, 2, 28, 10, 12, 0)] #exact start and stop time 

#Note the difference, first one is Series, 2nd one is DF 
>>> dft.loc[datetime(2013, 1, 1)]
A    2.375359
Name: 2013-01-01 00:00:00, dtype: float64
>>> dft.loc[ [datetime(2013, 1, 1)] ]
                   A
2013-01-01  2.375359

#Note 
ts[0] #first item , scalar 
#but 
dft[0] #error as for DF, [] includes column label 
dft['A'] #OK 
#but for slicing , works as it is row slicing 
ts[0:5]
dft[0:5]

##If a DF's Column or Series or Index is of strings , check string methods 
s = pd.Series(['A', 'B', 'C', 'Aaba', 'Baca', np.nan, 'CABA', 'dog', 'cat'])
dir(s.str)
s.str.lower() #elementwise 

##if a DF's Column or Series or Index is of datetime , check datetime methods 
s1 = pd.Series(pd.date_range('20130101 09:10:12', periods=4))
dir(s1.dt)
s1.dt.hour #elementwise 

##if a DF's Column or Series or Index is of type categorical, check category method 
s = pd.Series(["a","b","c","a"], dtype="category")
dir(s.cat)
s.cat.categories
s.cat.rename_categories([1,2,3])



##Check DF methods 
dir(dft)
dft.describe()

##Note Column is a  Series,  can be plotted 
s1 = pd.Series(pd.date_range('20130101 09:10:12', periods=4))
dir(s1.plot)
s1.plot.line()

##check Column(ie Series) methods 
s = pd.Series(pd.RangeIndex(stop=10))#start,stop,step
dir(s)
#for example conversion 
s.astype(str)
s.sum()
#np.methods() can be applied 
np.log(s)
#or arithmatic 
s * 2 
#or logical 
s == 2 
#Removing one column 
1.del will simply delete the Series from the DataFrame (in-place)
2.pop() will both delete the Series and return the Series as a result (also in-place)
3.drop(labels, axis=1) will return a new data frame with the column(s) removed (the original DataFrame object is not modified)







##DF  - Concat 
pd.concat(objs, axis=0, join='outer', join_axes=None, ignore_index=False,       
        keys=None, levels=None, names=None, verify_integrity=False)
    Concatenate pandas objects along a particular axis 
    with optional set logic along the other axes.
        �objs: a sequence or mapping of Series, DataFrame, or Panel objects.    
        �axis: {0, 1}, default 0(index). 
            =0 means vertical(row) stacking, =1 means horizontal(column) stacking 
        �join: {'inner', 'outer'}, default 'outer'. 
            Outer for union and inner for intersection.
        keys: new columns name 
        ignore_index : boolean, default False
            If True, do not use the index values along the concatenation axis. 
            The resulting axis will be labeled 0, ..., n - 1.
            
            
#Note numpy axis means the same as pandas 
#vertically(row) stacking array - note each is 2D 
>>> np.concatenate(( [[1,2],[3,4]] , [[5,6]]  ), axis=0) #, arg = list of 2D matrix 
array([[1, 2],
       [3, 4],
       [5, 6]])
#2nd array appended columnwise - note each is 2D 
>>> np.concatenate(( [[1,2],[3,4]] , [[5],[6]]  ), axis=1)
array([[1, 2, 5],
       [3, 4, 6]])
#Example 
df1 = pd.DataFrame({'A': ['A0', 'A1', 'A2', 'A3'],  #keys are columns                    
    'B': ['B0', 'B1', 'B2', 'B3'],                    
    'C': ['C0', 'C1', 'C2', 'C3'],                    
    'D': ['D0', 'D1', 'D2', 'D3']},                    
    index=[0, 1, 2, 3])
df2 = pd.DataFrame({'A': ['A4', 'A5', 'A6', 'A7'],                   
    'B': ['B4', 'B5', 'B6', 'B7'],                   
    'C': ['C4', 'C5', 'C6', 'C7'],                    
    'D': ['D4', 'D5', 'D6', 'D7']},                    
    index=[4, 5, 6, 7])
df3 = pd.DataFrame({'A': ['A8', 'A9', 'A10', 'A11'],                    
    'B': ['B8', 'B9', 'B10', 'B11'],                     
    'C': ['C8', 'C9', 'C10', 'C11'],                        
    'D': ['D8', 'D9', 'D10', 'D11']},                    
    index=[8, 9, 10, 11])

#Note same index values in multiple DFs would be duplicated in result DF 
#To ignore index in input DF, use ignore_index=True 
frames = [df1, df2, df3]
result = pd.concat(frames)    #Using concat, default axis=0, vertically(row) append 
>>> result
      A    B    C    D
0    A0   B0   C0   D0
1    A1   B1   C1   D1
2    A2   B2   C2   D2
3    A3   B3   C3   D3
4    A4   B4   C4   D4
5    A5   B5   C5   D5
6    A6   B6   C6   D6
7    A7   B7   C7   D7
8    A8   B8   C8   D8
9    A9   B9   C9   D9
10  A10  B10  C10  D10
11  A11  B11  C11  D11
>>> result = pd.concat(frames, axis=1) #horizontal(column) stacking 
>>> result
      A    B    C    D    A    B    C    D    A    B    C    D
0    A0   B0   C0   D0  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN
1    A1   B1   C1   D1  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN
2    A2   B2   C2   D2  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN
3    A3   B3   C3   D3  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN
4   NaN  NaN  NaN  NaN   A4   B4   C4   D4  NaN  NaN  NaN  NaN
5   NaN  NaN  NaN  NaN   A5   B5   C5   D5  NaN  NaN  NaN  NaN
6   NaN  NaN  NaN  NaN   A6   B6   C6   D6  NaN  NaN  NaN  NaN
7   NaN  NaN  NaN  NaN   A7   B7   C7   D7  NaN  NaN  NaN  NaN
8   NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN   A8   B8   C8   D8
9   NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN   A9   B9   C9   D9
10  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN  A10  B10  C10  D10
11  NaN  NaN  NaN  NaN  NaN  NaN  NaN  NaN  A11  B11  C11  D11

#Note append  is similar to axis=0 
result = df1.append(df2)
>>> result
    A   B   C   D
0  A0  B0  C0  D0
1  A1  B1  C1  D1
2  A2  B2  C2  D2
3  A3  B3  C3  D3
4  A4  B4  C4  D4
5  A5  B5  C5  D5
6  A6  B6  C6  D6
7  A7  B7  C7  D7

#the indexes must be disjoint or use ignore_index=True 
>>> df1.append(df1)
    A   B   C   D
0  A0  B0  C0  D0
1  A1  B1  C1  D1
2  A2  B2  C2  D2
3  A3  B3  C3  D3
0  A0  B0  C0  D0
1  A1  B1  C1  D1
2  A2  B2  C2  D2
3  A3  B3  C3  D3
>>> df1.append(df1).reset_index()
   index   A   B   C   D
0      0  A0  B0  C0  D0
1      1  A1  B1  C1  D1
2      2  A2  B2  C2  D2
3      3  A3  B3  C3  D3
4      0  A0  B0  C0  D0
5      1  A1  B1  C1  D1
6      2  A2  B2  C2  D2
7      3  A3  B3  C3  D3
>>> df1.append(df1, ignore_index=True)
    A   B   C   D
0  A0  B0  C0  D0
1  A1  B1  C1  D1
2  A2  B2  C2  D2
3  A3  B3  C3  D3
4  A0  B0  C0  D0
5  A1  B1  C1  D1
6  A2  B2  C2  D2
7  A3  B3  C3  D3

#To concatenate a mix of Series and DataFrames.
s1 = pd.Series(['X0', 'X1', 'X2', 'X3'], name='X')
result = pd.concat([df1, s1], axis=1) #horzontal stacking 
>>> result
    A   B   C   D   X
0  A0  B0  C0  D0  X0
1  A1  B1  C1  D1  X1
2  A2  B2  C2  D2  X2
3  A3  B3  C3  D3  X3



##DF - Database-style DataFrame merging
DataFrame.join(other, on=None, how='left', lsuffix='', rsuffix='', sort=False)
    Join : this DF's index or column(if 'on' given) with 'other' index 
    'other' index values sud be similar to 'this' DF's index or column
    Efficiently Join multiple DataFrame objects by index at once by passing a list.
    Use merge which is superset of join 
        on : column name, tuple/list of column names, or array-like
            Column(s) in the caller to join on the index in other, 
            otherwise joins index-on-index. 
            If multiples columns given, the passed DataFrame must have a MultiIndex. 
            Can pass an array as the join key if not already contained in the calling DataFrame. Like an Excel VLOOKUP operation
pandas.merge(left, right, how='inner', on=None, left_on=None, right_on=None,      
        left_index=False, right_index=False, sort=True,      
        suffixes=('_x', '_y'), copy=True, indicator=False)
DataFrame.merge(right, how='inner', on=None, left_on=None, right_on=None, 
        left_index=False, right_index=False, sort=False, suffixes=('_x', '_y'), copy=True, indicator=False, validate=None)
    If joining columns on columns, ie 'on' or (left_on,right_on), 
    the DataFrame indexes will be ignored. 
    Otherwise if joining indexes on indexes ie left_index,right_index 
    or indexes on a column(ie on*, *_index combination, 
    Note, one's index values must match with other's column's value) 
    the index will be passed on.    
    left, right : DataFrame
    how : {'left', 'right', 'outer', 'inner'}, default 'inner'
        �left: use only keys from left frame, similar to a SQL left outer join; preserve key order
        �right: use only keys from right frame, similar to a SQL right outer join; preserve key order
        �outer: use union of keys from both frames, similar to a SQL full outer join; sort keys lexicographically
        �inner: use intersection of keys from both frames, similar to a SQL inner join; preserve the order of the left keys
    on: Columns (names) to join on. 
        Must be found in both the left and right DataFrame objects. 
        If not passed and left_index and right_index are False, 
        the intersection of the columns in the DataFrames will be inferred to be the join keys
    �left_on: Columns from the left DataFrame to use as keys. 
        Can either be column names or arrays with length equal to the length of the DataFrame
    �right_on: Columns from the right DataFrame to use as keys. 
        Can either be column names or arrays with length equal to the length of the DataFrame
    �left_index: If True, use the index (row labels) from the left DataFrame as its join key(s). 
        In the case of a DataFrame with a MultiIndex (hierarchical), 
        the number of levels must match the number of join keys from the right DataFrame
    right_index: Same usage as left_index for the right DataFrame
    sort : boolean, default False
        Sort the join keys lexicographically in the result DataFrame. 
    suffixes : 2-length sequence (tuple, list, ...)
        Suffix to apply to overlapping column names in the left and right side, 
    copy : boolean, default True
        If False, do not copy data unnecessarily
    indicator : boolean or string, default False
        If True, adds a column to output DataFrame called '_merge' with information 
        on the source of each row.eg 'left_only', 'right_only','both' 
    validate : string, default None
        If specified, checks if merge is of specified type.
        �'one_to_one' or '1:1': check if merge keys are unique in both left and right datasets.
        �'one_to_many' or '1:m': check if merge keys are unique in left dataset.
        �'many_to_one' or 'm:1': check if merge keys are unique in right dataset.
        �'many_to_many' or 'm:m': allowed, but does not result in checks.

#Type of joins
�one-to-one joins: for example when joining two DataFrame objects 
 on their indexes (which must contain unique values)
�many-to-one joins: for example when joining an index (unique) to one or more                    
 columns in a DataFrame
�many-to-many joins: joining columns on columns.

>>> A              >>> B
    lkey value        rkey value
0   foo  1            foo  5
1   bar  2            bar  6
2   baz  3            qux  7
3   foo  4            bar  8
#read above and split 
df = pd.read_clipboard() #lkey  value rkey  value.1
A = df.iloc[:,[0,1]]
B = df.iloc[:, [2,3]]
B.columns= [ B.columns[0], 'value'] #rename 
>>> A
  lkey  value
0  foo      1
1  bar      2
2  baz      3
3  foo      4
>>> B
  rkey  value
0  foo      5
1  bar      6
2  qux      7
3  bar      8
#note for below index-column joining, one can use 'join' as well 
>>> pd.merge(A, B,  left_on='value',right_index = True) #left column 'value' == right index
   value lkey  value_x rkey  value_y
0      1  foo        1  bar        6
1      2  bar        2  qux        7
2      3  baz        3  bar        8


>>> A.merge(B, left_index=True, right_index=True) #index joining 
  lkey  value_x rkey  value_y
0  foo        1  foo        5
1  bar        2  bar        6
2  baz        3  qux        7
3  foo        4  bar        8
>>> A.merge(B, left_index=True, right_index=True, how='outer')#does not matter 
  lkey  value_x rkey  value_y
0  foo        1  foo        5
1  bar        2  bar        6
2  baz        3  qux        7
3  foo        4  bar        8
>>> A.merge(B, left_on='lkey', right_on='rkey', how='outer') #column joining 
   lkey  value_x  rkey  value_y
0  foo   1        foo   5
1  foo   4        foo   5
2  bar   2        bar   6
3  bar   2        bar   8
4  baz   3        NaN   NaN
5  NaN   NaN      qux   7
>>> A.merge(B, left_on='lkey', right_on='rkey', how='inner')
  lkey  value_x rkey  value_y
0  foo        1  foo        5
1  foo        4  foo        5
2  bar        2  bar        6
3  bar        2  bar        8
>>> A.merge(B, left_on='lkey', right_on='rkey', how='left')
  lkey  value_x rkey  value_y
0  foo        1  foo      5.0
1  bar        2  bar      6.0
2  bar        2  bar      8.0
3  baz        3  NaN      NaN
4  foo        4  foo      5.0
>>> A.merge(B, left_on='lkey', right_on='rkey', how='right')
  lkey  value_x rkey  value_y
0  foo      1.0  foo        5
1  foo      4.0  foo        5
2  bar      2.0  bar        6
3  bar      2.0  bar        8
4  NaN      NaN  qux        7




#Example 
left = pd.DataFrame({'key1': ['K0', 'K0', 'K1', 'K2'],                      
        'key2': ['K0', 'K1', 'K0', 'K1'],                     
        'A': ['A0', 'A1', 'A2', 'A3'],                     
        'B': ['B0', 'B1', 'B2', 'B3']})
right = pd.DataFrame({'key1': ['K0', 'K1', 'K1', 'K2'],                      
        'key2': ['K0', 'K0', 'K0', 'K0'],                        
        'C': ['C0', 'C1', 'C2', 'C3'],                         
        'D': ['D0', 'D1', 'D2', 'D3']}) 
#multiple keys 
result = pd.merge(left, right, on=['key1', 'key2'])
>>> result
    A   B key1 key2   C   D
0  A0  B0   K0   K0  C0  D0
1  A2  B2   K1   K0  C1  D1
2  A2  B2   K1   K0  C2  D2

# With The merge indicator
pd.merge(left, right, on=['key1', 'key2'], indicator=True)



DataFrame.dropna(axis=0, how='any', thresh=None, subset=None, inplace=False)
    Return object with labels on given axis omitted 
    where alternately any or all of the data are missing
    Parameters:
        axis : {0 or 'index', 1 or 'columns'}, or tuple/list thereof
            Pass tuple or list to drop on multiple axes
        how : {'any', 'all'}
            �any : if any NA values are present, drop that label
            �all : if all values are NA, drop that label
        thresh : int, default None
            int value : require that many non-NA values
        subset : array-like
            Labels along other axis to consider, 
            e.g. if you are dropping rows these would be a list of columns to include
        inplace : boolean, default False
            If True, do operation inplace and return None.
#Example 
df = pd.DataFrame([[np.nan, 2, np.nan, 0], [3, 4, np.nan, 1],
                        [np.nan, np.nan, np.nan, 5]],
                    columns=list('ABCD'))
>>> df
     A    B   C  D
0  NaN  2.0 NaN  0
1  3.0  4.0 NaN  1
2  NaN  NaN NaN  5
#Drop the columns where all elements are nan:
>>> df.dropna(axis=1, how='all')
     A    B  D
0  NaN  2.0  0
1  3.0  4.0  1
2  NaN  NaN  5
#Drop the columns where any of the elements is nan
>>> df.dropna(axis=1, how='any')
   D
0  0
1  1
2  5
#Drop the rows where all of the elements are nan 
#(there is no row to drop, so df stays the same):
>>> df.dropna(axis=0, how='all')
     A    B   C  D
0  NaN  2.0 NaN  0
1  3.0  4.0 NaN  1
2  NaN  NaN NaN  5


DataFrame.fillna(value=None, method=None, axis=None, 
            inplace=False, limit=None, downcast=None, **kwargs)
    Fill NA/NaN values using the specified method
    Parameters:
        value : scalar, dict, Series, or DataFrame
            Value to use to fill holes (e.g. 0), 
            alternately a dict/Series/DataFrame of values 
            specifying which value to use for each index (for a Series) 
            or column (for a DataFrame). 
            (values not in the dict/Series/DataFrame will not be filled). 
            This value cannot be a list.
        method : {'backfill', 'bfill', 'pad', 'ffill', None}, default None
            Method to use for filling holes in reindexed Series 
            pad / ffill: propagate last valid observation forward to next valid 
            backfill / bfill: use NEXT valid observation to fill gap
        axis : {0 or 'index', 1 or 'columns'}
        inplace : boolean, default False
            If True, fill in place. 
            
#Example 
df = pd.DataFrame([[np.nan, 2, np.nan, 0],
                        [3, 4, np.nan, 1],
                        [np.nan, np.nan, np.nan, 5],
                        [np.nan, 3, np.nan, 4]],
                        columns=list('ABCD'))
>>> df
     A    B   C  D
0  NaN  2.0 NaN  0
1  3.0  4.0 NaN  1
2  NaN  NaN NaN  5
3  NaN  3.0 NaN  4
#Replace all NaN elements with 0s.
>>> df.fillna(0)
    A   B   C   D
0   0.0 2.0 0.0 0
1   3.0 4.0 0.0 1
2   0.0 0.0 0.0 5
3   0.0 3.0 0.0 4
#We can also propagate non-null values forward or backward.
>>> df.fillna(method='ffill') #forward
    A   B   C   D
0   NaN 2.0 NaN 0
1   3.0 4.0 NaN 1   #  |
2   3.0 4.0 NaN 5   #  v
3   3.0 3.0 NaN 4

#Replace all NaN elements in column 'A', 'B', 'C', and 'D', 
#with 0, 1, 2, and 3 respectively.
>>> values = {'A': 0, 'B': 1, 'C': 2, 'D': 3}
>>> df.fillna(value=values)
    A   B   C   D
0   0.0 2.0 2.0 0
1   3.0 4.0 2.0 1
2   0.0 1.0 2.0 5
3   0.0 3.0 2.0 4

#Only replace the first NaN element.
>>> df.fillna(value=values, limit=1)
    A   B   C   D
0   0.0 2.0 2.0 0
1   3.0 4.0 NaN 1
2   NaN 1.0 NaN 5
3   NaN 3.0 NaN 4
#Note you can use .replace(to_repace, value) as well where to_replace could be np.nan 
df = pd.DataFrame({'A': [0, 1, 2, 3, 4],
                   'B': [5, 6, 7, 8, 9],
                    'C': ['a', 'b', 'c', 'd', 'e']})
>>> df.replace(0, 5) #0 by 5 
   A  B  C
0  5  5  a
1  1  6  b
2  2  7  c
3  3  8  d
4  4  9  e

#replace [0, 1, 2, 3] by 4 
>>> df.replace([0, 1, 2, 3], 4)
   A  B  C
0  4  5  a
1  4  6  b
2  4  7  c
3  4  8  d
4  4  9  e
#Replace 0 by 4 , 1 by 3, 2 by 2 and 3 by 1 
>>> df.replace([0, 1, 2, 3], [4, 3, 2, 1])
   A  B  C
0  4  5  a
1  3  6  b
2  2  7  c
3  1  8  d
4  4  9  e
#replace 0 by 10 and 1 by 100 
>>> df.replace({0: 10, 1: 100})
     A  B  C
0   10  5  a
1  100  6  b
2    2  7  c
3    3  8  d
4    4  9  e
#Replace column A , 0 by 100 and column B 5 by 100 
>>> df.replace({'A': 0, 'B': 5}, 100)
     A    B  C
0  100  100  a
1    1    6  b
2    2    7  c
3    3    8  d
4    4    9  e
#Replace column A , 0 by 100 and column B 5 by 500 
>>> df.replace({'A': 0, 'B': 5}, {'A': 100, 'B': 500})
     A    B  C
0  100  100  a
1    1    6  b
2    2    7  c
3    3    8  d
4    4    9  e
#replace column A, 0 by 100 and 4 by 400 
>>> df.replace({'A': {0: 100, 4: 400}})
     A  B  C
0  100  5  a
1    1  6  b
2    2  7  c
3    3  8  d
4  400  9  e

df = pd.DataFrame({'A': ['bat', 'foo', 'bait'],
            'B': ['abc', 'bar', 'xyz']})
#            
>>> df.replace(to_replace=r'^ba.$', value='new', regex=True)
      A    B
0   new  abc
1   foo  new
2  bait  xyz
#only for column A
>>> df.replace({'A': r'^ba.$'}, {'A': 'new'}, regex=True)
      A    B
0   new  abc
1   foo  bar
2  bait  xyz

>>> df.replace(regex=r'^ba.$', value='new')
      A    B
0   new  abc
1   foo  new
2  bait  xyz
>>> df.replace(regex={r'^ba.$': 'new', 'foo': 'xyz'})
      A    B
0   new  abc
1   xyz  new
2  bait  xyz

>>> df.replace(regex=[r'^ba.$', 'foo'], value='new')
      A    B
0   new  abc
1   new  new
2  bait  xyz

#Or .where(cond, other=nan)
#-1 means , caluclate other dimension based on given other dimensions 
df = pd.DataFrame(np.arange(10).reshape(-1, 2), columns=['A', 'B'])
m = df % 3 == 0
>>> df.where(m, -df)
   A  B
0  0 -1
1 -2  3
2 -4 -5
3  6 -7
4 -8  9





Series.map(arg, na_action=None)
    Map values of Series using input correspondence (a dict, Series, or function).
    arg : function, dict, or Series
#Example 
x = pd.Series([1,2,3], index=['one', 'two', 'three'])
>>> x
one      1
two      2
three    3
dtype: int64

y = pd.Series(['foo', 'bar', 'baz'], index=[1,2,3])
>>> y
1    foo
2    bar
3    baz
>>> x.map(y)
one   foo
two   bar
three baz

#For data frame 
df = pd.DataFrame({'key1': ['K0', 'K0', 'K1', 'K2'],                      
        'key2': ['K0', 'K1', 'K0', 'K1'],                     
        'A': ['A0', 'A1', 'A2', 'A3'],                     
        'B': ['B0', 'B1', 'B2', 'B3']})
>>> df.key1.map(lambda e: e[-1])
0    0
1    0
2    1
3    2
Name: key1, dtype: object
df['key11'] = df.key1.map(lambda e: e[-1])
>>> df
    A   B key1 key2 key11
0  A0  B0   K0   K0     0
1  A1  B1   K0   K1     0
2  A2  B2   K1   K0     1
3  A3  B3   K2   K1     2
    
    
DataFrame.transform(func, *args, **kwargs)
    func : callable, string, dictionary, or list of string/callables    
        Function would take each column (as Series) one by one 
        Accepted Combinations are:
            �string function name
            �function
            �list of functions
            �dict of column names -> functions (or list of functions)

#Examples
df = pd.DataFrame(np.random.randn(10, 3), columns=['A', 'B', 'C'],
            index=pd.date_range('1/1/2000', periods=10))
df.iloc[3:7] = np.nan

>>> df.transform(lambda x: (x - x.mean()) / x.std()) #x is each column 
                   A         B         C
2000-01-01  0.579457  1.236184  0.123424
2000-01-02  0.370357 -0.605875 -1.231325
2000-01-03  1.455756 -0.277446  0.288967
2000-01-04       NaN       NaN       NaN
2000-01-05       NaN       NaN       NaN
2000-01-06       NaN       NaN       NaN
2000-01-07       NaN       NaN       NaN
2000-01-08 -0.498658  1.274522  1.642524
2000-01-09 -0.540524 -1.012676 -0.828968
2000-01-10 -1.366388 -0.614710  0.005378

DataFrame.assign(**kwargs)
    Assign new columns to a DataFrame, returning a new object (a copy) 
    with the new columns added to the original ones. 
    Existing columns that are re-assigned will be overwritten.


df = pd.DataFrame({'A': range(1, 11), 'B': np.random.randn(10)})
>>> df.assign(ln_A = lambda df: np.log(df.A)) #takes df 
    A         B      ln_A
0   1  0.426905  0.000000
1   2 -0.780949  0.693147
2   3 -0.418711  1.098612
3   4 -0.269708  1.386294
4   5 -0.274002  1.609438
5   6 -0.500792  1.791759
6   7  1.649697  1.945910
7   8 -1.495604  2.079442
8   9  0.549296  2.197225
9  10 -0.758542  2.302585



DataFrame.apply(func, axis=0, broadcast=None, raw=False, reduce=None, result_type=None, args=(), **kwds)
    Apply a function along an axis of the DataFrame.
    axis : {0 or �index�, 1 or �columns�}, default 0
        Axis along which the function is applied:
        �0 or �index�: apply function to each column.
        �1 or �columns�: apply function to each row.
 
#Example 
>>> df = pd.DataFrame([[4, 9],] * 3, columns=['A', 'B'])
>>> df
   A  B
0  4  9
1  4  9
2  4  9
>>> df.apply(np.sqrt)
     A    B
0  2.0  3.0
1  2.0  3.0
2  2.0  3.0

>>> df.apply(np.sum, axis=0)
A    12
B    27
dtype: int64

>>> df.apply(np.sum, axis=1)
0    13
1    13
2    13
#Note  for df, apply's function takes full Series/Column 
#but for Series apply's func 
#Can be ufunc (a NumPy function that applies to the entire Series) 
#or a Python function that only works on single values(in case of DF, use applymap)
s = pd.Series([20, 21, 12],index=['London', 'New York', 'Helsinki'])
#each element 
s.apply(lambda x: x ** 2)
#or takes full series 
s.apply(np.sqrt)




DataFrame.applymap(func)
    Apply a function to a Dataframe elementwise.

#Example 
>>> df = pd.DataFrame([[1, 2.12], [3.356, 4.567]])
>>> df
       0      1
0  1.000  2.120
1  3.356  4.567

>>> df.applymap(lambda x: len(str(x)))
   0  1
0  3  4
1  5  5

>>> df.applymap(lambda x: x**2)
           0          1
0   1.000000   4.494400
1  11.262736  20.857489
#But it�s better to avoid applymap in that case.
>>> df ** 2
           0          1
0   1.000000   4.494400
1  11.262736  20.857489




##GroupBy 
   
DataFrame.groupby(by=None, axis=0, level=None, as_index=True, sort=True, group_keys=True, squeeze=False, **kwargs)
    Returns DataFrameGroupBy or SeriesGroupBy
    When aggregation function is applied on returned type,
    final return would be DataFrame or Series respectively 
    Parameters:
    by can be 
        �A Python function, to be called on the axis labels(axis=0, with Index, axis=1, with Columns)
        �A list or NumPy array of the same length as the selected axis
        �A dict or Series, providing a label -> group name mapping
        �For DataFrame objects, a string indicating a column to be used to group. 
         df.groupby('A') is just syntactic sugar for df.groupby(df['A']), 
        �For DataFrame objects, a string indicating an index level to be used to group.
        �A list of any of the above things
        �A Grouper object 
    axis : int, default 0(index, columnwise)
    level : int, level name, or sequence of such, default None
        If the axis is a MultiIndex (hierarchical), group by a particular level or levels
    as_index : boolean, default True
        For aggregated output, return object with group labels as the index. 
        Only relevant for DataFrame input. as_index=False is effectively "SQL-style' grouped output
    sort : boolean, default True
        Sort group keys. Get better performance by turning this off. 
    group_keys : boolean, default True
        When calling apply, add group keys to index to identify pieces
    squeeze : boolean, default False
        reduce the dimensionality of the return type if possible, 
        otherwise return a consistent type
        
# default is axis=0,columnwise
>>> grouped = obj.groupby(key)
>>> grouped = obj.groupby(key, axis=1)
>>> grouped = obj.groupby([key1, key2])

#Example 
#DataFrame results
>>> data.groupby(func, axis=0).mean()
>>> data.groupby(['col1', 'col2'])['col3'].mean() #


#Example 
df = pd.read_excel("./data/sales_transactions.xlsx")
>>> df.groupby('order').mean()
        account  quantity  unit price  ext price
order
10001  383080.0      7.00   30.266667   192.0400
10005  412290.0     31.60   53.264000  1637.0980
10006  218895.0     14.25   65.672500   931.1225
>>> df.groupby('order')["ext price"].mean() #returntype is Series
order
10001     192.0400
10005    1637.0980
10006     931.1225
Name: ext price, dtype: float64
>>> df.groupby('order')[["ext price"]].mean() #return type ise Dataframe 
       ext price
order
10001   192.0400
10005  1637.0980
10006   931.1225
>>> g =df.groupby('order')
>>> g.groups  #[row lables for group]
{10001: Int64Index([0, 1, 2], dtype='int64'), 10005: Int64Index([3,4,5,6,7], dtype='int64'), 10006: Int64Index([8, 9, 10, 11], dtype='int64

>>> g.indices
{10001: array([0, 1, 2], dtype=int64), 10005: array([3, 4, 5, 6]...), 10006: array([ 8,  9, 10, 11], dtype=int64)}

>>> g.ngroup()  #row_index vs group_index 
0     0
1     0
2     0
3     1
4     1
5     1
6     1
7     1
8     2
9     2
10    2
11    2
dtype: int64
>>> g.size() #group size
order
10001    3
10005    5
10006    4
dtype: int64



#Q= "What percentage of the order total does each sku represent?"
#First Approach - Merging(joining like SQL JOIN)
#Series with index =order 
>>> df.groupby('order')["ext price"].sum().rename("Order_Total")
order
10001     576.12
10005    8185.49
10006    3724.49
Name: Order_Total, dtype: float64

>>> df.groupby('order')["ext price"].sum().rename("Order_Total").reset_index()
   order  Order_Total
0  10001       576.12
1  10005      8185.49
2  10006      3724.49

#how to combine this data back with the original dataframe. 
order_total = df.groupby('order')["ext price"].sum().rename("Order_Total").reset_index()
df_1 = df.merge(order_total, on='order')
>>> df_1.head(3)
   account      name  order       sku  quantity  unit price  ext price  \
0   383080  Will LLC  10001  B1-20000         7       33.69     235.83
1   383080  Will LLC  10001  S1-27722        11       21.12     232.32
2   383080  Will LLC  10001  B1-86481         3       35.99     107.97

   Order_Total
0       576.12
1       576.12
2       576.12
df_1["Percent_of_Order"] = df_1["ext price"] / df_1["Order_Total"]


#Second Approach - Using Transform
>>> df.groupby('order')["ext price"]
>>> df.groupby('order')["ext price"].transform('sum')
0      576.12
1      576.12
2      576.12
3     8185.49
4     8185.49
5     8185.49
6     8185.49
7     8185.49
8     3724.49
9     3724.49
10    3724.49
11    3724.49
Name: ext price, dtype: float64

df["Order_Total"] = df.groupby('order')["ext price"].transform('sum')
df["Percent_of_Order"] = df["ext price"] / df["Order_Total"]



DataFrameGroupBy.agg(arg, *args, **kwargs)
    Aggregate using callable, string, dict, or list of string/callables
    Check further description from DataFrame.aggregate
    Parameters:
    func : callable, string, dictionary, or list of string/callables
        Accepted Combinations are:
        �string function name
        �function
        �list of functions
        �dict of column names -> functions (or list of functions)
 
#Examples
df = pd.DataFrame({'A': [1, 1, 2, 2],
                    'B': [1, 2, 3, 4],
                    'C': np.random.randn(4)})
>>> df
   A  B         C
0  1  1  0.362838
1  1  2  0.227877
2  2  3  1.267767
3  2  4 -0.562860

#The aggregation is for each column.
>>> df.groupby('A').agg('min')
   B         C
A
1  1  0.227877
2  3 -0.562860
#Multiple aggregations
>>> df.groupby('A').agg(['min', 'max'])
    B             C
  min max       min       max
A
1   1   2  0.227877  0.362838
2   3   4 -0.562860  1.267767

#Select a column for aggregation
>>> df.groupby('A').B.agg(['min', 'max'])
   min  max
A
1    1    2
2    3    4

#Different aggregations per column
>>> df.groupby('A').agg({'B': ['min', 'max'], 'C': 'sum'})
    B             C
  min max       sum
A
1   1   2  0.590716
2   3   4  0.704907




GroupBy.apply(func, *args, **kwargs)
    Apply function func group-wise and combine the results together.
    The function passed to apply must take a dataframe as its first argument 
    and return a dataframe, a series or a scalar. 
    Parameters:
        func : function
            A callable that takes a dataframe as its first argument, 
            and returns a dataframe, a series or a scalar. 
            In addition the callable may take positional and keyword arguments
            Note dataframe is each group with remaining columns 
        args, kwargs : tuple and dict
            Optional positional and keyword arguments to pass to func
 

#In the current implementation apply calls func twice on the first group to decide 
#whether it can take a fast or slow code path. 
#Examples
df = pd.DataFrame({'A': 'a a b'.split(), 'B': [1,2,3], 'C': [4,6, 5]})
g = df.groupby('A')

#Example 1: below the function passed to apply takes a dataframe as its argument 
#and returns a dataframe. Dataframe is each group with remaining columns 
#apply combines the result for each group together into a new dataframe:
>>> g.apply(lambda x: x / x.sum())
          B    C
0  0.333333  0.4
1  0.666667  0.6
2  1.000000  1.0

#Example 2: The function passed to apply takes a dataframe as its argument 
#and returns a series. 
#apply combines the result for each group together into a new dataframe:
>>> g.apply(lambda x: x.max() - x.min())
   B  C
A
a  1  2
b  0  0

#Example 3: The function passed to apply takes a dataframe as its argument 
#and returns a scalar. 
#apply combines the result for each group together into a series, 
#including setting the index as appropriate:
>>> g.apply(lambda x: x.C.max() - x.B.min())
A
a    5
b    2
dtype: int64


GroupBy.transform(func, *args, **kwargs)
    func : callable, string, dictionary, or list of string/callables    
        Function would take each column (as Series) of each group one by one 
        Accepted Combinations are:
            �string function name
            �function
            �list of functions
            �dict of column names -> functions (or list of functions)
    * apply implicitly passes all the columns for each group as a DataFrame to the custom function,
      while transform passes each column for each group as a Series to the custom function
    * The custom function passed to apply can return a scalar, or a Series or DataFrame (or numpy array or even list). 
      The custom function passed to transform must return a sequence (a one dimensional Series, array or list) 
      the same length as the group.
    
#Example 
df = pd.read_clipboard()
    A      B         C         D
0  foo    one  0.162003  0.087469
1  bar    one -1.156319 -1.526272
2  foo    two  0.833892 -1.666304
3  bar  three -2.026673 -0.322057
4  foo    two  0.411452 -0.954371
5  bar    two  0.765878 -0.095968
6  foo    one -0.654890  0.678091
7  foo  three -1.789842 -1.130922


#OK as X is each group as DF and see bothe C and D 
> df.groupby('A').apply(lambda x: (x['C'] - x['D']))
> df.groupby('A').apply(lambda x: (x['C'] - x['D']).mean())


#But below is not OK , 
> df.groupby('A').transform(lambda x: (x['C'] - x['D']))
ValueError: could not broadcast input array from shape (5) into shape (5,3)

> df.groupby('A').transform(lambda x: (x['C'] - x['D']).mean())
 TypeError: cannot concatenate a non-NDFrame object
 
#Actual usage of Transform ,  
zscore = lambda x: (x - x.mean()) / x.std() # Note that it does not reference anything outside of 'x' and for transform 'x' is one column.
>>> df.groupby('A').transform(zscore) #for each column of each group 

       C      D
0  0.989  0.128
1 -0.478  0.489
2  0.889 -0.589
3 -0.671 -1.150
4  0.034 -0.285
5  1.149  0.662
6 -1.404 -0.907
7 -0.509  1.653
#But 
>>> df.groupby('A').apply(zscore) 
ValueError: operands could not be broadcast together with shapes (6,) (2,)

#Which is exactly the same 
>>> df.groupby('A')['C'].transform(zscore)
#or 
>>> (df.groupby('A')['C'].apply(zscore))
0    0.989
1   -0.478
2    0.889
3   -0.671
4    0.034
5    1.149
6   -1.404
7   -0.509

#Another Usecase:- trying to assign results of reduction function back to original dataframe.
df['sum_C'] = df.groupby('A')['C'].transform(sum)
df.sort('A') # to clearly see the scalar ('sum') applies to the whole column of the group
#Output 
     A      B      C      D  sum_C
1  bar    one  1.998  0.593  3.973
3  bar  three  1.287 -0.639  3.973
5  bar    two  0.687 -1.027  3.973
4  foo    two  0.205  1.274  4.373
2  foo    two  0.128  0.924  4.373
6  foo    one  2.113 -0.516  4.373
7  foo  three  0.657 -1.179  4.373
0  foo    one  1.270  0.201  4.373

#Trying the same with .apply would give NaNs in sum_C. 
#Because .apply would return a reduced Series, which it does not know how to broadcast back:
df.groupby('A')['C'].apply(sum)
#Output 
A
bar    3.973
foo    4.373

#There are also cases when .transform is used to filter the data:
df[df.groupby(['B'])['D'].transform(sum) < -1]

     A      B      C      D
3  bar  three  1.287 -0.639
7  foo  three  0.657 -1.179







GroupBy.pipe(func, *args, **kwargs)
    Apply a function with arguments to this GroupBy object,
    Parameters:
    func : callable or tuple of (callable, string)
        Function to apply to this GroupBy object or, 
        alternatively, a (callable, data_keyword) tuple 
        where data_keyword is a string indicating the keyword of callable that expects the GroupBy object.
        Note function gets full groupedBy dataframe with it's groupby column as index 
    args : iterable, optional
        positional arguments passed into func.
    kwargs : dict, optional
        a dictionary of keyword arguments passed into func.
 
#Use .pipe when chaining together functions that expect Series, DataFrames or GroupBy objects. 
#Instead of writing
>>> f(g(h(df.groupby('group')), arg1=a), arg2=b, arg3=c)
#You can write
>>> (df
        .groupby('group')
        .pipe(f, arg1)
        .pipe(g, arg2)
        .pipe(h, arg3))
        

df = pd.DataFrame({'A': 'a b a b'.split(), 'B': [1, 2, 3, 4]})
>>> df
   A  B
0  a  1
1  b  2
2  a  3
3  b  4


#To get the difference between each groups maximum and minimum value in one pass, you can do
>>> df.groupby('A').pipe(lambda g: g.max() - g.min()) #g is groupedFataframe 
   B
A
a  2
b  2


##Difference between pipe and apply 
#Pipe function takes entire Groupby result DataFrame including groupby columns as index 
#Apply function takes only DF of each group's remaining columns (excluding groupby columns)

df = pd.DataFrame(dict(
    A=list('XXXXYYYYYY'),
    B=range(10)
))

   A  B
0  X  0
1  X  1
2  X  2
3  X  3
4  Y  4
5  Y  5
6  Y  6
7  Y  7
8  Y  8
9  Y  9

#Example 1
#Make the entire 'B' column sum to 1 while each sub-group sums to the same amount. 
#This requires that the calculation be aware of how many groups exist. 
#This is something we can't do with apply because apply wouldn't know how many groups exist.
s = df.groupby('A').B.pipe(lambda g: df.B / g.transform('sum') / g.ngroups)
s

0    0.000000
1    0.083333
2    0.166667
3    0.250000
4    0.051282
5    0.064103
6    0.076923
7    0.089744
8    0.102564
9    0.115385
Name: B, dtype: float64

#Note:
s.sum()

0.99999999999999989

#And:
s.groupby(df.A).sum()

A
X    0.5
Y    0.5
Name: B, dtype: float64


#Example 2 -  Subtract the mean of one group from the values of another. 
#Again, this can't be done with apply because apply doesn't know about other groups.
df.groupby('A').B.pipe(
    lambda g: (
        g.get_group('X') - g.get_group('Y').mean()
    ).append(
        g.get_group('Y') - g.get_group('X').mean()
    )
)

0   -6.5
1   -5.5
2   -4.5
3   -3.5
4    2.5
5    3.5
6    4.5
7    5.5
8    6.5
9    7.5
Name: B, dtype: float64



DataFrameGroupBy.filter(func, dropna=True, *args, **kwargs)
    Return a copy of a DataFrame excluding elements from groups 
    that do not satisfy the boolean criterion specified by func.
    Parameters:
        f : function
            Function to apply to each subframe. Should return True or False.
            f takes full DF 
        dropna : Drop groups that do not pass the filter. True by default;
            if False, groups that evaluate False are filled with NaNs.
    Returns:
    filtered : DataFrame 


#Example 
import pandas as pd
df = pd.DataFrame({'A' : ['foo', 'bar', 'foo', 'bar',
                          'foo', 'bar'],
                   'B' : [1, 2, 3, 4, 5, 6],
                   'C' : [2.0, 5., 8., 1., 2., 9.]})
grouped = df.groupby('A')
>>> grouped.filter(lambda x: x['B'].mean() > 3.)
     A  B    C
1  bar  2  5.0
3  bar  4  1.0
5  bar  6  9.0



##Melt 
data = {'weekday': ["Monday", "Tuesday", "Wednesday", 
         "Thursday", "Friday", "Saturday", "Sunday"],
        'Person 1': [12, 6, 5, 8, 11, 6, 4],
        'Person 2': [10, 6, 11, 5, 8, 9, 12],
        'Person 3': [8, 5, 7, 3, 7, 11, 15]}
df = pd.DataFrame(data, columns=['weekday',
        'Person 1', 'Person 2', 'Person 3'])
#output 
     weekday  Person 1  Person 2  Person 3
0     Monday        12        10         8
1    Tuesday         6         6         5
2  Wednesday         5        11         7

#How can you do group by on person 
#this is not normalized table 
#Melt data  - creating a generic form internally, which you can cast to specific shape
#each row is converted into id_vars versus other columns into 'variable'/var_name and 'value'/value_name
melt = pd.melt(df, id_vars=["weekday"], var_name="Person", value_name="Score")
#output 
     weekday    Person  Score
0     Monday  Person 1     12
1    Tuesday  Person 1      6
2  Wednesday  Person 1      5

#umpivot 
#pivot-unmelt - pivot(index=None, columns=None, values=None)
#'columns' columns name would be new DF's column labels 
#'values'= columnName  to use for populating new frame's cell values 
#'index'=Columnname for new frame's index

pm = melt.pivot(index='weekday', columns='Person', values='Score')
#output 
Person    Person 1  Person 2  Person 3
weekday
Friday          11         8         7
Monday          12        10         8
#reset_index()
pm2 = pm.reset_index()



##excel style pivot table 
#values=ColumnNames for aggfun , index=ColumnsNames for row-groupby , columns=ColumnNames on column-groupby , aggfunc=not string, but functions 
>>> table = pd.pivot_table(melt, values=['Score'], 
    index=['weekday'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size]) #no np method for count , we have np.count_nonzero 

#or to get to get all of those 
pd.pivot_table(melt, values=['Score'], 
    columns=['Person'], 
    aggfunc=[np.sum, np.max, lambda x:x.size])

##Stack and Unstack 
DataFrame.unstack(level=-1, fill_value=None)
DataFrame.stack(level=-1, dropna=True)
    level : int, string, or list of these, default -1 (last level)
        Level(s) of index to unstack, can pass level name
    fill_value : replace NaN with this value if the unstack produces missing values
    dropna : boolean, default True
        Whether to drop rows in the resulting Frame/Series with no valid values

#Meanings 
stack(column->row): Move last level(default) or 'level' of MultiIndex column labels 
       into last level of row labels
unstack(row->column): Move last level(default) or 'level' of MultiIndex row labels 
       into last level of column labels

#The stack function moves out a level in the DataFrame's columns 
#to produce either:
    �A Series, in the case of a simple column Index
    �A DataFrame, in the case of a MultiIndex in the columns

#Example 
tuples = list(zip(*[['bar', 'bar', 'baz', 'baz',
                    'foo', 'foo', 'qux', 'qux'],
                   ['one', 'two', 'one', 'two',
                    'one', 'two', 'one', 'two']]))
index = pd.MultiIndex.from_tuples(tuples, names=['first', 'second'])
df = pd.DataFrame(np.random.randn(8, 2), index=index, columns=['A', 'B'])
df2 = df[:4]
>>> df2
                     A         B
first second                    
bar   one     0.721555 -0.706771
      two    -1.039575  0.271860
baz   one    -0.424972  0.567020
      two     0.276232 -1.087401
      
stacked = df2.stack() #(column->row)
>>> stacked
first  second   
bar    one     A    0.721555
               B   -0.706771
       two     A   -1.039575
               B    0.271860
baz    one     A   -0.424972
               B    0.567020
       two     A    0.276232
               B   -1.087401
dtype: float64

>>> stacked.unstack() #(row->column)
                     A         B
first second                    
bar   one     0.721555 -0.706771
      two    -1.039575  0.271860
baz   one    -0.424972  0.567020
      two     0.276232 -1.087401

>>> stacked.unstack(1) #(row->column), level=1 (0-based) moved to column 
second        one       two
first                      
bar   A  0.721555 -1.039575
      B -0.706771  0.271860
baz   A -0.424972  0.276232
      B  0.567020 -1.087401

>>> stacked.unstack(0) #(row->column), level=0 (0-based)
first          bar       baz
second                      
one    A  0.721555 -0.424972
       B -0.706771  0.567020
two    A -1.039575  0.276232
       B  0.271860 -1.087401

#If the indexes have names
>>> stacked.unstack('second')#(row->column), level=1 (0-based)
second        one       two
first                      
bar   A  0.721555 -1.039575
      B -0.706771  0.271860
baz   A -0.424972  0.276232
      B  0.567020 -1.087401

##Combining stack/unstack with stats and GroupBy
columns = pd.MultiIndex.from_tuples([('A', 'cat'), ('B', 'dog'),
                                     ('B', 'cat'), ('A', 'dog')],
                                    names=['exp', 'animal'])
index = pd.MultiIndex.from_product([('bar', 'baz', 'foo', 'qux'),
                                    ('one', 'two')],
                                   names=['first', 'second'])
df = pd.DataFrame(np.random.randn(8, 4), index=index, columns=columns)
>>> df
exp                  A         B                   A
animal             cat       dog       cat       dog
first second                                        
bar   one     0.895717  0.805244 -1.206412  2.565646
      two     1.431256  1.340309 -1.170299 -0.226169
baz   one     0.410835  0.813850  0.132003 -0.827317
      two    -0.076467 -1.187678  1.130127 -1.436737
foo   one    -1.413681  1.607920  1.024180  0.569605
      two     0.875906 -2.211372  0.974466 -2.006747
qux   one    -0.410001 -0.078638  0.545952 -1.219217
      two    -1.226825  0.769804 -1.281247 -0.727707
      
#(column->row), then mean rowwise (index (0), columns (1)), then (row->column)
#here axis=0 means columnwise , =1 mean rowwise
>>> df.stack().mean(1).unstack() 
animal             cat       dog
first second                    
bar   one    -0.155347  1.685445
      two     0.130479  0.557070
baz   one     0.271419 -0.006733
      two     0.526830 -1.312207
foo   one    -0.194750  1.088763
      two     0.925186 -2.109060
qux   one     0.067976 -0.648927
      two    -1.254036  0.021048

# same result, another way
#axis : int, default 0, axis=0 means columnwise , =1 mean rowwise
#level : int, level name, or sequence of such, default None
#If the axis is a MultiIndex (hierarchical), group by a particular level or levels
>>> df.groupby(level=1, axis=1).mean()
animal             cat       dog
first second                    
bar   one    -0.155347  1.685445
      two     0.130479  0.557070
baz   one     0.271419 -0.006733
      two     0.526830 -1.312207
foo   one    -0.194750  1.088763
      two     0.925186 -2.109060
qux   one     0.067976 -0.648927
      two    -1.254036  0.021048
#(column->row),
>>> df.stack().groupby(level=1).mean()
exp            A         B
second                    
one     0.071448  0.455513
two    -0.424186 -0.204486
#(row->column)
>>> df.mean().unstack(0)
exp            A         B
animal                    
cat     0.060843  0.018596
dog    -0.413580  0.232430



##Compute a simple cross-tabulation of two (or more) factors
pandas.crosstab(index, columns, values=None, rownames=None, colnames=None, 
        aggfunc=None, margins=False, margins_name='All', 
        dropna=True, normalize=False)
    index : array-like, Series, or list of arrays/Series
        Values to group by in the rows
    columns : array-like, Series, or list of arrays/Series
        Values to group by in the columns
    values : array-like, optional
        Array of values to aggregate according to the factors. 
        Requires aggfunc be specified.
    aggfunc : function, optional
        If specified, requires values be specified as well
    rownames : sequence, default None
        If passed, must match number of row arrays passed
    colnames : sequence, default None
        If passed, must match number of column arrays passed
    margins : boolean, default False
        Add row/column margins (subtotals)
    margins_name : string, default 'All'
        Name of the row / column that will contain the totals when margins is True.
    dropna : boolean, default True
        Do not include columns whose entries are all NaN
    normalize : boolean, {'all', 'index', 'columns'}, or {0,1}, default False
        Normalize by dividing all values by the sum of values.
        �If passed 'all' or True, will normalize over all values.
        �If passed 'index' will normalize over each row.
        �If passed 'columns' will normalize over each column.
        �If margins is True, will also normalize margin values.

#Example 
df = pd.DataFrame({'A': [1, 2, 2, 2, 2], 'B': [3, 3, 4, 4, 4],
                   'C': [1, 1, np.nan, 1, 1]})
>>> df
   A  B    C
0  1  3  1.0
1  2  3  1.0
2  2  4  NaN
3  2  4  1.0
4  2  4  1.0
>>> pd.crosstab(df.A, df.B)
B  3  4
A      
1  1  0
2  1  3
>>> pd.crosstab(df.A, df.B, values=df.C, aggfunc=np.sum, normalize=True,margins=True)
B       3    4   All
A                   
1    0.25  0.0  0.25
2    0.25  0.5  0.75
All  0.50  0.5  1.00

foo = pd.Categorical(['a', 'b'], categories=['a', 'b', 'c'])
bar = pd.Categorical(['d', 'e'], categories=['d', 'e', 'f'])
>>> pd.crosstab(foo, bar)
col_0  d  e  f
row_0         
a      1  0  0
b      0  1  0
c      0  0  0
    









###iris example 
iris = pd.read_csv('data/iris.csv')
>>> iris.head()
SepalLength  SepalWidth  PetalLength  PetalWidth         Name
0          5.1         3.5          1.4         0.2  Iris-setosa
1          4.9         3.0          1.4         0.2  Iris-setosa
2          4.7         3.2          1.3         0.2  Iris-setosa
3          4.6         3.1          1.5         0.2  Iris-setosa
4          5.0         3.6          1.4         0.2  Iris-setosa
#Return new DF 
>>> (iris.assign(sepal_ratio = iris['SepalWidth'] / iris['SepalLength']).head())
SepalLength  SepalWidth  PetalLength  PetalWidth         Name  sepal_ratio
0          5.1         3.5          1.4         0.2  Iris-setosa       0.6863
1          4.9         3.0          1.4         0.2  Iris-setosa       0.6122
2          4.7         3.2          1.3         0.2  Iris-setosa       0.6809
3          4.6         3.1          1.5         0.2  Iris-setosa       0.6739
4          5.0         3.6          1.4         0.2  Iris-setosa       0.7200


#Or use function of one argument which is the  DF
>>> iris.assign(sepal_ratio = lambda df: (df['SepalWidth'] /df['SepalLength'])).head()
SepalLength  SepalWidth  PetalLength  PetalWidth         Name  sepal_ratio
0          5.1         3.5          1.4         0.2  Iris-setosa       0.6863
1          4.9         3.0          1.4         0.2  Iris-setosa       0.6122
2          4.7         3.2          1.3         0.2  Iris-setosa       0.6809
3          4.6         3.1          1.5         0.2  Iris-setosa       0.6739
4          5.0         3.6          1.4         0.2  Iris-setosa       0.7200



#Example - limit the DataFrame with a Sepal Length greater than 5, calculate the ratio, and plot:

(iris.query('SepalLength > 5').assign( SepalRatio = lambda df: df.SepalWidth / df.SepalLength,            
                     PetalRatio = lambda df: df.PetalWidth / df.PetalLength)   
                .plot(kind='scatter', x='SepalRatio', y='PetalRatio'))
plt.show()

#Clearly two clusters 
iris_m = iris.assign( SepalRatio = lambda df: df.SepalWidth / df.SepalLength, PetalRatio = lambda df: df.PetalWidth / df.PetalLength) 
iris_m.plot(kind='scatter', x='SepalRatio', y='PetalRatio')

##Quick K-Means - Find those two clusters 
from sklearn.cluster import KMeans
numpy_features = iris_m[ ['SepalRatio','PetalRatio' ]].values
kmeans = KMeans(n_clusters=2, random_state=0).fit(numpy_features)
>>> kmeans.cluster_centers_
array([[0.68569927, 0.16512688],
       [0.46103872, 0.33785156]])
>>> kmeans.labels_  #each point's cluster index 
array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0,
       0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
       
#Assignment       
iris['sepalRatio'] = iris.SepalWidth / iris.SepalLength
iris.columns
       
#Get the names of the columns
>>> iris.columns
Index(['SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth', 'Name','sepalRatio'],
      dtype='object')
      
#Any np.methods() can be used 
un = np.unique(iris.Name)
array(['Iris-setosa', 'Iris-versicolor', 'Iris-virginica'], dtype=object)      

>>> iris.Name.unique()
array(['Iris-setosa', 'Iris-versicolor', 'Iris-virginica'], dtype=object)

#access string column by .str 
dir(iris.Name.str)
iris.Name.str.lower()

>>> np.unique(iris.Name.apply(lambda x: un.tolist().index(x)))
array([0, 1, 2], dtype=int64)
#apply for Series, fn takes each element, 
#for DF, fn takes each col if axis=0 else takes each row if axis=1
iris["target"] = iris.Name.apply(lambda x: un.tolist().index(x))

#Get the first five rows of a column by name
iris['SepalLength'][:5]                     #Series
iris[ [ 'SepalLength', 'SepalWidth'] ][:5]  #DF 


#Create categorical ranges for numerical data. 14 is number of bins
sl_bin = pd.cut(iris['SepalLength'], 14)
sl_bin[:5]

#Look at the frequencies in the ranges created above
pd.value_counts(sl_bin)
sl_bin.value_counts()

#Access through .cat 
iris["category"] = sl_bin
iris.category.cat.categories
#to get index of each bin 
iris.category.cat.rename_categories(range(14))

#first six columns of the first row
#ix like .loc[row,column] , ie label based at first if not then iloc[row,column], index based
iris.ix[0,0:6]

#Order the data by specified column
iris['SepalLength'].sort_values()[:5]

#Sort by a column and that obtain a cross-section of that data , multiple can be given
sorteddata = iris.sort_values(by=['SepalLength', 'PetalLength'])  #DF
sorteddata.ix[:,0:6].head(3)  

#Obtain the first three rows and first three columns of the sorted data
sorteddata.iloc[0:3,0:3]

#Obtain value counts of specific column
iris['PetalLength'].value_counts()

#to obtain the datatype 
iris.dtypes

#Get the unique values for a column by name.
iris['Name'].unique()

#Get a count of the unique values of a column
len(iris['Name'].unique())

#Index into a column and get the first four rows
iris.ix[0:3,'Name']

#Obtain True/False  values which could be used inside iloc, loc etc 
iris.ix[:,'Name'] == 'Iris-setosa'
#Can get any columns , use  | , &, ~ for boolean conjunction, disjunction and inverse 
iris.loc[iris['Name'] == 'Iris-setosa', 'SepalLength']  #Series
iris.ix[iris['Name'] == 'Iris-setosa', 0] #note .iloc with boolean not available 
iris.loc[iris['Name'] == 'Iris-setosa', ['SepalLength','PetalLength']] #DF

#Query the data
qry1 = iris.query('Name == "Iris-setosa"')  #returns DF of original only where cond is valid 
qry1.head(10)

#Check a boolean condition
(iris.ix[:,'SepalLength'] > 4.3).any()


#Return descriptive statistics of the dataset- mean, std etc is calculated for each colu mn
>>> iris.describe()
       SepalLength
count   150.000000
mean      5.843333
std       0.828066
min       4.300000
25%       5.100000
50%       5.800000
75%       6.400000
max       7.900000
>>> iris.Name.describe()
count                 150
unique                  3
top       Iris-versicolor
freq                   50
Name: Name, dtype: object

#Crosstab(frequency) of the data by specified columns (of one column vs another)
pd.crosstab(iris['category'],iris['target']) #DF, multiindex 


#Group data and obtain the mean,
#group by col1 and then col2 and find mean of all other columns
grouped1 = iris.groupby('SepalLength') #single column 
grouped1 = iris.groupby(['SepalLength','PetalLength']) #pandas.core.groupby.DataFrameGroupBy
dir(grouped1)
grouped1.mean()  #DF
grouped1.agg(np.mean) #DF 
grouped1.mean().index #MultiIndex 
grouped1.agg({'SepalWidth':'count', 'PetalWidth':'mean'}) #DF 




##Visualization

#Plot counts of a specified column using Pand as
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns  #install it, pip install seaborn

iris.Name.value_counts().plot(kind='bar')
plt.show()
#with x and y 
iris.plot(x=None, y='SepalWidth', kind='line')
plt.show()
#full DF 
iris.plot( kind='line')
plt.show()
#for sub DF 
iris.iloc[:,0:4].plot(kind='line')
plt.show()
#with groupby 
iris.groupby('Name').plot(kind='line')
plt.show()
#as subplots 
iris.groupby('Name').plot(kind='line', subplots=True)
plt.show()
#for partial DF 
iris.iloc[:,0:5].groupby('Name')['SepalLength'].plot(kind='line', subplots=True)
plt.show()

#but in same plot 
fig, ax = plt.subplots(figsize=(8,6))
for label, df in iris.groupby('Name'):
    df.SepalLength.plot(kind="line", ax=ax, label=label)
plt.legend()
plt.show()

#all 
#https://matplotlib.org/users/colormaps.html
cm =['Blues', 'Greens', 'Reds']
fig, ax = plt.subplots(figsize=(8,6))
x_label = []
for i,(label, df) in enumerate(iris.groupby('Name')):
    x_label.append(label)
    df.plot(kind='line', ax=ax, colormap=cm[i])

plt.xlabel(x_label)
plt.legend()
plt.show()

#note 
iris.plot(kind='line') 
#is equivalent to 
iris.plot.line()
#and similarly for others 

#with subplots 
#multiple in one plot 
iris.plot(kind='line', y=['SepalLength','PetalLength'] )
#with subplots 
iris.plot(kind='line', y=['SepalLength','PetalLength'], subplots=True )

#Bar plot of median values
iris.groupby('Name')['SepalLength'].agg(np.mean).plot(kind = 'bar')
plt.show()

#Scatter_matrix or sns.pairplot
#hue is categorical data and for each hue, scatter_matrix is done
sns.pairplot(iris.iloc[:,0:5], hue='Name', size=2.5)
plt.show()

from pandas.plotting import scatter_matrix
scatter_matrix(iris.iloc[:,0:4], alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show()
#for only one Name 
scatter_matrix(iris.ix[iris.Name=='Iris-virginica',0:4], alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show()
#only density plot 
iris.SepalLength.plot.kde()
plt.show()
#or 
sns.kdeplot(iris.SepalLength)
sns.kdeplot(iris.SepalWidth)
plt.show()
#or
sns.distplot(iris.SepalLength)
plt.show()
#for bivariate kernel density estimate
sns.kdeplot(iris.iloc[:,0:4]) #bivariate kernel density estimate
plt.show()
#joint distribution of x,y and the marginal distributions (joit distribution with one const)
#For this plot, we'll set the style to a white background
#pearsonr = correlation coefficient  , -1 to 1, 0= not correlated, H0:not correlated 
#kind : { �scatter� | �reg� | �resid� | �kde� | �hex� }, optional
with sns.axes_style('white'):
    sns.jointplot(x="SepalLength", y="PetalLength", data=iris.iloc[:,0:4], kind='kde');

plt.show()

#Box plot - x= x axis categorical data, y= box plot variable  , hue=categorical data, for each, x vs y box plot is done 
#box plot - box-25%,median, 75%(third quartiles), min-max data - some convension of min and max - https://en.wikipedia.org/wiki/Box_plot, outliers
#seaborn.factorplot(x=None, y=None, hue=None, data=None, row=None, col=None, col_wrap=None, estimator=<function mean>, ci=95, n_boot=1000, units=None, order=None, hue_order=None, row_order=None, col_order=None, kind='point', size=4, aspect=1, orient=None, color=None, palette=None, legend=True, legend_out=True, sharex=True, sharey=True, margin_titles=False, facet_kws=None, **kwargs)
#kind : {point, bar, count, box, violin, strip}
import seaborn as sns
g = sns.factorplot(x="Name", y="PetalLength", hue="Name" ,data=iris.iloc[:,0:5], kind="box", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))
plt.show()

#Barplot 
g = sns.factorplot(x="Name", data=iris.iloc[:,0:5], aspect=2,  kind="count", color='steelblue')


##Other Plots 
##scatter_matrix 
#https://pandas.pydata.org/pandas-docs/stable/visualization.html

from pandas.plotting import scatter_matrix
df = pd.DataFrame(np.random.randn(1000, 4), columns=['a', 'b', 'c', 'd'])
scatter_matrix(ver, alpha=0.2, figsize=(6, 6), diagonal='kde')
#only density plot 
df.a.plot.kde()

##lagplot -Lag plots are used to check if a data set or time series is random. 
#Random data should not exhibit any structure in the lag plot. 
#Non-random structure implies that the underlying data are not random.
from pandas.plotting import lag_plot
lag_plot(df.a)

##Autocorrelation plots are often used for checking randomness in time series
#If time series is random, such autocorrelations should be near zero for any and all time-lag separations
from pandas.plotting import autocorrelation_plot
autocorrelation_plot(df.a)

#Bootstrap plots are used to visually assess the uncertainty of a statistic, 
#such as mean, median, midrange, etc. 
#A random subset of a specified size is selected from a data set, 
#the statistic in question is computed for this subset 
#and the process is repeated a specified number of times. 
#Resulting plots and histograms are what constitutes the bootstrap plot.
from pandas.plotting import bootstrap_plot
bootstrap_plot(df.a, size=50, samples=500, color='grey')


##Time/Date Plot 
ts = pd.Series(np.random.randn(1000), index=pd.date_range('1/1/2000', periods=1000))
ts = ts.cumsum()
ts.plot()

df = pd.DataFrame(np.random.randn(1000, 4), index=ts.index, columns=list('ABCD'))
df = df.cumsum()
plt.figure(); 
df.plot();

#with subplots 
df.plot(subplots=True, figsize=(6, 6));
#means 2 rows and 3 columns , each one is 6x6 
df.plot(subplots=True, layout=(2, 3), figsize=(6, 6), sharex=False);

#or maximum control 
fig, axes = plt.subplots(4, 4, figsize=(6, 6));
plt.subplots_adjust(wspace=0.5, hspace=0.5);
target1 = [axes[0][0], axes[1][1], axes[2][2], axes[3][3]]
target2 = [axes[3][0], axes[2][1], axes[1][2], axes[0][3]]
df.plot(subplots=True, ax=target1, legend=False, sharex=False, sharey=False);
(-df).plot(subplots=True, ax=target2, legend=False, sharex=False, sharey=False);
#or 
fig, axes = plt.subplots(nrows=2, ncols=2)
df['A'].plot(ax=axes[0,0]); axes[0,0].set_title('A');
df['B'].plot(ax=axes[0,1]); axes[0,1].set_title('B');
df['C'].plot(ax=axes[1,0]); axes[1,0].set_title('C');
df['D'].plot(ax=axes[1,1]); axes[1,1].set_title('D');




###*EXCEl: xlrd is required for pandas.read_excel 
pandas.read_excel(io, sheet_name=0, header=0, skiprows=None, skip_footer=0, index_col=None, names=None, usecols=None, parse_dates=False, date_parser=None, na_values=None, thousands=None, conirist_float=True, coniristers=None, dtype=None, true_values=None, false_values=None, engine=None, squeeze=False, **kwds)
    df = pd.read_excel("file_name", 'Sheet1') #needs xlrd
    #for example setting correct index from one column, if datetime, use to_datetime
    df.index = pd.to_datetime(df.Date)
DataFrame.to_excel(excel_writer, sheet_name='Sheet1', na_rep='', float_format=None, columns=None, header=True, index=True, index_label=None, startrow=0, startcol=0, engine=None, merge_cells=True, encoding=None, inf_rep='inf', irisbose=True, freeze_panes=None)
pandas.to_datetime(arg, errors='raise', dayfirst=False, yearfirst=False, utc=None, box=True, format=None, exact=True, unit=None, infer_datetime_format=False, origin='unix')[source]
    Convert argument to datetime.
    arg : integer, float, string, datetime, list, tuple, 1-d array, Series
    #common format 
    %w  Weekday as a decimal number, where 0 is Sunday and 6 is Saturday. 0, 1, �, 6   
    %d  Day of the month as a zero-padded decimal number. 01, 02, �, 31 
    %b  Month as locale's abbreviated name. Jan, Feb, �, Dec (en_US);
    %B  Month as locale's full name. January, February, �, December (en_US);
    %m  Month as a zero-padded decimal number. 01, 02, �, 12   
    %y  Year without century as a zero-padded decimal number. 00, 01, �, 99   
    %Y  Year with century as a decimal number. 1970, 1988, 2001, 2013   
    %H  Hour (24-hour clock) as a zero-padded decimal number. 00, 01, �, 23   
    %I  Hour (12-hour clock) as a zero-padded decimal number. 01, 02, �, 12   
    %p  Locale's equivalent of either AM or PM. AM, PM (en_US);
    %M  Minute as a zero-padded decimal number. 00, 01, �, 59   
    %S  Second as a zero-padded decimal number. 00, 01, �, 59 
    %f  Microsecond as a decimal number, zero-padded on the left. 000000, 000001, �, 999999 
    %z  UTC offset in the form +HHMM or -HHMM (empty string if the the object is naive). (empty), +0000, -0400, +1030 
    %Z  Time zone name (empty string if the object is naive). (empty), UTC, EST, CST   
    %j  Day of the year as a zero-padded decimal number. 001, 002, �, 366   
    %U  Week number of the year (Sunday as the first day of the week) as a zero padded decimal number. All days in a new year preceding the first Sunday are considered to be in week 0. 00, 01, �, 53 
    %W  Week number of the year (Monday as the first day of the week) as a decimal number. All days in a new year preceding the first Monday are considered to be in week 0. 00, 01, �, 53 

#Example  
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 
import statsmodels.api as sm 

dft = pd.read_excel(r"data\Nifty-17_Years_Data-V1.xlsx", parseDates=True, index_col=0, header=0, date_parser=lambda x: pd.to_datetime(x, format="%d-%b-%y"))
dft.index
>> df.head()

from pandas.tseries.offsets import *
dft.index.freq = Day() #set freq as D 

import datetime
#For specific exact index for DF , use .loc 
dft['2000-06-01'] #ERROR 
dft[datetime.date(2000, 6, 1)] #equivalent to exact  #ERROR #datetime.date(year, month, day)
#use below 
dft.loc['2000-06-01']
dft.iloc[0]
dft.loc[datetime.date(2000, 6, 1)] 
#for both DF and Series- any partial date string or slice of exact index works 
dft['2000-06-01']             #from 2013-01-01 00:00:00 till upto 2013-01-01 23:59:00
dft['2013']                 #Year based , from 2013-01-01 00:00:00 till upto 2013-03-11 10:39:00
dft['2013-1':'2013-2']      #slice, end inclusive 
dft['2013-1':'2013-2-28']   # stop time that includes all of the times on the last day
dft['2013-1':'2013-2-28 00:00:00'] #exact stop time     
dft[datetime.date(2013, 1, 1):datetime.date(2013,2,28)] #exact start and stop time 
dft[datetime.datetime(2013, 1, 1, 10, 12, 0):datetime.datetime(2013, 2, 28, 10, 12, 0)] #exact start and stop time 
#Note the difference, first one is Series, 2nd one is DF 
>>> dft.loc[datetime.date(2013, 1, 1)]
A    2.375359
Name: 2013-01-01 00:00:00, dtype: float64
>>> dft.loc[[datetime.date(2013, 1, 1)]]
                   A
2013-01-01  2.375359


#plot 
dft.plot(kind='line', subplots=True)
plt.show()
dft.Close.plot(kind='line')
plt.show()


#with subplots 
#multiple in one plot 
dft.plot(kind='line', y=['Open', 'Day Wise Variation ( points) '] )
#with subplots 
dft.plot(kind='line', y=['Open', 'Day Wise Variation ( points) '], subplots=True )


#complex plot 
#4x4 gridspecs, specification for 0,0 cell , row spanning 3 rows, column spanning 4 columns 
top = plt.subplot2grid((4,4), (0, 0), rowspan=3, colspan=4)
top.plot(dft.index, dft["Close"])
plt.title('Nifty close from 2000 - 2018')

#4x4 gridspecs, specification for 3,0 cell , row spanning 1 rows, column spanning 4 columns 
bottom = plt.subplot2grid((4,4), (3,0), rowspan=1, colspan=4)
bottom.bar(dft.index, dft['Day Wise Variation ( points) '])
plt.title('Nifty Day wise variations ')

plt.show()


##Groupby (for Time series, equivalent to aggregation)
#Calculate moving avarages 
#window : int,Size of the moving window. 
#This is the number of observations used for calculating the statistic.
dft_r = dft.rolling(30)  #rolling 30 samples 
dir(dft_r)
#plot rolling average 
dft_r.mean()['Open'] #DF 
dft_r.mean().dropna().plot(kind='line') #DF
plt.show()
#
dft_s = dft.ewm(com=0.5)#Returns Exponentially-weighted moving window(EWM) class ,com=decay in terms of center of mass
#
dft_s = dft.expanding(2) #Expanding window, Minimum number of observations in window required to have a value         (otherwise result is NA)
#or downsampling at month 
dft_s = dft.resample('M')
dir(dft_s)
#month value would be mean()
dft_s.mean() #DF 
dft_s['Open'].mean() #Series
dft_s['Open'].agg([np.sum, np.mean, np.std])
dft_s.agg({'Open':'mean', 'Close':'std'})
dft_s.agg({'Open':['mean',np.std], 'Close':['std','sum']})

#KDE plot
dft_s.Close.plot(kind='kde')

#lagplot -Lag plots are used to check if a data set or time series is random. 
#Random data should not exhibit any structure in the lag plot. 
#Non-random structure implies that the underlying data are not random.
from pandas.plotting import lag_plot
lag_plot(df.Close)
plt.show()


##Autocorrelation plots are often used for checking randomness in time series
#If time series is random, such autocorrelations should be near zero for  all time-lag separations(other than lag=0)
from pandas.plotting import autocorrelation_plot
autocorrelation_plot(df.Close)




###Another example- HandsOn
##Example  of Various operations possible in DataFrame, 
ver=pd.read_csv("data/ver.csv")  
#columns 
#index,year,day of the year,time,atmospheric pressure (mBar),rainfall (mm),wind speed (m/s),wind direction (degrees),surface temperature (C),relative humidity (%),wind_max (m/s),Tdew (C),wind_chill (C),uncalibrated solar flux (Kw/m2), calibrated solar flux (Kw/m2),battery (V),not used

#index 
ver.index 

#category 
ver['year'].astype('category')
ver['year'].astype('category').cat.categories
ver['year'].astype('category').cat.add_categories([2018])
ver['year'].astype('category').cat.rename_categories({2015:'a'})
ver['year'].astype('category').cat.rename_categories({2015:'a'}).astype(str)

#display few rows
pd.set_option('display.max_columns', 80)
ver.head(3)

#Determine the number of rows and columns in the dataset
ver.shape

#Find the number of rows in the dataset
len(ver)

#Get the names of the columns
ver.columns

#Get the first five rows of a column by name
ver['atmospheric pressure (mBar)'][:5]

#Create categorical ranges for numerical data. 14 is number of bins
atmospheric_pressure = pd.cut(ver['atmospheric pressure (mBar)'], 14)
atmospheric_pressure[:5]

#Look at the frequencies in the ranges created above
pd.value_counts(atmospheric_pressure)

#first six columns of the first row
#ix like .loc[row,column] , ie label based at first if not then iloc[row,column], index based
ver.ix[0,0:6]

#Order the data by specified column
ver['atmospheric pressure (mBar)'].sort_values()[:5]

#Sort by a column and that obtain a cross-section of that data , multiple can be given
sorteddata = ver.sort_values(by=['atmospheric pressure (mBar)', 'day of the year'])
sorteddata.ix[:,0:6].head(3)  

#Obtain the first three rows and first three columns of the sorted data
sorteddata.iloc[0:3,0:3]

#Obtain value counts of specific column
ver['atmospheric pressure (mBar)'].value_counts()

#to obtain the datatype for every colu mn
zip(ver.columns, [type(x) for x in ver.ix[0,:]])
#OR
ver.dtypes

#Get the unique values for a column by name.
ver['year'].unique()

#Get a count of the unique values of a column
len(ver['year'].unique())

#Index into a column and get the first four rows
ver.ix[0:3,'atmospheric pressure (mBar)']

#Obtain True/False  values
ver.ix[0:3,'atmospheric pressure (mBar)'] == 1025

#Return a subset of the data, >, >=, == and ~, |, &
atmsubset = ver[ (ver['atmospheric pressure (mBar)'] > 1010 ) & (ver['atmospheric pressure (mBar)'] < 1016) ]
atmsubset.head(5)
#Look at the shape of the dataset
atmsubset.shape

#Query the data
qry1 = ver.query('year == 2015')   #here column name must not contain any space etc
qry1.head(10)

#if column names contains space , use below to remove , required for even attribute access
originals = ver.columns[:]
ver.columns = [c.replace(' ', '_') for c in ver.columns]
ver.columns = [c.replace('(', '') for c in ver.columns]
ver.columns = [c.replace(')', '') for c in ver.columns]
qry1 = ver.query('atmospheric_pressure_mBar == 1016')
#Look at the shape of the data
qry1.shape

#Check a boolean condition
(ver.ix[:,'atmospheric_pressure_mBar'] > 1016).any()

#Return descriptive statistics of the dataset- mean, std etc is calculated for each colu mn
ver.describe()
#output 
atmospheric pressure (mBar)
count                 45000.000000
mean                   1015.946356
std                      12.309651
min                     977.000000
25%                    1010.000000
50%                    1016.000000
75%                    1025.000000
max                    1034.000000


#Crosstab(frequency) of the data by specified columns (of one column vs another)
pd.crosstab(ver['atmospheric pressure (mBar)'],ver['rainfall (mm)'])

#Get descriptive statistics for a specified column
ver.atmospheric_pressure_mBar.describe()

#Aggregate 
#aggregate(func, axis=0, *args, **kwargs), args, kargs are passed to func, axis=0, means columnwise, axis=1, rowwise 
ver.agg(['sum', 'min'])
ver.agg({'atmospheric_pressure_mBar' : ['sum', 'min'], 'rainfall_mm' : ['min', 'max']})
df.agg("mean", axis=1)


#Group data and obtain the mean,
#group by col1 and then col2 and find mean of all other columns
grouped1 = ver.groupby(['atmospheric_pressure_mBar','rainfall_mm']).mean()
grouped1

#Group data and obtain the mean/median/etc  values of all other colum ns
grpagg = ver.groupby('atmospheric_pressure_mBar').aggregate(np.median)
grpagg

#Group data and get the sums of all other colum ns
grpsum = ver.groupby('atmospheric_pressure_mBar').aggregate(['sum', 'count'])
grpsum

# add a new column which is string version of one colu mn
ver['applicant_race_name_1'] = pd.Series(np.array(map(str, ver['atmospheric_pressure_mBar'])), index=ver.index)
ver['applicant_race_name_1'][0]  #'1025'


#Return boolean values for a specified criteria
criterion = ver['applicant_race_name_1'].map(lambda x: x.endswith('5'))  #x= each elements 
>>> criterion.value_counts()  #single variable- frequency
False    40005
True      4995

##other 
#DataFrame.apply(func, axis=0, broadcast=None, raw=False, reduce=None, result_type=None, args=(), **kwds)
#apply func on axis(0, varying row ie columnwise, 1=rowwise), fun(Series):one_value
#DataFrame.applymap(func)  , apply func elementwise, func(each_element)
#DataFrame.aggregate(func, axis=0, *args, **kwargs)
#func is agg function or list of functions or dict(key columnName, value =agg funcs on ColumnName), could be strings eg mean, median, prod, sum, std, var,count 
#for List of functions strings, see pandas.DataFrame.GroupBy
#DataFrame.transform(func, *args, **kwargs), func(each_column):new_column
ver.apply(np.sum)
ver.applymap(lambda x:str(x))
ver.aggregate({'atmospheric pressure (mBar)':['mean','count','sum']})
ver.iloc[:,[3,4]].transform(lambda x: (x-x.mean())/x.std)


#Melt data  - creating a generic form internally, which you can cast to specific shape
#each row is converted into id_vars versus other columns into 'variable' and 'value'
melt = pd.melt(ver, id_vars = 'atmospheric pressure (mBar)')
#Obtain the first five rows of melted data
melt.iloc[0:5,:]   
#output - called 'stacked' or 'record' format:
        atmospheric pressure (mBar) variable  value
0                         1025      index       101.0
1                         1025      index       101.0
2                         1025      index       101.0
3                         1025      index       101.0
4                         1025      index       101.0
#Select 
melt[melt['variable'] == 'rainfall (mm)']

#check unique 
#subset : Only consider certain columns for identifying duplicates, by default use all of the columns
melt.drop_duplicates(subset=['variable', 'value'], keep='first') #keep : {'first', 'last', False}, default 'first'

#note melt can be on multiple id_vars and can be DF instance method
#and 'variable' can be renamed 
ver.melt(id_vars=['atmospheric pressure (mBar)', 'rainfall (mm)'], var_name='melted_variable')



#pivot-unmelt - pivot(index=None, columns=None, values=None)
#'columns' columns name would be new DF's column labels 
#'values'= columnName  to use for populating new frame's cell values 
#'index'=Columnname for new frame's index

#Note index has to be unique 

ver_new = ver.drop_duplicates(subset=['atmospheric pressure (mBar)'])
melt1 = pd.melt(ver_new, id_vars = 'atmospheric pressure (mBar)')
pm = melt1.pivot(index='atmospheric pressure (mBar)', columns='variable', values='value')
>>> pm.index
Int64Index([ 977,  978,  979,  980,  981,  982,  983,  984,  985,  986,  987,
             988,  989,  990,  991,  992,  993,  994,  995,  996,  997,  998,
             999, 1000, 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009,
            1010, 1011, 1012, 1013, 1014, 1015, 1016, 1017, 1018, 1019, 1020,
            1021, 1022, 1023, 1024, 1025, 1026, 1027, 1028, 1029, 1030, 1031,
            1032, 1033, 1034],
           dtype='int64', name='atmospheric pressure (mBar)')
>>> pm.columns
Index([' calibrated solar flux (Kw/m2)', 'Tdew (C)', 'battery (V)',
       'day of the year', 'index', 'not used', 'rainfall (mm)',
       'relative humidity (%)', 'surface temperature (C)', 'time',
       'uncalibrated solar flux (Kw/m2)', 'wind direction (degrees)',
       'wind speed (m/s)', 'wind_chill (C)', 'wind_max (m/s)', 'year'],
      dtype='object', name='variable')


##excel styple pivot table 
#values=ColumnNames for aggfun , index=ColumnsNames for row-groupby , columns=ColumnNames on column-groupby , aggfunc=not string, but functions 
>>> table = pd.pivot_table(ver, values=['atmospheric pressure (mBar)','rainfall (mm)'], index=['year', 'day of the year'], columns=['battery (V)'], aggfunc=[np.sum, np.max, lambda x:x.size]) #no np method for count , we have np.count_nonzero 





## Using Pandas for Analyzing Data - Visualization

#Plot counts of a specified column using Pand as
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns  #install it, conda install seaborn

ver.atmospheric_pressure_mBar.value_counts().plot(kind='barh')
plt.show()
#or use 
ver.plot(x=None, y='atmospheric_pressure_mBar', kind='line', 
    ax=None, subplots=False, sharex=None, sharey=False, layout=None, 
    figsize=None, use_index=True, title=None, grid=None, legend=True, 
    style=None, logx=False, logy=False, loglog=False, xticks=None, yticks=None, 
    xlim=None, ylim=None, rot=None, fontsize=None, colormap=None, table=False, 
    yerr=None, xerr=None, secondary_y=False, sort_columns=False, **kwds)
#x : label string or position, default None means index 
#y : label string or position, default None, means each column 
#kind:
#line : line plot (default)
#'bar' : vertical bar plot
#'barh' : horizontal bar plot
#'hist' : histogram
#'box' : boxplot
#'kde' : Kernel Density Estimation plot
#'density' : same as 'kde'
#'area' : area plot
#'pie' : pie plot
#'scatter' : scatter plot
#'hexbin' : hexbin plot

#note 
df.plot(kind='line') 
#is equivalent to 
df.plot.line()
#and similarly for others 

#Bar plot of median values
ver.groupby('atmospheric_pressure_mBar')['surface_temperature_C'].agg(np.median).plot(kind = 'bar')
plt.show()

#Box plot example - only for first 200 rows
g = sns.factorplot("atmospheric_pressure_mBar", "surface_temperature_C", "rainfall_mm" ,ver.loc[0:200], kind="box", palette="PRGn",aspect=2.25)
g.set(ylim=(0, 10))
plt.show()

#Bar plot example
g = sns.factorplot("atmospheric_pressure_mBar","rainfall_mm", data=ver.loc[0:200], hue="surface_temperature_C",size=3,aspect=2)
plt.show()


###*** MatplotLib 
#There are three layers to the matplotlib API. 
1.The matplotlib.backend_bases.FigureCanvas 
    is the area  onto which the figure is drawn, 
2.The matplotlib.backend_bases.Renderer 
    is the object  which knows how to draw on the FigureCanvas, 
    The FigureCanvas and Renderer handle all the details of talking 
    to user interface toolkits like wxPython or drawing languages like PostScript�
3.The matplotlib.artist.Artist 
    is the object that knows how to use a renderer to paint onto the canvas. 
    The Artist handles all the high level constructs 
    like representing and laying out the figure, text, and lines. 
    The typical user will spend 95% of their time working with the Artists.  
    There are two types of Artists: primitives and containers. 
    #check class hierarchy https://matplotlib.org/api/artist_api.html  
    The primitives represent the standard graphical objects 
    eg  Line2D, Rectangle, Text, AxesImage, etc.(subclass of Artist)
    and the containers are places to put primitives (Axis, Axes and Figure)(subclass of Artist) 
    
##
Artist 
    Tick 
        YTick 
        XTick 
    OffsetBox 
        DrawingArea 
        TextArea 
    Text 
        Annotation 
    Patch 
        Polygon
        Shadow 
        Spine 
        Wedge 
        YAArow 
        Elipse
            Arc 
            Circle 
        Arrow 
        Rectangle 
    Figure   #Create Axes 
    Legend 
    Axes  #Has many methods to create primitive Artists 
        PolarAxes
        GeoAxes
    Line2D 
    Table 
    Axis 
        YAxis 
        XAxis 
    AxesImage 
    Collection 
        TriMesh 
        PolyCollection 
        CircleCollection
        PathCollection
        EllipseCollection
        LineCollection
        PatchCollection
        QuadMesh 
  
##Axes 
Axes
    #https://matplotlib.org/api/axes_api.html
    the plotting area into which most of the objects go, 
    and the Axes has many special helper methods (plot(), text(), hist(), imshow()) 
    to create the most common graphics primitives (Line2D, Text, Rectangle, Image, respectively). 
    
    These helper methods will take  data (e.g., numpy arrays and strings) 
    and create primitive Artist instances as needed (e.g., Line2D), 
    add them to the relevant containers, and draw them when requested. 
    
    **The standard use is to create a Figure instance, 
    use the Figure to create one or more Axes or Subplot instances, 
    and use the Axes instance helper methods to create the primitives. 
    The Subplot, ( is  a subclass of Axes) that lives on a regular rows by columns grid of Subplot instances. 
    #Example 
    import matplotlib.pyplot as plt
    fig = plt.figure()  #has fig.axes : list of axes in Figure
    ax = fig.add_subplot(2,1,1) # 2x1 :two rows, one column,last arg=1: first Axe is current and returned
    
    **OR when plt.method() is called, it goes to current figure with current axes (by default first)
    #Example 
    import numpy as np
    import matplotlib.pyplot as plt

    # Compute the x and y coordinates for points on sine and cosine curves
    x = np.arange(0, 3 * np.pi, 0.1)
    y_sin = np.sin(x)
    y_cos = np.cos(x)

    # Plot the points using matplotlib
    plt.plot(x, y_sin)  #Default Axe
    plt.plot(x, y_cos)
    plt.xlabel('x axis label')
    plt.ylabel('y axis label')
    plt.title('Sine and Cosine')
    plt.legend(['Sine', 'Cosine'])
    plt.show()


    **To create an Axes at an arbitrary location, 
    use the matplotlib.pyplot.axes(arg=4Tuple) or matplotlib.figure.Figure.add_axes(rect=4Tuple) which takes 4Tuple=[left, bottom, width, height] 
    values in 0-1 relative figure coordinates:
    fig2 = plt.figure()
    ax2 = fig2.add_axes([0.15, 0.1, 0.7, 0.3])
    
    #usage of Axes 
    import numpy as np
    t = np.arange(0.0, 1.0, 0.01)
    s = np.sin(2*np.pi*t)
    line, = ax.plot(t, s, color='blue', lw=2)

    **when you call ax.plot, it creates a Line2D instance  and adds it to the Axes.lines list. 
    >>> ax.lines[0]
    <matplotlib.lines.Line2D instance at 0x19a95710>
    >>> line
    <matplotlib.lines.Line2D instance at 0x19a95710>

    **If you make subsequent calls to ax.plot (and the hold state is 'on' which is the default) 
    then additional lines will be added to the list. 
    
    **You can remove lines later simply by calling the list methods; 
    del ax.lines[0]
    ax.lines.remove(line)  # one or the other, not both!

    **The Axes also has helper methods to configure  and decorate the x-axis and y-axis tick, tick labels and axis labels:
    xtext = ax.set_xlabel('my xdata') # returns a Text instance
    ytext = ax.set_ylabel('my ydata')
    
    **Each Axes instance contains an XAxis and a YAxis instance, 
    which handle the layout and drawing of the ticks, tick labels and axis labels.
    #Example 
    import numpy as np
    import matplotlib.pyplot as plt

    fig = plt.figure()
    fig.subplots_adjust(top=0.8)
    ax1 = fig.add_subplot(211)
    ax1.set_ylabel('volts')
    ax1.set_title('a sine wave')

    t = np.arange(0.0, 1.0, 0.01)
    s = np.sin(2*np.pi*t)
    line, = ax1.plot(t, s, color='blue', lw=2)

    # Fixing random state for reproducibility
    np.random.seed(19680801)
    ax2 = fig.add_axes([0.15, 0.1, 0.7, 0.3])
    n, bins, patches = ax2.hist(np.random.randn(1000), 50,facecolor='yellow', edgecolor='yellow')
    ax2.set_xlabel('time (s)')
    plt.show()

    
##plt./ax.plot(x,y,fmt,...)
##check http://matplotlib.org/api/pyplot_api.html#matplotlib.pyplot.plot

plot(x, y)        # plot x and y using default line style and color
plot(x, y, 'bo')  # plot x and y using blue circle markers
plot(y)           # plot y using x as index array 0..N-1
plot(y, 'r+')     # ditto, but with red plusses

#If x and/or y is 2D, 
#then the corresponding columns will be plotted.

#arbitrary number can be specified
plot(x1, y1, 'g^', x2, y2, 'g- ')

#plot() returns Line2D instance which can be modified
line1, line2 = plot(x1, y1, x2, y2)

# Can use multiple plot commands on same graph
plot([1,2,3], [1,2,3], 'go-', label='line 1', linewidth=2)
plot([1,2,3], [1,4,9], 'rs',  label='line 2')
axis([0, 4, 0, 10])  #Set the axis
legend()


##fmt string
#For every x, y pair of arguments, there is an optional third argument
#which is the format string that indicates the color and line type of the plot.
#The default format string is 'b-', which is a solid blue line.


#character      description 
'-'             solid line style 
'--'            dashed line style 
'-.'            dash-dot line style 
':'             dotted line style 
'.'             point marker 
','             pixel marker 
'o'             circle marker 
'v'             triangle_down marker 
'^'             triangle_up marker 
'<'             triangle_left marker 
'>'             triangle_right marker 
'1'             tri_down marker 
'2'             tri_up marker 
'3'             tri_left marker 
'4'             tri_right marker 
's'             square marker 
'p'             pentagon marker 
'*'             star marker 
'h'             hexagon1 marker 
'H'             hexagon2 marker 
'+'             plus marker 
'x'             x marker 
'D'             diamond marker 
'd'             thin_diamond marker 
'|'             vline marker 
'_'             hline marker 

#character   color 
'b'         blue 
'g'         green 
'r'         red 
'c'         cyan 
'm'         magenta 
'y'         yellow 
'k'         black 
'w'         white
 
#Any Line2D property can be given
plot(x, y, color='green', linestyle='dashed', marker='o', markerfacecolor='blue', markersize=12).

## few Line2D properties that can be passsed to  plt.plot or ax.plot or other plot functions 
alpha                   float (0.0 transparent through 1.0 opaque) 
animated                [True | False] 
antialiased or aa       [True | False] 
clip_box                a matplotlib.transforms.Bbox instance 
clip_on                 [True | False] 
color or c              any matplotlib color 
dash_capstyle           ['butt' | 'round' | 'projecting'] 
dash_joinstyle          ['miter' | 'round' | 'bevel'] 
drawstyle               ['default' | 'steps' | 'steps-pre' | 'steps-mid' | 'steps-post'] 
fillstyle               ['full' | 'left' | 'right' | 'bottom' | 'top' | 'none'] 
label                   string or anything printable with '%s' conversion. 
linestyle or ls         ['solid' | 'dashed', 'dashdot', 'dotted' | (offset, on-off-dash-seq) | '-' | '--' | '-.' | ':' | 'None' | ' ' | ''] 
linewidth or lw         float value in points 
marker                  A valid marker style 
markeredgecolor or mec  any matplotlib color 
markeredgewidth or mew  float value in points 
markerfacecolor or mfc  any matplotlib color 
markersize or ms        float 
solid_capstyle          ['butt' | 'round' | 'projecting'] 
solid_joinstyle         ['miter' | 'round' | 'bevel'] 
visible                 [True | False] 
zorder                  any number 


#Example
import matplotlib.pyplot as plt
plt.plot([1,2,3,4])                #y values , x is taken as 0,1,2,3
plt.ylabel('some numbers')
plt.show()

# to plot the above with red circles, use 'ro'
import matplotlib.pyplot as plt
plt.plot([1,2,3,4], [1,4,9,16], 'ro')
plt.axis([0, 6, 0, 20])
plt.show()

#With multiple x, y pairs in same plot
import numpy as np
import matplotlib.pyplot as plt

# evenly sampled time at 200ms intervals
t = np.arange(0., 5., 0.2)

# red dashes, blue squares and green triangles
plt.plot(t, t, 'r--', t, t**2, 'bs', t, t**3, 'g^')
plt.show()

##Few plt. methods, Note below  operates on the current axes.
#Note below relevant methods withour arg gives current value eg xlim() gives current xlimit 

plt.xlabel('x axis label', fontsize=14, color='red')
plt.ylabel('y axis label')
plt.title('Sine and Cosine')
plt.legend(['Sine', 'Cosine'])
plt.axis([0, 4, 0, 10]) #Set the axis, [xmin, xmax, ymin, ymax] or 'off' or 'equal' or 'scaled' or 'tight' etc 
plt.text(60, .025, r'$\mu=100,\ \sigma=15$')  #Any text  or  '$any LaTex code$'
plt.grid(True)
plt.ylim(-2,2)
plt.xlim(-2,2)
plt.annotate('local max', xy=(2, 1), xytext=(3, 1.5),arrowprops=dict(facecolor='black', shrink=0.05),) #xytext=location of text, xy=location for annotation
plt.yscale('linear') #log, symlog, logit
plt.xscale('linear')

##Few Axes methods  , many are available on plt. as well 
#Note below relevant methods withour arg or get_*() gives current value 
#eg xlim() gives current xlimit , get_xlabel() gives current xlabel 

ax.set_xlabel('x axis label')
ax.set_ylabel('y axis label')
ax.set_title('Simple plot')
ax.legend(['Sine', 'Cosine'])

ax.axis([0, 4, 0, 10]) #Set the axis, [xmin, xmax, ymin, ymax] or 'off' or 'equal' or 'scaled' or 'tight' etc 
ax.set_axis_off() #Turn off the axis. 
ax.set_axis_on()  # Turn on the axis. 

ax.text(60, .025, r'$\mu=100,\ \sigma=15$')  #Any text 
ax.annotate('local max', xy=(2, 1), xytext=(3, 1.5),arrowprops=dict(facecolor='black', shrink=0.05),) #xytext=location of text, xy=location for annotation
ax.arrow(x, y, dx, dy, **kwargs)    #Add an arrow to the axes.
ax.grid(b=True|False, color='r', linestyle='-', linewidth=2)
ax.set_label(s)       #Set the label to s for auto legend.
 
ax.set_ylim(-2,2)
ax.set_xlim(-2,2)
ax.set_yscale('linear') #log, symlog, logit
ax.set_xscale('linear')
ax.set_visible(b)     #Set the artist's visibility.
ax.set_zorder(level)  #Set the zorder for the artist. Artists with lower zorder values are drawn first.

ax.set_xticks(ticks, minor=False)     #Set the x ticks with list of ticks
ax.set_xticklabels(labels, fontdict=None, minor=False, **kwargs)#Set the x-tick labels with list of string labels.
ax.set_yticks(ticks, minor=False)#Set the y ticks with list of ticks
ax.set_yticklabels(labels, fontdict=None, minor=False, **kwargs)#Set the y-tick labels with list of strings labels.

ax.xaxis_date(tz=None)  #Sets up x-axis ticks and labels that treat the x data as dates.
ax.yaxis_date(tz=None)  #Sets up y-axis ticks and labels that treat the y data as dates.
ax.minorticks_off()     #Remove minor ticks from the axes.
ax.minorticks_on()      #Remove minor ticks from the axes.
new_ax = ax.twinx()     #Create a twin Axes sharing the xaxis
new_ax = ax.twiny()     #Create a twin Axes sharing the yaxis


###+++ Matplotlib -  Specifying matplotlib.colors
#Only For the below basic colors, use a single letter
b: blue,g: green,r: red,c: cyan,m: magenta,y: yellow,k: black w: white

#All examples of colors 
#https://matplotlib.org/examples/color/named_colors.html

#Gray shades can be given as a string encoding a float in the 0-1 range, e.g.:
color = '0.75'

#can specify the color using an html hex string(RGB or RGBA), as in:
color = '#eeefff' or '#0F0F0F0F'

#or you can pass an R , G , B tuple, or RGBA 
#where each of R , G , B are in the range [0,1].
color = (0.5,0.5,0.5) or (0.1, 0.2, 0.5, 0.3));



#Or use legal html names for colors, like 'red, 'burlywood and 'chartreuse'
#https://www.w3schools.com/tags/ref_colornames.asp
color = 'burlywood'

## Working with multiple figures and axes
#Plots may contain many Figure, 
#each figure is one display window
#each Figure may contain many Axes
#Figure contains set/get of figure related attributes 
#eg get_figheight(),get_figwidth()
#Axes contains plot() and set/get of xlabel, ylabel etc


##Option-1 
#note subplots(..) returns (figure,axes)
#where axes is numpy.ndarray, hence access like axes[0,0], axes[0,1],... for complex subplots 
#for simple , can destructure immediately
figure, (ax1, ax2) = plt.subplots(nrows=1, ncols=2, sharex=False, sharey=True,...  )
ax1.plot(x,y,fmt,.....)  
ax1.set_title('Sharing Y axis')
ax2.scatter(x, y)
#then show 
plt.show()

##Reference pyplot.subplots(..)
matplotlib.pyplot.subplots(nrows=1, ncols=1, sharex=False, sharey=False,   
        squeeze=True, subplot_kw=None, gridspec_kw=None, **fig_kw)
    Check https://matplotlib.org/api/_as_gen/matplotlib.pyplot.subplots.html   
    subplots args= numrows, numcols, 
    fignum where fignum ranges from 1 to numrows*numcols. in args is optional if numrows*numcols<10
    sharex, sharey 
        bool or {�none�, �all�, �row�, �col�}, default: False
        Controls sharing of properties among x (sharex) or y (sharey) axes:
            �True or �all�: x- or y-axis will be shared among all subplots.
            �False or �none�: each subplot x- or y-axis will be independent.
            ��row�: each subplot row will share an x- or y-axis.
            ��col�: each subplot column will share an x- or y-axis.
        When subplots have a shared x-axis along a column, only the x tick labels of the bottom subplot are visible. 
        Similarly, when subplots have a shared y-axis along a row, only the y tick labels of the first column subplot are visible.
    squeeze 
        bool, optional, default: True
        �If True, extra dimensions are squeezed out from the returned Axes object:
            ?if only one subplot is constructed (nrows=ncols=1), the resulting single Axes object is returned as a scalar.
            ?for Nx1 or 1xN subplots, the returned object is a 1D numpy object array of Axes objects are returned as numpy 1D arrays.
            ?for NxM, subplots with N>1 and M>1 are returned as a 2D arrays.
        �If False, no squeezing at all is done: the returned Axes object is always a 2D array containing Axes instances, 
         even if it ends up being 1x1.
    Can take addition args in subplot_kw as below
        axisbg :The background color of the subplot, which can be any valid color specificer.
        polar:A boolean flag indicating whether the subplot plot should be a polar projection. Defaults to False.

#fig_kw :All additional keyword arguments are passed to the figure() call.
f, axs = plt.subplots(2,2,figsize=(15,15))  #axs is tuple of all axes

#Returns instance of Figure and number(nrows*ncols) of AxesSubplot
fig1, (ax1, ax2) = plt.subplots(nrows=2,ncols=1)
dir(fig1)  # check all the attributes
dir(ax1)    #check all the attributes

#Example
x = np.linspace(0, 2*np.pi, 400)
y = np.sin(x**2)

# Just a figure and one subplot
f, ax = plt.subplots()
ax.plot(x, y)
ax.set_title('Simple plot')

##Two subplots, unpack the output array immediately
f, (ax1, ax2) = plt.subplots(1, 2, sharey=True)
ax1.plot(x, y)
ax1.set_title('Sharing Y axis')
ax2.scatter(x, y)

# Four polar axes
plt.subplots(2, 2, subplot_kw=dict(polar=True))

# Share a X axis with each column of subplots
plt.subplots(2, 2, sharex='col')

# Share a Y axis with each row of subplots
plt.subplots(2, 2, sharey='row')

# Share a X and Y axis with all subplots
plt.subplots(2, 2, sharex='all', sharey='all')
# same as
plt.subplots(2, 2, sharex=True, sharey=True)



##Option-2 
fig = plt.figure(figsize=None, dpi=None, facecolor=None, edgecolor=None, linewidth=0. 0,
        frameon=None, subplotpars=None, tight_layout=None)
    Check https://matplotlib.org/api/_as_gen/matplotlib.pyplot.figure.html#matplotlib.pyplot.figure 
    num 
        integer or string, optional, default: none
        If not provided, a new figure will be created, and the figure number will be incremented. 
        The figure objects holds this number in a number attribute. If num is provided, 
        and a figure with this id already exists, make it active, and returns a reference to it. 
        If this figure does not exists, create it and returns it. 
        If num is a string, the window title will be set to this figure�s num.

#Example       
fig = plt.figure(figsize=(15,15), edgecolor='b', tight_layout=True)        #create a figure 
ax1 = fig.add_subplot(211)               # nrows, ncols, which_Axes_tomake_current ie 1  
ax1.plot(x,y,fmt,.....)  
ax2 = fig.add_subplot(212)
ax2.plot(x,y,fmt,.....) 
#then show 
plt.show()


##Few figure methods 
#1st arg = Either a 3-digit integer or three separate integers 
#If the three integers are I, J, and K, 
#the subplot is the Ith plot on a grid with J rows and K columns.
#projection :['aitoff' | 'hammer' | 'lambert' | 'mollweide' | 'polar' | 'rectilinear'], optional The projection type of the axes.
#polar : boolean, optionalIf True, equivalent to projection='polar'.
fig.add_subplot(i,j,k, projection, polar,**kwargs)

#Add an axes at position rect [left, bottom, width, height] 
#where all quantities are in fractions of figure width and height.
#also takes keyword arguments for Axes, get properties via plt.setp(ax) 
fig.add_axes(rect,projection, polar,**kwargs) 

#Other 
fig.legend(handles=(line1, line2, line3), labels=('label1', 'label2', 'label3'), loc='upper right') #loc can be (x,y) or predefined string , linen are matplotlib line instance
fig.text(x, y, s, *args, **kwargs) #Add text to figure.
fig.savefig(fname, **kwargs) #Save the current figure
fig.sca(a)          #Set the current axes to be a and return a
fig.set_dpi(val)            #Set the dots-per-inch of the figure, val is float 
fig.set_edgecolor(color)    #any matplotlib color 
fig.set_facecolor(color)    #any matplotlib color 
fig.set_figheight(val, forward=False) #val is float 
fig.set_figwidth(val, forward=False)  #val is float 
fig.set_size_inches(w, h=None, forward=True)
fig.subplots(nrows=1, ncols=1, sharex=False, sharey=False, squeeze=True, subplot_kw=None, gridspec_kw=None) #returns axes as ndarray






##Option-3 
plt.figure(1)                # the first figure
plt.subplot(211)             # nrows,ncols, which_Axes_tomake_current ie 1                             
plt.plot(x,y,fmt,.....)      # all plot/scatter/box/hist etc goes subplot 1 
plt.subplot(212)             # nrows,ncols, which_Axes_tomake_current ie 2
plt.plot(x,y,fmt,.....)      # all plot/scatter/box/hist etc goes subplot 2

plt.figure(2)                # a second figure, sets to this figure, all plot commands go here
plt.plot(x,y,fmt,.....)      # creates a subplot(111) by default

plt.figure(1)                # figure 1 current; subplot(212) still current
plt.subplot(211)             # make subplot(211) in figure1 current
plt.title('Easy as 1, 2, 3') # subplot 211 title
#then show 
plt.show()

#All plotting commands apply to the current axes.
#The function gca() returns the current axes (a matplotlib.axes.Axes instance ),
#and gcf() returns the current figure (matplotlib.figure.Figure instance ).
#clear the current figure with clf() and the current axes with cla()
ax = plt.gca()  #Get the current Axes instance on the current figure 
fig = plt.gcf()  #Get a reference to the current figure.
ax.cla() #clear 
fig.clf() # clear 



##Example
import numpy as np
import matplotlib.pyplot as plt

def f(t):    
    return np.exp(-t) * np.cos(2*np.pi*t)

t1 = np.arange(0.0, 5.0, 0.1)
t2 = np.arange(0.0, 5.0, 0.02)

plt.figure(1)          # created by defau lt
plt.subplot(211)
plt.plot(t1, f(t1), 'bo', t2, f(t2), 'k')

plt.subplot(212)
plt.plot(t2, np.cos(2*np.pi*t2), 'r--')
plt.show()



##Customizing Location of Subplot Using GridSpec
matplotlib.pyplot.subplot2grid(shape, loc, rowspan=1, colspan=1, fig=None, **kwargs)
    Create an axis at specific location inside a regular grid.
    Parameters:
        shape : sequence of 2 ints
            shape = (numrows,numcols)
            First entry is number of rows, second entry is number of columns.
        loc : sequence of 2 ints
            Location to place axis within grid. 
            First entry is row number, second entry is column number.
            activated ax would be at loc= (ithrow, jthcol)
        rowspan : int
            Number of rows for the axis to span to the right.
        colspan : int
            Number of columns for the axis to span downwards.
        fig : Figure, optional
            Figure to place axis in. Defaults to current figure.
        **kwargs
            Additional keyword arguments are handed to add_subplot.
            
            
    
#unlike matplotlibs subplot, the index starts from 0 in gridspec
ax = plt.subplot2grid((2,2),(0, 0))  # same as , ax = plt.subplot(2,2,1)


#To create a subplot that spans multiple cells,
ax2 = plt.subplot2grid((3,3), (1, 0), colspan=2) #3x3 plots with 2nd row, 1st col is covering 2 cols
ax3 = plt.subplot2grid((3,3), (1, 2), rowspan=2)


#Example to create 6x6 subplots
import numpy as np
import matplotlib.pyplot as p lt
fig1= plt.figure(1)
ax1 = plt.subplot2grid((3,3), (0,0), colspan=3)
ax2 = plt.subplot2grid((3,3), (1,0), colspan=2)
ax3 = plt.subplot2grid((3,3), (1, 2), rowspan=2)
ax4 = plt.subplot2grid((3,3), (2, 0))
ax5 = plt.subplot2grid((3,3), (2, 1))
fig2= plt.figure(2)
ax11 = plt.subplot2grid((3,3), (0,0), colspan=3)
ax21 = plt.subplot2grid((3,3), (1,0), colspan=2)
ax31 = plt.subplot2grid((3,3), (1, 2), rowspan=2)
ax41 = plt.subplot2grid((3,3), (2, 0))
ax51 = plt.subplot2grid((3,3), (2, 1))
#Now use ax1.plot() to direct commands to ax1, etc
x = np.linspace(-5,5,20)
y = np.sin(x)
ax1.plot(x,y,"r-")
ax11.plot(x,y,"b-")
plt.tight_layout()
plt.show()



##Saving to a file
#output format is deduced from the extension of the filename
matplotlib.pyplot.savefig(file_name)



##Example of - 3D plots 
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.axes3d import Axes3D
import numpy as np


fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')  #requires Axes3D
X = np.arange(-5, 5, 0.25)
Y = np.arange(-5, 5, 0.25)
X, Y = np.meshgrid(X, Y)
R = np.sqrt(X**2 + Y**2)
Z = np.sin(R)
surf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm, linewidth=0, antialiased=False)
ax.set_zlim(-1.01, 1.01)
# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=10)
plt.show()
##Example - Plot an interpolant to the sine function:
#interp(x, xp, fp[, left, right, period]) 	One-dimensional linear interpolation

x = np.linspace(0, 2*np.pi, 10)
y = np.sin(x)
xvals = np.linspace(0, 2*np.pi, 50)
yinterp = np.interp(xvals, x, y)
import matplotlib.pyplot as plt
plt.plot(x, y, 'o',xvals, yinterp, '-x')
plt.show()


##*numpy.polyfit(x, y, deg, rcond=None, full=False, w=None, cov=False)
#Least squares polynomial fit.
#Fit a polynomial p(x) = p[0] * x**deg + ... + p[deg] of degree deg to points (x, y). 
#Returns a vector of coefficients p that minimises the squared error.


x = np.array([0.0, 1.0, 2.0, 3.0,  4.0,  5.0])
y = np.array([0.0, 0.8, 0.9, 0.1, -0.8, -1.0])
z = np.polyfit(x, y, 3)  #Polynomial coefficients, highest power first,0th index 
>>> z
array([ 0.08703704, -0.81349206,  1.69312169, -0.03968254])
>>> p = np.poly1d(z) #highest power first,0th index 
>>> print(p)
         3          2
0.08704 x - 0.8135 x + 1.693 x - 0.03968
>>> p(0.5)   #evaluate 
0.6143849206349179
>>> p.r #roots
array([6.24151464, 3.08128307, 0.02370685])
#+,-,*,**,/ are overloaded , np.methods() can be called 
>> p**2
poly1d([ 7.57544582e-03, -1.41607878e-01,  9.56497928e-01, -2.76158982e+00,
       2.93122393e+00, -1.34374738e-01,  1.57470396e-03])
>> np.sin(p)
array([ 0.08692719, -0.72669053,  0.99252758, -0.03967213])


#High-order polynomials may oscillate wildly:
p30 = np.poly1d(np.polyfit(x, y, 30))
>>> p30(4)
-0.80000000000000204

#plot 
import matplotlib.pyplot as plt
xp = np.linspace(-2, 6, 100)
_ = plt.plot(x, y, '.', xp, p(xp), '-', xp, p30(xp), '--')
plt.ylim(-2,2)
plt.show()
    
##Drawing 2D data as mesh 
pcolor(C, cmap=None, alpha=None,...)
pcolor(X,Y,Z, cmap=None, alpha=None,...)
pcolormesh(X, Y,Z, cmap=None, alpha=None,...)
pcolormesh(C, cmap=None, alpha=None,...)
    Both methods are used to create a pseudocolor plot of a 2-D array using quadrilaterals.
    Note, these methods can be used with np.meshgrid() easily 
    While pcolor returns a PolyCollection, pcolormesh returns a QuadMesh. 
    The latter is more specialized for the given purpose and thus is faster.
    It should almost always be preferred.    
        C : array_like
            A scalar 2-D array. The values will be color-mapped.
        X, Y, Z : array_like, optional
            The coordinates of the quadrilateral corners. 
            The quadrilateral for C[i,j] has corners at:
            (X[i+1, j], Y[i+1, j])          (X[i+1, j+1], Y[i+1, j+1])
                                  +--------+
                                  | Z[i,j] |
                                  +--------+
                (X[i, j], Y[i, j])          (X[i, j+1], Y[i, j+1]),
        cmap : str or Colormap, optional
            A Colormap instance or registered colormap name. 
            The colormap maps the C/Z values to colors. Defaults to rcParams["image.cmap"].

imshow(X, cmap=None, norm=None, aspect=None, interpolation=None, alpha=None)
    If X and Y are each equidistant, imshow can be a faster alternative than pcolormesh
        X : array-like or PIL image
        The image data. Supported array shapes are:
            (M, N): an image with scalar data. The data is visualized using a colormap.
            (M, N, 3): an image with RGB values (float or uint8).
            (M, N, 4): an image with RGBA values (float or uint8), i.e. including transparency.
        The first two dimensions (M, N) define the rows and columns of the image.
        The RGB(A) values should be in the range [0 .. 1] for floats or [0 .. 255] for integers. Out-of-range values will be clipped to these bounds.

#Example 
import numpy as np; np.random.seed(1) 
import matplotlib.pyplot as plt

NumX, NumY = 5,7
Data = np.random.randint(1,9,size=NumX*NumY+1)

Matrix = np.zeros((NumY, NumX))

for i in range(NumY):
    for j in range(NumX):
        Matrix[i,j] = Data[i*NumX+j+1]

print(Matrix)

xi = np.arange(0, NumX)
yi = np.arange(0, NumY)
X, Y = np.meshgrid(xi, yi)

plt.pcolormesh(X, Y, Matrix)
for i in range(NumY-1):
    for j in range(NumX-1):
        plt.text(j,i, Matrix[i,j], color="w")
plt.colorbar() #put a color bar 

plt.show()

###Colormap 
#The colormap is a dictionary which maps numbers(float) to colors
#Many methods take cmap as well as sequence of floats which would be mapped to colors using cmap 
#Matplotlib provides many built-in colormaps. W
#hen you have a 2D array with values at each grid point is a float between 0 and 1. 
#The gray colormap maps 0 to black and 1 to white. 
#The jet colormap maps 0 to blue and 1 to red
#check https://matplotlib.org/examples/color/colormaps_reference.html
matplotlib.cm.get_cmap(name=None, lut=None)
    Get a colormap instance, defaulting to rc values if name is None.
    
    
##Sperical Plot on unit sphere 

import numpy as np
import scipy.linalg
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import matplotlib.pyplot as plt

# The matrix for completness
A = np.matrix([[4,3,4], [3,1,3], [4,3,4]])
A = scipy.linalg.hessenberg(A)

num_points = 25
theta = np.linspace(0, 2 * np.pi, num_points)
phi = np.linspace(0, np.pi, num_points)

THETA, PHI = np.meshgrid(theta, phi)

X = np.sin(PHI) * np.cos(THETA)
Y = np.sin(PHI) * np.sin(THETA)
Z = np.cos(PHI)

# Calculate RQS for points on unit sphere:
RQS = np.empty(PHI.shape)
for theta_pos, phi_pos in itertools.product(range(num_points), range(num_points)):
    x = np.array([X[theta_pos, phi_pos],
                  Y[theta_pos, phi_pos],
                  Z[theta_pos, phi_pos]])
    RQS[theta_pos, phi_pos] = np.dot(x, np.dot(A, np.conj(x).T))

# normalize in range 0..1
maxRQS = abs(RQS).max()
N = (RQS+maxRQS)/(2*maxRQS)

fig = plt.figure()
ax = fig.gca(projection='3d')
surf = ax.plot_surface(
    X, Y, Z, rstride=1, cstride=1,
    facecolors=cm.jet(N),
    linewidth=0, antialiased=False, shade=False)
plt.show()
    
###+++ Matplotlib - Plotting commands summary 
#http://matplotlib.org/api/pyplot_summary.html

#All these functions take any Line2D properties eg  ls='solid', ...
#http://matplotlib.org/api/lines_api.html#matplotlib.lines.Line2D


#use with prefix matplotlib.pyplot. or axes.

acorr(x)                    
    Plot the autocorrelation of  x.
xcorr(x,y)                  
    Plot the cross correlation between x and y.


bar(left, height)           
    Make a bar plot with x=left array and y=height array
barbs(...)                  
    Plot a 2-D field of barbs.
barh(bottom, width)         
    Make a horizontal bar plot with bottom and width array
boxplot(x)                  
    Make a box plot

cohere(x,y)                 
    Plot the coherence between x and  y
contour(x,y,z,N)            
    Plot contours, with egde
contourf(x,y,z,N)           
    Plot contours without edges

stem(x, y, linefmt, markerfmt, basefmt=)        
    plots vertical lines (using linefmt) at each x location from the baseline to y, and places a marker there using markerfmt. A horizontal line at 0 is is plotted using basefmt
errorbar(x, y, yerr, xerr, fmt)                 
    Plot an errorbar grap h.
eventplot(positions, orientation='horizontal')  
    Plot identical parallel lines at specific positio ns

fill(x,y,fmt)               
    Plot filled polygons

hexbin(x,y,C)               
    Make a hexagonal binning plot,  C specifies values at the coordinate (x[i],y[i] ).
hist(x, bins=10)            
    Plot a histogra m.
hist2d(x, y, bins=10)       
    Make a 2D histogram plo t.
hlines(y, xmin, xmax)       
    Plot horizontal lines at each y from xmin to xma x.
vlines(x, ymin,ymax)        
    Plot vertical lines at each x from ymin to ym ax


loglog(x,y)                 
    Make a plot with log scaling on both the x and y axi s.
semilogx(x,y)               
    Make a plot with log scaling on x
semilogy(x,y)               
    Make a plot with log scaling on  y

pcolor(x2d,y2d,Color1D)     
    Create a pseudocolor plot of a 2-D arra y.
pcolormesh(x2d,y2d,Color1D) 
    Plot a quadrilateral mesh of 2D array

magnitude_spectrum(x,Fs=2, Fc=0)  
    Plot the magnitude spectrum. Fs= sampling frequency, Fc=center frequency
angle_spectrum(x,Fs=2, Fc=0)      
    Plot the angle spectrum.
phase_spectrum(x,Fs=2, Fc=0)      
    Plot the phase spectrum.
psd(x,Fs=2, Fc=0)                 
    Plot the power spectral densit y.
specgram(x, NFFT=256, Fs=2, Fc=0) 
    Plot a spectrogr m.
csd(x,y)                          
    Plot the cross-spectral density.

pie(x)                          
    Plot a pie char t.
plot(x,y,fmt)                   
    Plot lines and/or markers to the Axe s.
plot_date(x,y,fmt)              
    Plot with data with dates in either x,y or bo th
spy(Z)                          
    Plot the sparsity pattern on a 2-D array,Z.
polar(theta, r)                 
    Make a polar plo t.
quiver(x,y,C)                   
    Plot a 2-D field of arrow s.

step(x,y)                       
    Make a step plo t.
streamplot(x,y,u,v)             
    Draws streamlines of a vector flow. x,y=1d array u, v : 2d arrays = x and y-velocities. Number of rows should match length of y, and the number of columns should match x.
stackplot(x,y)                  
    Draws a stacked area plot. x : 1d array of dimension N y : 2d array of dimension MxN
scatter(x,y)                    
    Make a scatter plot of x vs y, where x and y are sequence like objects of the same lengt hs


violinplot(dataset)             
    Make a violin plot for each column of datas  et 


  
    

'''
    Pre-processing and Resampling Using scikit 
    Extraction, selection and transformation 
    Creation of test and train data 
    Pipeline and GridSearch
    Linear Regression and metrics 
'''  

###*** scikit-learn(sklearn) - Steps of ML and General Concepts  
0.0MAINSTEP : Choose the righ estimator 
1.0 Use Feature Extraction(for text/image data) using  sklearn.feature_extraction
1.1 Features selection , dimensionality reduction using sklearn.feature_selection
1.2.Preprocessing steps(eg normalizer) from sklearn.preprocessing
    Use module scikit-pandas for simplification 
2. Split data into training and test data using sklearn.model_selection.train_test_split(*arrays, **options)
3. Combining various steps  - Use Pipeline 
4. Use feature union to concatenate many transformers to get more robust transformers 
5. Evaluate model performance on test data (sklearn.metric)
6. Using cross validation To evaluate model performance 
7. Compare result with Dummy classifier/regressor to understand improvement 
8. Select best parameter using GridSearchCV/RandomizedSearchCV or ModelSpecificCV or based on AIC/BIC 
9. Only for classifier - probablity calibration if you want prob score of X

##Norms
#a loss function or cost function  is used for parameter estimation, 
#and is some function of the difference between estimated and true values and is minimized 
#The objective function is negative of loss function and that is maximized 

#regularization is a process of introducing additional information in order to solve an ill-posed problem or to prevent overfitting
#this is generally added to loss function 

#Example is L1, L2  
L1 norm = Sum( |yi-f(x) |), robust, unstable or possible many solutions, only efficient for sparse matrix 
L2 norm = Sum ( (yi-f(x))**2), called least square, not robust, but one stable solution 

##Importnat methods of Regression/classifiation
model.get_params([deep])
    Get parameters for this estimator. 
    Take param name from this in GridSearch 
model.score(X, y[, sample_weight])    
    Returns score based on the estimator, 
    More is better 
fit(X, y[, sample_weight])                      
    Fit  model with optimization of loss function
predict(X)                      
    Predict given X
predict_proba(X)            
    Probability estimates, used for classification 
    
##Regression/classifiation class has many attributes(suffix _), 
model.coef_ : array, Estimated coefficients 
model.intercept_ : array, Independent term in the linear model.


##For saving models
#use pickle or joblib(efficient to store large ndarray)
from sklearn import svm
from sklearn import datasets
clf = svm.SVC()
iris = datasets.load_iris()
X, y = iris.data, iris.target
>>> clf.fit(X, y)  
SVC(C=1.0, cache_size=200, class_weight=None, coef0=0.0,
    decision_function_shape='ovr', degree=3, gamma='auto', kernel='rbf',
    max_iter=-1, probability=False, random_state=None, shrinking=True,
    tol=0.001, verbose=False)

import pickle
s = pickle.dumps(clf)
clf2 = pickle.loads(s)
>>> clf2.predict(X[0:1])
array([0])
>>> y[0]
0
#With joblib 
from sklearn.externals import joblib
joblib.dump(clf, 'filename.pkl') 
clf3 = joblib.load('filename.pkl') 

##Out-of-core traininf for big dataset 
#also check https://dask-ml.readthedocs.io/en/latest/

##Incremental learning
#below support partial_fit(X[, y]) method 
�Classification
    Note classifiers may be unable to cope with new/unseen targets classes. 
    Hence, pass all the possible classes to the first partial_fit call using the classes= parameter
    �sklearn.naive_bayes.MultinomialNB
    �sklearn.naive_bayes.BernoulliNB
    �sklearn.linear_model.Perceptron
    �sklearn.linear_model.SGDClassifier
    �sklearn.linear_model.PassiveAggressiveClassifier
    �sklearn.neural_network.MLPClassifier
�Regression
    �sklearn.linear_model.SGDRegressor
    �sklearn.linear_model.PassiveAggressiveRegressor
    �sklearn.neural_network.MLPRegressor
�Clustering
    �sklearn.cluster.MiniBatchKMeans
    �sklearn.cluster.Birch
�Decomposition / feature Extraction
    �sklearn.decomposition.MiniBatchDictionaryLearning
    �sklearn.decomposition.IncrementalPCA
    �sklearn.decomposition.LatentDirichletAllocation
�Preprocessing
    �sklearn.preprocessing.StandardScaler
    �sklearn.preprocessing.MinMaxScaler
    �sklearn.preprocessing.MaxAbsScaler

#Builtin-Example 
#http://scikit-learn.org/stable/auto_examples/applications/plot_out_of_core_classification.html#sphx-glr-auto-examples-applications-plot-out-of-core-classification-py

###All imports 
from sklearn.pipeline import * 
from sklearn.grid_search import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_selection import *  
from sklearn.feature_extraction.text import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn.svm import *  
from sklearn.tree import *  


###sanity check - DummyClassifier and DummyRegressor -

#When doing supervised learning, it does a simple sanity check consists of comparing 
#one's estimator against simple rules of thumb.
 
sklearn.dummy.DummyClassifier(strategy='stratified', random_state=None, constant=None)
    DummyClassifier implements below strategies for classification:
    �'stratified' generates random predictions by respecting the training set class distribution.
    �'most_frequent' always predicts the most frequent label in the training set.
    �'prior' always predicts the class that maximizes the class prior (like most_frequent`) and predict_proba returns the class prior.
    �'uniform' generates predictions uniformly at random.
    �'constant' always predicts a constant label that is provided by the user.

sklearn.dummy.DummyRegressor(strategy='mean', constant=None, quantile=None)
    DummyRegressor  implements below strategies:
    �mean always predicts the mean of the training targets.
    �median always predicts the median of the training targets.
    �quantile always predicts a user provided quantile of the training targets.
    �constant always predicts a constant value that is provided by the user.
    In all these strategies, the predict method completely ignores the input data.

###Example - sanity checking of iris 
from sklearn.datasets import load_iris
from sklearn.model_selection  import train_test_split
iris = load_iris()
X, y = iris.data, iris.target
y[y != 1] = -1
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)

#compare the accuracy of SVC and most_frequent:
from sklearn.dummy import DummyClassifier
from sklearn.svm import SVC
clf = SVC(kernel='linear', C=1).fit(X_train, y_train)
>>> clf.score(X_test, y_test) 
0.63...
clf = DummyClassifier(strategy='most_frequent',random_state=0)
clf.fit(X_train, y_train)
>>> clf.score(X_test, y_test)  
0.57...

#SVC doesn't do much better than a dummy classifier.
# Now, let's change the kernel:
>>> clf = SVC(kernel='rbf', C=1).fit(X_train, y_train)
>>> clf.score(X_test, y_test)  
0.97...






###***scikit-learn(sklearn) - MAINSTEP - Choosing the right estimator
#check  http://scikit-learn.org/stable/tutorial/machine_learning_map/index.html
#Different estimators are better suited for different types of data and different problems

#algorithm could be 
1. samples size > 50 
2. for predicting a category 
    2.1 for labeled data (classification)
        2.1.1 for < 100K samples
                2.1.1.1 linear SVC (C-Support Vector Classification) - sklearn.svm.SVC
                        based on Support Vector Method 
                        If SVC is not working 
                        .1 if the data is text 
                            use Naive Bayes - sklearn.naive_bayes                         
                        .2 if data is not text 
                            use Nearest Neighbors - sklearn.neighbors
                            If not working, use Ensemble methods
                            eg averaging methods -  Bagging methods (sklearn.ensemble.BaggingClassifier), Forests of randomized trees(sklearn.ensemble.RandomForestClassifier)
                            boosting methods - AdaBoost, sklearn.ensemble.AdaBoostClassifier, Gradient Tree Boosting - sklearn.ensemble.GradientBoostingClassifier        
        2.1.2 for >100K samples 
            Use Stochastic gradient descent(SGD) classifier sklearn.linear_model.SGDClassifier
            If not working, use kernel approximation, sklearn.kernel_approximation 
    2.2 for unlabelled data (clustering)
        2.2.1 for number of categories known 
            2.2.1.1 for samples <10K
                    Use K means - sklearn.cluster.KMeans
                    if not working 
                        use Spectral clustering, sklearn.cluster.SpectralClustering
                        or use Gaussian mixture models, sklearn.mixture.GMM
            2.2.1.2 for samples > 10K 
                    use mini batch kmeans - sklearn.cluster.MiniBatchKMeans
        2.2.2 for number of categories un-known
            2.2.2.1 for samples < 10K 
                    Use meanShift - sklearn.cluster.MeanShift
                    or Gaussian mixture model with variational inference , VBGMM, sklearn.mixture.VBGMM
            2.2.2.2 for samples > 10K 
                  Create subset with samples < 10K and use above 
    
3. for predicting a quantity - regression 
    3.1 for samples < 100K
        3.1.1 when few features should be important 
            Use Lasso, sklearn.linear_model.Lasso
            or ElasticNet, sklearn.linear_model.ElasticNet
        3.1.2 when all features should be important 
            Use Ridge Regression, sklearn.linear_model.Ridge
            or  Support Vector Regression using Support vector machines , sklearn.svm.SVR(kernel='linear')
            if not working 
                use sklearn.svm.SVR(kernel='rbf')
                or Ensemble methods 
                for example  avergaing methods - bagging sklearn.ensemble.BaggingRegressor
                or random forests, sklearn.ensemble.RandomForestRegressor
                or Boosing methods - sklearn.ensemble.GradientBoostingRegressor
    3.2 for samples size > 100K 
        Use  Stochastic Gradient Descent , sklearn.linear_model.SGDRegressor
4. for just visualizing data
    Use randomized Proncipal component analysis(PCA), sklearn.decomposition.PCA
    4.1 If PCA not working and samples <10K 
        Use isomap , sklearn.manifold.Isomap
        or Spectral embedding , sklearn.manifold.SpectralEmbedding
        If above not working 
            use Locally linear embedding , LLE - sklearn.manifold.locally_linear_embedding 
    4.2 If PCA not working and samples > 10K 
        use kernel approximation, sklearn.kernel_approximation 

        
        
        
###*** scikit-learn(sklearn) - STEP0: Split data into training and test data 

##Use - sklearn.model_selection.train_test_split
sklearn.model_selection.train_test_split(*arrays, **options)
    Returns list, length=2 * len(arrays), List containing train-test split of inputs.
    *arrays : sequence of indexables with same length / .shape[0]
        Allowed inputs are lists, numpy arrays, scipy-sparse matrices 
        or pandas dataframes.
    test_size, train_size : float, int, None, optional
        If float, should be between 0.0 and 1.0 and represent the proportion 
        of the dataset to include in the test split. 
        If int, represents the absolute number of test samples. 
        If None, the value is set to the complement of the train size. 
        By default, the value is set to 0.25. 
    random_state : int, RandomState instance or None, optional (default=None)
    shuffle : boolean, optional (default=True)
    stratify : array-like or None (default is None)
        If not None, data is split in a stratified fashion, using this as the class labels.

#Example 
import numpy as np
from sklearn.model_selection import train_test_split

X, y = np.arange(10).reshape((5, 2)), range(5)  #5 samples with two features 
>>> X
array([[0, 1],
       [2, 3],
       [4, 5],
       [6, 7],
       [8, 9]])
>>> list(y)
[0, 1, 2, 3, 4]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)

>>> X_train
array([[4, 5],
       [0, 1],
       [6, 7]])
>>> y_train
[2, 0, 3]
>>> X_test
array([[2, 3],
       [8, 9]])
>>> y_test
[1, 4]

##sklearn.model_selection.train_test_split uses sklearn.model_selection.ShuffleSplit
#To use low level - sklearn.model_selection.ShuffleSplit

from sklearn.model_selection import ShuffleSplit
X = np.array([[1, 2], [3, 4], [5, 6], [7, 8]]) # index = [0,1,2,3]
y = np.array([1, 2, 1, 2])

>>> rs = ShuffleSplit(n_splits=3, test_size=.25, random_state=0)  #n_splits : Number of re-shuffling & splitting iterations.
>>> rs.get_n_splits(X)
3
>>> print(rs)
ShuffleSplit(n_splits=3, random_state=0, test_size=0.25, train_size=None)

for train_index, test_index in rs.split(X):    #Generate indices to split data into training and test set.
    print("TRAIN:", train_index, "TEST:", test_index)

TRAIN: [3 1 0] TEST: [2]        #one set of splitting, get the indices and from them get the actual data 
TRAIN: [2 1 3] TEST: [0]
TRAIN: [0 2 1] TEST: [3]


rs = ShuffleSplit(n_splits=3, train_size=0.5, test_size=.25, random_state=0)
for train_index, test_index in rs.split(X):
    print("TRAIN:", train_index, "TEST:", test_index)

TRAIN: [3 1] TEST: [2]
TRAIN: [2 1] TEST: [0]
TRAIN: [0 2] TEST: [3]



##Scikit - sklearn-utils - Other methods for sampling/shuffling 
sklearn.utils.check_random_state(seed)                      Turn seed into a np.random.RandomState instance 
sklearn.utils.estimator_checks.check_estimator(Estimator)   Check if estimator adheres to scikit-learn conventions. 
sklearn.utils.resample(*arrays, **options)                  Resample arrays or sparse matrices in a consistent way 
sklearn.utils.shuffle(*arrays, **options)                   Alias to resample(*arrays, replace=False) to do random permutations of the collections.         

#Example 
>>> X = np.array([[1., 0.], [2., 1.], [0., 0.]])
>>> y = np.array([0, 1, 2])

>>> from scipy.sparse import coo_matrix
>>> X_sparse = coo_matrix(X)

>>> from sklearn.utils import shuffle
#can take multiple arrays as input 
>>> X, X_sparse, y = shuffle(X, X_sparse, y, random_state=0)
>>> X
array([[ 0.,  0.],
       [ 2.,  1.],
       [ 1.,  0.]])

>>> X_sparse                   
<3x2 sparse matrix of type '<... 'numpy.float64'>'
    with 3 stored elements in Compressed Sparse Row format>

>>> X_sparse.toarray()
array([[ 0.,  0.],
       [ 2.,  1.],
       [ 1.,  0.]])

>>> y
array([2, 1, 0])

#only take two 
>>> shuffle(y, n_samples=2, random_state=0)
array([0, 1])



###*** scikit-learn(sklearn) - STEP1: General steps for Feature extraction,selection and transformation 

#Note any transformation happens on full X [n_samples, n_features]
#Individual feature transformations possible with ndarray slice eg X.iloc[:, 2] or use module scikit-pandas

#call fit() first 
model.fit(X[, y]) 
#then call transform()
model.transform(X[, y]) 
#or call 
model.fit_transform(X[, y]) 

#To use the model for futher transformation of new input 
model.transform(new_X[, y]) 

#for inverset transform - note one hot encoding is inversed with on hot encoding labels
model.inverse_transform(transformed)

#Selecting best one along with Extraction 
model.restrict(selectionModel.get_support()) 


##General structure for  data types 
#Note in scikit , X must be  ndarray if all int/float or scipy.parse
#(prefeably Compressed Sparse Rows and Compressed Sparse Columns, others would be converted to this)
X : {array-like, sparse matrix}, shape [n_samples, n_features]
#latest sklearn takes pandas dataframe directly, Note X should be 2D float, y is 1D float 
lm.fit(df[['speed', 'weight']].astype(float64), df['result'].astype(float64))

#For compatbility reasons, to work with pandas , convert pandas DF to ndArray 
#Note latest version of sklearn can directly take pandas(coerce with np.array())
#but , if pandas has all numeric, then OK, else, convert to ndArray as object- which is NotOK
#can convert to .astype(floaf64) etc 
dataset_array = dataset.values
#or 
mat = dataset.as_matrix()

1.it's possible to use a pandas dataframe(homogeneous columns with dtype=float) 
  as an input for most sklearn fit/predict/transform methods, but the output of them is ndarray 
  if Dataframe contains heterogious columns and/or that aren't numeric,then sklearn fails as ndarray conversion by df.values would be dtype=Object 
  Trick is to manually convert  with astype(float64). OR use scikit-pandas's DataFrameWrapper 
  DataFrameWrapper can be used in place of X and y in fit/transform but does not have inverse_transform 
  sklearn preprocessing uses the same transformation to all columns, 
  but with scikit-pandas , one can apply different transformations to different columns 
  #Example  
    >>> df
       float_col  int_col str_col
    0        0.1        1       a
    1        0.2        2       b
    2        0.2        6     NaN
    3       10.1        8       c
    4        NaN       -1       a

    >>> df.values[:,:-1]
    array([[0.1, 1],
           [0.2, 2],
           [0.2, 6],
           [10.1, 8],
           [nan, -1]], dtype=object)

    >>> df.values[:,:-1].astype(float32)
    array([[  0.1       ,   1.        ],
           [  0.2       ,   2.        ],
           [  0.2       ,   6.        ],
           [ 10.10000038,   8.        ],
           [         nan,  -1.        ]], dtype=float32)
       
2. scikit  takes float32/float64 for feature value and label value
   Use transformers to change each feature
   Scikit use same transformers to all n_features, use scikit-pandas for better usage 
   Some transformers expect a 1D input (the Label-oriented ones) 
   while some others, like OneHotEncoder or Imputer, expect 2D, with the shape [n_samples, n_features], 
   while some other may take 1D or 2d eg StandardScaler
   Use ndarray slicing to get subset of data 
   For categorical input 
       Label*() is generally used for target, y 
       Without Label prefix, for features, X 
       Takes 1D as input 
            LabelEncoder to convert to integer 0...No_Of_classes, takes numeric and strings categorical
            LabelBinarizer(can take 2D of sinle column) to convert one hot encoding , takes numeric and strings categorical
            MultiLabelBinarizer(take 2D of many columns) to convert one hot encoding but for multilabel ie target is list of tuples of labels, takes numeric and strings categorical
            LabelBinarizer does not work with multi label ie input with tuples of multiple labels 
       Takes 2D as input 
           OneHotEncoder to convert one hot encoding, takes only numeric categorical
            (to convert to numeric from string categorical, use LabelEncoder)
            Note categorical features must be one hot encoded 
    For non categorical(continous numerical) Input 
        StandardScaler takes 1D or 2D , scales each feature/column to standard normal distribution 
        Takes 2D as input 
            Binarizer() to convert to 0/1 for binary based on threashold, takes continuous numeric 
            For sparse data, use MaxAbsScaler() to scale each feature  to [-1,1]
            Normalization scales individual sample/row to have unit norm
            MinMaxScaler scales each feature to  [feature_min,feature_max]
            Data with many outliers, use RobustScaler
            For using with features' high-order and interaction terms, use PolynomialFeatures
            To fill in missing values, use Imputer
            Use DictVectorizer to convert list of dict(key=columnName,value) to 2D array(string categorical value to onehot encoding, numeric value to numeric)
        For text feature, convert to numeric using TfidfVectorizer (=CountVectorizer + TfidfTransformer)
        It is sometimes not enough to center and scale the features independently, 
        since a downstream model can further make some assumption on the linear independence of the features.
        use sklearn.decomposition.PCA or sklearn.decomposition.RandomizedPCA with whiten=True 
        to further remove the linear correlation across features.
        
        
        
        
###*** scikit-learn(sklearn) - STEP1: scikit_pandas - Using sklearn transformation into Dataframe 

#bridge for scikit-learn pipelines and pandas data frame with dedicated transformers.

$ pip install sklearn-pandas

#scikit-pandas contains DataFrameMapper, a class for mapping pandas data frame columns to different sklearn transformations
#And A CategoricalImputer that replaces null-like values with the mode and works with string columns

#DataFrameMapper Can be used directly in Pipeline etc and has fit, transform, set_params, fit_transform but no inverse_transform

##General syntax 
#DataFrameMapper takes list of tuples, (columnName, Transformer) as first arg 
#create one tuple for each column else missing column would not be outputed to results 
#each tuple can be formed as (check actual usage as many combinations might not be possible, Use Pipeline in that case)
#tuple first element   tuple second element              Description 
'col'                  Any Transformer for 1D as input   LabelEncoder etc       
['col']                Any Transformer for 2D as input                  
'col'                  None                              No transformations for this col, directly ouputed to result
['col']                [Transformer1, Transformer2..]    Multiple transformer(2D) for one column 
                                                         Note 1D and 2D transformer can not be mixed 
                                                         eg LabelEncoder and OneHotEncoder 
                                                         Use Pipeline for that 
['col1', 'col2'..]     Feature_Selection                 feature selection applied to  all cols together
                                                         Note fit_transform now take X as well as Y 
                                                         if that feature selection requires
['col1', 'col2'..]     [Selection, Transformer1,..]      feature selection and then transformer
['col1', 'col2'..]     Transformer                       Eg Normalizer like transformer, which takes many columns                                                


#Note same transformer applied to multiple columns - Not possible directly 
Option 1
    Mention each column seperately 
Option 2 
    Use DataFrameMapper(.., default=Transformer)
    where default would be applied to any column not mentioned in first arg 
Option 3 
    Use gen_features(columns=['col1', 'col2',...], classes=[1D_Transformer])
    OR  gen_features(columns=[['col1'], ['col2'],...], classes=[2D_Transformer1, 2D_Transformer2])
    gen_features automates Option-1


#Example 

from sklearn_pandas import DataFrameMapper  #, cross_val_score

import pandas as pd
import numpy as np
import sklearn.preprocessing, sklearn.decomposition, sklearn.linear_model, sklearn.pipeline, sklearn.metrics
from sklearn.feature_extraction.text import CountVectorizer



data = pd.DataFrame({'pet':      ['cat', 'dog', 'dog', 'fish', 'cat', 'dog', 'cat', 'fish'],
                      'pet2':      ['cat', 'dog', 'dog', 'fish', 'cat', 'dog', 'cat', 'fish'],
                      'children': [4., 6, 3, 3, 2, 3, 5, 4],
                      'salary':   [90, 24, 44, 27, 32, 59, 36, 27]})
                      
                      
#Example of LabelBinarizer(one hot encoded) and StandardScaler
#Note LabelBinarizer takes 1D, hence 'pet without []
#StandardScaler takes 2D, hence ['children']
mapper = DataFrameMapper([
    ('pet', sklearn.preprocessing.LabelBinarizer()),  #LabelBinarizer can take 2D , all columns would be independently onehot encoded , use ['pet']
     (['children'], sklearn.preprocessing.StandardScaler())
 ])
>>> np.round(mapper.fit_transform(data.copy()), 2)
array([[ 1.  ,  0.  ,  0.  ,  0.21],
       [ 0.  ,  1.  ,  0.  ,  1.88],
       [ 0.  ,  1.  ,  0.  , -0.63],
       [ 0.  ,  0.  ,  1.  , -0.63],
       [ 1.  ,  0.  ,  0.  , -1.46],
       [ 0.  ,  1.  ,  0.  , -0.63],
       [ 1.  ,  0.  ,  0.  ,  1.04],
       [ 0.  ,  0.  ,  1.  ,  0.21]])
       
# For new Data 
sample = pd.DataFrame({'pet': ['cat'], 'children': [5.]})
>>> np.round(mapper.transform(sample), 2)
array([[1.  , 0.  , 0.  , 1.04]])

       
#Example of LabelEncoder(0..Numclasses0 , takes 1D 
mapper = DataFrameMapper([
     ('pet', sklearn.preprocessing.LabelEncoder()),
     (['children'], sklearn.preprocessing.StandardScaler())
 ])
>>> np.round(mapper.fit_transform(data.copy()), 2)
array([[ 0.  ,  0.21],
       [ 1.  ,  1.88],
       [ 1.  , -0.63],
       [ 2.  , -0.63],
       [ 0.  , -1.46],
       [ 1.  , -0.63],
       [ 0.  ,  1.04],
       [ 2.  ,  0.21]])
       
#Create another DF with pet as numerical Categorical 
df2 = pd.DataFrame(np.round(mapper.fit_transform(data.copy()), 2))
df2.columns=['pet', 'children']
>>> df2
   pet  children
0  0.0      0.21
1  1.0      1.88
2  1.0     -0.63
3  2.0     -0.63
4  0.0     -1.46
5  1.0     -0.63
6  0.0      1.04
7  2.0      0.21

#Other transformer  
mapper = DataFrameMapper([
     (['children', 'salary'], sklearn.preprocessing.Normalizer())
 ])
>>> print(mapper.fit_transform(data))
[[0.04440061 0.99901381]
 [0.24253563 0.9701425 ]
 [0.06802389 0.99768369]
 [0.11043153 0.99388373]
 [0.06237829 0.99805258]
 [0.05078185 0.99870977]
 [0.13756837 0.99049227]
 [0.14654866 0.98920346]]
#OK
mapper = DataFrameMapper([
    ('pet', sklearn.preprocessing.LabelEncoder()),
     (['children'], sklearn.preprocessing.StandardScaler())
 ])
>>> print(mapper.fit_transform(data))
[[ 0.          0.20851441]
 [ 1.          1.87662973]
 [ 1.         -0.62554324]
 [ 2.         -0.62554324]
 [ 0.         -1.4596009 ]
 [ 1.         -0.62554324]
 [ 0.          1.04257207]
 [ 2.          0.20851441]]

#OK with warning
mapper = DataFrameMapper([
    (['pet'], sklearn.preprocessing.LabelEncoder()),
     (['children'], sklearn.preprocessing.StandardScaler())
 ])
>>>print(mapper.fit_transform(data))
[[ 0.          0.20851441]
 [ 1.          1.87662973]
 [ 1.         -0.62554324]
 [ 2.         -0.62554324]
 [ 0.         -1.4596009 ]
 [ 1.         -0.62554324]
 [ 0.          1.04257207]
 [ 2.          0.20851441]]
 
#Example of LabelBinarizer(takes 1D) with numeric/string categorical
#OK
mapper = DataFrameMapper([
    ('pet', sklearn.preprocessing.LabelBinarizer()),
     (['children'], sklearn.preprocessing.StandardScaler())
 ])
>>> print(mapper.fit_transform(data))
[[ 1.          0.          0.          0.20851441]
 [ 0.          1.          0.          1.87662973]
 [ 0.          1.          0.         -0.62554324]
 [ 0.          0.          1.         -0.62554324]
 [ 1.          0.          0.         -1.4596009 ]
 [ 0.          1.          0.         -0.62554324]
 [ 1.          0.          0.          1.04257207]
 [ 0.          0.          1.          0.20851441]]
 
#OK
mapper = DataFrameMapper([
    (['pet'], sklearn.preprocessing.LabelBinarizer()),
     (['children'], sklearn.preprocessing.StandardScaler())
 ])
print(mapper.fit_transform(data))
[[ 1.          0.          0.          0.20851441]
 [ 0.          1.          0.          1.87662973]
 [ 0.          1.          0.         -0.62554324]
 [ 0.          0.          1.         -0.62554324]
 [ 1.          0.          0.         -1.4596009 ]
 [ 0.          1.          0.         -0.62554324]
 [ 1.          0.          0.          1.04257207]
 [ 0.          0.          1.          0.20851441]]
 
#Not OK - one transformer to multiple cols , use gen_features 
mapper = DataFrameMapper([
    (['pet', 'pet2'], sklearn.preprocessing.LabelBinarizer()),
     (['children'], sklearn.preprocessing.StandardScaler())
 ])
>>>print(mapper.fit_transform(data))
ValueError: ['pet', 'pet2']: Multioutput target data is not supported with label binarization

#OK
mapper = DataFrameMapper([
    ('pet',  sklearn.preprocessing.LabelBinarizer()),
    ('pet2',  sklearn.preprocessing.LabelBinarizer()),
     (['children'], sklearn.preprocessing.StandardScaler())
 ])
>>> print(mapper.fit_transform(data))
[[ 1.          0.          0.          1.          0.          0.   0.20851441]
 [ 0.          1.          0.          0.          1.          0.   1.87662973]
 [ 0.          1.          0.          0.          1.          0.  -0.62554324]
 [ 0.          0.          1.          0.          0.          1.  -0.62554324]
 [ 1.          0.          0.          1.          0.          0.  -1.4596009 ]
 [ 0.          1.          0.          0.          1.          0.  -0.62554324]
 [ 1.          0.          0.          1.          0.          0.   1.04257207]
 [ 0.          0.          1.          0.          0.          1.   0.20851441]]
 
#OK
mapper = DataFrameMapper([
    ('pet',  sklearn.preprocessing.MultiLabelBinarizer()),
     (['children'], sklearn.preprocessing.StandardScaler())
 ])
>>> print(mapper.fit_transform(data))
[[ 1.          1.          0.          0.          0.          0.   0.          0.          0.          1.          0.20851441]
 [ 0.          0.          1.          0.          1.          0.   0.          1.          0.          0.          1.87662973]
 [ 0.          0.          1.          0.          1.          0.   0.          1.          0.          0.         -0.62554324]
 [ 0.          0.          0.          1.          0.          1.   1.          0.          1.          0.         -0.62554324]
 [ 1.          1.          0.          0.          0.          0.   0.          0.          0.          1.         -1.4596009 ]
 [ 0.          0.          1.          0.          1.          0.   0.          1.          0.          0.         -0.62554324]
 [ 1.          1.          0.          0.          0.          0.   0.          0.          0.          1.          1.04257207]
 [ 0.          0.          0.          1.          0.          1.   1.          0.          1.          0.          0.20851441]]

#OK
mapper = DataFrameMapper([
    (['pet', 'pet2'], sklearn.preprocessing.MultiLabelBinarizer()),
     (['children'], sklearn.preprocessing.StandardScaler())
 ])
>>> print(mapper.fit_transform(data))
[[ 1.          0.          0.          0.20851441]
 [ 0.          1.          0.          1.87662973]
 [ 0.          1.          0.         -0.62554324]
 [ 0.          0.          1.         -0.62554324]
 [ 1.          0.          0.         -1.4596009 ]
 [ 0.          1.          0.         -0.62554324]
 [ 1.          0.          0.          1.04257207]
 [ 0.          0.          1.          0.20851441]]
 
#OK
mapper = DataFrameMapper([
    ('pet',  sklearn.preprocessing.MultiLabelBinarizer()),
    ('pet2',  sklearn.preprocessing.MultiLabelBinarizer()),
     (['children'], sklearn.preprocessing.StandardScaler())
 ])
>>> print(mapper.fit_transform(data))
[[ 1.          1.          0.          0.          0.          0.   0.          0.          0.          1.          1.          1.   0.          0.          0.          0.          0.          0.   0.          1.          0.20851441]
 [ 0.          0.          1.          0.          1.          0.   0.          1.          0.          0.          0.          0.   1.          0.          1.          0.          0.          1.   0.          0.          1.87662973]
 [ 0.          0.          1.          0.          1.          0.   0.          1.          0.          0.          0.          0.   1.          0.          1.          0.          0.          1.   0.          0.         -0.62554324]
 [ 0.          0.          0.          1.          0.          1.   1.          0.          1.          0.          0.          0.   0.          1.          0.          1.          1.          0.   1.          0.         -0.62554324]
 [ 1.          1.          0.          0.          0.          0.   0.          0.          0.          1.          1.          1.   0.          0.          0.          0.          0.          0.   0.          1.         -1.4596009 ]
 [ 0.          0.          1.          0.          1.          0.   0.          1.          0.          0.          0.          0.   1.          0.          1.          0.          0.          1.   0.          0.         -0.62554324]
 [ 1.          1.          0.          0.          0.          0.   0.          0.          0.          1.          1.          1.   0.          0.          0.          0.          0.          0.   0.          1.          1.04257207]
 [ 0.          0.          0.          1.          0.          1.   1.          0.          1.          0.          0.          0.   0.          1.          0.          1.          1.          0.   1.          0.          0.20851441]]
>>>


#Example of OneHotEncoder
#Note OneHotEncoder takes only numeric categorical and takes 2D 
mapper = DataFrameMapper([
     (['pet'], sklearn.preprocessing.OneHotEncoder()),
     (['children'], sklearn.preprocessing.StandardScaler())
 ])
>>> np.round(mapper.fit_transform(data.copy()), 2)
ValueError: ['pet']: could not convert string to float: 'fish'

>>> np.round(mapper.fit_transform(df2.copy()), 2)#OK
array([[ 1.  ,  0.  ,  0.  ,  0.21],
       [ 0.  ,  1.  ,  0.  ,  1.88],
       [ 0.  ,  1.  ,  0.  , -0.63],
       [ 0.  ,  0.  ,  1.  , -0.63],
       [ 1.  ,  0.  ,  0.  , -1.46],
       [ 0.  ,  1.  ,  0.  , -0.63],
       [ 1.  ,  0.  ,  0.  ,  1.04],
       [ 0.  ,  0.  ,  1.  ,  0.21]])


#Example of Binarizer - 0/1 bsed on some threshhold(default=0.5)
#Binarizer takes only numeric and 2D 
mapper = DataFrameMapper([
    ('pet', sklearn.preprocessing.Binarizer()),
     (['children'], sklearn.preprocessing.StandardScaler())
 ])
>>> np.round(mapper.fit_transform(data.copy()), 2)
ValueError: pet: could not convert string to float: 'fish'

mapper = DataFrameMapper([
     (['pet'], sklearn.preprocessing.OneHotEncoder()),
     (['children'], sklearn.preprocessing.Binarizer())
 ])
>>> np.round(mapper.fit_transform(df2.copy()), 2)
array([[1., 0., 0., 1.],
       [0., 1., 0., 1.],
       [0., 1., 0., 0.],
       [0., 0., 1., 0.],
       [1., 0., 0., 0.],
       [0., 1., 0., 0.],
       [1., 0., 0., 1.],
       [0., 0., 1., 1.]])
       

       

##Outputting a dataframe
#By default the output of the dataframe mapper is a numpy array as required by sklearn transformer 
#Or use  df_out=True
#Note this does not work together with the default=True or sparse=True arguments to the mapper.
mapper_df = DataFrameMapper([
            ('pet', sklearn.preprocessing.LabelBinarizer()),
            (['children'], sklearn.preprocessing.StandardScaler())
        ], df_out=True)
>>> np.round(mapper_df.fit_transform(data.copy()), 2)
   pet_cat  pet_dog  pet_fish  children
0      1.0      0.0       0.0      0.21
1      0.0      1.0       0.0      1.88
2      0.0      1.0       0.0     -0.63
3      0.0      0.0       1.0     -0.63
4      1.0      0.0       0.0     -1.46
5      0.0      1.0       0.0     -0.63
6      1.0      0.0       0.0      1.04
7      0.0      0.0       1.0      0.21
 
 
 

 
 

 
##Columns that don't need any transformation - use None 
#Only columns that are listed in the DataFrameMapper are kept
#To keep a column but don't apply any transformation to it, use None as transformer
mapper3 = DataFrameMapper([
        ('pet', sklearn.preprocessing.LabelBinarizer()),
        ('children', None)
    ])
>>> np.round(mapper3.fit_transform(data.copy()))
array([[ 1.,  0.,  0.,  4.],
       [ 0.,  1.,  0.,  6.],
       [ 0.,  1.,  0.,  3.],
       [ 0.,  0.,  1.,  3.],
       [ 1.,  0.,  0.,  2.],
       [ 0.,  1.,  0.,  3.],
       [ 1.,  0.,  0.,  5.],
       [ 0.,  0.,  1.,  4.]])
 
 
##Applying a default transformer
#A default transformer can be applied to columns not explicitly transformed in DataFrameMapper
#Use default = transformer 
#Using default=False (bydefault) drops unselected columns. 
#Using default=None pass the unselected columns unchanged.
mapper4 = DataFrameMapper([
            ('pet', sklearn.preprocessing.LabelBinarizer()),
            ('children', None)
        ], default=sklearn.preprocessing.StandardScaler())
>>> np.round(mapper4.fit_transform(data.copy()), 1)
array([[ 1. ,  0. ,  0. ,  4. ,  2.3],
       [ 0. ,  1. ,  0. ,  6. , -0.9],
       [ 0. ,  1. ,  0. ,  3. ,  0.1],
       [ 0. ,  0. ,  1. ,  3. , -0.7],
       [ 1. ,  0. ,  0. ,  2. , -0.5],
       [ 0. ,  1. ,  0. ,  3. ,  0.8],
       [ 1. ,  0. ,  0. ,  5. , -0.3],
       [ 0. ,  0. ,  1. ,  4. , -0.7]])

 
 

##Multiple transformers for the same column such that one after another transformer is applied 
mapper3 = DataFrameMapper([
            (['age'], [sklearn.preprocessing.Imputer(),
                       sklearn.preprocessing.StandardScaler()])])
data_3 = pd.DataFrame({'age': [1, np.nan, 3]})
>>> mapper3.fit_transform(data_3)
array([[-1.22474487],
       [ 0.        ],
       [ 1.22474487]])
 
##Same transformer for multiple columns , use gen_features
#For example, with three categorical columns, 'col1', 'col2', and 'col3'
from sklearn_pandas import gen_features
feature_def = gen_features(
        columns=['col1', 'col2', 'col3'],
        classes=[sklearn.preprocessing.LabelEncoder]
    )
>>> feature_def
[('col1', [LabelEncoder()]), ('col2', [LabelEncoder()]), ('col3', [LabelEncoder()])]
mapper5 = DataFrameMapper(feature_def)
data5 = pd.DataFrame({
        'col1': ['yes', 'no', 'yes'],
        'col2': [True, False, False],
        'col3': ['one', 'two', 'three']
    })
>>> mapper5.fit_transform(data5)
array([[1, 1, 0],
       [0, 0, 2],
       [1, 0, 1]])
       
       
#If it is required to override some of transformer parameters, (by default, default initializer is used)
#then a dict with 'class' key and transformer parameters should be provided. 
feature_def = gen_features(
        columns=[['col1'], ['col2'], ['col3']],
        classes=[{'class': sklearn.preprocessing.Imputer, 'strategy': 'most_frequent'}]
    )
mapper6 = DataFrameMapper(feature_def)
data6 = pd.DataFrame({
        'col1': [None, 1, 1, 2, 3],
        'col2': [True, False, None, None, True],
        'col3': [0, 0, 0, None, None]
    })
>>> mapper6.fit_transform(data6)
array([[ 1.,  1.,  0.],
       [ 1.,  0.,  0.],
       [ 1.,  1.,  0.],
       [ 2.,  1.,  0.],
       [ 3.,  1.,  0.]])
 
 
##Feature selection and other supervised transformations
#DataFrameMapper supports supervised transformers(ie feature selection) that require both X and y arguments. 

#Example - Treating the 'pet' column as the target, 
#we will select the column that best predicts it.

from sklearn.feature_selection import SelectKBest, chi2
mapper_fs = DataFrameMapper([
        (['children','salary'], SelectKBest(chi2, k=1))
    ])
#'children','salary' is converted to one column 
>>> mapper_fs.fit_transform(data[['children','salary']], data['pet'])
array([[ 90.],
       [ 24.],
       [ 44.],
       [ 27.],
       [ 32.],
       [ 59.],
       [ 36.],
       [ 27.]])
>>> mapper_fs.transformed_names_
['children_salary']

##With PCA 
mapper2 = DataFrameMapper([
        (['children', 'salary'], sklearn.decomposition.PCA(1))
    ])
>>> np.round(mapper2.fit_transform(data.copy()), 1)
array([[ 47.6],
       [-18.4],
       [  1.6],
       [-15.4],
       [-10.4],
       [ 16.6],
       [ -6.4],
       [-15.4]])
 
 
 
##CategoricalImputer
#scikit-learn Imputer transformer currently only works with numbers, 
#sklearn-pandas provides CategoricalImputer with strings, 
#substituting null values with the most frequent value in that column.

#Example: imputing with the mode:
>>> from sklearn_pandas import CategoricalImputer
>>> data = np.array(['a', 'b', 'b', np.nan], dtype=object)
>>> imputer = CategoricalImputer()
>>> imputer.fit_transform(data)
array(['a', 'b', 'b', 'b'], dtype=object)

#Example: imputing with a fixed value:
>>> from sklearn_pandas import CategoricalImputer
>>> data = np.array(['a', 'b', 'b', np.nan], dtype=object)
>>> imputer = CategoricalImputer(strategy='fixed_value', replacement='a')
>>> imputer.fit_transform(data)
array(['a', 'b', 'b', 'a'], dtype=object)
     
        
###A DataFrameMapper will return a dense feature array by default. 
#Setting sparse=True in the mapper will return a sparse array 
#whenever any of the extracted features is sparse. 

>>> mapper5 = DataFrameMapper([
        ('pet', CountVectorizer()),
    ], sparse=True)
>>> type(mapper5.fit_transform(data))
<class 'scipy.sparse.csr.csr_matrix'>
 
 
        
###HandsOn - Example - IRIS Data Analysis with PCA, LabelEncoder and StandardScaler
import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
from sklearn_pandas import DataFrameMapper
import matplotlib.pyplot as plt 
from sklearn.model_selection import train_test_split


iris = pd.read_csv('data/iris.csv')

>>> iris.columns
Index(['SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth', 'Name'], dtype='object')


#Direct LabelEncoder and PCA and StandardScaler(must for SVM)
dataset  = iris.values
X = dataset[:,0:4].astype(float)
raw_Y = dataset[:,4]
encoder = LabelEncoder()
encoder.fit(raw_Y)
Y = encoder.transform(raw_Y).astype(float)

pca = PCA(n_components=3)  #down from 4 to 3 features 
pca.fit(X)
X = pca.transform(X) #(150, 3)

scaler = StandardScaler()
X = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.33, random_state=42)

#Using DataFrameMapper 
mapper = DataFrameMapper([
     ('Name', LabelEncoder()),
     (['SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth'], [PCA(3), StandardScaler()] )
 ],  df_out=True)
out_df = mapper.fit_transform(iris.copy())

#All are pandas DF or Series 
X_train, X_test, y_train, y_test = train_test_split(out_df.iloc[:,1:], out_df.Name, test_size=0.33, random_state=42)




###*** Tf-Idf with text data 
#CountVectorizer implements both tokenization and occurrence counting in a single class:
from sklearn.feature_extraction.text import CountVectorizer

vectorizer = CountVectorizer()
>>> vectorizer                     
CountVectorizer(analyzer=...'word', binary=False, decode_error=...'strict',
        dtype=<... 'numpy.int64'>, encoding=...'utf-8', input=...'content',
        lowercase=True, max_df=1.0, max_features=None, min_df=1,
        ngram_range=(1, 1), preprocessor=None, stop_words=None,
        strip_accents=None, token_pattern=...'(?u)\\b\\w\\w+\\b',
        tokenizer=None, vocabulary=None)


corpus = [
 'This is the first document.',
 'This is the second second document.',
 'And the third one.',
 'Is this the first document?', 
 ]

X = vectorizer.fit_transform(corpus)

#The default configuration tokenizes the string by extracting words of at least 2 letters
>>> X.toarray()           
array([[0, 1, 1, 1, 0, 0, 1, 0, 1],
       [0, 1, 0, 1, 0, 2, 1, 0, 1],
       [1, 0, 0, 0, 1, 0, 1, 1, 0],
       [0, 1, 1, 1, 0, 0, 1, 0, 1]]...)


#The converse mapping from feature name to column index 
>>> vectorizer.vocabulary_.get('document')
1

#Hence words that were not seen in the training corpus will be completely ignored in future calls
>>> vectorizer.transform(['Something completely new.']).toarray()        
array([[0, 0, 0, 0, 0, 0, 0, 0, 0]]...)


#To preserve some of the local ordering information,extract 2-grams of words in addition to the 1-grams (individual words):
bigram_vectorizer = CountVectorizer(ngram_range=(1, 2),
                                    token_pattern=r'\b\w+\b', min_df=1)

#The vocabulary extracted by this vectorizer is hence much bigger 
#and can now resolve ambiguities encoded in local positioning patterns:
X_2 = bigram_vectorizer.fit_transform(corpus).toarray()
>>> X_2                    
array([[0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0],
       [0, 0, 1, 0, 0, 1, 1, 0, 0, 2, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0],
       [1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0],
       [0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1]]...)

       
##Tf�idf 
#Tf means term-frequency while tf�idf means term-frequency X inverse document-frequency
#http://scikit-learn.org/stable/modules/feature_extraction.html#tfidf-term-weighting

#In a large text corpus, some words will be very present (e.g. �the�, �a�, �is� in English) 
#hence carrying very little meaningful information about the actual contents of the document. 

#In order to re-weight the count features into floating point values suitable for usage by a classifier 
#it is very common to use the tf�idf transform.
TfidfTransformer(norm='l2', use_idf=True, smooth_idf=True, sublinear_tf=False)


#TfidfVectorizer that combines all the options/params of CountVectorizer and TfidfTransformer in a single model

from sklearn.feature_extraction.text import TfidfVectorizer
vectorizer = TfidfVectorizer()
vectorizer.fit_transform(corpus)










###*** Support Vector Machine
 
 
#Plot each data item(each row of X) as a point in n-dimensional space (where n is number of features (columns of X))
#with the value of each feature being the value of a particular coordinate.
#(these co-ordinates are known as Support Vectors)

#For example, for two features like Height and Hair length of an individual, 
#we plot these two variables in two dimensional space where each point has two co-ordinates 

#Next, find one line that splits these points 
#such that the distances from the closest point in each of the two groups will be farthest away.
#This line is classifier. 
#Depending on where the testing data lands on either side of the line, that's what class of the new data 


#In Scikit - different Kernel functions can be specified for the decision function
#decision function finds hyperplanes separating the space into areas associated with classification outcomes. 
#and gives Distance of the samples X to the separating hyperplane.
#Linear kernel seperates the plane linearly, non-linear kernel seperates the plan non-linear fashion with more complexity in time and storage space 

#Note start with simple kernel eg linear and try using non-linear ones to check score
#select the best kernel 

#Note If the number of features is much greater than the number of samples, 
#the method is likely to give poor performances

#scikit-learn support both dense (numpy.ndarray and convertible to that by numpy.asarray) 
#and sparse (any scipy.sparse)


##Scikit - SVM - Recomendations 
1.Setting C: C is 1 by default and it�s a reasonable default choice. 
  For noisy observations , decrease it. 
  It corresponds to regularize more the estimation.
2.Support Vector Machine algorithms are not scale invariant, 
  so Use StandardScaler or MinMaxScaler for train and test data 
3.In SVC, if data for classification are unbalanced (e.g. many positive and few negative), 
  set class_weight='balanced' and/or try different penalty parameters C.
4.To consistent result from run to run, use smaller tol parameter.
5.Using L1/L2 penalization by LinearSVC(loss='l2', penalty='l1', dual=False) 
  yields a sparse solution ie many coifficients for features becomes zero 
  Increasing C yields a more complex model (more feature are selected). 
6.Kernel cache size: For SVC, SVR, nuSVC and NuSVR, 
  the size of the kernel cache has a strong impact on run times for larger problems. 
  set cache_size to a higher value than the default of 200(MB), such as 500(MB) or 1000(MB).
7.Note start with simple kernel eg linear and try using non-linear ones and then  check score
  select the best kernel 
8.Check sklearn.metrics for various metrics for classification 
  hinge_loss is one good choice 
  
  
##Scikit - SVM - kernel function:
#It takes two inputs and returns a number interpreting how similar they are(ie find distance)
�linear: (x, x')
�polynomial: (gamma*(x, x')+ r)^d 
 d is specified by keyword degree, r by coef0, gamma by gamma(small value )
�rbf: exp(-gamma*|x-x'|^2). 
 gamma is specified by keyword gamma, must be greater than 0.
�sigmoid tanh(gamma(x,x') + r)
 where r is specified by coef0.
 
>>> linear_svc = svm.SVC(kernel='linear')
>>> linear_svc.kernel
'linear'
>>> rbf_svc = svm.SVC(kernel='rbf')
>>> rbf_svc.kernel
'rbf'

  
  
##Parameters of the Radial Basis Function (RBF) kernel - C and gamma. 
C, common to all SVM kernels
    trades off misclassification of training examples against simplicity of the decision surface. 
    A low C makes the decision surface smooth, 
    while a high C aims at classifying all training examples correctly. 
gamma 
    defines how much influence a single training example has. 
    The larger gamma is, the closer other examples must be to be affected.
    
#Proper choice of C and gamma is critical to the SVM�s performance.
#use sklearn.model_selection.GridSearchCV with C 
#and gamma spaced exponentially far apart to choose good values.


#SVC and NuSVC are similar methods, but accept slightly different sets of parameters 
#C-Support Vector Classification.
class sklearn.svm.SVC(C=1.0, kernel='rbf', degree=3, gamma='auto', coef0=0.0, 
        shrinking=True, probability=False, tol=0.001, cache_size=200, class_weight=None, verbose=False, max_iter=-1, decision_function_shape=None, random_state=None)
    kernel: 'linear', 'poly', 'rbf', 'sigmoid', 'precomputed' or a callable
    C : float, optional (default=1.0),Penalty parameter C of the error term

#Nu-Support Vector Classification.
class sklearn.svm.NuSVC(nu=0.5, kernel='rbf', degree=3, gamma='auto', coef0=0.0, shrinking=True, probability=False, tol=0.001, cache_size=200, class_weight=None, 
        verbose=False, max_iter=-1, decision_function_shape=None, random_state=None)
    nu : float, optional (default=0.5),An upper bound on the fraction of training errors 
        and a lower bound of the fraction of support vectors. 
        Should be in the interval (0, 1].

#LinearSVC is another implementation of Support Vector Classification for the case of a linear kernel
class sklearn.svm.LinearSVC(penalty='l2', loss='squared_hinge', dual=True, tol=0.0001, C=1.0, multi_class='ovr', fit_intercept=True, intercept_scaling=1, 
        class_weight=None, verbose=0, random_state=None, max_iter=1000)
    penalty : string, 'l1' or 'l2' (default='l2')

##Scikit - SVM - Regression - use SVR, NuSVR and LinearSVR

sklearn.svm.SVR(kernel='rbf', degree=3, gamma='auto', coef0=0.0, tol=0.001, C=1.0, 
        epsilon=0.1, shrinking=True, cache_size=200, verbose=False, max_iter=-1)
        
sklearn.svm.NuSVR(nu=0.5, C=1.0, kernel='rbf', degree=3, gamma='auto', coef0=0.0, 
        shrinking=True, tol=0.001, cache_size=200, verbose=False, max_iter=-1)

sklearn.svm.LinearSVR(epsilon=0.0, tol=0.0001, C=1.0, loss='epsilon_insensitive', 
        fit_intercept=True, intercept_scaling=1.0, dual=True, verbose=0, random_state=None, max_iter=1000)



      

    

###*** Combining various steps and Tunning  -  Pipeline and GridSearchCV/RandomizedSearchCV


###Searching parameters using GridSearchCV and RandomizedSearchCV (uses CV)

#get parameters(hyperparameters) by searching a parameter space for the best Cross-validation score
#Example - hyperparameters are C, kernel and gamma for Support Vector Classifier,  alpha for Lasso, etc.
#A search consists of:
�an estimator (regressor or classifier such as sklearn.svm.SVC());
�a parameter space, called param_grid/param_distributions
 Note param_grid is a dict with key=paramsName and value is list of values to try or a pdf distribution from scipy.stats.distributionName
 To get all paramameters of an estimator, use estimator.get_params([deep])
 In case of Pipeline , use stageName__estimatorParamName as key 
�a cross-validation scheme;
�a score function or list of such  
 Could be string name from sklearn.metrics or make_scorer with sklearn.metrics.*_score/_loss function 

##Reference 
class sklearn.model_selection.GridSearchCV(estimator, param_grid, scoring=None, 
            fit_params=None, n_jobs=1, iid=True, refit=True, cv=None, verbose=0, 
            pre_dispatch='2*n_jobs', error_score='raise', return_train_score='warn')
    Exhaustive search over specified parameter values for an estimator.
class sklearn.model_selection.RandomizedSearchCV(estimator, param_distributions, 
            n_iter=10, scoring=None, fit_params=None, n_jobs=1, 
            iid=True, refit=True, cv=None, verbose=0, pre_dispatch='2*n_jobs', 
            random_state=None, error_score='raise', return_train_score='warn')
    Randomized search on hyper parameters.
    In contrast to GridSearchCV, not all parameter values are tried out, 
    but rather a fixed number of parameter settings is sampled  from the specified distributions. 
    Hence faster than GridSearchCV
##Attributes:
    cv_results_ : dict of numpy (masked) ndarrays
        A dict with keys as column headers and values as columns, 
        that can be imported into a pandas DataFrame.
        The key 'params' is used to store a list of parameter settings dicts for all the parameter candidates.
        The mean_fit_time, std_fit_time, mean_score_time and std_score_time are all in seconds.
        For multi-metric evaluation, the scores for all the scorers are available 
        in the cv_results_ dict at the keys ending with that scorer's name ('_<scorer_name>') instead of '_score'       
    best_estimator_ : estimator or dict
        Estimator that was chosen by the search, 
        i.e. estimator which gave highest score (or smallest loss if specified) on the left out data.
        Not available if refit=False.
    best_score_ : float
        Mean cross-validated score of the best_estimator
    best_params_ : dict
        Parameter setting that gave the best results on the hold out data.
    best_index_ : int
        The index (of the cv_results_ arrays) which corresponds to the best candidate parameter setting.
    scorer_ : function or a dict
        Scorer function used on the held out data to choose the best parameters  for the model.
    n_splits_ : int
        The number of cross-validation splits (folds/iterations).
#Methods
    decision_function(X)    Call decision_function on the estimator with the best found parameters. 
    fit(X[, y, groups])     Run fit with all sets of parameters. 
    inverse_transform(Xt)   Call inverse_transform on the estimator with the best found params. 
    predict(X)              Call predict on the estimator with the best found parameters. 
    predict_log_proba(X)    Call predict_log_proba on the estimator with the best found parameters. 
    predict_proba(X)        Call predict_proba on the estimator with the best found parameters. 
    score(X[, y])           Returns the score on the given data, if the estimator has been refit. 
    set_params(**params)    Set the parameters of this estimator. 
    get_params([deep])      Get parameters for this estimator.
    transform(X)            Call transform on the estimator with the best found parameters. 

#Note 
GridSearchCV/RandomizedSearchCV -  Parallelism
    use the keyword n_jobs=-1.
GridSearchCV/RandomizedSearchCV -  Robustness to failure 
    Some parameter settings may result in a failure to fit one or more folds 
    of the data, use error_score=0 (or =np.NaN)  
GridSearchCV/RandomizedSearchCV - Default metric
    By default, it uses sklearn.metrics.accuracy_score for classification 
    and sklearn.metrics.r2_score for regression
    note scoring=can be list of scorer method strings, 
    in this case, mention refit=Best_scoring_method_as_string
GridSearchCV/RandomizedSearchCV - Other scoring functions from sklearn.metrics 
    Check score/loss function from sklearn.metrics and convert to scorer by sklearn.metrics.make_scorer
    >>> dir(sklearn.metrics)
    Or use string as given below  
    #scoring string         Function                        Comment
    #Classification     
    'accuracy'              metrics.accuracy_score   
    'average_precision'     metrics.average_precision_score   
    'f1'                    metrics.f1_score                for binary targets 
    'f1_micro'              metrics.f1_score                micro-averaged 
    'f1_macro'              metrics.f1_score                macro-averaged 
    'f1_weighted'           metrics.f1_score                weighted average 
    'f1_samples'            metrics.f1_score                by multilabel sample 
    'neg_log_loss'          metrics.log_loss r              equires predict_proba support 
    'precision' etc.        metrics.precision_score         suffixes apply as with 'f1' 
    'recall' etc.           metrics.recall_score            suffixes apply as with 'f1' 
    'roc_auc'               metrics.roc_auc_score   
    #Clustering     
    'adjusted_rand_score'   metrics.adjusted_rand_score   
    #Regression     
    'neg_mean_absolute_error'   metrics.mean_absolute_error   
    'neg_mean_squared_error'    metrics.mean_squared_error   
    'neg_median_absolute_error' metrics.median_absolute_error   
    'r2'                        metrics.r2_score 

##RandomizedSearchCV can take either a list of parameter values to try 
#or a distribution object with an rvs method for sampling(eg scipy.stats.distributions)

class expon_vector(stats.rv_continuous):
    def __init__(self, loc = 1.0, scale = 50.0, min_size=2, max_size = 10):
        self.loc = loc
        self.scale = scale
        self.min_size = min_size
        self.max_size = max_size
        self.size = max_size - min_size # Only for initialization
    def rvs(self):

        self.size = randint.rvs(low = self.min_size, 
                                high = self.max_size, size = 1)
        return expon.rvs(loc  = self.loc, scale = self.scale, size = self.size)
        
from scipy.stats import randint as sp_randint
from scipy.stats import expon
param_grid = [ {'svm_c': expon(scale=100, loc=5),
                    'mkl_c': expon(scale=100, loc=5),
                    'degree': sp_randint(0, 24),
                    'widths': expon_vector(loc = 0.1, scale = 100.0, 
                              min_size = 2, max_size = 10) } ]


###PipeLine 

#Pipeline can be used in GridSearchCV/RandomizedSearchCV/cross_val_predict/cross_val_score/cross_validate
#as pipeline supports fit, transform, fit_transform, predict, get_params 
#However in GridSearchCV/RandomizedSearchCV param_grid use stepName__paramName as dict key 

#All estimators in a pipeline, except the last one, must be transformers (i.e. must have a transform method). 
#The last estimator may be any type (transformer, classifier, etc.)
#Calling fit on the pipeline is the same as calling fit on each estimator in turn,
#transform the input and pass it on to the next step. 
#The pipeline has all the methods that the last estimator in the pipeline has,
#i.e. if the last estimator is a classifier, the Pipeline can be used as a classifier. 
#If the last estimator is a transformer, so is the pipeline.  
    

##Reference 
class sklearn.pipeline.Pipeline(steps, memory=None)
    The purpose of the pipeline is to assemble several steps that can be cross-validated 
    together while setting different parameters
    steps : list
        List of (name, transform) tuples 
        where name is userdefined string 
        where transform (implementing fit/transform) that are chained, 
        with the last object an estimator.


        
###Example of Pipeline with Gridsearch with Iris data (SVC)
#SVC: The fit time complexity is more than quadratic with the number of samples which makes it hard to scale to dataset with more than a couple of 10000 samples.
#SVC: The multiclass support is handled according to a one-vs-one scheme.
#C : float, optional (default=1.0)
#Penalty parameter C of the error term.


from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.decomposition import PCA


# generate some data to play with
iris = load_iris()
X, y = iris.data, iris.target 

#Split the data 
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)

#
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()

#Create estimators 
estimators = [('reduce_dim', PCA()), ('scaler', scaler),('clf', SVC())]
pipe = Pipeline(estimators)


>>> pipe 
Pipeline(steps=[('reduce_dim', PCA(copy=True, iterated_power='auto',n_components=None, random_state=None, svd_solver='auto', tol=0.0,whiten=False)), 
('clf', SVC(C=1.0, cache_size=200, class_weight=None,coef0=0.0, decision_function_shape=None, degree=3, gamma='auto',kernel='rbf', max_iter=-1, probability=False, random_state=None,shrinking=True, tol=0.001, verbose=False))])


#The estimators of a pipeline are stored as a list in the steps attribute:
>>>> pipe.steps[0]
('reduce_dim', PCA(copy=True, iterated_power='auto', n_components=None, random_state=None,
  svd_solver='auto', tol=0.0, whiten=False))

#OR as a dict in named_steps:
>>> pipe.named_steps['reduce_dim']
PCA(copy=True, iterated_power='auto', n_components=None, random_state=None,
  svd_solver='auto', tol=0.0, whiten=False)

#Get all parameters name of the Pipeline 
#includes 'self' and steps parameters 
>>> sorted(pipe.get_params().keys())
['clf', 'clf__C', 'clf__cache_size', 'clf__class_weight', 'clf__coef0', 'clf__decision_function_shape', 'clf__degree', 'clf__gamma', 'clf__kernel', 'clf__max_iter', 'clf__probability', 'clf__random_state', 'clf__shrinking', 'clf__tol', 'clf__verbose', 'memory', 'reduce_dim', 'reduce_dim__copy', 'reduce_dim__iterated_power', 'reduce_dim__n_components', 'reduce_dim__random_state', 'reduce_dim__svd_solver', 'reduce_dim__tol', 'reduce_dim__whiten', 'steps']

#Parameters of the estimators in the pipeline can be accessed 
#using the <estimator_name>__<parameter> syntax:
pipe.set_params(clf__C=10) 

#Then fit and predict 
pipe.fit(X_train, y_train)
prediction = pipe.predict(X_test)
>>> pipe.score(X_test, y_test)     #0.9393939393939394



#for example: for doing grid searches over parameter range 
from sklearn.model_selection import GridSearchCV
params = dict(reduce_dim__n_components=[2, 5, 10],clf__C=[0.1, 10, 100])
grid_search = GridSearchCV(pipe, param_grid=params, return_train_score=True)



#even with Estimators 
from sklearn.linear_model import LogisticRegression
params = dict(reduce_dim=[None, PCA(5), PCA(10)],
                clf=[SVC(), LogisticRegression()],
                clf__C=[0.1, 10, 100])
grid_search = GridSearchCV(pipe, param_grid=params, return_train_score=True)

#Then check the best parameter 
grid_search.fit(X, y)


#With customized CV 
C_range = np.logspace(-2, 10, 3)
gamma_range = np.logspace(-9, 3, 3)
param_grid = dict(clf__gamma=gamma_range, clf__C=C_range, clf__kernel=['linear', 'rbf'])

cv = sklearn.model_selection.StratifiedShuffleSplit(n_splits=3, test_size=0.2, random_state=42)

grid_search = GridSearchCV(pipe, param_grid=param_grid, cv=cv)
grid_search.fit(X, y)
print("The best parameters are %s with a score of %0.2f" % (grid_search.best_params_, grid_search.best_score_))
scores = grid_search.cv_results_['mean_test_score'].reshape(len(C_range), len(gamma_range))





#Estimator that was chosen by the search, 
#i.e. estimator which gave highest score (or smallest loss if specified)on the left out data
best_pipeline = grid_search.best_estimator_
best_pipeline.score(X_test, y_test) #0.9696969696969697
#best_params_ : Parameter setting that gave the best results on the hold out data.
>>> grid_search.best_params_
{'reduce_dim__n_components': 5, 'clf__C': 0.1}
#best_index_ : int,The index (of the cv_results_ arrays) which corresponds to the best candidate parameter setting.
grid_search.best_index_
#best_score_ : float,Mean cross-validated score of the best_estimator
grid_search.best_score_
#cv_results_: Full result grid of CV , time is in sec 
pd.DataFrame(grid_search.cv_results_)


### Transforming target in regression

TransformedTargetRegressor transforms the targets y before fitting a regression model. The predictions are mapped back to the original space via an inverse transform. It takes as an argument the regressor that will be used for prediction, and the transformer that will be applied to the target variable:
>>>

>>> import numpy as np
>>> from sklearn.datasets import load_boston
>>> from sklearn.compose import TransformedTargetRegressor
>>> from sklearn.preprocessing import QuantileTransformer
>>> from sklearn.linear_model import LinearRegression
>>> from sklearn.model_selection import train_test_split
>>> boston = load_boston()
>>> X = boston.data
>>> y = boston.target
>>> transformer = QuantileTransformer(output_distribution='normal')
>>> regressor = LinearRegression()
>>> regr = TransformedTargetRegressor(regressor=regressor,
...                                   transformer=transformer)
>>> X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
>>> regr.fit(X_train, y_train) 
TransformedTargetRegressor(...)
>>> print('R2 score: {0:.2f}'.format(regr.score(X_test, y_test)))
R2 score: 0.67
>>> raw_target_regr = LinearRegression().fit(X_train, y_train)
>>> print('R2 score: {0:.2f}'.format(raw_target_regr.score(X_test, y_test)))
R2 score: 0.64

### ColumnTransformer for heterogeneous data

Warning

The compose.ColumnTransformer class is experimental and the API is subject to change.

Many datasets contain features of different types, say text, floats, and dates, where each type of feature requires separate preprocessing or feature extraction steps. Often it is easiest to preprocess data before applying scikit-learn methods, for example using pandas. Processing your data before passing it to scikit-learn might be problematic for one of the following reasons:

    Incorporating statistics from test data into the preprocessors makes cross-validation scores unreliable (known as data leakage), for example in the case of scalers or imputing missing values.
    You may want to include the parameters of the preprocessors in a parameter search.

The ColumnTransformer helps performing different transformations for different columns of the data, within a Pipeline that is safe from data leakage and that can be parametrized. ColumnTransformer works on arrays, sparse matrices, and pandas DataFrames.

To each column, a different transformation can be applied, such as preprocessing or a specific feature extraction method:
>>>

>>> import pandas as pd
>>> X = pd.DataFrame(
...     {'city': ['London', 'London', 'Paris', 'Sallisaw'],
...      'title': ["His Last Bow", "How Watson Learned the Trick",
...                "A Moveable Feast", "The Grapes of Wrath"],
...      'expert_rating': [5, 3, 4, 5],
...      'user_rating': [4, 5, 4, 3]})

For this data, we might want to encode the 'city' column as a categorical variable, but apply a feature_extraction.text.CountVectorizer to the 'title' column. As we might use multiple feature extraction methods on the same column, we give each transformer a unique name, say 'city_category' and 'title_bow'. By default, the remaining rating columns are ignored (remainder='drop'):
>>>

>>> from sklearn.compose import ColumnTransformer
>>> from sklearn.feature_extraction.text import CountVectorizer
>>> column_trans = ColumnTransformer(
...     [('city_category', CountVectorizer(analyzer=lambda x: [x]), 'city'),
...      ('title_bow', CountVectorizer(), 'title')],
...     remainder='drop')

>>> column_trans.fit(X) 
ColumnTransformer(n_jobs=None, remainder='drop', sparse_threshold=0.3,
    transformer_weights=None,
    transformers=...)

>>> column_trans.get_feature_names()
... 
['city_category__London', 'city_category__Paris', 'city_category__Sallisaw',
'title_bow__bow', 'title_bow__feast', 'title_bow__grapes', 'title_bow__his',
'title_bow__how', 'title_bow__last', 'title_bow__learned', 'title_bow__moveable',
'title_bow__of', 'title_bow__the', 'title_bow__trick', 'title_bow__watson',
'title_bow__wrath']

>>> column_trans.transform(X).toarray()
... 
array([[1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0],
       [1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0],
       [0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
       [0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1]]...)

In the above example, the CountVectorizer expects a 1D array as input and therefore the columns were specified as a string ('city'). However, other transformers generally expect 2D data, and in that case you need to specify the column as a list of strings (['city']).

Apart from a scalar or a single item list, the column selection can be specified as a list of multiple items, an integer array, a slice, or a boolean mask. Strings can reference columns if the input is a DataFrame, integers are always interpreted as the positional columns.

We can keep the remaining rating columns by setting remainder='passthrough'. The values are appended to the end of the transformation:
>>>

>>> column_trans = ColumnTransformer(
...     [('city_category', CountVectorizer(analyzer=lambda x: [x]), 'city'),
...      ('title_bow', CountVectorizer(), 'title')],
...     remainder='passthrough')

>>> column_trans.fit_transform(X)
... 
array([[1, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 5, 4],
       [1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 3, 5],
       [0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 4, 4],
       [0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 5, 3]]...)

The remainder parameter can be set to an estimator to transform the remaining rating columns. The transformed values are appended to the end of the transformation:
>>>

>>> from sklearn.preprocessing import MinMaxScaler
>>> column_trans = ColumnTransformer(
...     [('city_category', CountVectorizer(analyzer=lambda x: [x]), 'city'),
...      ('title_bow', CountVectorizer(), 'title')],
...     remainder=MinMaxScaler())

>>> column_trans.fit_transform(X)[:, -2:]
... 
array([[1. , 0.5],
       [0. , 1. ],
       [0.5, 0.5],
       [1. , 0. ]])

The make_column_transformer function is available to more easily create a ColumnTransformer object. Specifically, the names will be given automatically. The equivalent for the above example would be:
>>>

>>> from sklearn.compose import make_column_transformer
>>> column_trans = make_column_transformer(
...     (CountVectorizer(analyzer=lambda x: [x]), 'city'),
...     (CountVectorizer(), 'title'),
...     remainder=MinMaxScaler())
>>> column_trans 
ColumnTransformer(n_jobs=None, remainder=MinMaxScaler(copy=True, ...),
         sparse_threshold=0.3,
         transformer_weights=None,
         transformers=[('countvectorizer-1', ...)





###Use of cross_val_predict/cross_val_score/cross_validate to get better estimates 

#Note train_test_split holds some data for Testing and that can not be used for training, reducing space for estimation 
#Use cross_val_predict/cross_val_score with crossvalidation strategy(arg=cv) 
#For example, cross_val_predict/cross_val_score with k-fold strategy (cv = sklearn.model_selection.KFold)
    the training set is split into k smaller sets 
    The following procedure is followed for each of the k 'folds':
        �A model is trained using k-1 of the folds as training data;
        �the resulting model is validated on the remaining part of the data 

##cv strategy(arg=cv)
sklearn.model_selection.StratifiedKFold(n_splits=3, shuffle=False, random_state=None)
    Stratified K-Folds cross-validator 
sklearn.model_selection.KFold(n_splits=3, shuffle=False, random_state=None)
    K-Folds cross-validator 
#http://scikit-learn.org/stable/modules/cross_validation.html#cross-validation-iterators
model_selection.GroupKFold([n_splits])                  K-fold iterator variant with non-overlapping groups. 
model_selection.LeaveOneGroupOut()                      Leave One Group Out cross-validator 
model_selection.LeavePGroupsOut(n_groups)               Leave P Group(s) Out cross-validator 
model_selection.LeaveOneOut()                           Leave-One-Out cross-validator 
model_selection.LeavePOut(p)                            Leave-P-Out cross-validator 
model_selection.ShuffleSplit([n_splits, ...])           Random permutation cross-validator 
model_selection.GroupShuffleSplit([...])                Shuffle-Group(s)-Out cross-validation iterator 
model_selection.StratifiedShuffleSplit([...])           Stratified ShuffleSplit cross-validator 
model_selection.PredefinedSplit(test_fold)              Predefined split cross-validator 
model_selection.TimeSeriesSplit([n_splits])             Time Series cross-validator 


##Reference  
sklearn.model_selection.cross_val_score(estimator, X, y=None, groups=None, 
            scoring=None, cv=None, n_jobs=1, verbose=0, fit_params=None, 
            pre_dispatch='2*n_jobs')
    scoring : string, callable or None, optional, default: None
        A string from sklearn.metrics  or a scorer callable object / function  
        with signature scorer(estimator, X, y).
        Check loss/score function from below and convert to scorer by sklearn.metrics.make_scorer(score_func, greater_is_better=True, needs_proba=False, needs_threshold=False, **kwargs)
        >>> dir(sklearn.metrics)
    cv : int, cross-validation generator or an iterable, optional
        Determines the cross-validation splitting strategy. 
        Possible inputs for cv are:
        �None, to use the default 3-fold cross validation,
        �integer, to specify the number of folds in a (Stratified)KFold,
        �An object to be used as a cross-validation generator.
        Check 
        >>> dir(sklearn.model_selection )
        �An iterable yielding train, test splits.
        For integer/None inputs, if the estimator is a classifier 
        and y is either binary or multiclass, StratifiedKFold is used. 
        In all other cases, KFold is used.
    n_jobs : integer, optional
        The number of CPUs to use to do the computation. -1 means 'all CPUs'.
    Returns:
    scores : array of float, shape=(len(list(cv)),)
        Array of scores of the estimator for each run of the cross validation.
        
sklearn.model_selection.cross_val_predict(estimator, X, y=None, groups=None, 
            cv=None, n_jobs=1, verbose=0, fit_params=None, pre_dispatch='2*n_jobs', 
            method='predict')
    Generate cross-validated estimates(predicted) for each input data point
    Returns: one predictions array for all folds: ndarray
    method : string, optional, default: �predict�
        Invokes the passed method name of the passed estimator. 
        For method=�predict_proba�, the columns correspond to the classes in sorted order.
    
   
#Example for iris data 
#for example - to estimate the accuracy of SVC by splitting the data, 
#fitting a model and computing the score 5 consecutive times 
from sklearn import datasets
iris = datasets.load.iris()

from sklearn.model_selection import cross_val_score
clf = svm.SVC(kernel='linear', C=1)

from sklearn.model_selection import cross_val_predict
predicted = cross_val_predict(clf, iris.data, iris.target, cv=10) #to get single predictions array out of all folds
>>> metrics.accuracy_score(iris.target, predicted) 
0.973...
#OR 
scores = cross_val_score(clf, iris.data, iris.target, cv=5) #to get score(ndarray) for each fold,
>>> scores                                              
array([ 0.96...,  1.  ...,  0.96...,  0.96...,  1.        ])

#mean score and the 95% CI the score estimate are hence given by
>>> print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
Accuracy: 0.98 (+/- 0.03)

#With new score function 
from sklearn import metrics
scores = cross_val_score(clf, iris.data, iris.target, cv=5, scoring='f1_macro')
>>> scores                                              
array([ 0.96...,  1.  ...,  0.96...,  0.96...,  1.        ])

#with new CV strategy 
from sklearn.model_selection import ShuffleSplit
n_samples = iris.data.shape[0]
cv = ShuffleSplit(n_splits=3, test_size=0.3, random_state=0)
>>> cross_val_score(clf, iris.data, iris.target, cv=cv)                                              
array([ 0.97...,  0.97...,  1.        ])

#Can be used with pipeline
from sklearn.pipeline import make_pipeline
clf = make_pipeline(preprocessing.StandardScaler(), svm.SVC(C=1))
>>> cross_val_score(clf, iris.data, iris.target, cv=cv)                                      
array([ 0.97...,  0.93...,  0.95...])



##Advanced crossvalidation - can evaluate a range of scoring 
sklearn.model_selection.cross_validate(estimator, X, y=None, groups=None, 
            scoring=None, cv=None, n_jobs=1, verbose=0, fit_params=None, 
            pre_dispatch='2*n_jobs', return_train_score='warn')
    Evaluate metric or metrics by cross-validation and also record fit/score times.
    Returns:
    scores : dict of float arrays of shape=(n_splits,)
        Array of scores of the estimator for each run of the cross validation.
        A dict of arrays containing the score/time arrays for each scorer is returned. 
        The possible keys for this dict are:
            test_score
                The score array for test scores on each cv split.
            train_score
                The score array for train scores on each cv split. This is available only if return_train_score parameter is True.
            fit_time
                The time for fitting the estimator on the train set for each cv split.
            score_time
                The time for scoring the estimator on the test set for each cv split. (Note time for scoring on the train set is not included even if return_train_score is set to True
        For single metric evaluation, 
        where the scoring parameter is a string, callable or None, 
        the keys will be - ['test_score', 'fit_time', 'score_time']
        And for multiple metric evaluation, the return value is a dict 
        with the following keys - 
        ['test_<scorer1_name>', 'test_<scorer2_name>', 'test_<scorer...>', 'fit_time', 'score_time']

       
#Example 

from sklearn.model_selection import cross_validate


#Single metric evaluation using cross_validate
cv_results = cross_validate(clf, iris.data, iris.target, return_train_score=False)
>>> sorted(cv_results.keys())                         
['fit_time', 'score_time', 'test_score']
>>> cv_results['test_score']    
array([ 0.33...,  0.08...,  0.03...])

#Multiple metric evaluation using cross_validate 
scoring = ['precision_macro', 'recall_macro']

scores = cross_validate(clf, iris.data, iris.target, scoring=scoring,cv=5, return_train_score=False)
>>> sorted(scores.keys())
['fit_time', 'score_time', 'test_precision_macro', 'test_recall_macro']
>>> scores['test_recall_macro']                       
array([ 0.96...,  1.  ...,  0.96...,  0.96...,  1.        ])

#Or as a dict mapping scorer name to a predefined or custom scoring function:
from sklearn.metrics.scorer import make_scorer
scoring = {'prec_macro': 'precision_macro',
           'rec_micro': make_scorer(recall_score, average='macro')}
scores = cross_validate(clf, iris.data, iris.target, scoring=scoring,
                        cv=5, return_train_score=True)
>>> sorted(scores.keys())                 
['fit_time', 'score_time', 'test_prec_macro', 'test_rec_micro',
 'train_prec_macro', 'train_rec_micro']
>>> scores['train_rec_micro']                         
array([ 0.97...,  0.97...,  0.99...,  0.98...,  0.98...])



## Cross validation of time series data
class sklearn.model_selection.TimeSeriesSplit(n_splits=3, max_train_size=None)

#Example of 3-split time series cross-validation on a dataset with 6 samples:
from sklearn.model_selection import TimeSeriesSplit

X = np.array([[1, 2], [3, 4], [1, 2], [3, 4], [1, 2], [3, 4]])
y = np.array([1, 2, 3, 4, 5, 6])
tscv = TimeSeriesSplit(n_splits=3)
>>> print(tscv)  
TimeSeriesSplit(max_train_size=None, n_splits=3)
>>> for train, test in tscv.split(X):
...     print("%s %s" % (train, test))
[0 1 2] [3]
[0 1 2 3] [4]
[0 1 2 3 4] [5]


##Validation curves: plotting scores to evaluate models
#Every estimator has its advantages and drawbacks. Its generalization error can be decomposed in terms of bias, variance and noise. The bias of an estimator is its average error for different training sets. The variance of an estimator indicates how sensitive it is to varying training sets. Noise is a property of the data.

#The function validation_curve can help in this case:
>>>

>>> import numpy as np
>>> from sklearn.model_selection import validation_curve
>>> from sklearn.datasets import load_iris
>>> from sklearn.linear_model import Ridge

>>> np.random.seed(0)
>>> iris = load_iris()
>>> X, y = iris.data, iris.target
>>> indices = np.arange(y.shape[0])
>>> np.random.shuffle(indices)
>>> X, y = X[indices], y[indices]

>>> train_scores, valid_scores = validation_curve(Ridge(), X, y, "alpha",
...                                               np.logspace(-7, 3, 3),
...                                               cv=5)
>>> train_scores            
array([[0.93..., 0.94..., 0.92..., 0.91..., 0.92...],
       [0.93..., 0.94..., 0.92..., 0.91..., 0.92...],
       [0.51..., 0.52..., 0.49..., 0.47..., 0.49...]])
>>> valid_scores           
array([[0.90..., 0.84..., 0.94..., 0.96..., 0.93...],
       [0.90..., 0.84..., 0.94..., 0.96..., 0.93...],
       [0.46..., 0.25..., 0.50..., 0.49..., 0.52...]])

If the training score and the validation score are both low, the estimator will be underfitting. If the training score is high and the validation score is low, the estimator is overfitting and otherwise it is working very well. A low training score and a high validation score is usually not possible. All three cases can be found in the plot below where we vary the parameter
of an SVM on the digits dataset.


##Learning curve

A learning curve shows the validation and training score of an estimator for varying numbers of training samples. It is a tool to find out how much we benefit from adding more training data and whether the estimator suffers more from a variance error or a bias error. If both the validation score and the training score converge to a value that is too low with increasing size of the training set, we will not benefit much from more training data. In the following plot you can see an example: naive Bayes roughly converges to a low score.

We can use the function learning_curve to generate the values that are required to plot such a learning curve (number of samples that have been used, the average scores on the training sets and the average scores on the validation sets):
>>>

>>> from sklearn.model_selection import learning_curve
>>> from sklearn.svm import SVC

>>> train_sizes, train_scores, valid_scores = learning_curve(
...     SVC(kernel='linear'), X, y, train_sizes=[50, 80, 110], cv=5)
>>> train_sizes            
array([ 50, 80, 110])
>>> train_scores           
array([[0.98..., 0.98 , 0.98..., 0.98..., 0.98...],
       [0.98..., 1.   , 0.98..., 0.98..., 0.98...],
       [0.98..., 1.   , 0.98..., 0.98..., 0.99...]])
>>> valid_scores           
array([[1. ,  0.93...,  1. ,  1. ,  0.96...],
       [1. ,  0.96...,  1. ,  1. ,  0.96...],
       [1. ,  0.96...,  1. ,  1. ,  0.96...]])








###*** Concatenating various transformers output into one Tranformer  - Use FeatureUnion 
#Union of all feature extracted components to create a large feature matrix 

#Concatenates( column/feature stacking) results of multiple transformer objects.
#This estimator applies a list of transformer objects in parallel 
#to the input data, then concatenates the results. 
#This is useful to combine several feature extraction mechanisms  into a single transformer.

#Parameters of the transformers may be set using its name and the parameter name separated by a �__�. 
#A transformer may be replaced entirely by setting the parameter with its name to another transformer, or removed by setting to None.



##Reference 
class sklearn.pipeline.FeatureUnion(transformer_list, n_jobs=1, transformer_weights=None)
        transformer_list : list of (string, transformer) tuples
            List of transformer objects to be applied to the data. 
        n_jobs : int, optional
            Number of jobs to run in parallel (default 1).
        transformer_weights : dict, optional
            Multiplicative weights for features per transformer. 
            Keys are transformer names, values the weights.
    #Methods
    fit(X[, y])             Fit all transformers using X. 
    fit_transform(X[, y])   Fit all transformers, transform the data and concatenate results. 
    get_feature_names()     Get feature names from all transformers. 
    get_params([deep])      Get parameters for this estimator. 
    set_params(**kwargs)    Set the parameters of this estimator. 
                            string = object
                            Parameters passed to the fit method of each step, 
                            eg: parameter 'p' for step with name 's' has key 's__p'.
                            (Note double underscore)
    transform(X)            Transform X separately by each transformer, concatenate results. 


###Example of Iris with Feature union  
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.model_selection import GridSearchCV
from sklearn.svm import SVC
from sklearn.datasets import load_iris
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest

iris = load_iris()
X, y = iris.data, iris.target
#Split the data 
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)

# This dataset is way too high-dimensional. Better do PCA:
pca = PCA(n_components=2)

# Maybe some original features where good, too?
selection = SelectKBest(k=1)

# Build estimator from PCA and Univariate selection:
combined_features = FeatureUnion([("pca", pca), ("univ_select", selection)])

>>> sorted(combined_features.get_params().keys())
['n_jobs', 'pca', 'pca__copy', 'pca__iterated_power', 'pca__n_components', 
'pca__random_state', 'pca__svd_solver', 'pca__tol', 'pca__whiten', 'transformer_list'
, 'transformer_weights', 'univ_select', 'univ_select__k', 'univ_select__score_func']

# Set new value and Use combined features to transform dataset:
combined_features.set_params(univ_select__k=1)
X_features = combined_features.fit(X, y).transform(X)
>>> X.shape, X_features.shape
((150, 4), (150, 3))

#Or Do a gridsearch for best param of SVC 
svm = SVC(kernel="linear")
pipeline = Pipeline([("features", combined_features), ("svm", svm)])
param_grid = dict(features__pca__n_components=[1, 2, 3],
                  features__univ_select__k=[1, 2],
                  svm__C=[0.1, 1, 10])

grid_search = GridSearchCV(pipeline, param_grid=param_grid)
grid_search.fit(X, y)
best_pipeline = grid_search.best_estimator_
grid_search.best_params_
best_pipeline.score(X_test, y_test) #1.0

 
 
 
 

###*** Linear Regression & metrics for linear regression 


##Linear Model Selection and Regularization 
#Regularization - technique for solving overfitting by L1,L2 norms (probably along with CV to determin those parameters)

ElasticNet Model 
    Combination of L1 and L2 penalty 
    The class ElasticNetCV can be used to set the parameters alpha and l1_ratio  by cross-validation.
    regParam , alpha
        corresponds to regularization parameter (called alpha),  
        controls the overall strength of the penalty, higher the value, more roboust to colinearity
    elasticNetParam, l1_ratio
        corresponds to L1/L2 ratio,  in range [0, 1]. 
        For elasticParam = 0, the penalty is an L2 penalty(ridge). 
        For elasticParam = 1, it is an L1 penalty(lasso)
        
Ridge Model        
    alpha is a complexity parameter that controls the amount of shrinkage
    the larger the value of alpha, the greater the amount of shrinkage 
    and thus the coefficients become more robust to collinearity.
    Use CV version to get best alpha
        reg = linear_model.RidgeCV(alphas=[0.1, 1.0, 10.0])

Lasso 
    alpha parameter controls the degree of sparsity of the coefficients estimated.
    For high-dimensional datasets with many collinear regressors, use LassoCV which optimizes alpha 
    LassoLarsCV is used  if the number of samples is very small compared to the number of features
    when alpha is 0, Lasso regression produces the same coefficients as a linear regression. 
    When alpha is very very large, all coefficients are zero.


###Example - boston - With alpha and Lasso , coefficients are sparse 

from sklearn.linear_model import *
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import load_boston
import pandas as pd

boston = load_boston() #['DESCR', 'data', 'feature_names', 'target']

scaler = StandardScaler()
X = scaler.fit_transform(boston["data"])
Y = boston["target"]
names = boston["feature_names"]

# Create a function called lasso,
def lasso(alphas):
    df = pd.DataFrame()    
    # Create a column of feature names
    df['Features Name'] = names
    for alpha in alphas:
        lasso = Lasso(alpha=alpha)        
        lasso.fit(X, Y)        
        column_name = 'Alpha = %f' % alpha
        df[column_name] = lasso.coef_
    #Optimized alpha 
    lcv = LassoCV()
    lcv.fit(X, Y)        
    column_name = 'Best Alpha = %f' % lcv.alpha_
    df[column_name] = lcv.coef_
    return df

#Note with increasing alpha, coefficients are zero 
lasso([.0001, .5, 10])   
    
    
    
    
    
##Data in general 
X 
    {array-like, sparse matrix}, shape (n_samples, n_features)
    Training vector, where n_samples is the number of samples and n_features is the number of features.
    Must be float32/float64 , use .astype(np.float64)
    String must be one hot encoded , use scikit-pandas for Dataframe or df.values if homogeneousely float64
y : array-like, shape (n_samples,)
    Target vector relative to X.
    For classifications, must be binary numeric or multiclass numeric or one hot coded if multilabel

##Methods for Regression 
fit(X, y[, sample_weight])                      
    Fit  model with coordinate descent 
path(X, y[, l1_ratio, eps, n_alphas, �]) 
    Compute elastic net path with coordinate descent 
predict(X)                      
    Predict using the linear model 
score(X, y[, sample_weight])    
    Returns the coefficient of determination R^2 of the prediction. 
set_params(**params)            
    Set the parameters of this estimator.
get_params([deep])              
    Get parameters for this estimator. 
    

    
    
##Below models are included 
#suffix CV means parameters are choosen by CrossValidation -for reducing overfitting 
#(there would be 'cv' argument in calling)
  
#OLS
linear_model.LinearRegression([...])               
    Ordinary least squares Linear Regression. 

#LogisticRegression is for classification 
linear_model.LogisticRegression([penalty, ...])     
    Logistic Regression (aka logit, MaxEnt) classifier. 
linear_model.LogisticRegressionCV([Cs, ...])        
    Logistic Regression CV (aka logit, MaxEnt) classifier. 


#SGD(Stochastic gradient descent)- for large-scale and sparse machine learning problems 
#often encountered in text classification and natural language processing. 
#cons: SGD is sensitive to feature scaling, hence use StandardScaler/MinMaxScaler/MaxAbsScaler
linear_model.SGDClassifier([loss, penalty, ...])    
    Linear classifiers with SGD(Stochastic gradient descent ) training. 
linear_model.SGDRegressor([loss, penalty, ...])     
    Linear model fitted by minimizing a regularized empirical loss with SGD 

#Perceptron:simple algorithm suitable for large scale learning
#slightly faster to train than SGD with the hinge loss 
#and that the resulting models are sparser
linear_model.Perceptron([penalty, alpha, ...]) 

#Ridge:Ridge regression addresses some of the problems of Ordinary Least Squares 
#by imposing a penalty on the size of coefficients.
#the larger the value of alpha the greater the amount of shrinkage 
#and thus the coefficients become more robust to collinearity(ie 2 or more features are corelated)
linear_model.Ridge([alpha, fit_intercept, ...]) 
    Linear least squares with l2 regularization. 
linear_model.RidgeClassifier([alpha, ...])          
    Classifier using Ridge regression. 
linear_model.RidgeClassifierCV([alphas, ...])       
    Ridge classifier with built-in cross-validation. 
linear_model.RidgeCV([alphas, ...])                 
    Ridge regression with built-in cross-validation. 
    
    
#Fit a Bayesian ridge model and optimize the regularization parameters lambda (precision of the weights) 
#and alpha (precision of the noise).
#It adapts to the data at hand and includes regularization parameters in the estimation procedure.
#time consuming 
linear_model.BayesianRidge([n_iter, tol, ...])      
    Bayesian ridge regression 
    
    
#Automatic Relevance Determination (ARD)Regression is very similar to Bayesian Ridge Regression, 
#but can lead to sparser weights w 
linear_model.ARDRegression([n_iter, tol, ...])      
    Bayesian ARD regression. 


##ElasticNet:ElasticNet is a linear regression model trained with L1 and L2 prior as regularizer. 
#This combination allows for learning a sparse model where few of the weights 
#are non-zero like Lasso, while still maintaining the regularization properties of Ridge.
linear_model.ElasticNet([alpha, l1_ratio, ...])     
    Linear regression with combined L1 and L2 priors as regularizer. 
linear_model.ElasticNetCV([l1_ratio, eps, ...])     
    Elastic Net model with iterative fitting along a regularization path 

    
##lasso:The Lasso is a linear model that estimates sparse coefficients.
#effectively reducing the number of variables  upon which the given solution is dependent.
#Lars:Least-angle regression (LARS) is also a regression algorithm for high-dimensional data
#cons: sensitive to noise 
linear_model.Lars([fit_intercept, verbose, ...])    
    Least Angle Regression model a.k.a. 
linear_model.LarsCV([fit_intercept, ...])           
    Cross-validated Least Angle Regression model 
linear_model.Lasso([alpha, fit_intercept, ...])     
    Linear Model trained with L1 prior as regularizer (aka the Lasso) 
linear_model.LassoCV([eps, n_alphas, ...])          
    Lasso linear model with iterative fitting along a regularization path 
linear_model.LassoLars([alpha, ...])                
    Lasso model fit with Least Angle Regression 
linear_model.LassoLarsCV([fit_intercept, ...])      
    Cross-validated Lasso, using the LARS algorithm 
linear_model.LassoLarsIC([criterion, ...])          
    Lasso model fit with Lars using BIC or AIC for model selection 

    
##OMP:algorithm for approximating the fit of a linear model 
#with constraints imposed on the number of non-zero coefficients 
linear_model.OrthogonalMatchingPursuit([...])       
    Orthogonal Matching Pursuit model (OMP) 
linear_model.OrthogonalMatchingPursuitCV([...])     
    Cross-validated Orthogonal Matching Pursuit model (OMP) 
linear_model.orthogonal_mp(X, y[, ...])             
    Orthogonal Matching Pursuit (OMP) 
linear_model.orthogonal_mp_gram(Gram, Xy[, ...])    
    Gram Orthogonal Matching Pursuit (OMP)

##The passive-aggressive algorithms are a family of algorithms for large-scale learning 
#with a regularization parameter C.
linear_model.PassiveAggressiveClassifier([...])     
    Passive Aggressive Classifier 
linear_model.PassiveAggressiveRegressor([C, ...])   
    Passive Aggressive Regressor 

##Multitask- that estimates sparse coefficients for multiple regression problems jointly
#Y is a 2D array, of shape (n_samples, n_tasks). 
linear_model.MultiTaskLasso([alpha, ...])           
    Multi-task Lasso model trained with L1/L2 mixed-norm as regularizer 
linear_model.MultiTaskElasticNet([alpha, ...])      
    Multi-task ElasticNet model trained with L1/L2 mixed-norm as regularizer 
linear_model.MultiTaskLassoCV([eps, ...])           
    Multi-task L1/L2 Lasso with built-in cross-validation. 
linear_model.MultiTaskElasticNetCV([...])           
    Multi-task L1/L2 ElasticNet with built-in cross-validation. 

    
    
##Randomized: The limitation of L1-based sparse models is that faced with a group of very correlated features, 
#they will select only one. 
#To mitigate this problem, it is possible to use randomization techniques, 
#reestimating the sparse model many times perturbing the design matrix or sub-sampling data 
#and counting how many times a given regressor is selected.
linear_model.RandomizedLasso([alpha, ...])          
    Randomized Lasso. 
linear_model.RandomizedLogisticRegression([...])    
    Randomized Logistic Regression 

    
    
##Models Robust to outliers and modeling errors 
#RANSAC is a non-deterministic algorithm producing only a reasonable result with a certain probability, 
#which is dependent on the number of iterations 
#HuberRegressor should be faster than RANSAC and Theil Sen unless the number of samples are very large,
# i.e n_samples >> n_features
#RANSAC is faster than Theil Sen and scales much better with the number of samples
#RANSAC will deal better with large outliers in the y direction (most common situation)
#Theil Sen will cope better with medium-size outliers in the X direction, 
#but this property will disappear in large dimensional settings.
#When in doubt, use RANSAC
linear_model.RANSACRegressor([...])                
    RANSAC (RANdom SAmple Consensus) algorithm. 
linear_model.HuberRegressor([epsilon, ...])         
    Linear regression model that is robust to outliers. 
linear_model.TheilSenRegressor([...])               
    Theil-Sen Estimator: robust multivariate regression model. 

    
##misc routines in linear_model 
linear_model.lars_path(X, y[, Xy, Gram, ...])       
    Compute Least Angle Regression or Lasso path using LARS algorithm [1] 
linear_model.lasso_path(X, y[, eps, ...])           
    Compute Lasso path with coordinate descent 
linear_model.lasso_stability_path(X, y[, ...])      
    Stability path based on randomized Lasso estimates 
linear_model.logistic_regression_path(X, y)         
    Compute a Logistic Regression model for a list of regularization parameters. 

    
    

###Regression metrics , sklearn.metric 
Estimator score method
    Estimators have a score method providing a default evaluation 
    criterion for the problem they are designed to solve   
    Use by model.score(X, y[, sample_weight]) after fitting 
Metric functions
    use sklearn.metrics.*_score(higher the better)
    or *_loss(lower the better) directly on the predicted Value 
With GridSearchCV/RandomizedSearchCV/cross_val_predict/cross_val_score/cross_validate
    Use string names from below 
    #scoring string         Function                    Comment
    #Regression     
    'mean_absolute_error'   metrics.mean_absolute_error   
    'mean_squared_error'    metrics.mean_squared_error   
    'median_absolute_error' metrics.median_absolute_error   
    'r2'                    metrics.r2_score   
    
##Reference of sklearn.metrics : Specific metrics for Regression 
metrics.explained_variance_score(y_true, y_pred)        Explained variance regression score function 
metrics.mean_absolute_error(y_true, y_pred)             Mean absolute error regression loss 
metrics.mean_squared_error(y_true, y_pred[, ...])       Mean squared error regression loss 
metrics.median_absolute_error(y_true, y_pred)           Median absolute error regression loss 
metrics.r2_score(y_true, y_pred[, ...])                 R^2 (coefficient of determination) regression score function. 


##Explained variance score - explained_variance_score()
#computes the explained variance regression score

#The best possible score is 1.0, lower values are worse.
from sklearn.metrics import explained_variance_score

from sklearn.linear_model import *
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import load_boston
import pandas as pd

boston = load_boston() #['DESCR', 'data', 'feature_names', 'target']

scaler = StandardScaler()
X = scaler.fit_transform(boston["data"])
y = boston["target"]

#Split the data 
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_true = train_test_split(X, y, test_size=0.33, random_state=42)

lcv = LassoCV()
lcv.fit(X_train, y_train)        
y_pred = pipe.predict(X_test)

>>> explained_variance_score(y_true, y_pred)  
0.957...


##Mean absolute error - mean_absolute_error()
#computes mean absolute error, a risk metric corresponding to the expected value 
#of the absolute error loss or l1-norm loss
from sklearn.metrics import mean_absolute_error

>>> mean_absolute_error(y_true, y_pred)
0.5

##Mean squared error - mean_squared_error()
#computes mean square error, a risk metric corresponding to the expected value of the 
#squared (quadratic) error loss or loss.
from sklearn.metrics import mean_squared_error

>>> mean_squared_error(y_true, y_pred)
0.375


##Median absolute error - median_absolute_error()
# is robust to outliers. 
#calculated by taking the median of all absolute differences between the target and the prediction
from sklearn.metrics import median_absolute_error

>>> median_absolute_error(y_true, y_pred)
0.5

##Rsquare score, the coefficient of determination
#provides a measure of how well future samples are likely to be predicted by the model. 

#Best possible score is 1.0 and it can be negative (because the model can be arbitrarily worse). 
#A constant model that always predicts the expected value of y, disregarding the input features, would get a R^2 score of 0.0.

from sklearn.metrics import r2_score
>>> r2_score(y_true, y_pred)  
0.948...


#MultiOuput regression 
y_true = [[0.5, 1], [-1, 1], [7, -6]]
y_pred = [[0, 2], [-1, 2], [8, -5]]
>>> r2_score(y_true, y_pred, multioutput='variance_weighted')
0.938...
y_true = [[0.5, 1], [-1, 1], [7, -6]]
y_pred = [[0, 2], [-1, 2], [8, -5]]
>>> r2_score(y_true, y_pred, multioutput='uniform_average')
0.936...
>>> r2_score(y_true, y_pred, multioutput='raw_values')
array([ 0.965...,  0.908...])
>>> r2_score(y_true, y_pred, multioutput=[0.3, 0.7])
0.925...




###Regression diagonstic - Scatter_matrix to check visually any co-relation of two variables 
from pandas.plotting import scatter_matrix
scatter_matrix(df, alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show()

##MSE 





###Regression diagonstic - Using yellowbrick 
$ pip install yellowbrick
$ python -m yellowbrick.download #download all dataset in cur dir data 


##Residuals Plot
#Residuals are the difference between  target variable (y) and the predicted value (y), 
#The residuals plot shows the difference between residuals on the vertical axis and the dependent variable, y on the horizontal axis, 
#allowing you to detect regions within the target that may be susceptible to more or less error.


#A common use of the residuals plot is to analyze the variance of the error of the regressor. 
#If the points are randomly dispersed around the horizontal axis, 
#a linear regression model is usually appropriate for the data; 
#otherwise, a non-linear model(eg GLM, use statsmodels, SVC(nonlinear kernel), Boosting) is more appropriate. 


from sklearn.model_selection import train_test_split

# Load the data
df = pd.read_csv("./data/concrete.csv")

# Identify the feature and target columns
feature_names = [
    'cement', 'slag', 'ash', 'water', 'splast', 'coarse', 'fine', 'age'
]
target_name = 'strength'


# Get the X and y data from the DataFrame
X = df[feature_names].as_matrix()
y = df[target_name].as_matrix()

# Create the train and test data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

from sklearn.linear_model import Ridge, Lasso
from yellowbrick.regressor import ResidualsPlot, PredictionError

# Instantiate the linear model and visualizer
ridge = Ridge()
visualizer = ResidualsPlot(ridge)

visualizer.fit(X_train, y_train)  # Fit the training data to the model
visualizer.score(X_test, y_test)  # Evaluate the model on the test data
visualizer.poof()                 # Draw/show/poof the data
#visualizer.poof(outpath="pcoords.png") #sve to file, ext determines file type 


#Note that if the histogram is not desired, it can be turned off with the hist=False flag
visualizer = ResidualsPlot(ridge, hist=False)





##Prediction Error Plot
#A prediction error plot shows the actual targets from the dataset against the predicted values 
#This allows us to see how much variance is in the model. 
#Data scientists can diagnose regression models using this plot by comparing against the 45 degree line, 
#where the prediction exactly matches the model.

lasso = Lasso()
visualizer = PredictionError(lasso)

visualizer.fit(X_train, y_train)  # Fit the training data to the visualizer
visualizer.score(X_test, y_test)  # Evaluate the model on the test data
g = visualizer.poof()             # Draw/show/poof the data


##Alpha Selection
#Regularization is designed to penalize model complexity, (complex model overfitts)
#therefore the higher the alpha, the less complex the model, decreasing the error due to variance (overfit). 
#Alphas that are too high on the other hand increase the error due to bias (underfit). 
#It is important, therefore to choose an optimal alpha such that the error is minimized in both directions.


import numpy as np
from sklearn.linear_model import LassoCV
from yellowbrick.regressor import AlphaSelection

# Create a list of alphas to cross-validate against
alphas = np.logspace(-10, 1, 400) #logspace(start, stop, num=50, endpoint=True, base=10.0, dtype=None)

# Instantiate the linear model and visualizer
model = LassoCV(alphas=alphas)
visualizer = AlphaSelection(model)

visualizer.fit(X, y)
g = visualizer.poof()








###HandsOn - Example - diabetes- Lasso, LassoCV 

import numpy as np
import matplotlib.pyplot as plt

from sklearn import datasets
from sklearn.linear_model import LassoCV
from sklearn.linear_model import Lasso
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score

diabetes = datasets.load_diabetes()

#plot scatter_matrix of each feature with other fetaure to understand colinearity
from pandas.plotting import scatter_matrix
import pandas as pd 
scatter_matrix(pd.DataFrame(diabetes.data, columns=diabetes.feature_names), alpha=0.2, figsize=(6, 6), diagonal='kde')
plt.show() 



X = diabetes.data
y = diabetes.target


lasso = Lasso(random_state=0)
alphas = np.logspace(-4, -0.5, 30) #logspace(start, stop, num=50, endpoint=True, base=10.0, dtype=None)

scores = list()
scores_std = list()

n_folds = 3

for alpha in alphas:
    lasso.alpha = alpha
    #get CV score, 3 as n_folds is 3 
    this_scores = cross_val_score(lasso, X, y, cv=n_folds, n_jobs=1)
    scores.append(np.mean(this_scores))
    scores_std.append(np.std(this_scores))
    
#Using optimized CV 
lasso_cv = LassoCV(alphas=alphas, random_state=0)
cv_scores = cross_val_score(lasso_cv, X, y, cv=n_folds, n_jobs=1)
scores.append(np.mean(cv_scores))
scores_std.append(np.std(cv_scores))
    
    
scores, scores_std = np.array(scores), np.array(scores_std)

plt.figure().set_size_inches(8, 6)
plt.semilogx(alphas, scores)

# plot error lines showing +/- std. errors of the scores
std_error = scores_std / np.sqrt(n_folds)

plt.semilogx(alphas, scores + std_error, 'b--')
plt.semilogx(alphas, scores - std_error, 'b--')

# alpha=0.2 controls the translucency of the fill color
plt.fill_between(alphas, scores + std_error, scores - std_error, alpha=0.2)

plt.ylabel('CV score +/- std error')
plt.xlabel('alpha')
plt.axhline(np.max(scores), linestyle='--', color='.5')
plt.xlim([alphas[0], alphas[-1]])

plt.show()


   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
    
    

'''
    Classification & metrics for classifications 
    SVM
    Decision Tree and ensemble methods 
    Clustering with KMeans 
    KNN
    AutoML and TPOT
'''
   
   
###*** Classification & metrics for classifications 

#All classifiers in scikit-learn do multiclass classification out-of-the-box. 


Multiclass and multilabel 
    All classifiers in scikit-learn do multiclass classification out-of-the-box. 
    OR use sklearn.multiclass module to experiment with different multiclass strategies.
    binary classification 
        target label maps to only two class 
    Multiclass classification 
        a classification task with more than two classes; 
        e.g., classify a set of images of fruits which may be oranges, apples, or pears. 
        Multiclass classification makes the assumption that each sample is assigned to one and only one label
        a fruit can be either an apple or a pear but not both at the same time.
        Other than inherently multiclass classifier, there are strategies for reducing the problem of multiclass classification 
        to multiple binary classification - One Vs the Rest and One vs One 
    Multilabel classification
        This assigns to each sample a set of target labels, instead of one target label  
        This can be thought as predicting properties of a data-point that are not mutually exclusive, 
        A text might be about any of religion, politics, finance or education at the same time or none of these.
    Multioutput regression 
        This assigns each sample a set of target values. 
        This can be thought of as predicting several properties for each data-point, 
        such as wind direction and magnitude at a certain location.
    Multioutput-multiclass classification called multi-task classification 
        A single estimator has to handle several joint classification tasks. 
        The output format is a 2d numpy array or sparse matrix.
        Multi-task classification is similar to the multi-output classification task with different model formulations. 
        The set of labels can be different for each output variable. 
        
        For instance, a sample could be assigned 'pear' for an output variable 
        that takes possible values in a finite set of species such as 'pear', 'apple'; 
        and 'blue' or 'green' for a second output variable that takes possible values 
        in a finite set of colors such as 'green', 'red', 'blue', 'yellow'...
        
        This means that any classifiers handling multi-output multiclass or multi-task classification tasks, 
        support the multi-label classification task as a special case. 

        At present, no metric in sklearn.metrics supports the multioutput-multiclass classification task.        

Inherently multiclass: 
    * sklearn.naive_bayes.BernoulliNB
    * sklearn.tree.DecisionTreeClassifier
    * sklearn.tree.ExtraTreeClassifier
    * sklearn.ensemble.ExtraTreesClassifier
    * sklearn.naive_bayes.GaussianNB
    * sklearn.neighbors.KNeighborsClassifier
    * sklearn.semi_supervised.LabelPropagation
    * sklearn.semi_supervised.LabelSpreading
    * sklearn.discriminant_analysis.LinearDiscriminantAnalysis
    * sklearn.svm.LinearSVC (setting multi_class='crammer_singer')
    * sklearn.linear_model.LogisticRegression (setting multi_class='multinomial')
    * sklearn.linear_model.LogisticRegressionCV (setting multi_class='multinomial')
    * sklearn.neural_network.MLPClassifier
    * sklearn.neighbors.NearestCentroid
    * sklearn.discriminant_analysis.QuadraticDiscriminantAnalysis
    * sklearn.neighbors.RadiusNeighborsClassifier
    * sklearn.ensemble.RandomForestClassifier
    * sklearn.linear_model.RidgeClassifier
    * sklearn.linear_model.RidgeClassifierCV
Multiclass as One-Vs-One: 
    * sklearn.svm.NuSVC
    * sklearn.svm.SVC.
    * sklearn.gaussian_process.GaussianProcessClassifier (setting multi_class = 'one_vs_one')
Multiclass as One-Vs-All: 
    * sklearn.ensemble.GradientBoostingClassifier
    * sklearn.gaussian_process.GaussianProcessClassifier (setting multi_class = 'one_vs_rest')
    * sklearn.svm.LinearSVC (setting multi_class='ovr')
    * sklearn.linear_model.LogisticRegression (setting multi_class='ovr')
    * sklearn.linear_model.LogisticRegressionCV (setting multi_class='ovr')
    * sklearn.linear_model.SGDClassifier
    * sklearn.linear_model.Perceptron
    * sklearn.linear_model.PassiveAggressiveClassifier
Support multilabel: 
    * sklearn.tree.DecisionTreeClassifier
    * sklearn.tree.ExtraTreeClassifier
    * sklearn.ensemble.ExtraTreesClassifier
    * sklearn.neighbors.KNeighborsClassifier
    * sklearn.neural_network.MLPClassifier
    * sklearn.neighbors.RadiusNeighborsClassifier
    * sklearn.ensemble.RandomForestClassifier
    * sklearn.linear_model.RidgeClassifierCV
Support multiclass-multioutput: 
    * sklearn.tree.DecisionTreeClassifier
    * sklearn.tree.ExtraTreeClassifier
    * sklearn.ensemble.ExtraTreesClassifier
    * sklearn.neighbors.KNeighborsClassifier
    * sklearn.neighbors.RadiusNeighborsClassifier
    * sklearn.ensemble.RandomForestClassifier

    
Data preprocessing 
    Note scikit only accepts label and feature with ndarray/sci.parse with float32/float64 type 
    In case of Pandas dataframe, use df.values to get ndarray(latest sklearn supports df directly)
    Use transformation convert other type(eg string) data to numerical value 
    module scikit-pandas simlifies many conversions, use it 
    binary/multiclass
        Accepts numerical class/target value ,No need to transform to one hot encoding 
        One way to transform string label/target to numerical , use LabelEncoder 
        LabelEncoder transforms to 0...NoOf_classes
        For categorical features with string , Use LabelBinarizer to transform to one hot encoding
        For categorical features with number, use OneHotEncoder
    multilabel
        Use MultiLabelBinarizer() to convert multilabel string/numeric categorical to multilabel  
        >>> from sklearn.preprocessing import MultiLabelBinarizer
        >>> y = [[2, 3, 4], [2], [0, 1, 3], [0, 1, 2, 3, 4], [0, 1, 2]]
        >>> MultiLabelBinarizer().fit_transform(y)
        array([[0, 0, 1, 1, 1],
               [0, 0, 1, 0, 0],
               [1, 1, 0, 1, 0],
               [1, 1, 1, 1, 1],
               [1, 1, 1, 0, 0]])


One-vs.-one
    In the one-vs.-one (OvO) reduction, 
    one trains K(K - 1)/2 binary classifiers for a K-way multiclass problem; 
    each receives the samples of a pair of classes from the original training set, and must learn to distinguish these two classes. 
    At prediction time, a voting scheme is applied: 
    all K (K - 1) / 2 classifiers are applied to an unseen sample 
    and the class that got the highest number of "+1" predictions gets predicted by the combined classifier
    Like OvR, OvO suffers from ambiguities in that some regions of its input space may receive the same number of votes
    ###Example of Multiclass with Iris 
    from sklearn import datasets
    from sklearn.multiclass import OneVsOneClassifier
    from sklearn.svm import LinearSVC
    iris = datasets.load_iris()
    X, y = iris.data, iris.target
    >>> OneVsOneClassifier(LinearSVC(random_state=0)).fit(X, y).predict(X)
    array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
           1, 2, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
           2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
           2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2])

    
One-vs.-rest
    The one-vs.-rest(or one-vs.-all, OvA or OvR, one-against-all, OAA) strategy involves 
    training a single classifier per class, with the samples of that class 
    as positive samples and all other samples as negatives. 
    This strategy requires the base classifiers to produce a real-valued confidence score 
    for its decision, rather than just a class label;
    Making decisions means applying all classifiers to an unseen sample x 
    and predicting the label k for which the corresponding classifier reports the highest confidence score
    OneVsRestClassifier supports multiclass and multilable(when input y is from MultiLabelBinarizer)
    ###Example of multiclass learning using OvR for iris:
    from sklearn import datasets
    from sklearn.multiclass import OneVsRestClassifier
    from sklearn.svm import LinearSVC
    iris = datasets.load_iris()
    X, y = iris.data, iris.target
    >>> OneVsRestClassifier(LinearSVC(random_state=0)).fit(X, y).predict(X)
    array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
           1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
           2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 1, 2, 2, 2, 2,
           2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2])


Error-Correcting Output-Codes         
    With these strategies, each class is represented in a Euclidean space, where each dimension can only be 0 or 1.
    each class is represented by a binary code (an array of 0 and 1). 
    The matrix which keeps track of the location/code of each class is called the code book. 
    The code size is the dimensionality of the aforementioned space. 
    Intuitively, each class should be represented by a code as unique as possible and a good code book should be designed to optimize classification accuracy
    In OutputCodeClassifier, the code_size attribute allows the user to control the number of classifiers 
    It is a percentage of the total number of classes.
    A number between 0 and 1 will require fewer classifiers than one-vs-the-rest
    A number greater than 1 will require more classifiers than one-vs-the-rest. 
    In this case, some classifiers will in theory correct for the mistakes made by other classifiers, hence the name �error-correcting
    #Exmaple of multiclass 
    from sklearn import datasets
    from sklearn.multiclass import OutputCodeClassifier
    from sklearn.svm import LinearSVC
    iris = datasets.load_iris()
    X, y = iris.data, iris.target
    clf = OutputCodeClassifier(LinearSVC(random_state=0),code_size=2, random_state=0)
    >>> clf.fit(X, y).predict(X)
    array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1,
           1, 2, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1,
           1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
           2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 1, 1, 2, 2, 2,
           2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2])
  

Multioutput regression
    Multioutput regression support can be added to any regressor with MultiOutputRegressor. 
    This strategy consists of fitting one regressor per target. 
    As MultiOutputRegressor fits one regressor per target it can not take advantage of correlations between targets.
    #Example 
    from sklearn.datasets import make_regression
    from sklearn.multioutput import MultiOutputRegressor
    from sklearn.ensemble import GradientBoostingRegressor
    X, y = make_regression(n_samples=10, n_targets=3, random_state=1)
    >>> MultiOutputRegressor(GradientBoostingRegressor(random_state=0)).fit(X, y).predict(X)
    array([[-154.75474165, -147.03498585,  -50.03812219],
           [   7.12165031,    5.12914884,  -81.46081961],
           [-187.8948621 , -100.44373091,   13.88978285],
           [-141.62745778,   95.02891072, -191.48204257],
           [  97.03260883,  165.34867495,  139.52003279],
           [ 123.92529176,   21.25719016,   -7.84253   ],
           [-122.25193977,  -85.16443186, -107.12274212],
           [ -30.170388  ,  -94.80956739,   12.16979946],
           [ 140.72667194,  176.50941682,  -17.50447799],
           [ 149.37967282,  -81.15699552,   -5.72850319]])

Multioutput classification
    Multioutput classification support can be added to any classifier with MultiOutputClassifier. 
    This strategy consists of fitting one classifier per target. 
    #Example 
    from sklearn.datasets import make_classification
    from sklearn.multioutput import MultiOutputClassifier
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.utils import shuffle
    import numpy as np
    X, y1 = make_classification(n_samples=10, n_features=100, n_informative=30, n_classes=3, random_state=1)
    y2 = shuffle(y1, random_state=1)
    y3 = shuffle(y1, random_state=2)
    Y = np.vstack((y1, y2, y3)).T
    n_samples, n_features = X.shape # 10,100
    n_outputs = Y.shape[1] # 3
    n_classes = 3
    forest = RandomForestClassifier(n_estimators=100, random_state=1)
    multi_target_forest = MultiOutputClassifier(forest, n_jobs=-1)
    >>> multi_target_forest.fit(X, Y).predict(X)
    array([[2, 2, 0],
           [1, 2, 1],
           [2, 1, 0],
           [0, 0, 2],
           [0, 2, 1],
           [0, 0, 2],
           [1, 1, 0],
           [1, 1, 1],
           [0, 0, 2],
           [2, 0, 0]])
         
         
##Data in general 
X 
    {array-like, sparse matrix}, shape (n_samples, n_features)
    Training vector, where n_samples is the number of samples and n_features is the number of features.
    Must be float32/float64 , use .astype(np.float64)
    String must be one hot encoded , use scikit-pandas for Dataframe or df.values if homogeneousely float64
y : array-like, shape (n_samples,)
    Target vector relative to X.
    For classifications, must be binary numeric or multiclass numeric or one hot coded if multilabel


    
##Methods for classifications , all might not be there in each estimator 
decision_function(X)        
    Predict decision function for samples. 
    decision function is more specific to the algorithm
    For example in LogisticRegression, it is confidence scores
    in SVC, finds hyperplanes separating the space into areas associated with classification outcomes. 
    and gives Distance of the samples X to the separating hyperplane.
    Note predict_proba depends on the loss function, 
    and decision_function is universally available and sometimes easy to compute 
    Parameters:	
        X : {array-like, sparse matrix}, shape = (n_samples, n_features)
    Returns:	
    Depends on Algorithm 
        LogisticRegression
            array, shape=(n_samples,) if n_classes == 2 else (n_samples, n_classes) :
            Confidence scores per (sample, class) combination. 
            In the binary case, confidence score for self.classes_[1] where >0 means this class would be predicted.
        SVC 
            array-like, shape (n_samples, n_classes * (n_classes-1) / 2)
            Returns the decision function of the sample for each class in the model. 
            If decision_function_shape=�ovr�, the shape is (n_samples, n_classes)
fit(X, y[, sample_weight])                      
    Fit  model with coordinate descent 
predict(X)                  
    Predict class labels for samples in X. 
    Returns 
        C : array, shape = [n_samples]
        Predicted class label per sample.
predict_log_proba(X)        
    Log of probability estimates. 
    Parameters:	
        X : array-like, shape = [n_samples, n_features]
    Returns:	
        T : array-like, shape = [n_samples, n_classes]
        Returns the log-probability of the sample for each class in the model, 
        where classes are ordered as they are in self.classes_.
predict_proba(X)            
    Probability estimates. 
    Parameters:	
        X : array-like, shape = [n_samples, n_features]
    Returns:	
        T : array-like, shape = [n_samples, n_classes]
        Returns the probability of the sample for each class in the model, 
        where classes are ordered as they are in self.classes_.
score(X, y[, sample_weight]) 
    Returns the mean accuracy on the given test data and labels. 
set_params(**params)        
    Set the parameters of this estimator. 
get_params([deep])              
    Get parameters for this estimator. 


    
### Classification Metrics 
Classifier score method
    Estimators have a score method providing a default evaluation 
    criterion for the problem they are designed to solve   
    Use by model.score(X, y[, sample_weight]) after fitting 
Metric functions
    use sklearn.metrics.*_score(higher the better)
    or *_loss(lower the better) directly on the predicted Value 
With GridSearchCV/RandomizedSearchCV/cross_val_predict/cross_val_score/cross_validate
    Use string names from below 
    OR use sklearn.metrics.make_scorer(sklearn.metrics.ANY_score_method)
    #scoring string         Function                    Comment
    #Classification     
    'accuracy'              metrics.accuracy_score   
    'average_precision'     metrics.average_precision_score   
    'f1'                    metrics.f1_score            for binary targets 
    'f1_micro'              metrics.f1_score            micro-averaged 
    'f1_macro'              metrics.f1_score            macro-averaged 
    'f1_weighted'           metrics.f1_score            weighted average 
    'f1_samples'            metrics.f1_score            by multilabel sample 
    'log_loss'              metrics.log_loss            requires predict_proba support 
    'precision' etc.        metrics.precision_score     suffixes apply as with 'f1' 
    'recall' etc.           metrics.recall_score        suffixes apply as with 'f1' 
    'roc_auc'               metrics.roc_auc_score   

    
###Example with cross_val_score and SVC with Iris 
from sklearn import svm, datasets
from sklearn.model_selection import cross_val_score
iris = datasets.load_iris()
X, y = iris.data, iris.target
clf = svm.SVC(probability=True, random_state=0)
>>> cross_val_score(clf, X, y, scoring='neg_log_loss') #Returns: scores : array of float, shape=(len(list(cv)),)
                                                       #Array of scores of the estimator for each run of the cross validation.
 
array([-0.07..., -0.16..., -0.06...])


#with GridSearchCV and fbeta_scoremake_scorer with SVC 
from sklearn.metrics import fbeta_score, make_scorer

#average : string, [None, �binary� (default), �micro�, �macro�, �samples�, �weighted�]
#for multiclass, choose how final score is calculated 
ftwo_scorer = make_scorer(fbeta_score, beta=2, average='weighted')

from sklearn.model_selection import GridSearchCV
from sklearn.svm import LinearSVC
grid = GridSearchCV(LinearSVC(), param_grid={'C': [1, 10]}, scoring=ftwo_scorer)
grid.fit(X,y)
grid.score(X,y)


##Example of customer scorer 
import numpy as np
def my_custom_loss_func(ground_truth, predictions):
    diff = np.abs(ground_truth - predictions).max()
    return np.log(1 + diff)

# loss_func will negate the return value of my_custom_loss_func,
#  which will be np.log(2), 0.693, given the values for ground_truth
#  and predictions defined below.
loss  = make_scorer(my_custom_loss_func, greater_is_better=False)
score = make_scorer(my_custom_loss_func, greater_is_better=True)

ground_truth = [[1, 1]]
predictions  = [0, 1]
from sklearn.dummy import DummyClassifier
clf = DummyClassifier(strategy='most_frequent', random_state=0)
clf = clf.fit(ground_truth, predictions)
>>> loss(clf,ground_truth, predictions) 
-0.69...
>>> score(clf,ground_truth, predictions) 
0.69...


##From binary to multiclass and multilabel

#While multiclass data is provided to the metric, like binary targets, as an array of class labels, 
#multilabel data is specified as an indicator matrix, in which cell [i, j] has value 1 if sample i has label j 
#and value 0 otherwise


#Some metrics are essentially defined for binary classification tasks (e.g. f1_score, roc_auc_score). 
#In these cases, by default only the positive label is evaluated, assuming by default that the positive class is labelled 1 (though this may be configurable through the pos_label parameter).

#In extending a binary metric to multiclass or multilabel problems, 
#(average=One_of_below)
"macro" 
    simply calculates the mean of the binary metrics, giving equal weight to each class. 
    In problems where infrequent classes are nonetheless important, 
    macro-averaging may be a means of highlighting their performance. 
    On the other hand, the assumption that all classes are equally important is often untrue, 
    such that macro-averaging will over-emphasize the typically low performance on an infrequent class.
"weighted" 
    accounts for class imbalance by computing the average of binary metrics 
    in which each class�s score is weighted by its presence in the true data sample.
"micro" 
    gives each sample-class pair an equal contribution to the overall metric 
    (except as a result of sample-weight). 
    Rather than summing the metric per class, 
    this sums the dividends and divisors that make up the per-class metrics 
    to calculate an overall quotient. 
    Micro-averaging may be preferred in multilabel settings, 
    including multiclass classification where a majority class is to be ignored.
"samples" 
    applies only to multilabel problems. 
    It does not calculate a per-class measure, instead calculating the metric over the true 
    and predicted classes for each sample in the evaluation data, 
    and returning their (sample_weight-weighted) average.
average=None
    Selecting  will return an array with the score for each class.


#Only  binary classification case:
sklearn.metrics.precision_recall_curve(y_true, probas_pred)     
    Compute precision-recall pairs for different probability thresholds 
sklearn.metrics.roc_curve(y_true, y_score[, pos_label, ...])    
    Compute Receiver operating characteristic (ROC) 
    Parameters 
    y_true : array, shape = [n_samples]
        True binary labels in range {0, 1} or {-1, 1}. 
        If labels are not binary, pos_label should be explicitly given.
    y_score : array, shape = [n_samples]
        Target scores, can either be probability estimates of the positive class, 
        confidence values, or non-thresholded measure of decisions 
        (as returned by 'decision_function' on some classifiers).
    pos_label : int or str, default=None
        Label considered as positive and others are considered negative.
    Returns fpr, tpr, thresholds
    '''
    https://en.wikipedia.org/wiki/Receiver_operating_characteristic
    Receiver operating characteristic
        Vary threashold for decision function and calculate fpr(1-specificity ie FP/(FP+TN)),tpr(sensitivity = TP/(TP+FN ))
    fpr : array, shape = [>2]
        Increasing false positive rates such that element i is the false positive rate of predictions with score >= thresholds[i].
    tpr : array, shape = [>2]
        Increasing true positive rates such that element i is the true positive rate of predictions with score >= thresholds[i].
    thresholds : array, shape = [n_thresholds]
        Decreasing thresholds on the decision function used to compute fpr and tpr. 
        thresholds[0] represents no instances being predicted and is arbitrarily set to max(y_score) + 1.
    '''
balanced_accuracy_score(y_true, y_pred[, �]) 
    Compute the balanced accuracy 

#Only for binary and multilabel (but not multiclass)
average_precision_score(y_true, y_score[, �]) 
    Compute average precision (AP) from prediction scores 
roc_auc_score(y_true, y_score[, average, �]) 
    Compute Area Under the Receiver Operating Characteristic Curve (ROC AUC) 
    from prediction scores. 

    
#Only Binary and multiclass case:
cohen_kappa_score(y1, y2[, labels, weights])        
    Cohen's kappa: a statistic that measures inter-annotator agreement, 
    Returns:kappa : float, number between -1 and 1. 
    The maximum value 1, means complete agreement; 
    zero or lower (-1) means chance agreement
confusion_matrix(y_true, y_pred[, labels])          
    Compute confusion matrix to evaluate the accuracy of a classification 
    Returns: C : array, shape = [n_classes, n_classes]
    entry i, j in a confusion matrix is the number of observations actually in group i, 
    but predicted to be in group j. 
    Diagonal should be max and offdiagonal should be zero
    
    for binary: two rows and two columns
    that reports the number of true positives(TP), false negatives(FN),  - Actual true row 
    and 2nd row as false positives(FP), and true negatives(TN) - actual false row 
    
    true positive (TP) eqv. with  true hit
    (TN) eqv. with correct rejection
    false positive (FP) eqv. with false alarm, Type I error 
    false negative (FN) eqv. with miss, Type II error
    
    #Other metrics based TP,TN,FP,EN 
    #sensitivity, recall, hit rate, or true positive rate (TPR)
    TPR  = TP/P   = TP /(TP + FN )
    #fall-out or false positive rate (FPR)
    FPR  = FP/N   = FP /(FP  + TN)    = 1 - TNR    
    #specificity or true negative rate (TNR)
    TNR  = TN /N   = TN/(T + FP)    
    #precision or positive predictive value (PPV)
    PPV  = TP/(TP+ FP)     
    
    #negative predictive value (NPV)
    NPV  = TN/(TN  + FN)  
    #miss rate or false negative rate (FNR)
    FNR  = FNP   = FN/(FN  + TP)     = 1 - TPR

    #false discovery rate (FDR)
    F D R  = F P /(F P  + T P)    = 1 - P P V    
    #false omission rate (FOR)
    F O R  = F N /(F N  + T N)     = 1 - N P V    
    #accuracy (ACC)
    A C C  = (T P  + T N)/(P + N )   = (T P  + T N)/(  T P  + T N  + F P  + F N )      
    #F1 score is the harmonic mean of precision and sensitivity
    F1   = 2 *P P V  * T P R /(  P P V  + T P R)     = 2 T P/(   2 T P  + F P  + F N)

hinge_loss(y_true, pred_decision[, labels, ...])    
    Average hinge loss (non-regularized) , 
    Mainly used for SVC 
    Returns:loss : float, lower the better 
sklearn.metrics.matthews_corrcoef(y_true, y_pred)               
    Compute the Matthews correlation coefficient (MCC) for binary classes 
    A coefficient of +1 represents a perfect prediction, 
    0 no better than random prediction 
    and -1 indicates total disagreement between prediction and observation

    
    
#Binary and multiclass and multilabel case:
accuracy_score(y_true, y_pred[, normalize, �]) 
    Accuracy classification score. 
classification_report(y_true, y_pred[, �]) 
    Build a text report showing the main classification metrics 
f1_score(y_true, y_pred[, labels, �]) 
    Compute the F1 score, also known as balanced F-score or F-measure 
fbeta_score(y_true, y_pred, beta[, labels, �]) 
    Compute the F-beta score 
hamming_loss(y_true, y_pred[, labels, �]) 
    Compute the average Hamming loss. 
jaccard_similarity_score(y_true, y_pred[, �]) 
    Jaccard similarity coefficient score 
log_loss(y_true, y_pred[, eps, normalize, �]) 
    Log loss, aka logistic loss or cross-entropy loss. 
precision_recall_fscore_support(y_true, y_pred) 
    Compute precision, recall, F-measure and support for each class 
precision_score(y_true, y_pred[, labels, �]) 
    Compute the precision 
recall_score(y_true, y_pred[, labels, �]) 
    Compute the recall 
zero_one_loss(y_true, y_pred[, normalize, �]) 
    Zero-one classification loss. 



##Example - confusion martrix (Binary and multiclass case)
from sklearn.metrics import confusion_matrix
from sklearn import svm, datasets

iris = datasets.load_iris()
X, y_true = iris.data, iris.target
clf = svm.SVC(probability=True, random_state=0)
y_pred = clf.fit(X, y_true).predict(X)

>>> confusion_matrix(y_true, y_pred)



##Hinge loss - hinge_loss(Binary and multiclass case), generally used for SVC 
#computes the average distance between the model and the data using hinge loss, 
#a one-sided metric that considers only prediction errors. 
#(Hinge loss is used in maximal margin classifiers such as support vector machines.)

#decision_function and predict 
#The desion function outputs  on which side of the hyperplane 
#generated by the classifier we are (and how far we are away from it). 
#Based on that information, the estimator then label the examples with the corresponding label

#in LinearSVC classifier, then decision_function will give you scores for each class label 
# and predict will give the class with the best score.



from sklearn import svm
from sklearn.metrics import hinge_loss

#clf from above for iris data 
pred_decision = clf.decision_function(X)
labels = np.array([0, 1, 2])
>>> hinge_loss(y_true, pred_decision, labels)  
0.56...


##Example of roc_curve(Only  binary classification)
import numpy as np
from sklearn import metrics
y = np.array([1, 1, 2, 2])
scores = np.array([0.1, 0.4, 0.35, 0.8]) #predict_proba

fpr, tpr, thresholds = metrics.roc_curve(y, scores, pos_label=2)
>>> fpr
array([ 0. ,  0.5,  0.5,  1. ])
>>> tpr
array([ 0.5,  0.5,  1. ,  1. ])
>>> thresholds
array([ 0.8 ,  0.4 ,  0.35,  0.1 ])


##average_precision_score  , Only for binary and multilabel (but not multiclass)
# Area under the precision-recall curve
#roc_curve  : Receiver operating characteristic (ROC), 1 is the best 
>>> metrics.roc_auc_score(y, scores)  #->1 better 
0.75
>>> metrics.average_precision_score(y_true, y_scores)  #->1 better 
0.79...



##accuracy_score - (Binary and multiclass and multilabel case)
from sklearn.metrics import accuracy_score

#y_true, y_pred from earlier iris data 
>>> accuracy_score(y_true, y_pred)
0.5
>>> accuracy_score(y_true, y_pred, normalize=False)
2

#In the multilabel case with binary label indicators:
>>> accuracy_score(np.array([[0, 1], [1, 1]]), np.ones((2, 2)))
0.5


##Classification report - (Binary and multiclass and multilabel case)
# a text report showing the main classification metrics. 
#support means no of observation in that category 
from sklearn.metrics import classification_report

#y_true, y_pred from earlier iris data 
target_names = ['Iris-setosa', 'Iris-versicolor', 'Iris-virginica']
>>> print(classification_report(y_true, y_pred, target_names=target_names))
                        precision    recall  f1-score   support

    Iris-setosa         0.67      1.00      0.80         2
    Iris-versicolor     0.00      0.00      0.00         1
    Iris-virginica      1.00      0.50      0.67         2

avg / total       0.67      0.60      0.59         5


##Hamming loss - (Binary and multiclass and multilabel case)
#computes the average Hamming loss or Hamming distance between two sets of samples
#lower the better 

#y_true, y_pred from earlier iris data 
>>> hamming_loss(y_true, y_pred)
0.25
#In the multilabel case with binary label indicators:
>>> hamming_loss(np.array([[0, 1], [1, 1]]), np.zeros((2, 2)))
0.75

##Jaccard similarity coefficient score - Binary and multiclass and multilabel case
#The Jaccard similarity coefficient of the i-th samples, 
#with a ground truth label set yi and predicted label set yi_hat, is defined as
#J(yi, yi_hat) = |yi INTERSECTION yi_hat|/|yi UNION yi_hat| where | | is set length 

#In binary and multiclass classification,
#the Jaccard similarity coefficient score is equal to the classification accuracy.

import numpy as np
from sklearn.metrics import jaccard_similarity_score

#y_true, y_pred from earlier iris data 
>>> jaccard_similarity_score(y_true, y_pred)
0.5
>>> jaccard_similarity_score(y_true, y_pred, normalize=False)
2

#In the multilabel case with binary label indicators:
>>> jaccard_similarity_score(np.array([[0, 1], [1, 1]]), np.ones((2, 2)))
0.75

##Precision, recall and F-measures - 1 the best , Binary and multiclass and multilabel case
#precision is the ability of the classifier not to label as positive a sample that is negative, 
#and recall is the ability of the classifier to find all the positive samples.
#F1 score is HM of precision and recall/sensitivity 
#The F-beta score is the weighted harmonic mean of precision and recall, 
#The beta parameter determines the weight of precision in the combined score
'''
    for binary: two rows and two columns
    that reports the number of true positives(TP), false negatives(FN),  - Actual true row 
    and 2nd row as false positives(FP), and true negatives(TN) - actual false row 
    

    #sensitivity, recall, hit rate, or true positive rate (TPR)
    TPR  = TP/P   = TP /(TP + FN )
    #precision or positive predictive value (PPV)
    PPV  = TP/(TP+ FP)     
    #accuracy (ACC)
    A C C  = (T P  + T N)/(P + N )   = (T P  + T N)/(  T P  + T N  + F P  + F N )      
    #F1 score is the harmonic mean of precision and sensitivity
    F1   = 2 *P P V  * T P R /(  P P V  + T P R)     = 2 T P/(   2 T P  + F P  + F N)
'''

from sklearn import metrics

#y_true, y_pred from earlier iris data 
#note average = 'micro', 'macro', 'weighted' or 'samples' or None 
>>> metrics.precision_score(y_true, y_pred)
1.0
>>> metrics.recall_score(y_true, y_pred)
0.5
>>> metrics.f1_score(y_true, y_pred)  
0.66...
>>> metrics.fbeta_score(y_true, y_pred, beta=0.5)  
0.83...
>>> metrics.fbeta_score(y_true, y_pred, beta=1)  
0.66...
>>> metrics.fbeta_score(y_true, y_pred, beta=2) 
0.55...
>>> metrics.precision_recall_fscore_support(y_true, y_pred, beta=0.5)  
(array([ 0.66...,  1.        ]), array([ 1. ,  0.5]), array([ 0.71...,  0.83...]), array([2, 2]...))


##Log loss, also called logistic regression loss or cross-entropy loss - Binary and multiclass and multilabel case
#log_loss function computes log loss given a list of ground-truth labels and a probability matrix, 
#as returned by an estimator's predict_proba method.
from sklearn.metrics import log_loss

#y_true, y_pred from earlier iris data 
>>> log_loss(y_true, y_pred)    
0.1738...







                 
###Probability calibration for Classifiers 
#When performing classification you often want not only to predict the class label, 
#but also obtain a probability of the respective label

#LogisticRegression returns well calibrated predictions by default as it directly optimizes log-loss. 
#In contrast, the other methods return biased probabilities
�GaussianNB tends to push probabilties to 0 or 1 
    (note the counts in the histograms). 
�RandomForestClassifier shows the opposite behavior: 
    the histograms show peaks at approximately 0.2 and 0.9 probability, 
    while probabilities close to 0 or 1 are very rare
�Linear Support Vector Classification (LinearSVC) 
    shows an even more sigmoid curve(S-curve)

##Solution - use CalibratedClassifierCV
sklearn.calibration.CalibratedClassifierCV(base_estimator=None, method='sigmoid', cv=3)
    In case that cv='prefit' 
    it is assumed that base_estimator has been fitted already 
    and all data is used for calibration

#Example of Iris Data 
import numpy as np


from sklearn.ensemble import RandomForestClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import log_loss

np.random.seed(0)

# Generate data
from sklearn.datasets import load_iris

iris = load_iris()
X, y = iris.data, iris.target
#Split the data 
from sklearn.model_selection import train_test_split
X_train_valid, X_test, y_train_valid, y_test = train_test_split(X, y, test_size=0.33, random_state=42)


# Train uncalibrated random forest classifier on whole train and validation
# data and evaluate on test data
clf = RandomForestClassifier(n_estimators=25)
clf.fit(X_train_valid, y_train_valid)
clf_probs = clf.predict_proba(X_test)
score = log_loss(y_test, clf_probs)

# Train random forest classifier, calibrate on validation data and evaluate
# on test data
clf = RandomForestClassifier(n_estimators=25)
clf.fit(X_train, y_train)
clf_probs = clf.predict_proba(X_test)

sig_clf = CalibratedClassifierCV(clf, method="sigmoid", cv="prefit")
sig_clf.fit(X_valid, y_valid)
sig_clf_probs = sig_clf.predict_proba(X_test)
sig_score = log_loss(y_test, sig_clf_probs)        
         
         
         
       


       
###HandsOn - Example - hand-written digits datasets - Comparison with various Classifiers 

# Standard scientific Python imports
import matplotlib.pyplot as plt

# Import datasets, classifiers and performance metrics
from sklearn import datasets, metrics
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC


# The digits dataset
digits = datasets.load_digits() #['DESCR', 'data', 'images', 'target', 'target_names']
print(digits.DESCR)


# 8x8 images of one channel uint8 ie grayscale image 
#>>> digits.keys()
#dict_keys(['images', 'target_names', 'data', 'target', 'DESCR'])
#>>> np.unique(digits.target)
#array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
#>>> digits.target_names
#array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
#>>> digits.data.shape
#(1797, 64)
#>>> digits.images.shape
#(1797, 8, 8)

# To apply a classifier on this data, we need to flatten the image, to
# turn the data in a (samples, feature) matrix:
n_samples = len(digits.images)
#data = digits.images.reshape((n_samples, -1)) #== digits.data




data = digits.data 
target = digits.target 


# Create a classifier: a support vector classifier
models = []
models.append(( 'LR' , LogisticRegression()))
models.append(( 'LDA' , LinearDiscriminantAnalysis()))
models.append(( 'KNN' , KNeighborsClassifier()))
models.append(( 'CART' , DecisionTreeClassifier()))
models.append(( 'NB' , GaussianNB()))
models.append(( 'SVM' , SVC(gamma=0.001)))

for name, classifier in models: 
    # We learn the digits on the first half of the digits
    classifier = classifier.fit(data[:n_samples // 2], target[:n_samples // 2])
    # Now predict the value of the digit on the second half:
    expected = target[n_samples // 2:]
    predicted = classifier.predict(data[n_samples // 2:])
    print("-----------------%s-----------------" % (name,) )
    print("Classification report for classifier %s:\n%s\n"% (classifier, metrics.classification_report(expected, predicted)))
    print("Confusion matrix:\n%s" % metrics.confusion_matrix(expected, predicted))
    print("accuracy:\n%s" % metrics.accuracy_score(expected, predicted))


#here classifier is the last value from models, ie SVC 
#Check first 4 prediction 
images_and_predictions = list(zip(digits.images[n_samples // 2:], predicted))

#look at the first 4 images
images_and_labels = list(zip(digits.images, digits.target))
for index, (image, label) in enumerate(images_and_labels[:4]):
    plt.subplot(2, 4, index + 1) #total ax, 8 as we are going to plot predicted as well 
    plt.axis('off')
    plt.imshow(image, cmap=plt.cm.gray_r, interpolation='nearest')
    plt.title('Training: %i' % label)
    
for index, (image, prediction) in enumerate(images_and_predictions[:4]):
    plt.subplot(2, 4, index + 5)
    plt.axis('off')
    plt.imshow(image, cmap=plt.cm.gray_r, interpolation='nearest')
    plt.title('Prediction: %i' % prediction)

plt.show()
 
          
         
         
       

       
         
         


###HandsOn - Example with mushrooms data 

import pandas as pd

dataset = pd.read_csv('./data/mushroom.csv')
names = [
    'class',
    'cap-shape',
    'cap-surface',
    'cap-color'
]
dataset.columns = names
>>> dataset.head()
       class cap-shape cap-surface cap-color
0     edible    convex      smooth    yellow
1     edible      bell      smooth     white
2  poisonous    convex       scaly     white
3     edible    convex      smooth      gray
4     edible    convex       scaly    yellow

features = ['cap-shape', 'cap-surface', 'cap-color']
target   = ['class']

X = dataset[features]
y = dataset[target]

'''
precision = true positives / (true positives + false positives)
recall = true positives / (false negatives + true positives)
F1 score = 2 * ((precision * recall) / (precision + recall))
'''



import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
from sklearn_pandas import DataFrameMapper, gen_features #don't bring other methods 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import f1_score
from sklearn.pipeline import Pipeline


def model_selection(X, y, estimator, return_model=False):
    #transformer for each column 
    feature_def = gen_features(
        columns=features,
        classes=[LabelEncoder]  #scikit_pandas can not handle OneHotEncoder after LabelEncoder as LabelEncoder expects 1D, oneHotEncoder expects 2D 
    )                           #Can use LabelBinarizer which is same as LabelEncoder, then OneHotEncoder
    X_mapper = DataFrameMapper(feature_def)
    y = LabelEncoder().fit_transform(y.values.ravel())
    #Note features categorical, so, convert them to OneHotEncoding 
    model = Pipeline([
        ('mapper', X_mapper),
        ('hotencoder', OneHotEncoder()), #OneHotEncoder requires numerical categorical 
        ('estimator', estimator)
    ])
    #
    model.fit(X, y)
    expected  = y
    predicted = model.predict(X)
    # Compute and return the F1 score (the harmonic mean of precision and recall)
    if not return_model:
        return (f1_score(expected, predicted))
    else:
        return model

# Try them all!
from sklearn.svm import LinearSVC, NuSVC, SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegressionCV, LogisticRegression, SGDClassifier
from sklearn.ensemble import BaggingClassifier, ExtraTreesClassifier, RandomForestClassifier

model_selection(X, y, LinearSVC())
#0.65846308387744845

model_selection(X, y, NuSVC())
#0.63838842388991346

model_selection(X, y, SVC())
#0.66251459711950167

model_selection(X, y, SGDClassifier())
#0.69944182052382997

model_selection(X, y, KNeighborsClassifier())
#0.65802139037433149

model_selection(X, y, LogisticRegressionCV())
#0.65846308387744845

model_selection(X, y, LogisticRegression())
#0.65812609897010799

model_selection(X, y, BaggingClassifier())
#0.687643484132343

model_selection(X, y, ExtraTreesClassifier())
#0.68713648045448383

model_selection(X, y, RandomForestClassifier())
#0.69317131158367451


###Visual Classification plot using yellowbrick
$ python -m yellowbrick.download

##Visual Model Evaluation

from yellowbrick.classifier import ClassificationReport

'''
precision
    Precision is the ability of a classiifer not to label an instance positive that is actually negative. For each class it is defined as as the ratio of true positives to the sum of true and false positives. Said another way, �for all instances classified positive, what percent was correct* �
recall
    Recall is the ability of a classifier to find all positive instances. For each class it is defined as the ratio of true positives to the sum of true positives and false negatives. Said another way, �for all instances that were actually positive, what percent was classified correctly* �
f1 score
    The F1 score is a weighted harmonic mean of precision and recall such that the best score is 1.0 and the worst is 0.0. Generally speaking, F1 scores are lower than accuracy measures as they embed precision and recall into their computation. As a rule of thumb, the weighted average of F1 should be used to compare classifier models, not global accuracy.
support
    Support is the number of actual occurrences of the class in the specified dataset. Imbalanced support in the training data may indicate structural weaknesses in the reported scores of the classifier and could indicate the need for stratified sampling or rebalancing. Support doesn�t change between models but instead diagnoses the evaluation process. 
'''

def visual_model_selection(X, y, estimator):
    model = model_selection(X, y, estimator, return_model=True)
    # Create a new figure to draw the classification report on
    _, ax = plt.subplots()
    # Instantiate the classification model and visualizer
    visualizer = ClassificationReport( model, ax=ax, classes=['edible', 'poisonous'] )
    visualizer.fit(X, y)
    visualizer.score(X, y)
    visualizer.poof()

    
visual_model_selection(X, y, LinearSVC())
visual_model_selection(X, y, NuSVC())
visual_model_selection(X, y, SVC())
visual_model_selection(X, y, SGDClassifier())
visual_model_selection(X, y, KNeighborsClassifier())
visual_model_selection(X, y, LogisticRegressionCV())
visual_model_selection(X, y, LogisticRegression())
visual_model_selection(X, y, BaggingClassifier())
visual_model_selection(X, y, ExtraTreesClassifier())
visual_model_selection(X, y, RandomForestClassifier())

    
    
##ROCAUC
#A ROCAUC (Receiver Operating Characteristic/Area Under the Curve) plot allows the user 
#to visualize the tradeoff between the classifier�s sensitivity and specificity.
#true curve would be full square in graph such that area under the curve is  1 

#ROC curves are typically used in binary classification
from yellowbrick.classifier import ROCAUC

logistic = model_selection(X, y, LogisticRegression(), True)
visualizer = ROCAUC(logistic)

visualizer.fit(X, y)  # Fit the training data to the visualizer
visualizer.score(X, y)  # Evaluate the model on the test data
g = visualizer.poof()   # Draw/show/poof the data, mention path to store in that 

#Another example with breastCancer 
from sklearn.datasets import load_breast_cancer
from yellowbrick.classifier import ROCAUC
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
data = load_breast_cancer()
X = data['data']
y = data['target']
X_train, X_test, y_train, y_test = train_test_split(X, y)
viz = ROCAUC(LogisticRegression())
viz.fit(X_train, y_train)
viz.score(X_test, y_test)
viz.poof() # mention path to store in that 





     
         
 
    
    
    
    
    
    
    
    
    
    
    
    
    

      
        
        
        
        
        
     
###*** scikit-learn(sklearn) - Decision Trees and ensemble Methods 
#Decision Trees (DTs) are a non-parametric supervised learning method 

#Simple to understand and to interpret. Trees can be visualised.
#Does not require preprocessing 
#cons: prone to overfitting 
#Solution- Consider performing dimensionality reduction (PCA, ICA, or Feature selection) 
#beforehand to give tree a better chance of finding features that are discriminative


##Tips 
#http://scikit-learn.org/stable/modules/tree.html#tips-on-practical-use
� Decision trees tend to overfit on data with a large number of features. 
  Getting the right ratio of samples to number of features is important, 
  since a tree with few samples in high dimensional space is very likely to overfit.
  
� Consider performing dimensionality reduction (PCA, ICA, or Feature selection) beforehand 
  to give  tree a better chance of finding features that are discriminative.
  
� Visualise  tree as you are training by using the export function. 
  Use max_depth=3 as an initial tree depth , then increase the depth.
  
� Remember that the number of samples required to populate the tree doubles for each additional level the tree grows to. 
  Use max_depth to control the size of the tree to prevent overfitting.
  
� Use min_samples_split or min_samples_leaf to control the number of samples at a leaf node. 
  A very small number will usually mean the tree will overfit, 
  whereas a large number will prevent the tree from learning the data. 
  Try min_samples_leaf=5 as an initial value. 
  If the sample size varies greatly, a float number can be used as percentage in these two parameters. 
  The main difference between the two is that min_samples_leaf guarantees a minimum number of samples in a leaf, 
  while min_samples_split can create arbitrary small leaves, though min_samples_split is more common in the literature.
  
� Balance your dataset before training to prevent the tree from being biased toward the classes that are dominant
  Class balancing can be done by sampling an equal number of samples from each class, 
  or preferably by normalizing the sum of the sample weights (sample_weight) for each class to the same value. 
  Also note that weight-based pre-pruning criteria, such as min_weight_fraction_leaf, 
  will then be less biased toward dominant classes than criteria that are not aware of the sample weights, 
  like min_samples_leaf.
  
�If the samples are weighted, it will be easier to optimize the tree structure using weight-based pre-pruning criterion 
 such as min_weight_fraction_leaf, which ensure that leaf nodes contain at least a fraction 
 of the overall sum of the sample weights.
 
�If the input matrix X is very sparse, it is recommended to convert to sparse csc_matrix before calling fit 
 and sparse csr_matrix before calling predict.
 Training time can be orders of magnitude faster for a sparse matrix input compared to a dense matrix 
 when features have zero values in most of the samples.


##Classifier 
class sklearn.tree.DecisionTreeClassifier(criterion='gini', 
        splitter='best', max_depth=None, 
        min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_features=None, random_state=None, max_leaf_nodes=None, min_impurity_decrease=0.0, min_impurity_split=None, class_weight=None, presort=False)
#Attributes 
classes_ : array of shape = [n_classes] or a list of such arrays
    The classes labels (single output problem), 
    or a list of arrays of class labels (multi-output problem).
feature_importances_ : array of shape = [n_features]
    The feature importances. The higher, the more important the feature
max_features_ : int,
    The inferred value of max_features.
tree_ : Tree object
    The underlying Tree object.

    
#DecisionTreeClassifier is capable of both binary 
#(where the labels are [-1, 1]) classification 
#and multiclass (where the labels are [0, �, K-1]) classification.

from sklearn.datasets import load_iris
from sklearn import tree
iris = load_iris()
clf = tree.DecisionTreeClassifier()
clf = clf.fit(iris.data, iris.target)
>>> clf.predict(iris.data[:1, :])
array([0])
#the probability of each class can be predicted
>>> clf.predict_proba(iris.data[:1, :])
array([[ 1.,  0.,  0.]])
>>> clf.feature_importances_
array([0.01333333, 0.        , 0.56405596, 0.42261071])
>>> iris.feature_names
['sepal length (cm)', 'sepal width (cm)', 'petal length (cm)', 'petal width (cm)']


#check the decision Tree visualization 
#install graphvz from https://graphviz.gitlab.io/_pages/Download/Download_windows.html
#and 
$ pip install graphviz
#example 
import graphviz 
dot_data = tree.export_graphviz(clf, out_file=None, 
                         feature_names=iris.feature_names,  
                         class_names=iris.target_names,  
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = graphviz.Source(dot_data)  
graph.render('iris') #'iris.pdf'








##Regression 
class sklearn.tree.DecisionTreeRegressor(criterion='mse', splitter='best', max_depth=None, min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_features=None, random_state=None, max_leaf_nodes=None, min_impurity_decrease=0.0, min_impurity_split=None, presort=False)
#Attributes 
classes_ : array of shape = [n_classes] or a list of such arrays
    The classes labels (single output problem), 
    or a list of arrays of class labels (multi-output problem).
feature_importances_ : array of shape = [n_features]
    The feature importances. The higher, the more important the feature
max_features_ : int,
    The inferred value of max_features.
tree_ : Tree object
    The underlying Tree object.


#Example 
from sklearn.datasets import load_boston
from sklearn.model_selection import cross_val_score
from sklearn.tree import DecisionTreeRegressor
boston = load_boston()
regressor = DecisionTreeRegressor(random_state=0)
>>> cross_val_score(regressor, boston.data, boston.target, cv=10) #accuracy score from 10 CV folds 
array([ 0.61..., 0.57..., -0.34..., 0.41..., 0.75...,
        0.07..., 0.29..., 0.33..., -1.42..., -1.77...])

>>> regressor.feature_importances_
array([0.01333333, 0.        , 0.56405596, 0.42261071])
>>> regressor.feature_names
['sepal length (cm)', 'sepal width (cm)', 'petal length (cm)', 'petal width (cm)']


        


###Ensemble methods - regressor and clssifications 
##Two families of ensemble methods
Averaging methods
    build several estimators independently and then to average their predictions. 
    On average, the combined estimator is usually better than any of the single base estimator 
    because its variance is reduced.
    Examples: Bagging methods, Forests of randomized trees, �
    bagging methods work best with strong and complex models (e.g., fully developed decision trees)
Boosting methods
    base estimators are built sequentially and one tries to reduce the bias of the combined estimator. 
    The motivation is to combine several weak models to produce a powerful ensemble.
    Examples: AdaBoost, Gradient Tree Boosting, �
    Boosting methods work best with weak models (e.g., shallow decision trees).




##Out of Bag Estimates 
�When random subsets of the dataset are drawn as random subsets of the samples, 
 then this algorithm is known as Pasting
�When samples are drawn with replacement, then the method is known as Bagging 
�When random subsets of the dataset are drawn as random subsets of the features, 
 then the method is known as Random Subspaces 
�Finally, when base estimators are built on subsets of both samples and features, 
 then the method is known as Random Patches 


##Bagging meta-estimator
class sklearn.ensemble.BaggingClassifier(base_estimator=None, n_estimators=10, max_samples=1.0, max_features=1.0, bootstrap=True, bootstrap_features=False, oob_score=False, warm_start=False, n_jobs=1, random_state=None, verbose=0)
class sklearn.ensemble.BaggingRegressor(base_estimator=None, n_estimators=10, max_samples=1.0, max_features=1.0, bootstrap=True, bootstrap_features=False, oob_score=False, warm_start=False, n_jobs=1, random_state=None, verbose=0)
    Takes one base-estimator and then uses Averaging method to get the best predictions 
    max_samples and max_features control the size of the subsets (in terms of samples and features), 
    while bootstrap and bootstrap_features control whether samples and features are drawn with or without replacement. 
    When using a subset of the available samples the generalization accuracy can be estimated 
    with the out-of-bag samples by setting oob_score=True
    
    
##Random forest 
#Based on randomized decision trees
#Like decision trees, forests of trees also extend to multi-output problems (if Y is an array of size [n_samples, n_outputs]).
RandomForestClassifier(n_estimators=10, criterion=�gini�, max_depth=None, min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_features=�auto�, max_leaf_nodes=None, min_impurity_decrease=0.0, min_impurity_split=None, bootstrap=True, oob_score=False, n_jobs=1, random_state=None, verbose=0, warm_start=False, class_weight=None)
RandomForestRegressor(n_estimators=10, criterion=�mse�, max_depth=None, min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_features=�auto�, max_leaf_nodes=None, min_impurity_decrease=0.0, min_impurity_split=None, bootstrap=True, oob_score=False, n_jobs=1, random_state=None, verbose=0, warm_start=False)

##Extremely Randomized Trees- advanced than RandomForest
ExtraTreesClassifier(n_estimators=10, criterion=�gini�, max_depth=None, min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_features=�auto�, max_leaf_nodes=None, min_impurity_decrease=0.0, min_impurity_split=None, bootstrap=False, oob_score=False, n_jobs=1, random_state=None, verbose=0, warm_start=False, class_weight=None)
ExtraTreesRegressor(n_estimators=10, criterion=�mse�, max_depth=None, min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_features=�auto�, max_leaf_nodes=None, min_impurity_decrease=0.0, min_impurity_split=None, bootstrap=False, oob_score=False, n_jobs=1, random_state=None, verbose=0, warm_start=False)

#The main parameters to adjust 
n_estimators
    number of trees in the forest. 
    The larger the better, but also the longer it will take to compute
max_features
    size of the random subsets of features to consider when splitting a node. 
    The lower the greater the reduction of variance, but also the greater the increase in bias. 
    Take max_features=n_features for regression problems, 
    and max_features=sqrt(n_features) for classification tasks 
n_jobs 
    If n_jobs=k then computations are partitioned into k jobs, and run on k cores of the machine. 
    If n_jobs=-1 then all cores available on the machine are used

##boosting methods, 
#base estimators are built sequentially 
#and one tries to reduce the bias of the combined estimator. 
#The motivation is to combine several weak models to produce a powerful ensemble.
GradientBoostingRegressor(loss=�ls�, learning_rate=0.1, n_estimators=100, subsample=1.0, criterion=�friedman_mse�, min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_depth=3, min_impurity_decrease=0.0, min_impurity_split=None, init=None, random_state=None, max_features=None, alpha=0.9, verbose=0, max_leaf_nodes=None, warm_start=False, presort=�auto�)
GradientBoostingClassifier(loss=�deviance�, learning_rate=0.1, n_estimators=100, subsample=1.0, criterion=�friedman_mse�, min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, max_depth=3, min_impurity_decrease=0.0, min_impurity_split=None, init=None, random_state=None, max_features=None, verbose=0, max_leaf_nodes=None, warm_start=False, presort=�auto�)

AdaBoostClassifier(base_estimator=None, n_estimators=50, learning_rate=1.0, algorithm=�SAMME.R�, random_state=None)
AdaBoostRegressor(base_estimator=None, n_estimators=50, learning_rate=1.0, loss=�linear�, random_state=None)

#For largeDataset,use RandomForestClassifier as an alternative to GradientBoostingClassifier .
#As GradientBoostingClassifier memory requirements would be huge 

#Imp attributes 
estimators_ : list of DecisionTreeClassifier
    The collection of fitted sub-estimators.
classes_ : array of shape = [n_classes] or a list of such arrays(Only for Classifiers)
    The classes labels (single output problem), or a list of arrays of class labels (multi-output problem).
n_classes_ : int or list (Only for Classifiers)
    The number of classes (single output problem), or a list containing the number of classes for each output (multi-output problem).
n_features_ : int
    The number of features when fit is performed.
n_outputs_ : int
    The number of outputs when fit is performed.
feature_importances_ : array of shape = [n_features]
    The feature importances (the higher, the more important the feature).
oob_score_ : float
    Score of the training dataset obtained using an out-of-bag estimate.

##GBRT 
#The advantages of GBRT are:
�Natural handling of data of mixed type (= heterogeneous features)
�Predictive power
�Robustness to outliers in output space (via robust loss functions)
#The disadvantages of GBRT are:
�Scalability, due to the sequential nature of boosting it can hardly be parallelized


##Loss Function of GBRT 
#Regression
* Least squares ('ls')
    The natural choice for regression due to its superior computational properties. 
    The initial model is given by the mean of the target values.
* Least absolute deviation ('lad')
    A robust loss function for regression. 
    The initial model is given by the median of the target values.
* Huber ('huber')
    Another robust loss function that combines least squares and least absolute deviation; 
    use alpha to control the sensitivity with regards to outliers 
* Quantile ('quantile')
    A loss function for quantile regression. 
    Use 0 < alpha < 1 to specify the quantile. 
    This loss function can be used to create prediction intervals 

#Classification
* Binomial deviance ('deviance')
    The negative binomial log-likelihood loss function for binary classification (provides probability estimates). 
    The initial model is given by the log odds-ratio.
* Multinomial deviance ('deviance'): 
    The negative multinomial log-likelihood loss function for multi-class classification 
    with n_classes mutually exclusive classes. It provides probability estimates. 
    The initial model is given by the prior probability of each class. At each iteration n_classes regression trees have to be constructed which makes GBRT rather inefficient for data sets with a large number of classes.
* Exponential loss ('exponential')
    The same loss function as AdaBoostClassifier. 
    Less robust to mislabeled examples than 'deviance'; can only be used for binary classification.


##Regularization of GBRT  - Shrinkage
#scales the contribution of each weak learner by a factor , nu(learning_rate) 
#is also called the learning rate because it scales the step length the gradient descent procedure; 

#The parameter learning_rate strongly interacts with the parameter n_estimators, the number of weak learners to fit. 
#Smaller values of learning_rate require larger numbers of weak learners to maintain a constant training error. 
#Empirical evidence suggests that small values of learning_rate(e.g. learning_rate <= 0.1) favor better test error. 
#and choose n_estimators by early stopping. 

##Regularization of GBRT -Subsampling-stochastic gradient boosting, 
#which combines gradient boosting with bootstrap averaging (bagging). 
#At each iteration the base classifier is trained on a fraction subsample of the available training data.
#The subsample is drawn without replacement. A typical value of subsample is 0.5.


###Example of AdaBoostClassifier with iris 
from sklearn.model_selection import cross_val_score
from sklearn.datasets import load_iris
from sklearn.ensemble import AdaBoostClassifier

iris = load_iris()
clf = AdaBoostClassifier(n_estimators=100)
scores = cross_val_score(clf, iris.data, iris.target)
>>> scores.mean()                             
0.9...

clf = clf.fit(iris.data, iris.target)
>>> clf.feature_importances_
array([0.  , 0.  , 0.54, 0.46])
>>> iris.feature_names
['sepal length (cm)', 'sepal width (cm)', 'petal length (cm)', 'petal width (cm)']



###Example of boston with  GradientBoostingRegressor
import numpy as np
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import *
from sklearn import datasets

boston = datasets.load_boston()

est = GradientBoostingRegressor(n_estimators=100, learning_rate=0.1,
    max_depth=1, random_state=0, loss='ls').fit(boston.data, boston.target )
    
>>> mean_squared_error( boston.target, est.predict(boston.data))    
10.00...

>>> est.feature_importances_
array([0.08, 0.  , 0.  , 0.03, 0.05, 0.24, 0.  , 0.18, 0.  , 0.05, 0.11,  0.03, 0.23])
>>> boston.feature_names
array(['CRIM', 'ZN', 'INDUS', 'CHAS', 'NOX', 'RM', 'AGE', 'DIS', 'RAD', 'TAX', 'PTRATIO', 'B', 'LSTAT'], dtype='<U7')


# Fitting additional weak-learners - for GradientBoosting
#to add more estimators to an already fitted model.
est.set_params(n_estimators=200, warm_start=True)  # set warm_start and new nr of trees
est.fit(boston.data, boston.target) # fit additional 100 trees to est
>>> mean_squared_error( boston.target, est.predict(boston.data))      
8.





###Example of GradientBoostingClassifier with iris 
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.ensemble import *
from sklearn import datasets
import matplotlib.pyplot as plt 

iris = datasets.load_iris()
clf = GradientBoostingClassifier(n_estimators=100, learning_rate=1.0,
    max_depth=1, random_state=0).fit(iris.data, iris.target)

#Often features do not contribute equally to predict the target response
#the basic idea is: the more often a feature is used in the split points of a tree the more important that feature is. 
#The feature importances (the higher, the more important the feature).
>>> clf.feature_importances_  
array([0.13333333, 0.33      , 0.13333333, 0.11666667])
>>> iris.feature_names
['sepal length (cm)', 'sepal width (cm)', 'petal length (cm)', 'petal width (cm)']



##Partial dependence plots (PDP) show the dependence 
#between the target response(label) and a set of 'target' features, 
#marginalizing over the values of all other features 

#One-way PDPs tell us about the interaction between the target response and the 'target' feature 
#A way to look at y axis values is that they are relative to each other in the other plots. 
#When that number is higher than in the other plots in absolute values, 
#it means it is more important cause the impact of that variable on the output is larger.


#PDPs with two target features show the interactions among the two features
from sklearn.ensemble.partial_dependence import plot_partial_dependence

>>> iris.feature_names
['sepal length (cm)', 'sepal width (cm)', 'petal length (cm)', 'petal width (cm)']


#For multi-class models, you need to set the class label (target response)
#for which the PDPs should be created 
#for binary, label is not required 

#eg-two one-way PDPs for the features 0 and 1 and a two-way PDP between the two features
features = [0, 1, (0, 1)]  #
fig, axs = plot_partial_dependence(clf, iris.data, features, label=0) 
plt.show()


#If you need the raw values of the partial dependence function 
#only for binary class 
from sklearn.ensemble.partial_dependence import partial_dependence
pdp, axes = partial_dependence(clf, [0], X=X)
>>> pdp  
array([[ 2.46643157,  2.46643157, ...
>>> axes  
[array([-1.62497054, -1.59201391, ...




###Voting Classifier 
#combine conceptually different machine learning classifiers and use a majority vote 
#or the average predicted probabilities (soft vote) to predict the class labels
sklearn.ensemble.VotingClassifier(estimators, voting='hard', weights=None, n_jobs=1, flatten_transform=None)
    Two subtypes are selected by 
    voting : str, {'hard', 'soft'} (default='hard')
        Majority Class Labels (Majority/Hard Voting)
            the predicted class label for a particular sample is the class label that represents the majority (mode) 
            of the class labels predicted by each individual classifier
        Weighted Average Probabilities (Soft Voting)
            soft voting returns the class label 
            as argmax of the sum of predicted probabilities.
            
            
##hard voting 
#E.g., if the prediction for a given sample is
�classifier 1 -> class 1
�classifier 2 -> class 1
�classifier 3 -> class 2

#the VotingClassifier (with voting='hard') would classify the sample as 'class 1' 
#based on the majority class label.

#In the cases of a tie, the VotingClassifier will select the class based 
#on the ascending sort order. E.g., in the following scenario
�classifier 1 -> class 2
�classifier 2 -> class 1
#the class label 1 will be assigned to the sample.


###Example of VotingClassifier(hard) with iris 
from sklearn import datasets
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import VotingClassifier

iris = datasets.load_iris()
X, y = iris.data[:, 1:3], iris.target

clf1 = LogisticRegression(random_state=1)
clf2 = RandomForestClassifier(random_state=1)
clf3 = GaussianNB()

eclf = VotingClassifier(estimators=[('lr', clf1), ('rf', clf2), ('gnb', clf3)], voting='hard')

for clf, label in zip([clf1, clf2, clf3, eclf], ['Logistic Regression', 'Random Forest', 'naive Bayes', 'Ensemble']):
    scores = cross_val_score(clf, X, y, cv=5, scoring='accuracy')
    print("Accuracy: %0.2f (+/- %0.2f) [%s]" % (scores.mean(), scores.std(), label))
#Output 
Accuracy: 0.90 (+/- 0.05) [Logistic Regression]
Accuracy: 0.93 (+/- 0.05) [Random Forest]
Accuracy: 0.91 (+/- 0.04) [naive Bayes]
Accuracy: 0.95 (+/- 0.05) [Ensemble]




##soft voting 
#let's assume we have 3 classifiers 
#and a 3-class classification problems where we assign equal weights to all classifiers w1=1, w2=1, w3=1.
classifier      class 1     class 2     class 3
classifier 1    w1 * 0.2    w1 * 0.5    w1 * 0.3 
classifier 2    w2 * 0.6    w2 * 0.3    w2 * 0.1 
classifier 3    w3 * 0.3    w3 * 0.4    w3 * 0.3 
weighted average 0.37       0.4         0.3 

#the predicted class label is 2, since it has the highest average probability.
###Example of VotingClassifier(soft) with iris 
from sklearn import datasets
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from itertools import product
from sklearn.ensemble import VotingClassifier

# Loading some example data
iris = datasets.load_iris()
X = iris.data[:, [0,2]]
y = iris.target

# Training classifiers
clf1 = DecisionTreeClassifier(max_depth=4)
clf2 = KNeighborsClassifier(n_neighbors=7)
clf3 = SVC(kernel='rbf', probability=True)
eclf = VotingClassifier(estimators=[('dt', clf1), ('knn', clf2), ('svc', clf3)], voting='soft', weights=[2,1,2])

clf1 = clf1.fit(X,y)
clf2 = clf2.fit(X,y)
clf3 = clf3.fit(X,y)
eclf = eclf.fit(X,y)
>>> print(eclf.predict(X))
[1 1 1 2 2 2]




##Using the VotingClassifier with GridSearch

from sklearn.model_selection import GridSearchCV
clf1 = LogisticRegression(random_state=1)
clf2 = RandomForestClassifier(random_state=1)
clf3 = GaussianNB()
eclf = VotingClassifier(estimators=[('lr', clf1), ('rf', clf2), ('gnb', clf3)], voting='soft')

params = {'lr__C': [1.0, 100.0], 'rf__n_estimators': [20, 200],}

grid = GridSearchCV(estimator=eclf, param_grid=params, cv=5)
grid = grid.fit(iris.data, iris.target)


##to predict the class labels based on the predicted class-probabilities 
#(scikit-learn estimators in the VotingClassifier must support predict_proba method):
eclf = VotingClassifier(estimators=[('lr', clf1), ('rf', clf2), ('gnb', clf3)], voting='soft')
#OR weights can be provided for the individual classifiers:
eclf = VotingClassifier(estimators=[('lr', clf1), ('rf', clf2), ('gnb', clf3)], voting='soft', weights=[2,5,1])






###*** Nearest Neighbors - classification and Regression 

#Unsupervised nearest neighbors is the foundation of many other learning methods, 
#notably manifold learning and spectral clustering and kernel density estimation

#Supervised neighbors-based learning comes in two flavors: 
#classification for data with discrete labels, and regression for data with continuous labels.


#The principle behind nearest neighbor methods is to find a predefined number of training samples(k)
#closest in distance to the new point, and predict the label from these

#The number of samples can be a user-defined constant (k-nearest neighbor learning), 
#or vary based on the local density of points (radius-based neighbor learning).

#Neighbors-based methods are known as non-generalizing machine learning methods, 
#since they simply 'remember' all of its training data 
#(possibly transformed into a fast indexing structure such as a Ball Tree or KD Tree).


##Finding the Nearest Neighbors - unsupervised algorithms


from sklearn.neighbors import NearestNeighbors
import numpy as np
X = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])
nbrs = NearestNeighbors(n_neighbors=2, algorithm='ball_tree').fit(X)
>>> distances, indices = nbrs.kneighbors(X)
>>> indices                                           
array([[0, 1],
       [1, 0],
       [2, 1],
       [3, 4],
       [4, 3],
       [5, 4]]...)
>>> distances
array([[0.        , 1.        ],
       [0.        , 1.        ],
       [0.        , 1.41421356],
       [0.        , 1.        ],
       [0.        , 1.        ],
       [0.        , 1.41421356]])


#To produce a sparse graph showing the connections between neighboring points:
>>> nbrs.kneighbors_graph(X).toarray()
array([[1., 1., 0., 0., 0., 0.],
       [1., 1., 0., 0., 0., 0.],
       [0., 1., 1., 0., 0., 0.],
       [0., 0., 0., 1., 1., 0.],
       [0., 0., 0., 1., 1., 0.],
       [0., 0., 0., 0., 1., 1.]])

       
##Classification and Regression       
       
#KNeighborsClassifier/KNeighborsRegressor implements learning based on the k(int) nearest neighbors of each query point
# The optimal choice of the value k is highly data-dependent: 
#in general a larger k suppresses the effects of noise, but makes the classification boundaries less distinct.


#RadiusNeighborsClassifier/RadiusNeighborsRegressor implements learning based on the number of neighbors 
#within a fixed radius r(float) of each training point
#Use when the data is not uniformly sampled, but less effective for higher dimensional data 
 
#The default value, weights = 'uniform', assigns uniform weights to each neighbor. 
#weights = 'distance' assigns weights proportional to the inverse of the distance from the query point

 
 
###Iris classification 

print(__doc__)

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn import neighbors, datasets

n_neighbors = 15

# import some data to play with
iris = datasets.load_iris()

# we only take the first two features.
X = iris.data
y = iris.target
weights = 'uniform'


clf = neighbors.KNeighborsClassifier(n_neighbors, weights=weights)
clf.fit(X, y)
Z = clf.predict(X)
clf.score(X,y) #X_test, y_test





###*** scikit-learn(sklearn) External projects - auto_ml - Quick Intro 
#Automated machine learning for production and analytics, 
#built on scikit-learn and related projects. 
#Trains a pipeline wth all the standard machine learning steps. 
#Tuned for prediction speed and ease of transfer to production environments.

$ pip install auto_ml

#comment out calc_feature_importance parameter 
'''
 File "c:\python35\lib\site-packages\auto_ml\utils_models.py", line 176, in get model_from_name
   model_map['CatBoostRegressor'] = CatBoostRegressor(calc_feature_importance=True)
TypeError: __init__() got an unexpected keyword argument 'calc_feature_importanc
'''

##Header row information - column_descriptions
#each column is a numerical column, unless you specify otherwise using one of the types noted below.
'output'        Output column, must 
'categorical'   By default, any string value in cloumn is taken as Categoorical 
                For numerucal category, use this type 
'nlp'           For NLP text data, encoded using TF-IDF, along with some other feature engineering 
                (count of some aggregations like total capital letters, puncutation characters, smiley faces, etc., as well as a sentiment prediction of that text).
'ignore'        This column of data will be ignored.
'date'          Creates new features like day_of_week, or minutes_into_day, etc. 
                Then the original date field will be removed from the training data   

class Predictor(type_of_estimator, column_descriptions, verbose=True, name=None)
    Parameters:	
        type_of_estimator ('regressor' or 'classifier')
            Whether you want a classifier or regressor
        column_descriptions (dictionary)
            'column_name' : 'type '
            where type  ['categorical', 'output', 'nlp', 'date', 'ignore'] 
            All columns are assumed to be continuous unless labeled otherwise.      
#few important attribute of Predictor
self._scorer = scoring
self.scoring = 'accuracy_score'

#Instance methods of Predictor     
#https://auto-ml.readthedocs.io/en/latest/api_docs_for_geeks.html
ml_predictor.train(raw_training_data, user_input_func=None, optimize_final_model=None, 
        write_gs_param_results_to_file=True, perform_feature_selection=None, verbose=True, 
        X_test=None, y_test=None, ml_for_analytics=True, take_log_of_y=None, 
        model_names=None, perform_feature_scaling=None, calibrate_final_model=False, 
        _scorer=None, scoring=None, verify_features=False, training_params=None, 
        grid_search_params=None, compare_all_models=False, cv=2, feature_learning=False, 
        fl_data=None, optimize_feature_learning=False, 
        train_uncertainty_model=False, uncertainty_data=None, uncertainty_delta=None, 
        uncertainty_delta_units=None, calibrate_uncertainty=False, uncertainty_calibration_settings=None, 
        uncertainty_calibration_data=None, uncertainty_delta_direction=None, advanced_analytics=None, 
        analytics_config=None, prediction_intervals=None, predict_intervals=None, ensemble_config=None, 
        trained_transformation_pipeline=None, transformed_X=None, transformed_y=None, 
        return_transformation_pipeline=False, X_test_already_transformed=False, skip_feature_responses=None, 
        prediction_interval_params=None):
    raw_training_data 
        (DataFrame, or a list of dictionaries)
        where each dictionary represents a row of data. 
        Each row should have both the training features, and the output value we are trying to predict.) 
    optimize_final_model (Boolean) � [default- False] 
        Whether or not to perform GridSearchCV on the final model. 
        True increases computation time significantly, 
        but will likely increase accuracy.
    perform_feature_selection (Boolean) 
        [default- True for large datasets (> 100,000 rows),     False for small datasets] 
    verbose � [default- True] 
    ml_for_analytics (Boolean) � [default- True] 
        Whether or not to print out results 
        for which features the trained model found useful. 
    take_log_of_y (Boolean) � [default- None] 
        For regression problems, 
        accuracy is sometimes improved by taking the natural log of y values during training, 
        so they all exist on a comparable scale.
    model_names (list of strings) 
        [default- relevant 'GradientBoosting'] Which model(s) to try. 
        from scikit-learn are ['ARDRegression', 'AdaBoostClassifier', 'AdaBoostRegressor', 'BayesianRidge', 'ElasticNet', 'ExtraTreesClassifier', 'ExtraTreesRegressor', 'GradientBoostingClassifier', 'GradientBoostingRegressor', 'Lasso', 'LassoLars', 'LinearRegression', 'LogisticRegression', 'MiniBatchKMeans', 'OrthogonalMatchingPursuit', 'PassiveAggressiveClassifier', 'PassiveAggressiveRegressor', 'Perceptron', 'RANSACRegressor', 'RandomForestClassifier', 'RandomForestRegressor', 'Ridge', 'RidgeClassifier', 'SGDClassifier', 'SGDRegressor']. 
        Other options : eg model_names=['DeepLearningClassifier']
            DeepLearningClassifier and DeepLearningRegressor(tensorflow,keras)
            XGBClassifier and XGBRegressor
            LGBMClassifer and LGBMRegressor
            CatBoostClassifier and CatBoostRegressor    
    perform_feature_scaling � [default- True] 
        Whether to scale values, roughly to the range of {-1, 1}. 
    calibrate_final_model � [default- False] 
        Whether to calibrate the probability predictions coming  from the final trained classifier. 
        Usefulness depends on your scoring metric, and model. 
        If True, you must pass in values for X_test and y_test as well. 
    cv � [default- 2] 
        How many folds of cross-validation to perform. 
        The default of 2 works well for very large datasets. 
    feature_learning � [default- False] 
        Whether or not to use Deep Learning to learn features from the data. 
        The learned features are then predicted 
        for every row in the training data, and fed into a final model 
        (by default, gradient boosting) to turn those features 
        and the original features into the most accurate predictions possible. 
        If True, you must pass in fl_data as well. 
    fl_data � [default- None] 
        If feature_learning=True, then this is the dataset 
        we will fit the deep learning model on. 
        This dataset should be different than your df_train dataset.
    compare_all_models - [default=False]
        True means many scikit Models would be compared 
        If False, by default uses GradientBoostingRegressor or GradientBoostingClassifier
    scoring=None
        Scoring string from sklearn.metrics 
        Default is 'accuracy_score' for classifcation
        Uses internal Scorer 
    optimize_feature_learning=False
    train_uncertainty_model=False    
    calibrate_uncertainty=False
	return_transformation_pipeline=False
	X_test_already_transformed=False
    
ml_predictor.predict(prediction_data)
    prediction_data 
        A single dictionary, or a DataFrame, or list of dictionaries. 
    Return type:	
        list of predicted values, of the same length and order as the prediction_rows passed in. 
        If a single dictionary is passed in, 
        the return value will be the predicted value, not nested in a list (so just a single number or predicted class).

ml_predictor.predict_proba(prediction_data)
    Return type:	Only works for 'classifier' estimators. 
        each row in the returned list will now itself be a list, of length (number of categories in training data) 
        The items in this row's list will represent the probability of each category.
        
ml_predictor.score(X_test, y_test, advanced_scoring=True, verbose=2)
    verbose � [default- 2] 
    Return type:	
        number representing the trained estimator's score on the validation data.
        
ml_predictor.predict_intervals(prediction_data, return_type=None)
    return_type 
        [default- dict for single prediction, list of lists for multiple predictions] 
        Accepted values are 'df', 'list', 'dict'. 
        If 'df', we will return a pandas DataFrame, 
        with the columns [prediction, prediction_lower, prediction_median, prediction_upper]. 
        If 'list', we will return a single (non-nested) list for single predictions, 
        and a list of lists for batch predictions. 
        If 'dict', we will return a single (non-nested) dictionary for single predictions, 
        and a list of dictionaries for batch predictions.
        
ml_predictor.save(file_name='auto_ml_saved_pipeline.dill', verbose=True)
    This function will serialize the trained pipeline to disk


##Training data format
1.Must either be a pandas DataFrame, 
  or a list filled with python dictionaries.
2.The non-header-row objects can be 'sparse'. 
  Dict:You only have to include attributes on each object 
  that actually apply to that row. 
  Recomended: pass None or nan  if you have missing values

  
##ml_for_analytics : Interpreting Results
regression based models 
    coefficient for each feature. 
    Note that by default, features are scaled to roughly the range of [0,1].
    => all else equal, we'd expect a change 
    from being the smallest to the largest value 
    on this particular variable will lead to [coefficient] 
    impact on our output variable.
random-forest-esque models 
    amount of variance 
    that is explained by this feature. 
    These values will, in total, sum up to 1.



    
###Example - auto_ml with boston housing price 

from auto_ml import Predictor
from auto_ml.utils import get_boston_dataset
from auto_ml.utils_models import load_ml_model

# Load data
df_train, df_test = get_boston_dataset()

>>> df_train.columns
Index(['CRIM', 'ZN', 'INDUS', 'CHAS', 'NOX', 'RM', 'AGE', 'DIS', 'RAD', 'TAX','PTRATIO', 'B', 'LSTAT', 'MEDV'],
      dtype='object')
      
      
# Tell auto_ml which column is 'output'
# Also note columns that aren't purely numerical
# Examples include ['nlp', 'date', 'categorical', 'ignore']
column_descriptions = { 'MEDV': 'output'  , 'CHAS': 'categorical'}

ml_predictor = Predictor(type_of_estimator='regressor', column_descriptions=column_descriptions)

#for GridSearchCV , optimize_final_model=True 
#perform_feature_selection (Boolean) ,[default- True for large datasets (> 100,000 rows),     False for small datasets] 
#perform_feature_scaling � [default- True] , Whether to scale values, roughly to the range of {-1, 1}. 
#compare_all_models - [default=False],True means many scikit Models would be compared 
#If False, by default uses GradientBoostingRegressor or GradientBoostingClassifier

ml_predictor.train(df_train) #,optimize_final_model=True, compare_all_models=True)


# Score the model on test data
test_score = ml_predictor.score(df_test, df_test.MEDV)

# auto_ml is specifically tuned for running in production
# It can get predictions on an individual row (passed in as a dictionary)
# A single prediction like this takes ~1 millisecond
# Here we will demonstrate saving the trained model, and loading it again
file_name = ml_predictor.save() #check the filename 

trained_model = load_ml_model(file_name)

# .predict and .predict_proba take in either:
# A pandas DataFrame
# A list of dictionaries
# A single dictionary (optimized for speed in production evironments)
predictions = trained_model.predict(df_test)
print(predictions)
#All params in the model 
trained_model.get_params()
#Final model params , note thos .get_params() is only available in trained_model
>>> trained_model.get_params()['final_model__model']
GradientBoostingRegressor(alpha=0.9, criterion='friedman_mse', init=None,
             learning_rate=0.1, loss='ls', max_depth=3, max_features=None,
             max_leaf_nodes=None, min_impurity_decrease=0.0,
             min_impurity_split=None, min_samples_leaf=1,
             min_samples_split=2, min_weight_fraction_leaf=0.0,
             n_estimators=35, presort=False, random_state=None,
             subsample=1.0, verbose=0, warm_start=True)



             
             
             
             
             
             
###*** scikit-learn(sklearn) External projects - TPOT 
#TPOT An automated machine learning toolkit 
#that optimizes a series of scikit-learn operators to design a machine learning pipeline, 
#including data and feature preprocessors as well as the estimators. 
#Works as a drop-in replacement for a scikit-learn estimator.

$ pip install deap update_checker tqdm stopit
$ pip install pywin32
#Xboost 
conda install py-xgboost

#genetic programming
#for TPOT-MDR configuration
$ pip install scikit-mdr skrebate

$pip install tpot


##Classification
class tpot.TPOTClassifier(generations=100, population_size=100,
                          offspring_size=None, mutation_rate=0.9,
                          crossover_rate=0.1,
                          scoring='accuracy', cv=5,
                          subsample=1.0, n_jobs=1,
                          max_time_mins=None, max_eval_time_mins=5,
                          random_state=None, config_dict=None,
                          warm_start=False,
                          memory=None,
                          periodic_checkpoint_folder=None,
                          verbosity=0,
                          disable_update_check=False)
    Automated machine learning for supervised classification tasks.
    The TPOTClassifier performs an intelligent search over machine learning pipelines that can contain supervised classification models, preprocessors, feature selection techniques, and any other estimator or transformer that follows the scikit-learn API. 
    The TPOTClassifier will also search over the hyperparameters of all objects in the pipeline.
    By default, TPOTClassifier will search over a broad range of supervised classification algorithms, transformers, and their parameters. 
    However, the algorithms, transformers, and hyperparameters that the TPOTClassifier searches over can be fully customized using the config_dict parameter.
    generations: int, optional (default=100)
        Number of iterations to the run pipeline optimization process. Must be a positive number.
        Generally, TPOT will work better when you give it more generations (and therefore time) to optimize the pipeline.
        TPOT will evaluate population_size + generations � offspring_size pipelines in total. 
    population_size: int, optional (default=100)
        Number of individuals to retain in the genetic programming population every generation. Must be a positive number.
        Generally, TPOT will work better when you give it more individuals with which to optimize the pipeline. 
##Regression
class tpot.TPOTRegressor(generations=100, population_size=100,
                         offspring_size=None, mutation_rate=0.9,
                         crossover_rate=0.1,
                         scoring='neg_mean_squared_error', cv=5,
                         subsample=1.0, n_jobs=1,
                         max_time_mins=None, max_eval_time_mins=5,
                         random_state=None, config_dict=None,
                         warm_start=False,
                         memory=None,
                         periodic_checkpoint_folder=None,
                         verbosity=0,
                         disable_update_check=False)
    Automated machine learning for supervised regression tasks.
    Parameters: 	
    generations: int, optional (default=100)
        Number of iterations to the run pipeline optimization process. Must be a positive number.
        Generally, TPOT will work better when you give it more generations (and therefore time) to optimize the pipeline.
        TPOT will evaluate population_size + generations � offspring_size pipelines in total. 
    population_size: int, optional (default=100)
        Number of individuals to retain in the genetic programming population every generation. Must be a positive number.
        Generally, TPOT will work better when you give it more individuals with which to optimize the pipeline. 



###Example - Iris flower classification using TPOT
from tpot import TPOTClassifier
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
import numpy as np

iris = load_iris()
X_train, X_test, y_train, y_test = train_test_split(iris.data.astype(np.float64),
    iris.target.astype(np.float64), train_size=0.75, test_size=0.25)

tpot = TPOTClassifier(generations=5, population_size=50, verbosity=2)
tpot.fit(X_train, y_train)
print(tpot.score(X_test, y_test))
tpot.export('tpot_iris_pipeline.py')  #get the pipeline code 


#eg : generated file: tpot_iris_pipeline.py
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.pipeline import make_pipeline, make_union
from tpot.builtins import StackingEstimator

# NOTE: Make sure that the class is labeled 'target' in the data file
tpot_data = pd.read_csv('PATH/TO/DATA/FILE', sep='COLUMN_SEPARATOR', dtype=np.float64)
features = tpot_data.drop('target', axis=1).values
training_features, testing_features, training_target, testing_target = \
            train_test_split(features, tpot_data['target'].values, random_state=42)

# Score on the training set was:0.9735177865612649
exported_pipeline = make_pipeline(
    StackingEstimator(estimator=LogisticRegression(C=20.0, dual=False, penalty="l2")),
    GaussianNB()
)

exported_pipeline.fit(training_features, training_target)
results = exported_pipeline.predict(testing_features)






###Example - Boston housing prices modeling using TPOT
from tpot import TPOTRegressor
from sklearn.datasets import load_boston
from sklearn.model_selection import train_test_split

housing = load_boston()
X_train, X_test, y_train, y_test = train_test_split(housing.data, housing.target,
                                                    train_size=0.75, test_size=0.25)

tpot = TPOTRegressor(generations=5, population_size=50, verbosity=2)
tpot.fit(X_train, y_train)
print(tpot.score(X_test, y_test))
tpot.export('tpot_boston_pipeline.py')#get the pipeline code 

#eg : generated file: tpot_boston_pipeline.py
import numpy as np

from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import train_test_split

# NOTE: Make sure that the class is labeled 'class' in the data file
tpot_data = np.recfromcsv('PATH/TO/DATA/FILE', delimiter='COLUMN_SEPARATOR', dtype=np.float64)
features = np.delete(tpot_data.view(np.float64).reshape(tpot_data.size, -1),
                     tpot_data.dtype.names.index('class'), axis=1)
training_features, testing_features, training_target, testing_target = \
    train_test_split(features, tpot_data['class'], random_state=42)

exported_pipeline = GradientBoostingRegressor(alpha=0.85, learning_rate=0.1, loss="ls",
                                              max_features=0.9, min_samples_leaf=5,
                                              min_samples_split=6)

exported_pipeline.fit(training_features, training_target)
results = exported_pipeline.predict(testing_features)



###HandsOn - Example - MNIST digit recognition using TPOT 
from tpot import TPOTClassifier
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

digits = load_digits()
X_train, X_test, y_train, y_test = train_test_split(digits.data, digits.target,
                                                    train_size=0.75, test_size=0.25)

tpot = TPOTClassifier(generations=5, population_size=50, verbosity=2)
tpot.fit(X_train, y_train)
print(tpot.score(X_test, y_test))
tpot.export('tpot_mnist_pipeline.py')#get the pipeline code 



#eg : generated file: tpot_mnist_pipeline.py
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

# NOTE: Make sure that the class is labeled 'class' in the data file
tpot_data = np.recfromcsv('PATH/TO/DATA/FILE', delimiter='COLUMN_SEPARATOR', dtype=np.float64)
features = np.delete(tpot_data.view(np.float64).reshape(tpot_data.size, -1),
                     tpot_data.dtype.names.index('class'), axis=1)
training_features, testing_features, training_target, testing_target = \
    train_test_split(features, tpot_data['class'], random_state=42)

exported_pipeline = KNeighborsClassifier(n_neighbors=6, weights="distance")

exported_pipeline.fit(training_features, training_target)
results = exported_pipeline.predict(testing_features)






###*** scikit-learn(sklearn) - Clustering 

#Method name            Parameters                  Scalability                               Usecase                                                                     Geometry (metric used)
K-Means                 number of clusters          Very large n_samples,                     General-purpose, even cluster size,flat geometry, not too many clusters     Distances between points 
                                                    medium n_clusters with MiniBatch code     
Affinity propagation    damping, sample preference  Not scalable with n_samples               Many clusters, uneven cluster size, non-flat geometry                       Graph distance (e.g. nearest-neighbor graph) 
Mean-shift              bandwidth                   Not scalable with n_samples               Many clusters, uneven cluster size, non-flat geometry                       Distances between points 
Spectral clustering     number of clusters          Medium n_samples, small n_clusters        Few clusters, even cluster size, non-flat geometry                          Graph distance (e.g. nearest-neighbor graph) 
Ward hierarchical       number of clusters          Large n_samples and n_clusters            Many clusters, possibly connectivity constraints                            Distances between points 
                                                                                              
Agglomerative           number of clusters,                                                   
                        linkage type, distance      Large n_samples and n_clusters            Many clusters, possibly connectivity constraints, non Euclidean distances   Any pairwise distance 
DBSCAN neighborhood     size                        Very large n_samples, medium n_clusters   Non-flat geometry, uneven cluster sizes                                     Distances between nearest points 
Gaussian mixtures       many                        Not scalable                              Flat geometry, good for density estimation                                  Mahalanobis distances to centers 
                                                                                              
Birch                   branching factor, threshold,                                          
                        optional global clusterer.  Large n_clusters and n_samples            Large dataset, outlier removal, data reduction.                             Euclidean distance between points 
                                                                                              


##Scikit - Clustering -  K-Means - unsupervised algorithm  for clustering problem
#http://scikit-learn.org/stable/modules/clustering.html

#to classify a given data set through a certain number of  clusters (assume k clusters). 
#Data points inside a cluster are homogeneous and heterogeneous to peer groups



##How to determine value of K(use Elbow Method of yellowbrick)
#each cluster has its own centroid. 
#Sum of square of difference between centroid and the data points within a cluster 
#constitutes 'within sum of square' value for that cluster. 

#Also, when the sum of square values for all the clusters are added, 
#it becomes total 'within sum of square' value for the cluster solution.

#as the number of cluster increases, this value keeps on decreasing 
#but if you plot the result you may see that the sum of squared distance decreases 
#sharply up to some value of k(=optimum number of cluster), and then much more slowly after that. 

#KMeans 
sklearn.cluster.KMeans(n_clusters=8, init='k-means++', n_init=10, max_iter=300, tol=0.0001, precompute_distances='auto', verbose=0, 
        random_state=None, copy_x=True, n_jobs=1)        
    init : {'k-means++', 'random' or an ndarray}
    
    
    
##Mini Batch K-Means - variant of the KMeans
#uses mini-batches to reduce the computation time
#MiniBatchKMeans converges faster than KMeans, but the quality of the results is reduced. 
#In practice this difference in quality can be quite small, 
sklearn.cluster.MiniBatchKMeans(n_clusters=8, init='k-means++', max_iter=100, batch_size=100, verbose=0, compute_labels=True, random_state=None, tol=0.0, max_no_improvement=10, 
            init_size=None, n_init=3, reassignment_ratio=0.01)


#Attributes 
cluster_centers_ : array, [n_clusters, n_features]
    Coordinates of cluster centers
labels_ 
    Labels of each point
inertia_ : float. 
    Sum of distances of samples to their closest cluster center.

#Methods
fit(X[, y])          Compute k-means clustering. 
fit_predict(X[, y])  Compute cluster centers and predict cluster index for each sample. 
                      Returns:
                      labels : array, shape [n_samples,]
                        Index of the cluster each sample belongs to. 
fit_transform(X[, y]) Compute clustering and transform X to cluster-distance space. 
                      Returns:
                        X_new : array, shape [n_samples, k]
                            X transformed in the new space. 
get_params([deep])   Get parameters for this estimator. 
predict(X)           Predict the closest cluster each sample in X belongs to. 
                     Returns:
                     labels : array, shape [n_samples,]
                        Index of the cluster each sample belongs to.
score(X[, y])        Opposite of the value of X on the K-means objective. 
set_params(**params) Set the parameters of this estimator. 
transform(X)         Transform X to a cluster-distance space. 
                      Returns:
                        X_new : array, shape [n_samples, k]
                            X transformed in the new space. 
 



###Cluster Metrics 
##Silhouette Coefficient - sklearn.metrics.silhouette_score() when ground truth labels are not known
    �a: The mean distance between a sample and all other points in the same class.
    �b: The mean distance between a sample and all other points in the next nearest cluster.
#Silhouette Coefficient is function of above 

#�The score is bounded between -1 for incorrect clustering and +1 for highly dense clustering. 
#Scores around zero indicate overlapping clusters.
#The score is higher when clusters are dense and well separated, which relates to a standard concept of a cluster.
from sklearn import metrics
from sklearn.metrics import pairwise_distances
from sklearn import datasets
dataset = datasets.load_iris()
X = dataset.data
y = dataset.target


#it is applied to the results of a cluster analysis.
import numpy as np
from sklearn.cluster import KMeans
kmeans_model = KMeans(n_clusters=3, random_state=1).fit(X)
labels = kmeans_model.labels_
>>> metrics.silhouette_score(X, labels, metric='euclidean')                                 
0.55...

     
       
###Clustering Visualizers using yellowbrick
##The elbow method for K
#visualizes multiple clustering models with different values for K

#Model selection is based on whether or not there is an �elbow� in the curve; 
#e.g. if the curve looks like an arm, if there is a clear change in angle from one part of the curve to another.

from sklearn.datasets import load_iris
iris = load_iris()

from sklearn.cluster import MiniBatchKMeans

from yellowbrick.cluster import KElbowVisualizer

# Instantiate the clustering model and visualizer
visualizer = KElbowVisualizer(MiniBatchKMeans(), k=(4,12))

visualizer.fit(iris.data[:, 0:4] ) # Fit the training data to the visualizer
visualizer.poof() # Draw/show/poof the data


##Silhouette Visualizer
#The Silhouette Coefficient is used when the ground-truth about the dataset is unknown 
#and computes the density of clusters computed by the model. 
#The score is computed by averaging the silhouette coefficient for each sample, computed as the difference between the average intra-cluster distance 
#and the mean nearest-cluster distance for each sample, normalized by the maximum value. 

#This produces a score between 1 and -1, where 1 is highly dense clusters and -1 is completely incorrect clustering.

#The Silhouette Visualizer displays the silhouette coefficient for each sample on a per-cluster basis, 
#visualizing which clusters are dense and which are not. 
#This is particularly useful for determining cluster imbalance, or for selecting a value for K by comparing multiple visualizers.

from sklearn.datasets import make_blobs

# Make 8 blobs dataset
X, y = make_blobs(centers=8)

from sklearn.cluster import MiniBatchKMeans

from yellowbrick.cluster import SilhouetteVisualizer

# Instantiate the clustering model and visualizer
model = MiniBatchKMeans(6)
visualizer = SilhouetteVisualizer(model)

visualizer.fit(X) # Fit the training data to the visualizer
visualizer.poof() # Draw/show/poof the data
#K=2 would give good 







###Example - Image Color Quantization - KMeans(plot_color_quantization_kmeans.py)
#Performs a pixel-wise Vector Quantization (VQ) of an image 
#reducing the number of colors required to show the image from 96,615 unique colors to 64, while preserving the overall appearance quality

#pixels are represented in a 3D-space and K-means is used to find 64 color clusters. 
#In the image processing literature, the codebook obtained from K-means (the cluster centers) is called the color palette. 
#Using a single byte, up to 256 colors can be addressed, 
#whereas an RGB encoding requires 3 bytes per pixel. 
#The GIF file format, for example, uses such apalette.

#For comparison, a quantized image using a random codebook (colors picked uprandomly) is also shown.


import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import pairwise_distances_argmin
from sklearn.datasets import load_sample_image
from sklearn.utils import shuffle
from time import time

n_colors = 64

# Load the Summer Palace photo
china = load_sample_image("china.jpg")

#>>> china.shape #ndarray of 427x640 with 3channels(RGB) of unit8 ie byte 
#(427, 640, 3)

# Convert to floats 
#plt.imshow behaves works well on float data (need to be in the range [0-1])
china = np.array(china, dtype=np.float64) / 255

# Load Image and transform to a 2D numpy array.
w, h, d = original_shape = tuple(china.shape)
assert d == 3
image_array = np.reshape(china, (w * h, d)) #make it 2D 

print("Fitting model on a small sub-sample of the data")
t0 = time()
image_array_sample = shuffle(image_array, random_state=0)[:1000] #1000x3 ie 3 channel of float RGB 
kmeans = KMeans(n_clusters=n_colors, random_state=0).fit(image_array_sample)
print("done in %0.3fs." % (time() - t0))

#Codebook is cluster means
kmeans.cluster_centers_  #(64, 3) ie nclusterx3channels 


# Get labels for all points
print("Predicting color indices on the full image (k-means)")
t0 = time()
labels = kmeans.predict(image_array)
print("done in %0.3fs." % (time() - t0))
#>>> np.unique(labels)  # 0-63, index of kmeans.cluster_centers_
#array([ 0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,
#       17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33,
#       34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
#       51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63])

codebook_random = shuffle(image_array, random_state=0)[:n_colors + 1]
print("Predicting color indices on the full image (random)")
t0 = time()
#get pairwise distance 
labels_random = pairwise_distances_argmin(codebook_random,image_array, axis=0)
print("done in %0.3fs." % (time() - t0))


def recreate_image(codebook, labels, w, h):
    """Recreate the (compressed) image from the code book & labels"""
    d = codebook.shape[1]
    image = np.zeros((w, h, d))
    label_idx = 0
    for i in range(w):
        for j in range(h):
            image[i][j] = codebook[labels[label_idx]]
            label_idx += 1
    return image

# Display all results, alongside original image
plt.figure(1)
plt.clf()
ax = plt.axes([0, 0, 1, 1])
plt.axis('off')
plt.title('Original image (96,615 colors)')
plt.imshow(china)

plt.figure(2)
plt.clf()
ax = plt.axes([0, 0, 1, 1])
plt.axis('off')
plt.title('Quantized image (64 colors, K-Means)')
plt.imshow(recreate_image(kmeans.cluster_centers_, labels, w, h))

plt.figure(3)
plt.clf()
ax = plt.axes([0, 0, 1, 1])
plt.axis('off')
plt.title('Quantized image (64 colors, Random)')
plt.imshow(recreate_image(codebook_random, labels_random, w, h))
plt.show()























###+++ Other Topics 
###*** scikit-learn(sklearn) - Neural network models (supervised) - Multi-layer Perceptron
#Use keras for large database (Keras support TensorFlow/mxnet)

Advantages of Multi-layer Perceptron are:
    �Capability to learn non-linear models.
    �Capability to learn models in real-time (on-line learning) using partial_fit.
Disadvantages of Multi-layer Perceptron (MLP) include:
    �MLP with hidden layers have a non-convex loss function 
     where there exists more than one local minimum. 
     Therefore different random weight initializations can lead to different validation accuracy.
    �MLP requires tuning a number of hyperparameters 
     such as the number of hidden neurons, layers, and iterations.
    �MLP is sensitive to feature scaling.
     so it is highly recommended to scale  data. 
     For example, scale each attribute on the input vector X to [0, 1] or [-1, +1], 
     or standardize it to have mean 0 and variance 1
    
##Tuning 
�Finding a reasonable regularization parameter alpha is best done using GridSearchCV, 
 usually in the range 10.0 ** -np.arange(1, 7).
�Empirically, L-BFGS converges faster and with better solutions on small datasets. 
 For relatively large datasets, however, Adam is very robust. 
 SGD with momentum or nesterov�s momentum, on the other hand, can perform better than those two algorithms 
 if learning rate is correctly tuned.


##Reference 
#Both MLPRegressor and MLPClassifier use parameter alpha for regularization (L2 regularization) term 
#which helps in avoiding overfitting by penalizing weights with large magnitudes
class sklearn.neural_network.MLPRegressor(hidden_layer_sizes=(100, ), activation='relu', solver='adam', alpha=0.0001, batch_size='auto', learning_rate='constant', learning_rate_init=0.001, power_t=0.5, max_iter=200, shuffle=True, random_state=None, tol=0.0001, verbose=False, warm_start=False, momentum=0.9, nesterovs_momentum=True, early_stopping=False, validation_fraction=0.1, beta_1=0.9, beta_2=0.999, epsilon=1e-08)
    Multi-layer Perceptron regressor.
class sklearn.neural_network.MLPClassifier(hidden_layer_sizes=(100, ), 
        activation='relu', solver='adam', alpha=0.0001, 
        batch_size='auto', learning_rate='constant', 
        learning_rate_init=0.001, power_t=0.5, max_iter=200, 
        shuffle=True, random_state=None, tol=0.0001, verbose=False, 
        warm_start=False, momentum=0.9, nesterovs_momentum=True, 
        early_stopping=False, validation_fraction=0.1, beta_1=0.9, beta_2=0.999, epsilon=1e-08)
    Multi-layer Perceptron classifier.
    This model optimizes the log-loss function using LBFGS  or stochastic gradient descent.
    Parameters:
    hidden_layer_sizes : tuple, length = n_layers - 2, default (100,) 
        The ith element represents the number of neurons 
        in the ith hidden layer.
    activation : {'identity', 'logistic', 'tanh', 'relu'}, default 'relu'
        Activation function for the hidden layer.
        �'identity', no-op activation, useful to implement linear bottleneck, returns f(x) = x
        �'logistic', the logistic sigmoid function, returns f(x) = 1 / (1 + exp(-x)).
        �'tanh', the hyperbolic tan function, returns f(x) = tanh(x).
        �'relu', the rectified linear unit function, returns f(x) = max(0, x)
    solver : {'lbfgs', 'sgd', 'adam'}, default 'adam'
        The solver for weight optimization.
        �'lbfgs' is an optimizer in the family of quasi-Newton methods.
        �'sgd' refers to stochastic gradient descent.
        �'adam' refers to a stochastic gradient-based optimizer proposed by Kingma, Diederik, and Jimmy Ba
    alpha : float, optional, default 0.0001
        L2 penalty (regularization term) parameter.
    batch_size : int, optional, default 'auto'
        Size of minibatches for stochastic optimizers. 
        If the solver is 'lbfgs', the classifier will not use minibatch. 
        When set to 'auto', batch_size=min(200, n_samples)
    learning_rate : {'constant', 'invscaling', 'adaptive'}, default 'constant'
        Learning rate schedule for weight updates.
        �'constant' is a constant learning rate given by 'learning_rate_init'.
        �'invscaling' gradually decreases the learning rate learning_rate_ at each time step 't' using an inverse scaling exponent of 'power_t'. effective_learning_rate = learning_rate_init / pow(t, power_t)
        �'adaptive' keeps the learning rate constant to 'learning_rate_init' as long as training loss keeps decreasing. Each time two consecutive epochs fail to decrease training loss by at least tol, or fail to increase validation score by at least tol if 'early_stopping' is on, the current learning rate is divided by 5.
        Only used when solver='sgd'.
    learning_rate_init : double, optional, default 0.001
        The initial learning rate used. 
        It controls the step-size in updating the weights. 
        Only used when solver='sgd' or 'adam'.
    power_t : double, optional, default 0.5
        The exponent for inverse scaling learning rate. 
        It is used in updating effective learning rate when the learning_rate is set to 'invscaling'. Only used when solver='sgd'.
    max_iter : int, optional, default 200
        Maximum number of iterations. 
        The solver iterates until convergence (determined by 'tol') 
        or this number of iterations. 
        For stochastic solvers ('sgd', 'adam'), 
        note that this determines the number of epochs 
        (how many times each data point will be used), 
        not the number of gradient steps.
    shuffle : bool, optional, default True
        Whether to shuffle samples in each iteration. 
        Only used when solver='sgd' or 'adam'.

#Attributes:
classes_ : array or list of array of shape (n_classes,)
    Class labels for each output.
loss_ : float
    The current loss computed with the loss function.
coefs_ : list, length n_layers - 1
    The ith element in the list represents the 
    weight matrix corresponding to layer i.
intercepts_ : list, length n_layers - 1
    The ith element in the list represents 
    the bias vector corresponding to layer i + 1.
n_iter_ : int,
    The number of iterations the solver has ran.
n_layers_ : int
    Number of layers.
n_outputs_ : int
    Number of outputs.
out_activation_ : string
    Name of the output activation function.
 

 

###Example -  MLP - MNIST 

import matplotlib.pyplot as plt
from sklearn.datasets import fetch_mldata
from sklearn.neural_network import MLPClassifier


mnist = fetch_mldata("MNIST original")
# rescale the data, use the traditional train/test split
X, y = mnist.data / 255., mnist.target
X_train, X_test = X[:60000], X[60000:]
y_train, y_test = y[:60000], y[60000:]


# mlp = MLPClassifier(hidden_layer_sizes=(100, 100), max_iter=400, alpha=1e-4, solver='sgd', verbose=10, tol=1e-4, random_state=1)
mlp = MLPClassifier(hidden_layer_sizes=(50,), max_iter=10, alpha=1e-4,
                    solver='sgd', verbose=10, tol=1e-4, random_state=1,
                    learning_rate_init=.1)
mlp.fit(X_train, y_train)

print("Training set score: %f" % mlp.score(X_train, y_train))
print("Test set score: %f" % mlp.score(X_test, y_test))

fig, axes = plt.subplots(4, 4)
# use global min / max to ensure all weights are shown on the same scale
vmin, vmax = mlp.coefs_[0].min(), mlp.coefs_[0].max()
for coef, ax in zip(mlp.coefs_[0].T, axes.ravel()):
    ax.matshow(coef.reshape(28, 28), cmap=plt.cm.gray, vmin=.5 * vmin,   vmax=.5 * vmax)
    ax.set_xticks(())
    ax.set_yticks(())
plt.show()






###*** scikit-learn(sklearn)- Dimensionality reductions - PCA, FactorAnalysis,NMF, LDA, LSA etc 


##Scikit- Dimensionality reductions - PCA

#PCA is based on Singular value decomposition (generalization of eigenvalue decomposition, A*v=Lambda*v, v= eigenvector, lambda = eigenvalue )
#the singular value decomposition of an m � n   real or complex matrix M  is a factorization of the form
#M = U*Sigma*V_Conjugate 
#M = mXn matrix - real or complex 
#U = mXm  real or complex unitary matrix, called left singular vector 
#Sigma = diagonal matrix , each element is singular values of M 
#V = nXn, real or complex unitary matrix, called right singular vector 
#Unitary matrix = A*A_conjugate = A_conjugate * A = Identity matrix  
 

#PCA is used to decompose a multivariate dataset in a set of successive 
#orthogonal components that explain a maximum amount of the variance. 

#PCA is implemented as a transformer object(.transform(X)) that learns n components in its fit method, 
#and can be used on new data to project it on these components
#Note fit() must be called once!! and then use transform() as many times as required 
#Means don't use fit_transform()

##Methods for all these classes 
fit(X[, y])             Fit the FactorAnalysis model to X using EM 
fit_transform(X[, y])   Fit to data, then transform it. 
get_covariance()        Compute data covariance with the FactorAnalysis model. 
get_params([deep])      Get parameters for this estimator. 
get_precision()         Compute data precision matrix with the FactorAnalysis model. 
score(X[, y])           Compute the average log-likelihood of the samples 
score_samples(X)        Compute the log-likelihood of each sample 
set_params(**params)    Set the parameters of this estimator. 
transform(X)            Apply dimensionality reduction to X using the model. 


#SVD suffers from a problem called 'sign indeterminancy', 
#which means the sign of the components_ and the output from transform depend on the algorithm and random state

class sklearn.decomposition.ProbabilisticPCA(n_components=None, copy=True, whiten=False)
    Additional layer on top of PCA that adds a probabilistic evaluation 
    of Principal component analysis (PCA)
class sklearn.decomposition.PCA(n_components=None, copy=True, whiten=False, svd_solver='auto', tol=0.0, iterated_power='auto', random_state=None)
    n_components : int, None or string
            Number of components to keep. 
            if n_components is not set all components are kept:
            n_components == min(n_samples, n_features)
            if n_components == 'mle', Minka's MLE is used to guess the dimension 
            if 0 < n_components < 1, select the number of components 
            such that the amount of variance that needs to be explained is greater than the percentage specified by n_components
    whiten : bool, optional
                When True (False by default) the components_ vectors are divided by n_samples times singular values to ensure uncorrelated outputs with unit component-wise variances.
                Whitening will remove some information from the transformed signal (the relative variance scales of the components) but can sometime improve the predictive accuracy of the downstream estimators by making there data respect some hard-wired assumptions
    svd_solver : string {'auto', 'full', 'arpack', 'randomized'}
        auto :
            the solver is selected by a default policy based on X.shape and n_components: 
            if the input data is larger than 500x500 and the number of components to extract 
            is lower than 80% of the smallest dimension of the data, t
            hen the more efficient 'randomized' method is enabled. 
            Otherwise the exact full SVD is computed and optionally truncated afterwards.
        full :
            run exact full SVD calling the standard LAPACK solver via scipy.linalg.svd and select the components by postprocessing
        arpack :
            run SVD truncated to n_components calling ARPACK solver 
            via scipy.sparse.linalg.svds. It requires strictly 0 < n_components < X.shape[1]
        randomized :
            run randomized SVD by the method of Halko et al.
    #Attributes are 
    components_ : array, [n_components, n_features]
        Principal axes in feature space, representing the directions of maximum variance in the data.
    explained_variance_ratio_ : array, [n_components]
        Percentage of variance explained by each of the selected components. 
        If n_components is not set then all components are stored 
        and the sum of explained variances is equal to 1.0
    mean_ : array, [n_features]
        Per-feature empirical mean, estimated from the training set.
    n_components_ : int
        The estimated number of components. Relevant when n_components is set to 'mle' or a number between 0 and 1 to select using explained variance.
    noise_variance_ : float
        The estimated noise covariance following the Probabilistic PCA model
    
    
    
##Scikit - Dimensionality reduction(non PCA) - Factor Analysis
#Factor analysis can produce similar components (the columns of its loading matrix) to PCA. 
#However, might not be  orthogonal
#However, This allows better model selection than probabilistic PCA in the presence of heteroscedastic noise

class sklearn.decomposition.FactorAnalysis(n_components=None, tol=0.01, copy=True, max_iter=1000, noise_variance_init=None, svd_method='randomized', iterated_power=3, random_state=0)

 
 
##Scikit - PCA - Incremental PCA - minibatch PCA
#plain PCA is not suitable of large dataset which can not be fit into main memory 
#Useful for large data set 
sklearn.decomposition.IncrementalPCA(n_components=None, whiten=False, copy=True, batch_size=None)
#Attributes and methods are similar to PCA 
#implement out-of-core Principal Component Analysis either by:
    �Using its partial_fit method on chunks of data fetched sequentially from the local hard drive or a network database.
    �Calling its fit method on a memory mapped file using numpy.memmap.







##Scikit - PCA - Approximate PCA - RandomizedPCA
#creates lower-dimensional data that preserves most of the variance, 
#by dropping the singular vector of components associated with lower singular values.
sklearn.decomposition.RandomizedPCA(n_components=None, copy=True, iterated_power=3, whiten=False, random_state=None)



##Scikit - PCA - Kernel PCA
#an extension of PCA which achieves non-linear dimensionality reduction through the use of kernels

class sklearn.decomposition.KernelPCA(n_components=None, kernel='linear', gamma=None, degree=3, coef0=1, kernel_params=None, alpha=1.0, fit_inverse_transform=False, eigen_solver='auto', tol=0, max_iter=None, remove_zero_eig=False, random_state=None, copy_X=True, n_jobs=1)
    kernel : 'linear' | 'poly' | 'rbf' | 'sigmoid' | 'cosine' | 'precomputed'
        Kernel. Default='linear'.
    gamma : float, default=1/n_features
        Kernel coefficient for rbf, poly and sigmoid kernels. Ignored by other kernels.
    degree : int, default=3
        Degree for poly kernels. Ignored by other kernels.
    coef0 : float, default=1
        Independent term in poly and sigmoid kernels. Ignored by other kernels.
    kernel_params : mapping of string to any, default=None
        Parameters (keyword arguments) and values for kernel passed as callable object. Ignored by other kernels.
    alpha : int, default=1.0
        Hyperparameter of the ridge regression that learns the inverse transform (when fit_inverse_transform=True).
    fit_inverse_transform : bool, default=False
        Learn the inverse transform for non-precomputed kernels. (i.e. learn to find the pre-image of a point)

        
        

##Scikit - PCA  for Sparse data -SparsePCA and MiniBatchSparsePCA
#SparsePCA time complexity : O(n ** 3)
#Mini-batch sparse PCA (MiniBatchSparsePCA) is a variant of SparsePCA that is faster but less accurate
class sklearn.decomposition.SparsePCA(n_components=None, alpha=1, ridge_alpha=0.01, max_iter=1000, tol=1e-08, method='lars', n_jobs=1, U_init=None, V_init=None, verbose=False, random_state=None)
class sklearn.decomposition.MiniBatchSparsePCA(n_components=None, alpha=1, ridge_alpha=0.01, n_iter=100, callback=None, batch_size=3, verbose=False, shuffle=True, n_jobs=1, method='lars', random_state=None)




##Scikit - PCA - Truncated 
#TruncatedSVD implements a variant of singular value decomposition (SVD) 
#that only computes the k largest singular values, where k is a user-specified parameter.

#When truncated SVD is applied to term-document matrices 
#(as returned by CountVectorizer or TfidfVectorizer), 
#this transformation is known as latent semantic analysis (LSA), 

class sklearn.decomposition.TruncatedSVD(n_components=2, algorithm='randomized', n_iter=5, random_state=None, tol=0.0)






##Scikit - Dimensionality reduction(non PCA) - DictionaryLearning and SparseCoder

#DictionaryLearning:a matrix factorization problem that amounts to finding a (usually overcomplete) dictionary 
#that will perform good  at sparsely encoding the fitted data.
    
#dictionary learning applied on image patches has been shown to give good results
#in image processing tasks such as image completion, inpainting and denoising, 
#as well as for supervised recognition tasks.

class sklearn.decomposition.MiniBatchDictionaryLearning(n_components=None, alpha=1, n_iter=1000, fit_algorithm='lars', n_jobs=1, batch_size=3, shuffle=True, dict_init=None, transform_algorithm='omp', transform_n_nonzero_coefs=None, transform_alpha=None, verbose=False, split_sign=False, random_state=None)
    Mini-batch dictionary learning
    implements partial_fit, which updates the dictionary 
    by iterating only once over a mini-batch
class sklearn.decomposition.DictionaryLearning(n_components=None, alpha=1, max_iter=1000, tol=1e-08, fit_algorithm='lars', transform_algorithm='omp', transform_n_nonzero_coefs=None, transform_alpha=None, n_jobs=1, code_init=None, dict_init=None, verbose=False, split_sign=False, random_state=None)
    n_components : int,
        number of dictionary elements to extract
    fit_algorithm : {'lars', 'cd'}
    
    
#SparseCoder:Finds a sparse representation of data against a fixed, precomputed dictionary
#Each row of the result is the solution to a sparse coding problem. 
#The goal is to find a sparse array code such that:
#X ~= code * dictionary

class sklearn.decomposition.SparseCoder(dictionary, transform_algorithm='omp', transform_n_nonzero_coefs=None, transform_alpha=None, split_sign=False, n_jobs=1)
    finding a representation of the data as a linear combination of 
    as few dictionary atoms as possible
    dictionary : array, [n_components, n_features]
        The dictionary atoms used for sparse coding. 
        Lines are assumed to be normalized to unit norm.
    transform_algorithm : {'lasso_lars', 'lasso_cd', 'lars', 'omp', 'threshold'}
        �Orthogonal matching pursuit (Orthogonal Matching Pursuit (OMP))
        �Least-angle regression (Least Angle Regression)
        �Lasso computed by least-angle regression
        �Lasso using coordinate descent (Lasso)
        �Thresholding
    #Methods
    fit(X[, y])             Do nothing and return the estimator unchanged 
    fit_transform(X[, y])   Fit to data, then transform it. 
    get_params([deep])      Get parameters for this estimator. 
    set_params(**params)    Set the parameters of this estimator. 
    transform(X)            Encode the data as a sparse combination of the dictionary atoms. 

    

    
    
##Scikit - Dimensionality reduction(non PCA) - Independent component analysis (ICA)
#PCA and factor analysis essentially assume components with  Gaussian distribtion with a low-rank covariance matrix
#ICA is used when  non-Gaussian distribution is assumed

#Note to use ICA,  whitening must be applied

#Typically, ICA is not used for reducing dimensionality 
#but for separating superimposed signals. 
#It is classically used to separate mixed signals (a problem known as blind source separation
#ICA can also be used as  linear decomposition that finds components with some sparsity:
class sklearn.decomposition.FastICA(n_components=None, algorithm='parallel', whiten=True, fun='logcosh', fun_args=None, max_iter=200, tol=0.0001, w_init=None, random_state=None)


    
    
##Scikit - Dimensionality reduction(non PCA) - Non-negative matrix factorization (NMF or NNMF)
#NMF can be plugged in instead of PCA or its variants, 
#in the cases where the data matrix does not contain negative values

#Unlike PCA, the representation of a vector is obtained in an additive fashion, 
#by superimposing the components, without subtracting. 
#Such additive models are efficient for representing images and text

#It finds a decomposition of samples X into two matrices W and H of non-negative elements, 
#by optimizing the distance d between X and the matrix product WH


class sklearn.decomposition.NMF(n_components=None, init=None, solver='cd', beta_loss='frobenius', tol=0.0001, max_iter=200, random_state=None, alpha=0.0, l1_ratio=0.0, verbose=0, shuffle=False)
    init : 'random' | 'nndsvd' | 'nndsvda' | 'nndsvdar' | 'custom'
        Method used to initialize the procedure. 
        Default: 'nndsvd' if n_components < n_features, otherwise random. 
        Valid options:
            �'random': non-negative random matrices, scaled with:sqrt(X.mean() / n_components)
            �'nndsvd': Nonnegative Double Singular Value Decomposition (NNDSVD)initialization (better for sparseness)
            �'nndsvda': NNDSVD with zeros filled with the average of X(better when sparsity is not desired)
            �'nndsvdar': NNDSVD with zeros filled with small random values(generally faster, less accurate alternative to NNDSVDa for when sparsity is not desired)
            �'custom': use custom matrices W and H
    solver : 'cd' | 'mu'
        Numerical solver to use: 'cd' is a Coordinate Descent solver. 
        'mu' is a Multiplicative Update solver.
    beta_loss : float or string, default 'frobenius'
        String must be in {'frobenius', 'kullback-leibler', 'itakura-saito'}
 

 
 

##Scikit - Dimensionality reduction(non PCA) - Latent Dirichlet Allocation (LDA)

#Latent Dirichlet Allocation is a generative probabilistic model 
#for collections of discrete dataset such as text corpora. 
#It is also a topic model that is used for discovering abstract topics from a collection of documents.

#When LatentDirichletAllocation is applied on a 'document-term' matrix, 
#the matrix will be decomposed into a 'topic-term' matrix and a 'document-topic' matrix. 
#While 'topic-term' matrix is stored as components_ in the model, 
#'document-topic' matrix can be calculated from transform method.

#LatentDirichletAllocation also implements partial_fit method. 
#This is used when data can be fetched sequentially.

class sklearn.decomposition.LatentDirichletAllocation(n_components=10, doc_topic_prior=None, topic_word_prior=None, learning_method=None, learning_decay=0.7, learning_offset=10.0, max_iter=10, batch_size=128, evaluate_every=-1, total_samples=1000000.0, perp_tol=0.1, mean_change_tol=0.001, max_doc_update_iter=100, n_jobs=1, verbose=0, random_state=None, n_topics=None)
   
   
   
   

    
    
###Example - Iris with IncrementalPCA
import numpy as np
import matplotlib.pyplot as plt

from sklearn.datasets import load_iris
from sklearn.decomposition import PCA, IncrementalPCA

iris = load_iris()
X = iris.data
y = iris.target

n_components = 2
ipca = IncrementalPCA(n_components=n_components, batch_size=10)
X_ipca = ipca.fit_transform(X)

pca = PCA(n_components=n_components)
X_pca = pca.fit_transform(X)

for X_transformed, title in [(X_ipca, "Incremental PCA"), (X_pca, "PCA")]:
    plt.figure(figsize=(8, 8))
    for c, i, target_name in zip("rgb", [0, 1, 2], iris.target_names):
        plt.scatter(X_transformed[y == i, 0], X_transformed[y == i, 1],
                    c=c, label=target_name)

    if "Incremental" in title:
        err = np.abs(np.abs(X_pca) - np.abs(X_ipca)).mean()
        plt.title(title + " of iris dataset\nMean absolute unsigned error "      "%.6f" % err)
    else:
        plt.title(title + " of iris dataset")
    plt.legend(loc="best")
    plt.axis([-4, 4, -1.5, 1.5])

plt.show()
 
    
    
    
    
    
    
###Example - Comparison of Various methods in dimensionality reductions using newsgroup data 
#a corpus of documents 
#and extract additive models of the topic structure of the corpus. 
#The output is a list of topics, each represented as a list of terms 
....
Topic #0: edu com mail send graphics ftp pub available contact university list faq ca information cs 1993 program sun uk mit
Topic #1: don like just know think ve way use right good going make sure ll point got need really time doesn
...

#code 
 
from __future__ import print_function
from time import time

from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.decomposition import NMF, LatentDirichletAllocation
from sklearn.datasets import fetch_20newsgroups

n_samples = 2000
n_features = 1000
n_components = 10
n_top_words = 20


def print_top_words(model, feature_names, n_top_words):
    for topic_idx, topic in enumerate(model.components_):
        message = "Topic #%d: " % topic_idx
        message += " ".join([feature_names[i]
                             for i in topic.argsort()[:-n_top_words - 1:-1]])
        print(message)
    print()


# Load the 20 newsgroups dataset and vectorize it. We use a few heuristics
# to filter out useless terms early on: the posts are stripped of headers,
# footers and quoted replies, and common English words, words occurring in
# only one document or in at least 95% of the documents are removed.

print("Loading dataset...")
t0 = time()
dataset = fetch_20newsgroups(shuffle=True, random_state=1,
                             remove=('headers', 'footers', 'quotes'))
data_samples = dataset.data[:n_samples]
print("done in %0.3fs." % (time() - t0))

# Use tf-idf features for NMF.
print("Extracting tf-idf features for NMF...")
tfidf_vectorizer = TfidfVectorizer(max_df=0.95, min_df=2,
                                   max_features=n_features,
                                   stop_words='english')
t0 = time()
tfidf = tfidf_vectorizer.fit_transform(data_samples)
print("done in %0.3fs." % (time() - t0))

# Use tf (raw term count) features for LDA.
print("Extracting tf features for LDA...")
tf_vectorizer = CountVectorizer(max_df=0.95, min_df=2,
                                max_features=n_features,
                                stop_words='english')
t0 = time()
tf = tf_vectorizer.fit_transform(data_samples)
print("done in %0.3fs." % (time() - t0))
print()

# Fit the NMF model
print("Fitting the NMF model (Frobenius norm) with tf-idf features, "
      "n_samples=%d and n_features=%d..."
      % (n_samples, n_features))
t0 = time()
nmf = NMF(n_components=n_components, random_state=1,
          alpha=.1, l1_ratio=.5).fit(tfidf)
print("done in %0.3fs." % (time() - t0))

print("\nTopics in NMF model (Frobenius norm):")
tfidf_feature_names = tfidf_vectorizer.get_feature_names()
print_top_words(nmf, tfidf_feature_names, n_top_words)

# Fit the NMF model
print("Fitting the NMF model (generalized Kullback-Leibler divergence) with "
      "tf-idf features, n_samples=%d and n_features=%d..."
      % (n_samples, n_features))
t0 = time()
nmf = NMF(n_components=n_components, random_state=1,
          beta_loss='kullback-leibler', solver='mu', max_iter=1000, alpha=.1,
          l1_ratio=.5).fit(tfidf)
print("done in %0.3fs." % (time() - t0))

print("\nTopics in NMF model (generalized Kullback-Leibler divergence):")
tfidf_feature_names = tfidf_vectorizer.get_feature_names()
print_top_words(nmf, tfidf_feature_names, n_top_words)

print("Fitting LDA models with tf features, "
      "n_samples=%d and n_features=%d..."
      % (n_samples, n_features))
lda = LatentDirichletAllocation(n_components=n_components, max_iter=5,
                                learning_method='online',
                                learning_offset=50.,
                                random_state=0)
t0 = time()
lda.fit(tf)
print("done in %0.3fs." % (time() - t0))

print("\nTopics in LDA model:")
tf_feature_names = tf_vectorizer.get_feature_names()
print_top_words(lda, tf_feature_names, n_top_words)







###*** Feature Analysis Visualizers using yellowbrick
##http://www.scikit-yb.org/en/latest/api/index.html
#covers following diagram 
* RadViz Visualizer
* Rank Features
* Parallel Coordinates
* PCA Projection
* Manifold Visualization
* Feature Importances
* Recursive Feature Elimination
* Direct Data Visualization


##PCA Projection
#The PCA Decomposition visualizer utilizes principal component analysis to decompose high dimensional data into two or three dimensions 
#so that each instance can be plotted in a scatter plot. 
#The use of PCA means that the projected dataset can be analyzed along axes of principal variation 
#and can be interpreted to determine if spherical distance metrics can be utilized.

# Load the classification data set
data = pd.read_csv('./data/credit.csv')

# Specify the features of interest and the target
target = "default"
features = [col for col in data.columns if col != target]

# Extract the instance data and the target
X = data[features]
y = data[target]

# Create a list of colors to assign to points in the plot
colors = np.array(['r' if yi else 'b' for yi in y])

from yellowbrick.features.pca import PCADecomposition

visualizer = PCADecomposition(scale=True, color=colors)
visualizer.fit_transform(X, y)
visualizer.poof()



#in three dimensions to attempt to visualize more principal components 
#and get a better sense of the distribution in high dimensions.

visualizer = PCADecomposition(scale=True, color=colors, proj_dim=3)
visualizer.fit_transform(X, y)
visualizer.poof()

   


###*** Linear and Quadratic Discriminant Analysis - Classification 
#they have closed-form solutions that can be easily computed, 
#are inherently multiclass, have proven to work well in practice 
#and have no hyperparameters to tune

class sklearn.discriminant_analysis.LinearDiscriminantAnalysis(solver='svd', shrinkage=None, priors=None, n_components=None, store_covariance=False, tol=0.0001)
    Linear Discriminant Analysis
    A classifier with a linear decision boundary, 
    generated by fitting class conditional densities to the data 
    and using Bayes' rule.
    #Dimensionalityreduction:
    The desired dimensionality can be set using the n_components constructor parameter
    and using 'transform()' to transform those 
    #Shrinkage
    Shrinkage is a tool to improve estimation of covariance matrices 
    in situations where the number of training samples is small compared 
    to the number of features. 
    In this scenario, the empirical sample covariance is a poor estimator. 
    Hence, Set shrinkage parameter to 'auto'. 
    But solver parameter should be  'lsqr' or 'eigen'.
#Methods
decision_function(X)    Predict confidence scores for samples. 
fit(X, y)               Fit LinearDiscriminantAnalysis model according to the given training data and parameters. 
fit_transform(X[, y])   Fit to data, then transform it. 
get_params([deep])      Get parameters for this estimator. 
predict(X)              Predict class labels for samples in X. 
predict_log_proba(X)    Estimate log probability. 
predict_proba(X)        Estimate probability. 
score(X, y[, sample_weight]) Returns the mean accuracy on the given test data and labels. 
set_params(**params)    Set the parameters of this estimator. 
transform(X)            Project data to maximize class separation. 


#Example 
import numpy as np
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
X = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])
y = np.array([1, 1, 1, 2, 2, 2])
clf = LinearDiscriminantAnalysis()
>>> clf.fit(X, y)
LinearDiscriminantAnalysis(n_components=None, priors=None, shrinkage=None,
              solver='svd', store_covariance=False, tol=0.0001)
>>> print(clf.predict([[-0.8, -1]])) #predict class 
[1]




class sklearn.discriminant_analysis.QuadraticDiscriminantAnalysis(priors=None, reg_param=0.0, store_covariance=False, tol=0.0001, store_covariances=None)
    Quadratic Discriminant Analysis
    A classifier with a quadratic decision boundary, 
    generated by fitting class conditional densities to the data 
    and using Bayes' rule.

#Methods
decision_function(X)    Predict confidence scores for samples. 
fit(X, y)               Fit LinearDiscriminantAnalysis model according to the given training data and parameters. 
get_params([deep])      Get parameters for this estimator. 
predict(X)              Predict class labels for samples in X. 
predict_log_proba(X)    Estimate log probability. 
predict_proba(X)        Estimate probability. 
score(X, y[, sample_weight]) Returns the mean accuracy on the given test data and labels. 
set_params(**params)    Set the parameters of this estimator. 

#Example 
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
import numpy as np
X = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])
y = np.array([1, 1, 1, 2, 2, 2])
clf = QuadraticDiscriminantAnalysis()
>>> clf.fit(X, y)
QuadraticDiscriminantAnalysis(priors=None, reg_param=0.0,
                              store_covariance=False,
                              store_covariances=None, tol=0.0001)
>>> print(clf.predict([[-0.8, -1]]))
[1]





###*** Naive Bayes - classification - Bayes' theorem
#http://scikit-learn.org/stable/modules/naive_bayes.html
#Check exmample - https://www.kdnuggets.com/2017/03/email-spam-filtering-an-implementation-with-python-and-scikit-learn.html

#an assumption of independence between predictors/features 
#Naive Bayes methods are a set of supervised learning algorithms based on applying Bayes� theorem 
#with the �naive� assumption of independence between every pair of features

#naive Bayes classifiers have worked quite well in many real-world situations, document classification and spam filtering. 
#They require a small amount of training data to estimate the necessary parameters
# it is known to be a bad estimator, so the probability outputs from predict_proba are not to be taken too seriously.

#MultinomialNB, BernoulliNB, and GaussianNB expose a partial_fit(X, y[, classes, sample_weight]) method that can be used incrementally

#Gaussian Naive Bayes- Gaussian Naive Bayes algorithm for classification
class sklearn.naive_bayes.GaussianNB(priors=None)


###Example of Naive Bayes with iris data 

from sklearn import datasets
iris = datasets.load_iris()
from sklearn.naive_bayes import GaussianNB
gnb = GaussianNB()
y_pred = gnb.fit(iris.data, iris.target).predict(iris.data)
>>> print("Number of mislabeled points out of a total %d points : %d"
    % (iris.data.shape[0],(iris.target != y_pred).sum()))
Number of mislabeled points out of a total 150 points : 6



##multiclass/Multinomial Naive Bayes
sklearn.naive_bayes.MultinomialNB(alpha=1.0, fit_prior=True, class_prior=None)
    Used in text classification (where the data are typically represented as word vector counts)
    alpha : float, optional (default=1.0),
        Additive (Laplace/Lidstone) smoothing parameter (0 for no smoothing).

#Exmaple 
import numpy as np
X = np.random.randint(5, size=(6, 100))   #6x100 random with 0 5 
y = np.array([1, 2, 3, 4, 5, 6])          #target for each row 
from sklearn.naive_bayes import MultinomialNB
clf = MultinomialNB()
clf.fit(X, y)
>>> print(clf.predict(X[2:3]))     #row index 2 of X
[3]


##Bernoulli Naive Bayes
sklearn.naive_bayes.BernoulliNB(alpha=1.0, binarize=0.0, fit_prior=True, class_prior=None)
    For data that is distributed according to multivariate Bernoulli distributions; 
    i.e., there may be multiple features 
    but each one is assumed to be a binary-valued (Bernoulli, boolean) variable
    binarize : float or None, optional,
        Threshold for binarizing (mapping to booleans) of sample features. 
        If None, input is presumed to already consist of binary vectors.

#Example 
import numpy as np
X = np.random.randint(2, size=(6, 100))
Y = np.array([1, 2, 3, 4, 4, 5])
from sklearn.naive_bayes import BernoulliNB
clf = BernoulliNB()
clf.fit(X, Y)
>>> print(clf.predict(X[2:3]))
[3]



###XBoost - eXtreme Gradient Boosting
#Xboost - http://www.picnet.com.au/blogs/guido/post/2016/09/22/xgboost-windows-x64-binaries-for-download/
$ git clone https://github.com/dmlc/xgboost.git xgboost_install_dir
$ copy libxgboost.dll (downloaded from above link) into the xgboost_install_dir\python-package\xgboost\ directory
$ cd xgboost_install_dir\python-package\
$ python setup.py install

#test
import xgboost
xr = xgboost.XGBRegressor() #using sklearn Interface 

##Xboost interface 
class xgboost.DMatrix(data, label=None, missing=None, weight=None, silent=False, feature_names=None, feature_types=None, nthread=None)
    DMatrix is a internal data structure that used by XGBoost which is optimized for both memory efficiency 
    and training speed. 
    You can construct DMatrix from numpy.arrays
    save_binary(fname, silent=True)
        Save DMatrix to an XGBoost buffer
        
class xgboost.Booster(params=None, cache=(), model_file=None)
    Booster is the model of xgboost, 
    that contains low level routines for training, prediction and evaluation
    Takes DMatrix in fit, predict 
    load_model(fname)
        Load the model from a file.
    predict(data, output_margin=False, ntree_limit=0, pred_leaf=False, pred_contribs=False, approx_contribs=False)
        Predict with data
    get_score(fmap='', importance_type='weight')
        Get feature importance of each feature
    dump_model(fout, fmap='', with_stats=False)
        Dump model into a text file.
    eval(data, name='eval', iteration=0)
        Evaluate the model on mat
xgboost.train(params, dtrain, num_boost_round=10, evals=(), obj=None, feval=None, maximize=False, early_stopping_rounds=None, evals_result=None, verbose_eval=True, xgb_model=None, callbacks=None, learning_rates=None)
    Train a booster with dtrain(DMatrix) and given parameters
    Return : a trained booster model(Booster)
    evals_result (dict) � 
        This dictionary stores the evaluation results of all the items in watchlist. 
        Example: with a watchlist containing [(dtest,'eval'), (dtrain,'train')] 
        and a parameter containing ('eval_metric': 'logloss') 
        Returns: 
        {'train': {'logloss': ['0.48253', '0.35953']},
        'eval': {'logloss': ['0.480385', '0.357756']}}
xgboost.cv(params, dtrain, num_boost_round=10, nfold=3, stratified=False, folds=None, metrics=(), obj=None, feval=None, maximize=False, early_stopping_rounds=None, fpreproc=None, as_pandas=True, verbose_eval=None, show_stdv=True, seed=0, callbacks=None, shuffle=True)
    Cross-validation with given parameters.
    Returns:evaluation history
 

##Data Interface
import xgboost as xgb

#The XGBoost python module is able to load data from:
    �libsvm txt format file
    �Numpy 2D array, and
    �xgboost binary buffer file.

#To load a libsvm text file or a XGBoost binary file into DMatrix:
dtrain = xgb.DMatrix('train.svm.txt')
dtest = xgb.DMatrix('test.svm.buffer')

#To load a numpy array into DMatrix:
data = np.random.rand(5, 10)  # 5 entities, each contains 10 features
label = np.random.randint(2, size=5)  # binary target
dtrain = xgb.DMatrix(data, label=label)

#To load a scpiy.sparse array into DMatrix:
csr = scipy.sparse.csr_matrix((dat, (row, col)))
dtrain = xgb.DMatrix(csr)

#Saving DMatrix into a XGBoost binary file will make loading faster:
dtrain = xgb.DMatrix('train.svm.txt')
dtrain.save_binary('train.buffer')

#Missing values can be replaced by a default value in the DMatrix constructor:
dtrain = xgb.DMatrix(data, label=label, missing=-999.0)

#Weights can be set when needed:
w = np.random.rand(5, 1)
dtrain = xgb.DMatrix(data, label=label, missing=-999.0, weight=w)


##Setting Parameters
#Booster parameters
param = {'max_depth': 2, 'eta': 1, 'silent': 1, 'objective': 'binary:logistic'}
param['nthread'] = 4
param['eval_metric'] = 'auc'

#You can also specify multiple eval metrics:
param['eval_metric'] = ['auc', 'ams@0']

# alternatively:
# plst = param.items()
# plst += [('eval_metric', 'ams@0')]

#Specify validations set to watch performance
evallist = [(dtest, 'eval'), (dtrain, 'train')]


#Training-Training a model requires a parameter list and data set.
num_round = 10
bst = xgb.train(plst, dtrain, num_round, evallist)

#After training, the model can be saved.
bst.save_model('0001.model')

#The model and its feature map can also be dumped to a text file.
# dump model
bst.dump_model('dump.raw.txt')
# dump model with feature map
bst.dump_model('dump.raw.txt', 'featmap.txt')

#A saved model can be loaded as follows:
bst = xgb.Booster({'nthread': 4})  # init model
bst.load_model('model.bin')  # load data


##Early Stopping
xgb.train(..., evals=evals, early_stopping_rounds=10)

#Prediction
#A model that has been trained or loaded can perform predictions on data sets.
# 7 entities, each contains 10 features
data = np.random.rand(7, 10)
dtest = xgb.DMatrix(data)
ypred = bst.predict(dtest)

#If early stopping is enabled during training, 
#you can get predictions from the best iteration with bst.best_ntree_limit:
ypred = bst.predict(dtest, ntree_limit=bst.best_ntree_limit)



##Plotting
#To plot importance
xgb.plot_importance(bst)

#To plot the output tree via matplotlib
xgb.plot_tree(bst, num_trees=2)

#When you use IPython, you can use the to_graphviz function
xgb.to_graphviz(bst, num_trees=2)


    
    
##sklearn Interface 
class xgboost.XGBRegressor(max_depth=3, learning_rate=0.1, n_estimators=100, silent=True, objective='reg:linear', booster='gbtree', n_jobs=1, nthread=None, gamma=0, min_child_weight=1, max_delta_step=0, subsample=1, colsample_bytree=1, colsample_bylevel=1, reg_alpha=0, reg_lambda=1, scale_pos_weight=1, base_score=0.5, random_state=0, seed=None, missing=None, **kwargs)
class xgboost.XGBClassifier(max_depth=3, learning_rate=0.1, n_estimators=100, silent=True, objective='binary:logistic', booster='gbtree', n_jobs=1, nthread=None, gamma=0, min_child_weight=1, max_delta_step=0, subsample=1, colsample_bytree=1, colsample_bylevel=1, reg_alpha=0, reg_lambda=1, scale_pos_weight=1, base_score=0.5, random_state=0, seed=None, missing=None, **kwargs)
    Check http://xgboost.readthedocs.io/en/latest/parameter.html
    max_depth : int
        Maximum tree depth for base learners.
    learning_rate : float
        Boosting learning rate (xgb's 'eta')
    n_estimators : int
        Number of boosted trees to fit.
    silent : boolean
        Whether to print messages while running boosting.
    objective : string or callable
        Specify the learning task and the corresponding learning objective or a custom objective function to be used 
        �[default=reg:linear]
            'reg:linear' �linear regression
            'reg:logistic' �logistic regression
            'binary:logistic' �logistic regression for binary classification, output probability
            'binary:logitraw' �logistic regression for binary classification, output score before logistic transformation
            'count:poisson' �poisson regression for count data, output mean of poisson distribution?max_delta_step is set to 0.7 by default in poisson regression (used to safeguard optimization)
            'multi:softmax' �set XGBoost to do multiclass classification using the softmax objective, you also need to set num_class(number of classes)
            'multi:softprob' �same as softmax, but output a vector of ndata * nclass, which can be further reshaped to ndata, nclass matrix. The result contains predicted probability of each data point belonging to each class.
            'rank:pairwise' �set XGBoost to do ranking task by minimizing the pairwise loss
            'reg:gamma' �gamma regression with log-link. Output is a mean of gamma distribution. It might be useful, e.g., for modeling insurance claims severity, or for any outcome that might be gamma-distributed
            'reg:tweedie' �Tweedie regression with log-link. It might be useful, e.g., for modeling total loss in insurance, or for any outcome that might be Tweedie-distributed.
    booster: string
        Specify which booster to use: gbtree, gblinear or dart.
        gbtree and dart use tree based model while gblinear uses linear function.
    reg_alpha : float (xgb's alpha)
        L1 regularization term on weights
    reg_lambda : float (xgb's lambda)
        L2 regularization term on weights
    #Methods 
    fit(X, y, sample_weight=None, eval_set=None, eval_metric=None, early_stopping_rounds=None, verbose=True, xgb_model=None)
        eval_metric:default according to objective
        (rmse for regression, and error for classification, mean average precision for ranking )
        ?User can add multiple evaluation metrics via list 
          'rmse': root mean square error
          'mae': mean absolute error
          'logloss': negative log-likelihood
          'error': Binary classification error rate. It is calculated as #(wrong cases)/#(all cases). For the predictions, the evaluation will regard the instances with prediction value larger than 0.5 as positive instances, and the others as negative instances.
          'error@t': a different than 0.5 binary classification threshold value could be specified by providing a numerical value through 't'.
          'merror': Multiclass classification error rate. It is calculated as #(wrong cases)/#(all cases).
          'mlogloss': Multiclass logloss
          'auc': Area under the curve for ranking evaluation.
          'ndcg':Normalized Discounted Cumulative Gain
          'map':Mean average precision
          'ndcg@n','map@n': n can be assigned as an integer to cut off the top positions in the lists for evaluation.
          'ndcg-','map-','ndcg@n-','map@n-': In XGBoost, NDCG and MAP will evaluate the score of a list without any positive samples as 1. By adding '-' in the evaluation metric XGBoost will evaluate these score as 0 to be consistent under some conditions. training repeatedly
          'poisson-nloglik': negative log-likelihood for Poisson regression
          'gamma-nloglik': negative log-likelihood for gamma regression
          'gamma-deviance': residual deviance for gamma regression
          'tweedie-nloglik': negative log-likelihood for Tweedie regression (at a specified value of the tweedie_variance_power parameter)
    evals_result()
        Return the evaluation results.
        #Example 
        param_dist = {'objective':'binary:logistic', 'n_estimators':2}
        clf = xgb.XGBClassifier(**param_dist)
        clf.fit(X_train, y_train,eval_set=[(X_train, y_train), (X_test, y_test)], eval_metric='logloss', verbose=True)
        >>> evals_result = clf.evals_result()
            {'validation_0': {'logloss': ['0.604835', '0.531479']},
            'validation_1': {'logloss': ['0.41965', '0.17686']}}
            
xgboost.to_graphviz(booster, fmap='', num_trees=0, rankdir='UT', yes_color='#0000FF', no_color='#FF0000', **kwargs)
    Convert specified tree to graphviz instance
xgboost.plot_tree(booster, fmap='', num_trees=0, rankdir='UT', ax=None, **kwargs)
    Plot specified tree.      
xgboost.plot_importance(booster, ax=None, height=0.2, xlim=None, ylim=None, title='Feature importance', xlabel='F score', ylabel='Features', importance_type='weight', max_num_features=None, grid=True, show_values=True, **kwargs)
    Plot importance based on fitted trees.
        �booster (Booster, XGBModel or dict) � Booster or XGBModel instance, 

##Check parameter tuning 
https://www.analyticsvidhya.com/blog/2016/03/complete-guide-parameter-tuning-xgboost-with-codes-python/
 


##With sklearn 
import pickle
import xgboost as xgb

import numpy as np
from sklearn.model_selection import KFold, train_test_split, GridSearchCV
from sklearn.metrics import confusion_matrix, mean_squared_error
from sklearn.datasets import load_iris, load_digits, load_boston

rng = np.random.RandomState(31337)

print("Zeros and Ones from the Digits dataset: binary classification")
digits = load_digits(2)
y = digits['target']
X = digits['data']
kf = KFold(n_splits=2, shuffle=True, random_state=rng)
for train_index, test_index in kf.split(X):
    xgb_model = xgb.XGBClassifier().fit(X[train_index], y[train_index])
    predictions = xgb_model.predict(X[test_index])
    actuals = y[test_index]
    print(confusion_matrix(actuals, predictions))

print("Iris: multiclass classification")
iris = load_iris()
y = iris['target']
X = iris['data']
kf = KFold(n_splits=2, shuffle=True, random_state=rng)
for train_index, test_index in kf.split(X):
    xgb_model = xgb.XGBClassifier().fit(X[train_index], y[train_index])
    predictions = xgb_model.predict(X[test_index])
    actuals = y[test_index]
    print(confusion_matrix(actuals, predictions))

print("Boston Housing: regression")
boston = load_boston()
y = boston['target']
X = boston['data']
kf = KFold(n_splits=2, shuffle=True, random_state=rng)
for train_index, test_index in kf.split(X):
    xgb_model = xgb.XGBRegressor().fit(X[train_index], y[train_index])
    predictions = xgb_model.predict(X[test_index])
    actuals = y[test_index]
    print(mean_squared_error(actuals, predictions))

print("Parameter optimization")
y = boston['target']
X = boston['data']
xgb_model = xgb.XGBRegressor()
clf = GridSearchCV(xgb_model,{'max_depth': [2,4,6],'n_estimators': [50,100,200]}, verbose=1)
clf.fit(X,y)
print(clf.best_score_)
print(clf.best_params_)

# The sklearn API models are picklable
print("Pickling sklearn API models")
# must open in binary format to pickle
pickle.dump(clf, open("best_boston.pkl", "wb"))
clf2 = pickle.load(open("best_boston.pkl", "rb"))
print(np.allclose(clf.predict(X), clf2.predict(X)))

# Early-stopping

X = digits['data']
y = digits['target']
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
clf = xgb.XGBClassifier()
clf.fit(X_train, y_train, early_stopping_rounds=10, eval_metric="auc",
        eval_set=[(X_test, y_test)])











