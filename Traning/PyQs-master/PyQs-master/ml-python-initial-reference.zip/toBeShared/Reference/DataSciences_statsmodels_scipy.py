
###SciPy  - scientific and engineering functions based on NumPy array 

#below modules re present 
•Clustering package                                 (scipy.cluster)
•Constants                                          (scipy.constants)
•Discrete Fourier transforms                        (scipy.fftpack)
•Integration and ODEs                               (scipy.integrate)
•Interpolation                                      (scipy.interpolate)
•Input and output                                   (scipy.io)
•Linear algebra                                     (scipy.linalg)
•Miscellaneous routines                             (scipy.misc)
•Multi-dimensional image processing                 (scipy.ndimage)
•Orthogonal distance regression                     (scipy.odr)
•Optimization and root finding                      (scipy.optimize)
•Signal processing                                  (scipy.signal)
•Sparse matrices                                    (scipy.sparse)
•Sparse linear algebra                              (scipy.sparse.linalg)
•Compressed Sparse Graph Routines                   (scipy.sparse.csgraph)
•Spatial algorithms and data structures             (scipy.spatial)
•Special functions                                  (scipy.special)
•Statistical functions                              (scipy.stats)
•Statistical functions for masked arrays            (scipy.stats.mstats)


### SciPi - Quick matplotlib plot 
#https://matplotlib.org/api/pyplot_api.html#matplotlib.pyplot.plot

import matplotlib.pyplot as plt


#For multi lines, an arbitrary number of x, y, fmt groups can be specified
#x,y are numpy array or list  , fmt = 'One_char_fromColor_one_char_fromLineStyle'
plt.plot(x1, y1, 'g^', x2, y2, 'g-', ....)

#or for single line 
plt.plot(x, y, color='green', linestyle='dashed', marker='o',  markerfacecolor='blue', markersize=12).
#colors can be full names ('green'), hex strings ('#008000'), 
#RGB or RGBA tuples ((0,1,0,1)) or grayscale intensities as a string ('0.8')

#then show 
plt.show()

## line style or marker
'-'     solid line style 
'--'    dashed line style 
'-.'    dash-dot line style 
':'     dotted line style 
'.'     point marker 
','     pixel marker 
'o'     circle marker 
'v'     triangle_down marker 
'^'     triangle_up marker 
'<'     triangle_left marker 
'>'     triangle_right marker 
'1'     tri_down marker 
'2'     tri_up marker 
'3'     tri_left marker 
'4'     tri_right marker 
's'     square marker 
'p'     pentagon marker 
'*'     star marker 
'h'     hexagon1 marker 
'H'     hexagon2 marker 
'+'     plus marker 
'x'     x marker 
'D'     diamond marker 
'd'     thin_diamond marker 
'|'     vline marker 
'_'     hline marker 

#color style 
'b'     blue 
'g'     green 
'r'     red 
'c'     cyan 
'm'     magenta 
'y'     yellow 
'k'     black 
'w'     white 

## few properties that can be passsed to  plt.plot or ax.plot or other plot functions 
alpha                   float (0.0 transparent through 1.0 opaque) 
animated                [True | False] 
antialiased or aa       [True | False] 
clip_box                a matplotlib.transforms.Bbox instance 
clip_on                 [True | False] 
color or c              any matplotlib color 
dash_capstyle           ['butt' | 'round' | 'projecting'] 
dash_joinstyle          ['miter' | 'round' | 'bevel'] 
drawstyle               ['default' | 'steps' | 'steps-pre' | 'steps-mid' | 'steps-post'] 
fillstyle               ['full' | 'left' | 'right' | 'bottom' | 'top' | 'none'] 
label                   string or anything printable with '%s' conversion. 
linestyle or ls         ['solid' | 'dashed', 'dashdot', 'dotted' | (offset, on-off-dash-seq) | '-' | '--' | '-.' | ':' | 'None' | ' ' | ''] 
linewidth or lw         float value in points 
marker                  A valid marker style 
markeredgecolor or mec  any matplotlib color 
markeredgewidth or mew  float value in points 
markerfacecolor or mfc  any matplotlib color 
markersize or ms        float 
solid_capstyle          ['butt' | 'round' | 'projecting'] 
solid_joinstyle         ['miter' | 'round' | 'bevel'] 
visible                 [True | False] 
zorder                  any number 

##Few other plot functions on plt. or on ax., 
#Most of the above key words can be given 
.scatter(x, y, s=None, c=None, marker=None, **kwargs)                           Make a scatter plot of x vs y. 
.plot_date(x, y, fmt='o', tz=None, xdate=True, ydate=False, *, data=None, **kwargs)  A plot with data that contains dates. 
.step(x, y,**kwargs)       Make a step plot. 

.loglog(x, y,**kwargs)     Make a plot with log scaling on both the x and y axis. 
.semilogx(x, y,**kwargs)   Make a plot with log scaling on the x axis. 
.semilogy(x, y,**kwargs)   Make a plot with log scaling on the y axis. 

.bar(x, height, width_default: 0.8, *, align='center', **kwargs)        Make a bar plot,
.barh(y, width, height_default: 0.8, *, align='center', **kwargs)       Make a horizontal bar plot. 

.pie(x, explode=None, labels=None, colors=None, ..)                     Plot a pie chart. 
.fill(sequence of x, y, color like plot, **kwargs)  Plot filled polygons. 

.vlines(x, ymin, ymax, colors='k', linestyles='solid', label='', *, data=None, **kwargs)            Plot vertical lines. 
.hlines(y, xmin, xmax, colors='k', linestyles='solid', label='', *, data=None, **kwargs)            Plot horizontal lines at each y from xmin to xmax. 

.axhline(y=0, xmin=0, xmax=1, **kwargs)             Add a horizontal line across the axis.
.axhspan(ymin, ymax, xmin=0, xmax=1, **kwargs)      Add a horizontal span (rectangle) across the axis.
.axvline(x=0, ymin=0, ymax=1, **kwargs)             Add a vertical line across the axes
.axvspan(xmin, xmax, ymin=0, ymax=1, **kwargs)      Add a vertical span (rectangle) across the axes

.hist(x, bins=None, range=None, density=None, weights=None, cumulative=False,..)        Plot a histogram.
.imshow(X_shape (n, m) or (n, m, 3) or (n, m, 4) ,..)   Display an image on the axes.
.matshow(Z_shape (n, m), **kwargs)                      Plot a matrix or array as an image.


##With subplots 
#Draw Window contains many Figure 
#Each Figure can have multiple axes on them
#Axes are used to draw 

##Option-1 
#note subplots(..) returns (figure,axes)
#where axes is numpy.ndarray, hence access like axes[0,0], axes[0,1],... for complex subplots 
#for simple , can destructure immediately
figure, (ax1, ax2) = plt.subplots(nrows=1, ncols=2, sharex=False, sharey=True,...  )
ax1.plot(x,y,fmt,.....)  
ax1.set_title('Sharing Y axis')
ax2.scatter(x, y)
#then show 
plt.show()

##Option-2 
fig = plt.figure(figsize=(15,15))        #create a figure 
ax1 = fig.add_subplot(211)               ## nrows,ncols, which_Axes_tomake_current ie 1  
ax1.plot(x,y,fmt,.....)  
ax2 = fig.add_subplot(212)
ax2.plot(x,y,fmt,.....) 
#then show 
plt.show()

##Option-3 
plt.figure(1)                # the first figure
plt.subplot(211)             # nrows,ncols, which_Axes_tomake_current ie 1                             
plt.plot(x,y,fmt,.....)      # all plot/scatter/box/hist etc goes subplot 1 
plt.subplot(212)             # nrows,ncols, which_Axes_tomake_current ie 2
plt.plot(x,y,fmt,.....)      # all plot/scatter/box/hist etc goes subplot 2

plt.figure(2)                # a second figure, sets to this figure, all plot commands go here
plt.plot(x,y,fmt,.....)      # creates a subplot(111) by default

plt.figure(1)                # figure 1 current; subplot(212) still current
plt.subplot(211)             # make subplot(211) in figure1 current
plt.title('Easy as 1, 2, 3') # subplot 211 title
#then show 
plt.show()

##Few utility methods 
ax = plt.gca()  #Get the current Axes instance on the current figure 
fig = plt.gcf()  #Get a reference to the current figure.
ax.cla() #clear 
fig.clf() # clear 

##Few figure methods 
fig.legend(handles=(line1, line2, line3), labels=('label1', 'label2', 'label3'), loc='upper right') #loc can be (x,y) or predefined string , linen are matplotlib line instance
fig.text(x, y, s, *args, **kwargs) #Add text to figure.
fig.savefig(fname, **kwargs) #Save the current figure
fig.sca(a)          #Set the current axes to be a and return a
fig.set_dpi(val)            #Set the dots-per-inch of the figure, val is float 
fig.set_edgecolor(color)    #any matplotlib color 
fig.set_facecolor(color)    #any matplotlib color 
fig.set_figheight(val, forward=False) #val is float 
fig.set_figwidth(val, forward=False)  #val is float 
fig.set_size_inches(w, h=None, forward=True)
fig.subplots(nrows=1, ncols=1, sharex=False, sharey=False, squeeze=True, subplot_kw=None, gridspec_kw=None) #returns axes as ndarray


##Few plt. methods, Note below  operates on the current axis.
#Note below relevant methods withour arg gives current value eg xlim() gives current xlimit 
plt.xlabel('x axis label', fontsize=14, color='red')
plt.ylabel('y axis label')
plt.title('Sine and Cosine')
plt.legend(['Sine', 'Cosine'])
plt.axis([0, 4, 0, 10]) #Set the axis, [xmin, xmax, ymin, ymax] or 'off' or 'equal' or 'scaled' or 'tight' etc 
plt.text(60, .025, r'$\mu=100,\ \sigma=15$')  #Any text  or  '$any LaTex code$'
plt.grid(True)
plt.ylim(-2,2)
plt.xlim(-2,2)
plt.annotate('local max', xy=(2, 1), xytext=(3, 1.5),arrowprops=dict(facecolor='black', shrink=0.05),) #xytext=location of text, xy=location for annotation
plt.yscale('linear') #log, symlog, logit
plt.xscale('linear')

##Few Axes methods  , many are available on plt. as well 
#Note below relevant methods withour arg or get_*() gives current value 
#eg xlim() gives current xlimit , get_xlabel() gives current xlabel 
ax.set_xlabel('x axis label')
ax.set_ylabel('y axis label')
ax.set_title('Simple plot')
ax.legend(['Sine', 'Cosine'])

ax.axis([0, 4, 0, 10]) #Set the axis, [xmin, xmax, ymin, ymax] or 'off' or 'equal' or 'scaled' or 'tight' etc 
ax.set_axis_off() #Turn off the axis. 
ax.set_axis_on()  # Turn on the axis. 

ax.text(60, .025, r'$\mu=100,\ \sigma=15$')  #Any text 
ax.annotate('local max', xy=(2, 1), xytext=(3, 1.5),arrowprops=dict(facecolor='black', shrink=0.05),) #xytext=location of text, xy=location for annotation
ax.arrow(x, y, dx, dy, **kwargs)    #Add an arrow to the axes.
ax.grid(b=True|False, color='r', linestyle='-', linewidth=2)
ax.set_label(s)       #Set the label to s for auto legend.
 
ax.set_ylim(-2,2)
ax.set_xlim(-2,2)
ax.set_yscale('linear') #log, symlog, logit
ax.set_xscale('linear')
ax.set_visible(b)     #Set the artist's visibility.
ax.set_zorder(level)  #Set the zorder for the artist. Artists with lower zorder values are drawn first.

ax.set_xticks(ticks, minor=False)     #Set the x ticks with list of ticks
ax.set_xticklabels(labels, fontdict=None, minor=False, **kwargs)#Set the x-tick labels with list of string labels.
ax.set_yticks(ticks, minor=False)#Set the y ticks with list of ticks
ax.set_yticklabels(labels, fontdict=None, minor=False, **kwargs)#Set the y-tick labels with list of strings labels.

ax.xaxis_date(tz=None)  #Sets up x-axis ticks and labels that treat the x data as dates.
ax.yaxis_date(tz=None)  #Sets up y-axis ticks and labels that treat the y data as dates.
ax.minorticks_off()     #Remove minor ticks from the axes.
ax.minorticks_on()      #Remove minor ticks from the axes.
new_ax = ax.twinx()     #Create a twin Axes sharing the xaxis
new_ax = ax.twiny()     #Create a twin Axes sharing the yaxis



###Scipy - scipy.linalg - https://docs.scipy.org/doc/scipy/reference/linalg.html
#similar to Python numpy.linalg

##scipy.linalg.inv(a, overwrite_a=False, check_finite=True)

>>> from scipy import linalg
>>> a = np.array([[1., 2.], [3., 4.]])
>>> linalg.inv(a)
array([[-2. ,  1. ],
       [ 1.5, -0.5]])
>>> np.dot(a, linalg.inv(a))
array([[ 1.,  0.],
       [ 0.,  1.]])


##scipy.linalg.solve(a, b, sym_pos=False, lower=False, overwrite_a=False, overwrite_b=False, debug=None, check_finite=True, assume_a='gen', transposed=False)

 >>> a = np.array([[3, 2, 0], [1, -1, 0], [0, 5, 1]])
>>> b = np.array([2, 4, -1])
>>> from scipy import linalg
>>> x = linalg.solve(a, b)
>>> x
array([ 2., -2.,  9.])
>>> np.dot(a, x) == b
array([ True,  True,  True], dtype=bool)


##scipy.linalg.eig(a, b=None, left=False, right=True, overwrite_a=False, overwrite_b=False, check_finite=True, homogeneous_eigvals=False)
a : (M, M) array_like
    A complex or real matrix whose eigenvalues and eigenvectors will be computed.

b : (M, M) array_like, optional
    Right-hand side matrix in a generalized eigenvalue problem. 
    Default is None, identity matrix is assumed.

Returns:
    w : (M,) or (2, M) double or complex ndarray
    The eigenvalues, each repeated according to its multiplicity. 
    The shape is (M,) unless homogeneous_eigvals=True.

vl : (M, M) double or complex ndarray
    The normalized left eigenvector corresponding to the eigenvalue w[i] is the column vl[:,i]. 
    Only returned if left=True.

vr : (M, M) double or complex ndarray
    The normalized right eigenvector corresponding to the eigenvalue w[i] is the column vr[:,i]. 
    Only returned if right=True.
 
 
>>> import numpy as np
>>> import scipy as sp
>>> import scipy.linalg
>>> K = np.mat([[1.8, -1.097+0.995j], [-1.097-0.955j, 1.8]])
>>> M = np.mat([[209., 0.], [0., 209.]])
>>> M
matrix([[ 209.,    0.],
        [   0.,  209.]])
>>> K
matrix([[ 1.800+0.j   , -1.097+0.955j],
        [-1.097-0.955j,  1.800+0.j   ]])
>>> D, V = sp.linalg.eig(K, b=M)
>>> D
array([ 0.00165333 -1.99202696e-19j,  0.01557155 +0.00000000e+00j])
>>> V
array([[ 0.70710678 +0.00000000e+00j, -0.53332494 +4.64289256e-01j],
       [ 0.53332494 +4.64289256e-01j,  0.70710678 -8.38231384e-18j]])







###Scipy - optimize - https://docs.scipy.org/doc/scipy/reference/optimize.html


##scipy.optimize.minimize(fun, x0, args=(), method=None, jac=None, hess=None, hessp=None, bounds=None, constraints=(), tol=None, callback=None, options=None)
#Minimization of scalar function of one or more variables
fun : callable
    The objective function to be minimized. 
    Must be in the form f(x, *args). 
    The optimizing argument, x, is a 1-D array of points, 
    and args is a tuple of any additional fixed parameters needed to completely specify the function
bounds : sequence, optional
    Bounds for variables (only for L-BFGS-B, TNC and SLSQP). 
    (min, max) pairs for each element in x, defining the bounds on that parameter. 
    Use None for one of min or max when there is no bound in that direction.
constraints : dict or sequence of dict, optional
    Constraints definition (only for COBYLA and SLSQP). 
    Each constraint is defined in a dictionary with fields:
    type : str
           Constraint type: 'eq' for equality, 'ineq' for inequality.
    fun : callable
          The function defining the constraint.
method : Type of solver. Should be one of
    •'Nelder-Mead' 
    •'Powell' 
    •'CG' 
    •'BFGS' 
    •'Newton-CG' 
    •'L-BFGS-B' 
    •'TNC' 
    •'COBYLA' 
    •'SLSQP' 
    •'dogleg' 
    •'trust-ncg' 
    •'trust-exact' 
    •'trust-krylov' 
Returns:res : OptimizeResult
    Attributes are 
        x (ndarray) The solution of the optimization. 
        success (bool) Whether or not the optimizer exited successfully. 
        status (int) Termination status of the optimizer. 
        message (str) Description of the cause of the termination. 
        fun, jac, hess: ndarray Values of objective function, its Jacobian and its Hessian (if available). 
        hess_inv (object): Inverse of the objective function's Hessian; 
        nfev, njev, nhev: (int) Number of evaluations of the objective functions and of its Jacobian and Hessian. 
        nit (int): Number of iterations performed by the optimizer. 
        maxcv (float): The maximum constraint violation 

     
#Example - The objective function is, two variables= x[0], x[1]
>>> fun = lambda x: (x[0] - 1)**2 + (x[1] - 2.5)**2

#There are three constraints defined as:
>> cons = ({'type': 'ineq', 'fun': lambda x:  x[0] - 2 * x[1] + 2},
        {'type': 'ineq', 'fun': lambda x: -x[0] - 2 * x[1] + 6},
        {'type': 'ineq', 'fun': lambda x: -x[0] + 2 * x[1] + 2})
#And variables must be positive, hence the following bounds:
>>> bnds = ((0, None), (0, None))
#The optimization problem is solved using the SLSQP method as:
>>> res = minimize(fun, (2, 0), method='SLSQP', bounds=bnds,  constraints=cons)
>>> res.x
>>> print(res.message)
>>> res.hess_inv

#Example - minimizing the Rosenbrock function. 
#This function (and its respective derivatives) is implemented in rosen 
from scipy.optimize import minimize, rosen, rosen_der
#Option-1 
>>> x0 = [1.3, 0.7, 0.8, 1.9, 1.2]
>>> res = minimize(rosen, x0, method='Nelder-Mead', tol=1e-6)
>>> res.x
array([ 1.,  1.,  1.,  1.,  1.])
##Option-2 
>>> res = minimize(rosen, x0, method='BFGS', jac=rosen_der,
...                options={'gtol': 1e-6, 'disp': True})
Optimization terminated successfully.
         Current function value: 0.000000
         Iterations: 26
         Function evaluations: 31
         Gradient evaluations: 31
>>> res.x
array([ 1.,  1.,  1.,  1.,  1.])
>>> print(res.message)
Optimization terminated successfully.
>>> res.hess_inv




##scipy.optimize.minimize_scalar(fun, bracket=None, bounds=None, args=(), method='brent', tol=None, options=None)
#Minimization of scalar function of one variable.
    method : Type of solver. Should be one of:
        •'Brent' 
        •'Bounded' 
        •'Golden' 


>>> def f(x):
        return (x - 2) * x * (x + 2)**2


#Using the Brent method, we find the local minimum as:
>>> from scipy.optimize import minimize_scalar
>>> res = minimize_scalar(f)
>>> res.x
1.28077640403
#Using the Bounded method, we find a local minimum with specified bounds as:
>>> res = minimize_scalar(f, bounds=(-3, -1), method='bounded')
>>> res.x
-2.0000002026


##Equation (Local) Minimizers
nnls(A, b)                                          Solve argmin_x || Ax - b ||_2 for x>=0. 
                                                    A : ndarray,Matrix A 
                                                    b : ndarray,Right-hand side vector.
                                                    Returns:
                                                        x : ndarray,Solution vector.
                                                        rnorm : float,The residual, || Ax-b ||_2.
lsq_linear(A, b[, bounds, method, tol, ...])        Solve a linear  
least_squares(fun, x0[, jac, bounds, ...])          Solve a nonlinear least-squares problem with bounds on the variables. 


##scipy.optimize.lsq_linear(A, b, bounds=(-inf, inf), method='trf', tol=1e-10, lsq_solver=None, lsmr_tol=None, max_iter=None, verbose=0)
#Solve a linear least-squares problem with bounds on the variables.
#Given a m-by-n design matrix A and a target vector b with m elements
    method : 'trf' or 'bvls'
    lsq_solver : {None, 'exact', 'lsmr'}, optional
    Returns:OptimizeResult with the following fields defined:
        x : ndarray, shape (n,)
            Solution found.
        cost : float
            Value of the cost function at the solution.
        fun : ndarray, shape (m,)
            Vector of residuals at the solution.
        nit : int
            Number of iterations. Zero if the unconstrained solution is optimal.
        status : int
            Reason for algorithm termination:
            •-1 : the algorithm was not able to make progress on the last iteration.
            •0 : the maximum number of iterations is exceeded.
            •1 : the first-order optimality measure is less than tol.
            •2 : the relative change of the cost function is less than tol.
            •3 : the unconstrained solution is optimal.
        message : str
            Verbal description of the termination reason.
        success : bool
            True if one of the convergence criteria is satisfied (status > 0).
 
#Example 
from scipy.sparse import rand
from scipy.optimize import lsq_linear

np.random.seed(0)
m = 20000
n = 10000
A = rand(m, n, density=1e-4)
b = np.random.randn(m)
lb = np.random.randn(n)
ub = lb + 1

>>> res = lsq_linear(A, b, bounds=(lb, ub), lsmr_tol='auto', verbose=1)
>>> res.x


##scipy.optimize.least_squares(fun, x0, jac='2-point', bounds=(-inf, inf), method='trf', ftol=1e-08, xtol=1e-08, gtol=1e-08, x_scale=1.0, loss='linear', f_scale=1.0, diff_step=None, tr_solver=None, tr_options={}, jac_sparsity=None, max_nfev=None, verbose=0, args=(), kwargs={})
#Solve a nonlinear least-squares problem with bounds on the variables.
fun : callable
    Function which computes the vector of residuals, 
    with the signature fun(x, *args, **kwargs), 
    i.e., the minimization proceeds with respect to its first argument. 
    The argument x passed to this function is an ndarray of shape (n,) 
    (never a scalar, even for n=1). 
    It must return a 1-d array_like of shape (m,) or a scalar. 
bounds : 2-tuple of array_like, optional
    Lower and upper bounds on independent variables. 
    Defaults to no bounds.
    Each array must match the size of x0 or be a scalar, 
    in the latter case a bound will be the same for all variables. 
    Use np.inf with an appropriate sign to disable bounds on all or some variables.
method : 
    {'trf', 'dogbox', 'lm'}, optional
loss : str or callable, optional
    Determines the loss function. The following keyword values are allowed:
    •'linear' (default) : rho(z) = z. Gives a standard least-squares problem.
    •'soft_l1' : rho(z) = 2 * ((1 + z)**0.5 - 1). The smooth approximation of l1 (absolute value) loss. Usually a good choice for robust least squares.
    •'huber' : rho(z) = z if z <= 1 else 2*z**0.5 - 1. Works similarly to 'soft_l1'.
    •'cauchy' : rho(z) = ln(1 + z). Severely weakens outliers influence, but may cause difficulties in optimization process.
    •'arctan' : rho(z) = arctan(z). Limits a maximum loss on a single residual, has properties similar to 'cauchy'.
    If callable, it must take a 1-d ndarray z=f**2 
    and return an array_like with shape (3, m) 
    where row 0 contains function values, 
    row 1 contains first derivatives
    and row 2 contains second derivatives. 
    Method 'lm' supports only 'linear' loss.
Returns:OptimizeResult with the following fields defined:
    x : ndarray, shape (n,)
        Solution found.
    cost : float
        Value of the cost function at the solution.
    fun : ndarray, shape (m,)
        Vector of residuals at the solution.
    jac : ndarray, sparse matrix or LinearOperator, shape (m, n)
        Modified Jacobian matrix at the solution
    grad : ndarray, shape (m,)
        Gradient of the cost function at the solution.
    status : int
        The reason for algorithm termination:
        •-1 : improper input parameters status returned from MINPACK.
        •0 : the maximum number of function evaluations is exceeded.
        •1 : gtol termination condition is satisfied.
        •2 : ftol termination condition is satisfied.
        •3 : xtol termination condition is satisfied.
        •4 : Both ftol and xtol termination conditions are satisfied.
    message : str
        Verbal description of the termination reason.
    success : bool
        True if one of the convergence criteria is satisfied (status > 0).
 



#Example -  solve a curve fitting problem using robust loss function 
#to take care of outliers in the data. 

#Define the model function as y = a + b * exp(c * t), 
#where t is a predictor variable, 
#y is an observation and a, b, c are parameters to estimate.

#generate data:
>>> def gen_data(t, a, b, c, noise=0, n_outliers=0, random_state=0):
        y = a + b * np.exp(t * c)    
        rnd = np.random.RandomState(random_state)
        error = noise * rnd.randn(t.size)
        outliers = rnd.randint(0, t.size, n_outliers)
        error[outliers] *= 10    
        return y + error
    
a = 0.5
b = 2.0
c = -1
t_min = 0
t_max = 10
n_points = 15

t_train = np.linspace(t_min, t_max, n_points)
y_train = gen_data(t_train, a, b, c, noise=0.1, n_outliers=3)


#Define function for computing residuals and initial estimate of parameters.
#a=x[0], b= x[1], c = x[2]
>>> def fun(x, t, y):
        return x[0] + x[1] * np.exp(x[2] * t) - y

>>> x0 = np.array([1.0, 1.0, 0.0])
#Compute a standard least-squares solution:
>>> res_lsq = least_squares(fun, x0, args=(t_train, y_train))


#compute two solutions with two different robust loss functions. 
#The parameter f_scale is set to 0.1, meaning that inlier residuals should not significantly exceed 0.1 
#(the noise level used).
>>> res_soft_l1 = least_squares(fun, x0, loss='soft_l1', f_scale=0.1, args=(t_train, y_train))
>>> res_log = least_squares(fun, x0, loss='cauchy', f_scale=0.1,    args=(t_train, y_train))


#plot all the curves. 
#by selecting an appropriate loss 
#we can get estimates close to optimal even in the presence of strong outliers. 

#it is recommended to try 'soft_l1' or 'huber' losses first (if at all necessary)
#as the other two options may cause difficulties in optimization process

>>> t_test = np.linspace(t_min, t_max, n_points * 10)
>>> y_true = gen_data(t_test, a, b, c)
>>> y_lsq = gen_data(t_test, *res_lsq.x)
>>> y_soft_l1 = gen_data(t_test, *res_soft_l1.x)
>>> y_log = gen_data(t_test, *res_log.x)

>>> import matplotlib.pyplot as plt
>>> plt.plot(t_train, y_train, 'o')
>>> plt.plot(t_test, y_true, 'k', linewidth=2, label='true')
>>> plt.plot(t_test, y_lsq, label='linear loss')
>>> plt.plot(t_test, y_soft_l1, label='soft_l1 loss')
>>> plt.plot(t_test, y_log, label='cauchy loss')
>>> plt.xlabel("t")
>>> plt.ylabel("y")
>>> plt.legend()
>>> plt.show()


##scipy.optimize.curve_fit(f, xdata, ydata, p0=None, sigma=None, absolute_sigma=False, check_finite=True, bounds=(-inf, inf), method=None, jac=None, **kwargs)
#Use non-linear least squares to fit a function, f, to data.
    f : callable
        The model function, f(x, ...). 
        It must take the independent variable as the first argument 
        and the parameters to fit as separate remaining arguments.
        xdata : An M-length sequence or an (k,M)-shaped array for functions 
        with k predictors,The independent variable where the data is measured.
    ydata : M-length sequence
        
    p0 : None, scalar, or N-length sequence, optional
        Initial guess for the parameters. 
        If None, then the initial values will all be 1 
    bounds : 2-tuple of array_like, optional
        Lower and upper bounds on independent variables. 
        Defaults to no bounds. 
        Each element of the tuple must be either an array 
        with the length equal to the number of parameters, 
        or a scalar (in which case the bound is taken to be the same for all parameters.) 
        Use np.inf with an appropriate sign to disable bounds on all or some parameters.
    Returns:
        popt : array
            Optimal values for the parameters 
            so that the sum of the squared residuals of f(xdata, *popt) - ydata is minimized
        pcov : 2d array
            The estimated covariance of popt. 
            The diagonals provide the variance of the parameter estimate. 
            To compute one standard deviation errors on the parameters 
            use perr = np.sqrt(np.diag(pcov)).
 
#Example 
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit



def func(x, a, b, c):
    return a * np.exp(-b * x) + c


#define the data to be fit with some noise
>>> xdata = np.linspace(0, 4, 50)
>>> y = func(xdata, 2.5, 1.3, 0.5)  #a,b,c
>>> y_noise = 0.2 * np.random.normal(size=xdata.size)
>>> ydata = y + y_noise
>>> plt.plot(xdata, ydata, 'b-', label='data')


#Fit for the parameters a, b, c of the function func
>>> popt, pcov = curve_fit(func, xdata, ydata) #popt is array [a,b,c]
>>> plt.plot(xdata, func(xdata, *popt), 'r-', label='fit')


#Constrain the optimization to the region of 0 < a < 3, 0 < b < 2 and 0 < c < 1:
>>> popt, pcov = curve_fit(func, xdata, ydata, bounds=(0, [3., 2., 1.]))
>>> plt.plot(xdata, func(xdata, *popt), 'g--', label='fit-with-bounds')
>>> plt.xlabel('x')
>>> plt.ylabel('y')
>>> plt.legend()
>>> plt.show()


##Global Optimization
basinhopping(func, x0[, niter, T, stepsize, ...]) Find the global minimum of a function using the basin-hopping algorithm 
brute(func, ranges[, args, Ns, full_output, ...]) Minimize a function over a given range by brute force. 
differential_evolution(func, bounds[, args, ...]) Finds the global minimum of a multivariate function 

##scipy.optimize.brute(func, ranges, args=(), Ns=20, full_output=0, finish=<function fmin>, disp=False
Uses the 'brute force' method, 
i.e. computes the function's value at each point of a multidimensional 
grid of points, to find the global minimum of the function.
    func : callable
        The objective function to be minimized. 
        Must be in the form f(x, *args), 
        where x is the argument in the form of a 1-D array (ie x,y,z,..)
        and args is a tuple of any additional fixed parameters needed to completely 
        specify the function.
    ranges : tuple
        Each component of the ranges tuple must be either a 'slice object' 
        or a range tuple of the form (low, high). 
        The program uses these to create the grid of points 
        on which the objective function will be computed
    Returns:
    x0 : ndarray
        A 1-D array containing the coordinates of a point 
        at which the objective function had its minimum value. 
    fval : float
        Function value at the point x0. 
 
 
#Example - define the objective function f as the sum of three other functions, 
#f = f1 + f2 + f3. 
#We suppose each of these has a signature (z, *params), 
#where z = (x, y), and params and the functions are as defined below.


params = (2, 3, 7, 8, 9, 10, 44, -1, 2, 26, 1, -2, 0.5)
def f1(z, *params):
    x, y = z
    a, b, c, d, e, f, g, h, i, j, k, l, scale = params
    return (a * x**2 + b * x * y + c * y**2 + d*x + e*y + f)

def f2(z, *params):
    x, y = z
    a, b, c, d, e, f, g, h, i, j, k, l, scale = params
    return (-g*np.exp(-((x-h)**2 + (y-i)**2) / scale))

def f3(z, *params):
    x, y = z
    a, b, c, d, e, f, g, h, i, j, k, l, scale = params
    return (-j*np.exp(-((x-k)**2 + (y-l)**2) / scale))



def f(z, *params):
    return f1(z, *params) + f2(z, *params) + f3(z, *params)


rranges = (slice(-4, 4, 0.25), slice(-4, 4, 0.25))
from scipy import optimize
resbrute = optimize.brute(f, rranges, args=params, full_output=True, finish=optimize.fmin)
>>>resbrute[0]  # global minimum
array([-1.05665192,  1.80834843])
>>> resbrute[1]  # function value at global minimum
-3.4085818767

##scipy.optimize.differential_evolution
scipy.optimize.differential_evolution(func, bounds, args=(), strategy='best1bin', maxiter=1000, popsize=15, tol=0.01, mutation=(0.5, 1), recombination=0.7, seed=None, callback=None, disp=False, polish=True, init='latinhypercube', atol=0)[source]
    Finds the global minimum of a multivariate function. 
    Differential Evolution is stochastic in nature (does not use gradient methods) 
    to find the minimium, and can search large areas of candidate space, 
    but often requires larger numbers of function evaluations than conventional gradient based techniques.
Parameters:
    func : callable
        The objective function to be minimized. 
        Must be in the form f(x, *args), 
        where x is the argument in the form of a 1-D array 
        and args is a tuple of any additional fixed parameters needed to completely specify the function.
    bounds : sequence
        Bounds for variables. 
        (min, max) pairs for each element in x, defining the lower and upper bounds for the optimizing argument of func. 
        It is required to have len(bounds) == len(x). 
        len(bounds) is used to determine the number of parameters in x.
    args : tuple, optional
        Any additional fixed parameters needed to completely specify the objective function.
    strategy : str, optional
        •'best1bin'
        •'best1exp'
        •'rand1exp'
        •'randtobest1exp'
        •'best2exp'
        •'rand2exp'
        •'randtobest1bin'
        •'best2bin'
        •'rand2bin'
        •'rand1bin'
        The default is 'best1bin'.
Returns:res : OptimizeResult
    Important attributes are: x the solution array, 
    success a Boolean flag indicating if the optimizer exited successfully 
    message which describes the cause of the termination
#Example - find the minimum of the Ackley function (http://en.wikipedia.org/wiki/Test_functions_for_optimization).
from scipy.optimize import differential_evolution
import numpy as np
def ackley(x):  #function of two variables 
    arg1 = -0.2 * np.sqrt(0.5 * (x[0] ** 2 + x[1] ** 2))
    arg2 = 0.5 * (np.cos(2. * np.pi * x[0]) + np.cos(2. * np.pi * x[1]))
    return -20. * np.exp(arg1) - np.exp(arg2) + 20. + np.e

bounds = [(-5, 5), (-5, 5)]
result = differential_evolution(ackley, bounds)
>>> result.x, result.fun
(array([ 0.,  0.]), 4.4408920985006262e-16)




##Linear Programming
scipy.optimize.linprog(c, A_ub=None, b_ub=None, A_eq=None, b_eq=None, bounds=None, method='simplex', callback=None, options=None)[source]
    Minimize a linear objective function subject to linear equality 
    and inequality constraints.
    Minimize:     c^T * x
    Subject to:   A_ub * x <= b_ub
                  A_eq * x == b_eq
    Parameters:
    c : array_like
        Coefficients of the linear objective function to be minimized.
    A_ub : array_like, optional
        2-D array which, when matrix-multiplied by x, 
        gives the values of the upper-bound inequality constraints at x.

    b_ub : array_like, optional
        1-D array of values representing the upper-bound of each inequality constraint 
        (row) in A_ub.
    A_eq : array_like, optional
        2-D array which, when matrix-multiplied by x, 
        gives the values of the equality constraints at x.
    b_eq : array_like, optional
        1-D array of values representing the RHS of each equality constraint (row) in A_eq.
    bounds : sequence, optional
        (min, max) pairs for each element in x, defining the bounds on that parameter. 
        Use None for one of min or max when there is no bound in that direction. 
        By default bounds are (0, None) (non-negative) 
        If a sequence containing a single tuple is provided, 
        then min and max will be applied to all variables in the problem.
    method : str, optional
        Type of solver. 'simplex' and 'interior-point' are supported.     
    Returns:A scipy.optimize.OptimizeResult consisting of the following fields:
        x : ndarray
            The independent variable vector which optimizes the linear programming problem.
        fun : float
            Value of the objective function.
        slack : ndarray
            The values of the slack variables. Each slack variable corresponds to an inequality constraint. If the slack is zero, then the corresponding constraint is active.
        success : bool
            Returns True if the algorithm succeeded in finding an optimal solution.
        status : int
            An integer representing the exit status of the optimization
        nit : int
        The number of iterations performed.
        message : str
            A string descriptor of the exit status of the optimization.

#Example 

#Minimize: f = -1*x[0] + 4*x[1]
#Subject to: -3*x[0] + 1*x[1] <= 6
#            1*x[0] + 2*x[1] <= 4
#where:           
#            x[1] >= -3
#            -inf <= x[0] <= inf


c = [-1, 4]
A = [[-3, 1], [1, 2]]  #row1= -3*x[0] + 1*x[1], row2= 1*x[0] + 2*x[1] 
b = [6, 4]  #<= 6, <= 4
x0_bounds = (None, None) #-inf <= x[0] <= inf
x1_bounds = (-3, None) #x[1] >= -3
from scipy.optimize import linprog
res = linprog(c, A_ub=A, b_ub=b, bounds=(x0_bounds, x1_bounds), options={"disp": True})
Optimization terminated successfully.
     Current function value: -22.000000
     Iterations: 1
>>> print(res)
     fun: -22.0
 message: 'Optimization terminated successfully.'
     nit: 1
   slack: array([ 39.,   0.])
  status: 0
 success: True
       x: array([ 10.,  -3.])

       
       
##Root finding - Scalar functions
# Ridders' method is faster than bisection, 
#but not generally as fast as the Brent rountines
brentq(f, a, b[, args, xtol, rtol, maxiter, ...]) Find a root of a function in a bracketing interval using Brent's method. 
brenth(f, a, b[, args, xtol, rtol, maxiter, ...]) Find root of f in [a,b]. 
ridder(f, a, b[, args, xtol, rtol, maxiter, ...]) Find a root of a function in an interval. 
bisect(f, a, b[, args, xtol, rtol, maxiter, ...]) Find root of a function within an interval. 
newton(func, x0[, fprime, args, tol, ...]) Find a zero using the Newton-Raphson or secant method. 

#Example - newton 
#fprime2 : The second order derivative of the function when available and convenient
>>> def f(x):
        return (x**3 - 1)  # only one real root at x = 1

from scipy import optimize
#fprime and fprime2 not provided, use secant method
root = optimize.newton(f, 1.5)
>>> root
1.0000000000000016

#Only fprime provided, use Newton Raphson method
root = optimize.newton(f, 1.5, fprime=lambda x: 3 * x**2)
>>> root
1.0

#fprime2 provided, fprime provided/not provided use parabolic Halley's method
root = optimize.newton(f, 1.5, fprime2=lambda x: 6 * x)
>>> root
1.0000000000000016
root = optimize.newton(f, 1.5, fprime=lambda x: 3 * x**2,fprime2=lambda x: 6 * x)
>>> root
1.0

#Example - of brenth

>>> def f(x):
        return (x**2 - 1)
        
from scipy import optimize
root = optimize.brenth(f, -2, 0)
>>> root
-1.0
root = optimize.brenth(f, 0, 2)
>>> root
1.0

#Example of bisect 
#f(a) and f(b) cannot have the same signs. Slow but sure.
>>> def f(x):
        return (x**2 - 1)

from scipy import optimize
root = optimize.bisect(f, 0, 2)
>>> root
1.0
root = optimize.bisect(f, -2, 0)
>>> root
-1.0




##Fixed point finding:
fixed_point(func, x0[, args, xtol, maxiter, ...]) Find a fixed point of the function. 
#Given a function of one or more variables and a starting point, 
#find a fixed-point of the function: i.e. where func(x0) == x0.                             
from scipy import optimize
def func(x, c1, c2):
    return np.sqrt(c1/(x+c2))

c1 = np.array([10,12.])
c2 = np.array([3, 5.])
>>> xx = optimize.fixed_point(func, [1.2, 1.3], args=(c1,c2))
array([ 1.4920333 ,  1.37228132])
>>> func(xx,c1,c2)
array([1.4920333 , 1.37228132])
    
       
       
##Multidimensional root finding - General nonlinear solvers:
scipy.optimize.root(fun, x0, args=(), method='hybr', jac=None, tol=None, callback=None, options=None)[source]
    Find a root of a vector function.
    Parameters:
        fun : callable
            A vector function to find a root of.
        x0 : ndarray
            Initial guess.
        args : tuple, optional
            Extra arguments passed to the objective function and its Jacobian.
        method : str, optional
            •Method Krylov uses Krylov approximation for inverse Jacobian. 
                It is suitable for large-scale problem
            Type of solver. Should be one of
            •'hybr' 
            •'lm' 
            •'broyden1' 
            •'broyden2' 
            •'anderson' 
            •'linearmixing' 
            •'diagbroyden' 
            •'excitingmixing' 
            •'krylov' 
            •'df-sane' 
        jac : bool or callable, optional
            If jac is a Boolean and is True, 
            fun is assumed to return the value of Jacobian along with the objective function. 
            If False, the Jacobian will be estimated numerically. 
            jac can also be a callable returning the Jacobian of fun. 
            In this case, it must accept the same arguments as fun.
    Returns:
        sol : OptimizeResult
        Important attributes are: x the solution array, 
        success a Boolean flag indicating if the algorithm exited successfully 
        message which describes the cause of the termination
 
#Example , with two variable, x[0], x[1]
def fun(x):
    return [x[0]  + 0.5 * (x[0] - x[1])**3 - 1.0,
         0.5 * (x[1] - x[0])**3 + x[1]]


#this is optional 
def jac(x):
    return np.array([[1 + 1.5 * (x[0] - x[1])**2,
                   -1.5 * (x[0] - x[1])**2],
                  [-1.5 * (x[1] - x[0])**2,
                   1 + 1.5 * (x[1] - x[0])**2]])


from scipy import optimize
sol = optimize.root(fun, [0, 0], jac=jac, method='hybr')
>>> sol.x
array([ 0.8411639,  0.1588361])






### Scipy - Integration (scipy.integrate)

from scipy import integrate

>>> help(integrate) 
Methods for Integrating Functions given function object.
quad          -- General purpose integration.   
dblquad       -- General purpose double integration.   
tplquad       -- General purpose triple integration.   
fixed_quad    -- Integrate func(x) using Gaussian quadrature of order n.   
quadrature    -- Integrate with given tolerance using Gaussian quadrature.   
romberg       -- Integrate func using Romberg integration.
 
Methods for Integrating Functions given fixed samples.
trapz         -- Use trapezoidal rule to compute integral from samples.   
cumtrapz      -- Use trapezoidal rule to cumulatively compute integral.   
simps         -- Use Simpson's rule to compute integral from samples.   
romb          -- Use Romberg Integration to compute integral from  (2**k + 1) evenly-spaced samples.

#Example - scipy.integrate.trapz(y, x=None, dx=1.0, axis=-1)
>>> np.trapz([1,2,3])
4.0
>>> np.trapz([1,2,3], x=[4,6,8])
8.0
>>> np.trapz([1,2,3], dx=2)
8.0
>>> a = np.arange(6).reshape(2, 3)
>>> a
array([[0, 1, 2],
       [3, 4, 5]])
>>> np.trapz(a, axis=0)
array([ 1.5,  2.5,  3.5])
>>> np.trapz(a, axis=1)
array([ 2.,  8.])



##General integration (quad)
#scipy.integrate.quad(func, a, b, args=(), full_output=0, epsabs=1.49e-08, epsrel=1.49e-08, limit=50, points=None, weight=None, wvar=None, wopts=None, maxp1=50, limlst=50)
#to integrate a function of one variable between two point s.
#The points can be +/-inf to indicate infinite limits.
a : float
    Lower limit of integration (use -numpy.inf for -infinity).
b : float
    Upper limit of integration (use numpy.inf for +infinity).
Returns:
    y : float The integral of func from a to b.
    abserr : float ,An estimate of the absolute error in the result.
 
#Example 
>>> from scipy import integrate
>>> x2 = lambda x: x**2
>>> integrate.quad(x2, 0, 4)
(21.333333333333332, 2.3684757858670003e-13)
>>> print(4**3 / 3.)  # analytical result
21.3333333333


#Calculate ∫ ∞ 0 e −x dx 
>>> invexp = lambda x: np.exp(-x)
>>> integrate.quad(invexp, 0, np.inf)
(1.0, 5.842605999138044e-11)


#with addl args 
>>> f = lambda x,a : a*x
>>> y, err = integrate.quad(f, 0, 1, args=(1,))
>>> y
0.5
>>> y, err = integrate.quad(f, 0, 1, args=(3,))
>>> y
1.5




##General multiple integration (dblquad, tplquad, nquad)
scipy.integrate.dblquad(func, a, b, gfun, hfun, args=(), epsabs=1.49e-08, epsrel=1.49e-08)
    Return the double (definite) integral of func(y, x) from x = a..b 
    and y = gfun(x)..hfun(x).
scipy.integrate.tplquad(func, a, b, gfun, hfun, qfun, rfun, args=(), epsabs=1.49e-08, epsrel=1.49e-08)[source]
    Return the triple integral of func(z, y, x) from x = a..b, 
    y = gfun(x)..hfun(x), and z = qfun(x,y)..rfun(x,y).
scipy.integrate.nquad(func, ranges, args=None, opts=None, full_output=False)[source]
    Integration over multiple variables.
    func : The function to be integrated,func(x0, x1, ..., xn, t0, t1, ..., tm)
        where integration is carried out over x0, ... xn, which must be floats. 
        That is, integration over x0 is the innermost integral, and xn is the outermost.
    ranges : iterable object
        Each element of ranges may be either a sequence of 2 numbers, 
        or else a callable that returns such a sequence. 
        ranges[0] corresponds to integration over x0, and so on. 
        If an element of ranges is a callable, 
        then it will be called with all of the integration arguments available, 
        as well as any parametric arguments. 
        e.g. if func = f(x0, x1, x2, t0, t1), 
        then ranges[0] may be defined as either (a, b) 
        or else as (a, b) = range0(x1, x2, t0, t1).
    args : iterable object, optional
        Additional arguments t0, ..., tn, required by func, ranges, and opts.
Returns:
    result/y : float,The resultant integral.
    abserr : float,An estimate of the error.
 

>>> from scipy.integrate import quad, dblquad
>>> def I(n):        
        return dblquad(lambda t, x: np.exp(-x*t)/t**n, 0, np.inf, lambda x: 1, lambda x: np.inf)

>>> print(I(4))
(0.25000000000435768, 1.0518245707751597e-09)
>>> print(I(3))
(0.33333333325010883, 2.8604069919261191e-09)
>>> print(I(2))
(0.49999999999857514, 1.8855523253868967e-09)

#Example 

from scipy import integrate
func = lambda x0,x1,x2,x3 : x0**2 + x1*x2 - x3**3 + np.sin(x0) + (
                                1 if (x0-.2*x3-.5-.25*x1>0) else 0)
                                
points = [[lambda x1,x2,x3 : 0.2*x3 + 0.5 + 0.25*x1], [], [], []]
def opts0(*args, **kwargs):
     return {'points':[0.2*args[2] + 0.5 + 0.25*args[0]]}
     
>>> integrate.nquad(func, [[0,1], [-1,1], [.13,.8], [-.15,1]],
                    opts=[opts0,{},{},{}], full_output=True)
(1.5267454070738633, 2.9437360001402324e-14, {'neval': 388962})


scale = .1
def func2(x0, x1, x2, x3, t0, t1):
    return x0*x1*x3**2 + np.sin(x2) + 1 + (1 if x0+t1*x1-t0>0 else 0)
def lim0(x1, x2, x3, t0, t1):
    return [scale * (x1**2 + x2 + np.cos(x3)*t0*t1 + 1) - 1,
            scale * (x1**2 + x2 + np.cos(x3)*t0*t1 + 1) + 1]
def lim1(x2, x3, t0, t1):
    return [scale * (t0*x2 + t1*x3) - 1,
            scale * (t0*x2 + t1*x3) + 1]
def lim2(x3, t0, t1):
    return [scale * (x3 + t0**2*t1**3) - 1,
            scale * (x3 + t0**2*t1**3) + 1]
def lim3(t0, t1):
    return [scale * (t0+t1) - 1, scale * (t0+t1) + 1]
def opts0(x1, x2, x3, t0, t1):
    return {'points' : [t0 - t1*x1]}
def opts1(x2, x3, t0, t1):
    return {}
def opts2(x3, t0, t1):
    return {}
def opts3(t0, t1):
    return {}
>>> integrate.nquad(func2, [lim0, lim1, lim2, lim3], args=(0,0),
...                 opts=[opts0, opts1, opts2, opts3])
(25.066666666666666, 2.7829590483937256e-13)






###Scipy - interpolation or extraploation , use with scipy.interpolate.


interp1d(x, y[, kind, axis, copy, ...])     Interpolate a 1-D function. 
                                            kind : str or int, optional
                                            Specifies the kind of interpolation as a string 
                                            ('linear, 'nearest', 'zero, 'slinear', 'quadratic, 'cubic')
                                            where 'zero', 'slinear', 'quadratic and 'cubic' 
                                            refer to a spline interpolation of zeroth, first, second or third order) 
                                            or as an integer specifying the order of the spline interpolator to use. 
                                            Default is 'linear'.

interp2d(x, y, z[, kind, copy, ...])        Interpolate over a 2-D grid. 
                                            kind : {'linear, 'cubic, 'quintic'}, optional
                                            The kind of spline interpolation to use. 
                                            Default is 'linear'.


#it has __call__(x,y,..) for getting interpolated values 
#x, y : array_like,Arrays defining the data point coordinates.

#Note that calling interp1d/interp2d with NaNs present in input values results in undefined behaviour.

#example 
>>> import matplotlib.pyplot as plt
>>> from scipy import interpolate
>>> x = np.arange(0, 10)
>>> y = np.exp(-x/3.0)
>>> f = interpolate.interp1d(x, y)



>>> xnew = np.arange(0, 9, 0.1)
>>> ynew = f(xnew)   # use interpolation function returned by `interp1d`
>>> plt.plot(x, y, 'o', xnew, ynew, '-')
>>> plt.show()


#Example 

>>> from scipy import interpolate
>>> x = np.arange(-5.01, 5.01, 0.25)
>>> y = np.arange(-5.01, 5.01, 0.25)
>>> xx, yy = np.meshgrid(x, y) #xx is row stack of x, yy is column stack of y 
>>> z = np.sin(xx**2+yy**2)
>>> f = interpolate.interp2d(x, y, z, kind='cubic')

#Now use the obtained interpolation function and plot the result:
>>> import matplotlib.pyplot as plt
>>> xnew = np.arange(-5.01, 5.01, 1e-2)
>>> ynew = np.arange(-5.01, 5.01, 1e-2)
>>> znew = f(xnew, ynew)
>>> plt.plot(x, z[0, :], 'ro-', xnew, znew[0, :], 'b-')
>>> plt.show()


##Multidimensional interpolation on regular grids.
scipy.interpolate.interpn(points, values, xi, method='linear', bounds_error=True, fill_value=nan)[source]
    Parameters:
        points : tuple of ndarray of float, with shapes (m1, ), ..., (mn, )
            The points defining the regular grid in n dimensions.
        values : array_like, shape (m1, ..., mn, ...)
            The data on the regular grid in n dimensions.
        xi : ndarray of shape (..., ndim)
            The coordinates to sample the gridded data at
        method : str, optional
            The method of interpolation to perform. 
            Supported are 'linear' and 'nearest', and 'splinef2d'. 
            'splinef2d' is only supported for 2-dimensional data.
    Returns:
        values_x : ndarray, shape xi.shape[:-1] + values.shape[ndim:]
            Interpolated values at input coordinates.
 

#Example 
import numpy as np

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm

# Set up grid and array of values
x1 = np.arange(10)
x2 = np.arange(10)
arr = x1 + x2[:, np.newaxis]  #x2 is converted to (10,1)

# Set up grid for plotting
X, Y = np.meshgrid(x1, x2) #xx is row stack of x, yy is column stack of y 

# Plot the values as a surface plot to depict
fig = plt.figure()
ax = fig.gca(projection='3d')
surf = ax.plot_surface(X, Y, arr, rstride=1, cstride=1, cmap=cm.jet,
                       linewidth=0, alpha=0.8)
fig.colorbar(surf, shrink=0.5, aspect=5)

# to interpolate along a line, i.e., one point along the first dimension, 
#but all points along the second dimension
from scipy.interpolate import interpn

interp_x = 3.5           # Only one value on the x1-axis
interp_y = np.arange(10) # A range of values on the x2-axis

# Note the following two lines that are used to set up the
# interpolation points as a 10x2 array!
interp_mesh = np.array(np.meshgrid(interp_x, interp_y))
>>> interp_mesh
array([[[3.5],
        [3.5],
        [3.5],
        [3.5],
        [3.5],
        [3.5],
        [3.5],
        [3.5],
        [3.5],
        [3.5]],

       [[0. ],
        [1. ],
        [2. ],
        [3. ],
        [4. ],
        [5. ],
        [6. ],
        [7. ],
        [8. ],
        [9. ]]])
>>> interp_mesh.shape
(2, 10, 1)  
>>> np.rollaxis(interp_mesh, 0, 3).shape
(10, 1, 2)
interp_points = np.rollaxis(interp_mesh, 0, 3).reshape((10, 2))
>>> interp_points
array([[3.5, 0. ],
       [3.5, 1. ],
       [3.5, 2. ],
       [3.5, 3. ],
       [3.5, 4. ],
       [3.5, 5. ],
       [3.5, 6. ],
       [3.5, 7. ],
       [3.5, 8. ],
       [3.5, 9. ]])
#or 
interp_points = np.array( [ [3.5,i] for i in range(10)  ])
# Perform the interpolation
interp_arr = interpn((x1, x2), arr, interp_points)

# Plot the result
ax.scatter(interp_x * np.ones(interp_y.shape), interp_y, interp_arr, s=20,
           c='k', depthshade=False)
plt.xlabel('x1')
plt.ylabel('x2')
plt.show()




















###SciPy - Parse 
#There are seven available sparse matrix types: 
#each suitable for some tasks
1.csc_matrix: Compressed Sparse Column format
2.csr_matrix: Compressed Sparse Row format
3.bsr_matrix: Block Sparse Row format
4.lil_matrix: List of Lists format
5.dok_matrix: Dictionary of Keys format
6.coo_matrix: COOrdinate format (aka IJV, triplet format)
7.dia_matrix: DIAgonal format

#don't use np.methods() on sparse matrix directly 
#Use Scipy parseMatrix instance methods if available 
#or use np version after conversion to array
#with sparseInstance.toarray(), sparseInstance.todense()

#To construct a matrix efficiently, use either dok_matrix or lil_matrix. 

#The lil_matrix class supports basic slicing and fancy indexing with a similar syntax to NumPy arrays.

##Parse - Arithmatic Operation 
#To perform  arithmetic operations(elementwise)  *, -, +, - ,/, ** 
#first convert the matrix to either CSC(.tocsc()) or CSR format(.tocsr()) 
#Or convery to np.ndarray array via toarray() or todense() and then use np methods
#The lil_matrix format is row-based, so conversion to CSR is efficient


##Common instance attributes and Methods 
•mtx.A - same as mtx.toarray()
•mtx.T - transpose (same as mtx.transpose())
•mtx.H - Hermitian (conjugate) transpose
•mtx.real - real part of complex matrix
•mtx.imag - imaginary part of complex matrix
•mtx.size - the number of nonzeros (same as self.getnnz())
•mtx.shape - the number of rows and columns (tuple)

#Below instance methods for arithmatic operations 
power(n[, dtype])	This function performs element-wise power.
multiply(other)	    Point-wise multiplication by another matrix
dot(other)	        Ordinary dot product

#Nonzero elements 
count_nonzero()	    Number of non-zero entries,
nonzero()	        nonzero indices

#each element datatype conversion, instance method
asfptype()	                    Upcast matrix to a floating point format (if necessary)
astype(dtype[, casting, copy])	Cast the matrix elements to a specified type.

#Formating instance methods 
asformat(format)	Return this matrix in a given sparse format
getformat()	        Format of a matrix representation as a string.
getmaxprint()	    Maximum number of elements to display when printed.

#Getting row or column 
getcol(j)	Returns a copy of column j of the matrix, as an (m x 1) sparse matrix (column vector).
getrow(i)	Returns a copy of row i of the matrix, as a (1 x n) sparse matrix (row vector).

#shape change 
reshape(shape[, order])	    Gives a new shape to a sparse matrix without changing its data.

#Instances have following methods 
maximum(other)	            Element-wise maximum between this and another matrix.
mean([axis, dtype, out])	Compute the arithmetic mean along the specified axis.
minimum(other)	            Element-wise minimum between this and another matrix.
copy()	                    Returns a copy of this matrix.
sum([axis, dtype, out])	    Sum the matrix elements over a given axis.
transpose([axes, copy])	    Reverses the dimensions of the sparse matrix.
#only for CSR,CSC,COO, BSR not for DIA,LIL and DOK
argmax([axis, out])         Return indices of maximum elements along an axis
argmin([axis, out])         Return indices of minimum elements along an axis
max([axis, out])            Return the maximum of the matrix or maximum along an axis. 
min([axis, out])            Return the minimum of the matrix or maximum along an axis. 


#Diagonal manipulation methods 
diagonal([k])	        Returns the k-th diagonal of the matrix.
setdiag(values[, k])	Set diagonal or off-diagonal elements of the array.

#Instances have below mathematical functions 
tan()	    Element-wise tan.
tanh()	    Element-wise tanh.
sign()	    Element-wise sign.
sin()	    Element-wise sin.
sinh()	    Element-wise sinh.
sqrt()	    Element-wise sqrt.
rint()	    Element-wise rint.
arcsin()	Element-wise arcsin.
arcsinh()	Element-wise arcsinh.
arctan()	Element-wise arctan.
arctanh()	Element-wise arctanh.
ceil()	    Element-wise ceil.
conj()	    Element-wise complex conjugation.
conjugate()	Element-wise complex conjugation.
expm1()	    Element-wise expm1.
floor()	    Element-wise floor.
log1p()	    Element-wise log1p.
rad2deg()	Element-wise rad2deg.
deg2rad()	Element-wise deg2rad.
trunc()	    Element-wise trunc.

#Instances Have below methods for conversion 
toarray([order, out])	    Return a dense ndarray representation of this matrix.
tobsr([blocksize, copy])	Convert this matrix to Block Sparse Row format.
tocoo([copy])	            Convert this matrix to COOrdinate format.
tocsc([copy])	            Convert this matrix to Compressed Sparse Column format.
tocsr([copy])	            Convert this matrix to Compressed Sparse Row format.
todense([order, out])	    Return a dense matrix representation of this matrix.
todia([copy])	            Convert this matrix to sparse DIAgonal format.
todok([copy])	            Convert this matrix to Dictionary Of Keys format.
tolil([copy])	            Convert this matrix to LInked List format.

##scipy.parse  - Building sparse matrices:
eye(m[, n, k, dtype, format])   Sparse matrix with ones on diagonal 
identity(n[, dtype, format])    Identity matrix in sparse format 
hstack(blocks[, format, dtype]) Stack sparse matrices horizontally (column wise) 
vstack(blocks[, format, dtype]) Stack sparse matrices vertically (row wise) 

tril(A[, k, format])            Return the lower triangular portion of a matrix in sparse format 
triu(A[, k, format])            Return the upper triangular portion of a matrix in sparse format 

kron(A, B[, format])            kronecker product of sparse matrices A and B 
kronsum(A, B[, format])         kronecker sum of sparse matrices A and B 

diags(diagonals[, offsets, shape, format, dtype]) Construct a sparse matrix from diagonals. 

spdiags(data, diags, m, n[, format])        Return a sparse matrix from diagonals. 
block_diag(mats[, format, dtype])           Build a block diagonal sparse matrix from provided matrices. 

bmat(blocks[, format, dtype])               Build a sparse matrix from sparse sub-blocks 

rand(m, n[, density, format, dtype, ...])   Generate a sparse matrix of the given shape and density with uniformly distributed values. 
random(m, n[, density, format, dtype, ...]) Generate a sparse matrix of the given shape and density with randomly distributed values. 

#Sparse matrix tools:
find(A)        Return the indices and values of the nonzero elements of a matrix 

#Identifying sparse matrices:
issparse(x)  
isspmatrix(x)  
isspmatrix_csc(x)  
isspmatrix_csr(x)  
isspmatrix_bsr(x)  
isspmatrix_lil(x)  
isspmatrix_dok(x)  
isspmatrix_coo(x)  
isspmatrix_dia(x) 





##Sparse matrix type - DIAgonal format - scipy.sparse.dia_matrix 
#Creation 
dia_matrix(D)
    with a dense matrix
dia_matrix(S)
    with another sparse matrix S (equivalent to S.todia())
dia_matrix((M, N), [dtype])
    to construct an empty matrix with shape (M, N), dtype is optional, 
dia_matrix((data, offsets), shape=(M, N))
    where the data[k,:] stores the diagonal entries for diagonal offsets[k]
    •offset for each diagonal
        • 0 is the main diagonal, a[i,i]
        • negative offset = below eg -1 is next diagonal below main diagonal  
        • positive offset = above eg 1 is next  diagonal above main diagonal 

#Example 
>>> import numpy as np
>>> from scipy import sparse
>>> import matplotlib.pyplot as plt
>>> data = np.array([[1, 2, 3, 4]]).repeat(3, axis=0)
>>> data
array([[1, 2, 3, 4],
       [1, 2, 3, 4],
       [1, 2, 3, 4]])
>>> offsets = np.array([0, -1, 2])
>>> mtx = sparse.dia_matrix((data, offsets), shape=(4, 4))
>>> mtx.todense()
matrix([[1, 0, 3, 0],
        [1, 2, 0, 4],
        [0, 2, 3, 0],
        [0, 0, 3, 4]])
>>> data = np.arange(12).reshape((3, 4)) + 1
>>> data
array([[ 1,  2,  3,  4],
       [ 5,  6,  7,  8],
       [ 9, 10, 11, 12]])
>>> mtx = sparse.dia_matrix((data, offsets), shape=(4, 4))
>>> mtx.data   
array([[ 1,  2,  3,  4],
       [ 5,  6,  7,  8],
       [ 9, 10, 11, 12]]...)
>>> mtx.offsets
array([ 0, -1,  2], dtype=int32)
>>> print(mtx)   
  (0, 0)        1
  (1, 1)        2
  (2, 2)        3
  (3, 3)        4
  (1, 0)        5
  (2, 1)        6
  (3, 2)        7
  (0, 2)        11
  (1, 3)        12
>>> mtx.todense()
matrix([[ 1,  0, 11,  0],
        [ 5,  2,  0, 12],
        [ 0,  6,  3,  0],
        [ 0,  0,  7,  4]])


#Note arithmatic operations not supported 
>>> vec = np.ones((4, ))
>>> vec
array([ 1.,  1.,  1.,  1.])
>>> mtx * vec
array([ 12.,  19.,   9.,  11.])
>>> mtx.toarray() * vec
array([[  1.,   0.,  11.,   0.],
       [  5.,   2.,   0.,  12.],
       [  0.,   6.,   3.,   0.],
       [  0.,   0.,   7.,   4.]])


       
##Sparse matrix type - scipy.sparse.lil_matrix - List of Lists format
#Creation 
lil_matrix(D)
    with a dense matrix or rank-2 ndarray D
lil_matrix(S)
    with another sparse matrix S (equivalent to S.tolil())
lil_matrix((M, N), [dtype])
    to construct an empty matrix with shape (M, N) dtype is optional, defaulting to dtype='d'.
      
#Advantages of the LIL format
•supports flexible slicing
•changes to the matrix sparsity structure are efficient
#Disadvantages of the LIL format
•arithmetic operations LIL + LIL are slow (consider CSR or CSC)
•slow column slicing (consider CSC)
•slow matrix vector products (consider CSR or CSC)

#Example - create an empty LIL matrix:
>>> mtx = sparse.lil_matrix((4, 5))
#prepare random data:
>>> from numpy.random import rand
>>> data = np.round(rand(2, 3))
>>> data
array([[ 1.,  1.,  1.],
       [ 1.,  0.,  1.]])
#assign the data using fancy indexing:
>>> mtx[:2, [1, 2, 3]] = data # indices: row=[0,1], column=[1,2,3]
>>> print(mtx) 
  (0, 1)  1.0
  (0, 2)  1.0
  (0, 3)  1.0
  (1, 1)  1.0
  (1, 3)  1.0
>>> mtx.todense()
matrix([[ 0.,  1.,  1.,  1.,  0.],
        [ 0.,  1.,  0.,  1.,  0.],
        [ 0.,  0.,  0.,  0.,  0.],
        [ 0.,  0.,  0.,  0.,  0.]])
>>> mtx.toarray()
array([[ 0.,  1.,  1.,  1.,  0.],
       [ 0.,  1.,  0.,  1.,  0.],
       [ 0.,  0.,  0.,  0.,  0.],
       [ 0.,  0.,  0.,  0.,  0.]])
#more slicing and indexing:
>>> mtx = sparse.lil_matrix([[0, 1, 2, 0], [3, 0, 1, 0], [1, 0, 0, 1]])
>>> mtx.todense()
matrix([[0, 1, 2, 0],
        [3, 0, 1, 0],
        [1, 0, 0, 1]]...)
>>> print(mtx) 
  (0, 1)    1
  (0, 2)    2
  (1, 0)    3
  (1, 2)    1
  (2, 0)    1
  (2, 3)    1
>>> mtx[:2, :]  
<2x4 sparse matrix of type '<... 'numpy.int64'>'
  with 4 stored elements in LInked List format>
>>> mtx[:2, :].todense()
matrix([[0, 1, 2, 0],
        [3, 0, 1, 0]]...)
>>> mtx[1:2, [0,2]].todense()
matrix([[3, 1]]...)
>>> mtx.todense()    
matrix([[0, 1, 2, 0],
        [3, 0, 1, 0],
        [1, 0, 0, 1]]...)


##Sparse matrix type - Dictionary of Keys format - scipy.sparse.dok_matrix
#Creation 
dok_matrix(D)
    with a dense matrix, D
dok_matrix(S)
    with a sparse matrix, S
dok_matrix((M,N), [dtype])
    create the matrix with initial shape (M,N) dtype is optional, defaulting to dtype='d'
#Advantage and disadvantage 
•efficient O(1) access to individual elements
•flexible slicing, changing sparsity structure is efficient
•can be efficiently converted to a coo_matrix once constructed
•slow arithmetics (for loops with dict.iteritems())


#Example 
>>> mtx = sparse.dok_matrix((5, 5), dtype=np.float64)
>>> mtx     
<5x5 sparse matrix of type '<... 'numpy.float64'>'
        with 0 stored elements in Dictionary Of Keys format>
>>> for ir in range(5):
        for ic in range(5):
            mtx[ir, ic] = 1.0 * (ir != ic)
>>> mtx     
<5x5 sparse matrix of type '<... 'numpy.float64'>'
        with 20 stored elements in Dictionary Of Keys format>
>>> mtx.todense()
matrix([[ 0.,  1.,  1.,  1.,  1.],
        [ 1.,  0.,  1.,  1.,  1.],
        [ 1.,  1.,  0.,  1.,  1.],
        [ 1.,  1.,  1.,  0.,  1.],
        [ 1.,  1.,  1.,  1.,  0.]])
#slicing and indexing:
>>>>>> mtx[1, 1]
0.0
>>> mtx[1, 1:3]     
<1x2 sparse matrix of type '<... 'numpy.float64'>'
      with 1 stored elements in Dictionary Of Keys format>
>>> mtx[1, 1:3].todense()
matrix([[ 0.,  1.]])
>>> mtx[[2,1], 1:3].todense()
matrix([[ 1.,  0.],
        [ 0.,  1.]])    
        
    
##Sparse matrix type - COOrdinate format -  scipy.sparse.coo_matrix
#Creation 
coo_matrix(D)
    with a dense matrix D
coo_matrix(S)
    with another sparse matrix S (equivalent to S.tocoo())
coo_matrix((M, N), [dtype])
    to construct an empty matrix with shape (M, N) dtype is optional, defaulting to dtype='d'.
coo_matrix((data, (i, j)), [shape=(M, N)])
    to construct from three arrays:
    1.data[:] the entries of the matrix, in any order
    2.i[:] the row indices of the matrix entries
    3.j[:] the column indices of the matrix entries
    Where A[i[k], j[k]] = data[k]. 


#Advantages of the COO format
•facilitates fast conversion among sparse formats
•permits duplicate entries (see example)
•very fast conversion to and from CSR/CSC formats
#Disadvantages of the COO format
•does not directly support:
•arithmetic operations
•slicing

#Example - create empty COO matrix:
>>> mtx = sparse.coo_matrix((3, 4), dtype=np.int8)
>>> mtx.todense()
matrix([[0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0]], dtype=int8)
#Example - create using (data, ij) tuple:
#nonzero data at index [0,0], [3,3], [1,1], [0,2]
>>> row = np.array([0, 3, 1, 0])
>>> col = np.array([0, 3, 1, 2])
>>> data = np.array([4, 5, 7, 9])
>>> mtx = sparse.coo_matrix((data, (row, col)), shape=(4, 4))
>>> mtx     
<4x4 sparse matrix of type '<... 'numpy.int64'>'
        with 4 stored elements in COOrdinate format>
>>> mtx.todense()
matrix([[4, 0, 9, 0],
        [0, 7, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 5]])
#duplicates entries are summed together:
#note three data elements are at [0,0]
>>>>>> row = np.array([0, 0, 1, 3, 1, 0, 0])
>>> col = np.array([0, 2, 1, 3, 1, 0, 0])
>>> data = np.array([1, 1, 1, 1, 1, 1, 1])
>>> mtx = sparse.coo_matrix((data, (row, col)), shape=(4, 4))
>>> mtx.todense()
matrix([[3, 0, 1, 0],
        [0, 2, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 1]])
#no slicing…:
>>> mtx[2, 3]   
Traceback (most recent call last):
...
TypeError: 'coo_matrix' object ...     


##Sparse matrix type - Compressed Sparse Row format- csr_matrix
#creation 
csr_matrix(D)
    with a dense matrix or rank-2 ndarray D
csr_matrix(S)
    with another sparse matrix S (equivalent to S.tocsr())
csr_matrix((M, N), [dtype])
    to construct an empty matrix with shape (M, N) dtype is optional, 
    defaulting to dtype=d.
csr_matrix((data, (row_ind, col_ind)), [shape=(M, N)])
    where data, row_ind and col_ind (all arrays) satisfy the relationship 
    a[row_ind[k], col_ind[k]] = data[k].
csr_matrix((data, indices, indptr), [shape=(M, N)])
    is the standard CSR representation 
    where the column indices for row i are stored in 
    indices[indptr[i]:indptr[i+1]] 
    and their corresponding values are stored in 
    data[indptr[i]:indptr[i+1]]. 
        •indices is array of column indices
        •data is array of corresponding nonzero values
        •indptr points to row starts in indices and data
        •length is n_row + 1, last item = number of values = length of both indices and data
        •item (i, j) can be accessed as data[indptr[i]+k], where k is position of j in indices[indptr[i]:indptr[i+1]]

#Advantages of the CSR format
    •efficient arithmetic operations CSR + CSR, CSR * CSR, etc.
    •efficient row slicing
    •fast matrix vector product
#Disadvantages of the CSR format
    •slow column slicing operations (consider CSC)
    •changes to the sparsity structure are expensive (consider LIL or DOK)

    
#Example - create using (data, ij) tuple:
#non-zero value at index [0,0], [0,2], [1,2], [2,0],[2,1],[2,2]
>>> row = np.array([0, 0, 1, 2, 2, 2])
>>> col = np.array([0, 2, 2, 0, 1, 2])  #indices
#index              0  1  2  3  4  5
#indptr:            0     2  3       6    #from row 
#indptr: points to row starts in indices and data
#any item in indptr = index of row where row's value change (Note atleast one item in a row is required evenif =0)
#last item in indptr = len(row)
>>> data = np.array([1, 2, 3, 4, 5, 6])
>>> mtx = sparse.csr_matrix((data, (row, col)), shape=(3, 3))
>>> mtx.todense()   
matrix([[1, 0, 2],
        [0, 0, 3],
        [4, 5, 6]]...)
>>> mtx.data
array([1, 2, 3, 4, 5, 6]...)
>>> mtx.indices  #array of column indices, same as above col 
array([0, 2, 2, 0, 1, 2], dtype=int32)
>>> mtx.indptr #points to row starts in indices and data
array([0, 2, 3, 6], dtype=int32)
#create using (data, indices, indptr) tuple:
>>> data = np.array([1, 2, 3, 4, 5, 6])
>>> indices = np.array([0, 2, 2, 0, 1, 2])
>>> indptr = np.array([0, 2, 3, 6])
>>> mtx = sparse.csr_matrix((data, indices, indptr), shape=(3, 3))
>>> mtx.todense()
matrix([[1, 0, 2],
        [0, 0, 3],
        [4, 5, 6]])
>>> (mtx + mtx).toarray()
array([[ 2,  0,  4],
       [ 0,  0,  6],
       [ 8, 10, 12]], dtype=int32)
>>> mtx[1,1]
0
>>> mtx[0:2,0:2]
<2x2 sparse matrix of type '<class 'numpy.int32'>'
        with 1 stored elements in Compressed Sparse Row format>
>>> mtx[0:2,0:2].todense()
matrix([[1, 0],
        [0, 0]], dtype=int32)
>> mtx.sqrt().todense()
matrix([[1.        , 0.        , 1.41421356],
       [0.        , 0.        , 1.73205081],
       [2.        , 2.23606798, 2.44948974]])
       
>>> mtx.power(3).todense()
matrix([[  1,   0,   8],
        [  0,   0,  27],
        [ 64, 125, 216]], dtype=int32)      
       
##Sparse matrix type - Compressed Sparse Column format - scipy.sparse.csc_matrix
#Creation 
csc_matrix(D)
    with a dense matrix or rank-2 ndarray D
csc_matrix(S)
    with another sparse matrix S (equivalent to S.tocsc())
csc_matrix((M, N), [dtype])
    to construct an empty matrix with shape (M, N) dtype is optional, defaulting to dtype='d'.
csc_matrix((data, (row_ind, col_ind)), [shape=(M, N)])
    where data, row_ind and col_ind satisfy the relationship 
    a[row_ind[k], col_ind[k]] = data[k].
csc_matrix((data, indices, indptr), [shape=(M, N)])
    is the standard CSC representation 
    where the row indices for column i are stored in 
    indices[indptr[i]:indptr[i+1]] 
    and their corresponding values are stored in 
    data[indptr[i]:indptr[i+1]]. 
    This is similar to CSR but indptr is for column 
        •indices is array of row indices
        •data is array of corresponding nonzero values
        •indptr points to column starts in indices and data
        •length is n_col + 1, last item = number of values = length of both indices and data
         •item (i, j) can be accessed as data[indptr[j]+k], where k is position of i in indices[indptr[j]:indptr[j+1]]


#Example - create using (data, ij) tuple:
>>> row = np.array([0, 2, 2, 0, 1, 2]) #indices 
>>> col = np.array([0, 0, 1, 2, 2, 2])
#index              0  1  2  3  4  5
#indptr:            0  2  3  6
#indptr: points to col starts in indices and data
#any item in indptr= index of col where col's value change (Note atleast one item in a col is required evenif =0)
#last item in indptr = len(col)

>>> data = np.array([1, 2, 3, 4, 5, 6])
>>> mtx = sparse.csc_matrix((data, (row, col)), shape=(3, 3))
>>> mtx         
<3x3 sparse matrix of type '<... 'numpy.int64'>'
        with 6 stored elements in Compressed Sparse Column format>
>>> mtx.todense()   
array([[1, 0, 4],
       [0, 0, 5],
       [2, 3, 6]])
>>> mtx.data   
array([1, 4, 5, 2, 3, 6]...)
>>> mtx.indices     #array of row indices, same as above row 
array([0, 2, 2, 0, 1, 2], dtype=int32)
>>> mtx.indptr  #points to column starts in indices and data
array([0, 2, 3, 6], dtype=int32)
#create using (data, indices, indptr) tuple:
>>> indptr = np.array([0, 2, 3, 6])
>>> indices = np.array([0, 2, 2, 0, 1, 2])
>>> data = np.array([1, 2, 3, 4, 5, 6])
>>> csc_matrix((data, indices, indptr), shape=(3, 3)).toarray()
array([[1, 0, 4],
       [0, 0, 5],
       [2, 3, 6]])
    
    
    
##Sparse matrix type - Block Sparse Row format - scipy.sparse.bsr_matrix
#basically a CSR with dense sub-matrices of fixed shape instead of scalar items
#block size (R, C) must evenly divide the shape of the matrix (M, N)
#Creation 
bsr_matrix(D, [blocksize=(R,C)])
    where D is a dense matrix or 2-D ndarray.
bsr_matrix(S, [blocksize=(R,C)])
    with another sparse matrix S (equivalent to S.tobsr())
bsr_matrix((M, N), [blocksize=(R,C), dtype])
    to construct an empty matrix with shape (M, N) dtype is optional, defaulting to dtype='d'.
bsr_matrix((data, ij), [blocksize=(R,C), shape=(M, N)])
    where data and ij satisfy a[ij[0, k], ij[1, k]] = data[k]
bsr_matrix((data, indices, indptr), [shape=(M, N)])
    is the standard BSR representation 
    where the block column indices for row i are stored in 
    indices[indptr[i]:indptr[i+1]] 
    and their corresponding block values are stored in 
    data[ indptr[i]: indptr[i+1] ]. 
        •indices is array of column indices for each block
        •data is array of corresponding nonzero values of shape (nnz, R, C)
        •indptr points to row starts in indices and data

#Example - create empty BSR matrix with (1, 1) block size (like CSR…):
>>> mtx = sparse.bsr_matrix((3, 4), dtype=np.int8)
>>> mtx  
<3x4 sparse matrix of type '<... 'numpy.int8'>'
        with 0 stored elements (blocksize = 1x1) in Block Sparse Row format>
>>> mtx.todense()
matrix([[0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0]], dtype=int8)
#Example - create empty BSR matrix with (3, 2) block size:
>>>>>> mtx = sparse.bsr_matrix((3, 4), blocksize=(3, 2), dtype=np.int8)
>>> mtx  
<3x4 sparse matrix of type '<... 'numpy.int8'>'
        with 0 stored elements (blocksize = 3x2) in Block Sparse Row format>
>>> mtx.todense()
matrix([[0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0]], dtype=int8)
#Example - create using (data, ij) tuple with (1, 1) block size (like CSR…):
>>> row = np.array([0, 0, 1, 2, 2, 2])
>>> col = np.array([0, 2, 2, 0, 1, 2])
>>> data = np.array([1, 2, 3, 4, 5, 6])
>>> mtx = sparse.bsr_matrix((data, (row, col)), shape=(3, 3))
>>> mtx  
<3x3 sparse matrix of type '<... 'numpy.int64'>'
        with 6 stored elements (blocksize = 1x1) in Block Sparse Row format>
>>> mtx.todense()   
matrix([[1, 0, 2],
        [0, 0, 3],
        [4, 5, 6]]...)
>>> mtx.data    
array([[[1]],
       [[2]],
       [[3]],
       [[4]],
       [[5]],
       [[6]]]...)
>>> mtx.indices
array([0, 2, 2, 0, 1, 2], dtype=int32)
>>> mtx.indptr
array([0, 2, 3, 6], dtype=int32)
#Example - create using (data, indices, indptr) tuple with (2, 2) block size:
>>> indptr = np.array([0, 2, 3, 6])
>>> indices = np.array([0, 2, 2, 0, 1, 2])
>>> data = np.array([1, 2, 3, 4, 5, 6]).repeat(4).reshape(6, 2, 2)
>>> mtx = sparse.bsr_matrix((data, indices, indptr), shape=(6, 6))
>>> mtx.todense()
matrix([[1, 1, 0, 0, 2, 2],
        [1, 1, 0, 0, 2, 2],
        [0, 0, 0, 0, 3, 3],
        [0, 0, 0, 0, 3, 3],
        [4, 4, 5, 5, 6, 6],
        [4, 4, 5, 5, 6, 6]])
>>> data
array([[[1, 1],
        [1, 1]],
       [[2, 2],
        [2, 2]],
       [[3, 3],
        [3, 3]],
       [[4, 4],
        [4, 4]],
       [[5, 5],
        [5, 5]],
       [[6, 6],
        [6, 6]]])
        
        
        



###SciPy - Parse - Sparse linear algebra (scipy.sparse.linalg)
#Matrix Operations
inv(A)              Compute the inverse of a sparse matrix 
expm(A)             Compute the matrix exponential using Pade approximation. 
expm_multiply(A, B[, start, stop, num, endpoint])   Compute the action of the matrix exponential of A on B. 

#Matrix norms
norm(x[, ord, axis])    Norm of a sparse matrix 
onenormest(A[, t, itmax, compute_v, compute_w])     Compute a lower bound of the 1-norm of a sparse matrix. 

#Direct methods for solving linear equation systems:
spsolve(A, b[, permc_spec, use_umfpack])    Solve the sparse linear system Ax=b, where b may be a vector or a matrix. 
spsolve_triangular(A, b[, lower, ...])      Solve the equation A x = b for x, assuming A is a triangular matrix. 

#Iterative methods for solving linear equation systems:
bicg(A, b[, x0, tol, maxiter, M, callback])     Use BIConjugate Gradient iteration to solve Ax = b. 
bicgstab(A, b[, x0, tol, maxiter, M, callback]) Use BIConjugate Gradient STABilized iteration to solve Ax = b. 
cg(A, b[, x0, tol, maxiter, M, callback])       Use Conjugate Gradient iteration to solve Ax = b. 
cgs(A, b[, x0, tol, maxiter, M, callback])      Use Conjugate Gradient Squared iteration to solve Ax = b. 
gmres(A, b[, x0, tol, restart, maxiter, M, ...]) Use Generalized Minimal RESidual iteration to solve Ax = b. 
lgmres(A, b[, x0, tol, maxiter, M, ...])        Solve a matrix equation using the LGMRES algorithm. 
minres(A, b[, x0, shift, tol, maxiter, M, ...]) Use MINimum RESidual iteration to solve Ax=b 
qmr(A, b[, x0, tol, maxiter, M1, M2, callback]) Use Quasi-Minimal Residual iteration to solve Ax = b. 
gcrotmk(A, b[, x0, tol, maxiter, M, ...])       Solve a matrix equation using flexible GCROT(m,k) algorithm. 

#Iterative methods for least-squares problems:
lsqr(A, b[, damp, atol, btol, conlim, ...])     Find the least-squares solution to a large, sparse, linear system of equations. 
lsmr(A, b[, damp, atol, btol, conlim, ...])     Iterative solver for least-squares problems. 

#Eigenvalue problems:
eigs(A[, k, M, sigma, which, v0, ncv, ...])     Find k eigenvalues and eigenvectors of the square matrix A. 
eigsh(A[, k, M, sigma, which, v0, ncv, ...])    Find k eigenvalues and eigenvectors of the real symmetric square matrix or complex hermitian matrix A. 
lobpcg(A, X[, B, M, Y, tol, maxiter, ...])      Locally Optimal Block Preconditioned Conjugate Gradient Method (LOBPCG) 

#Singular values problems:
svds(A[, k, ncv, tol, which, v0, maxiter, ...]) Compute the largest k singular values/vectors for a sparse matrix. 

#Complete or incomplete LU factorizations
splu(A[, permc_spec, diag_pivot_thresh, ...])       Compute the LU decomposition of a sparse, square matrix. 
spilu(A[, drop_tol, fill_factor, drop_rule, ...])   Compute an incomplete LU decomposition for a sparse, square matrix. 



##Example -  Matrix vector product
import numpy as np
from scipy.sparse import csr_matrix
A = csr_matrix([[1, 2, 0], [0, 0, 3], [4, 0, 5]])
v = np.array([1, 0, -1])
>>> A.dot(v)   #or np.dot(A.toarray(), v)
array([ 1, -3, -1], dtype=int64)

##Example - Construct a 1000x1000 lil_matrix and add some values to it:
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import spsolve
from numpy.linalg import solve, norm
from numpy.random import rand

A = lil_matrix((1000, 1000))
A[0, :100] = rand(100)   #first row, column till 100
A[1, 100:200] = A[0, :100]  #2nd row, column 10 to 200 set from above 
A.setdiag(rand(1000))  #set diag elements 

#convert it to CSR format and solve A x = b for x:
A = A.tocsr()
b = rand(1000)
x = spsolve(A, b)

#Convert it to a dense matrix and solve, and check that the result is the same:
x_ = solve(A.toarray(), b)

#compute norm of the error with:
err = norm(x-x_)
err < 1e-10 #True


##Example - inv 
>>> from scipy.sparse import csc_matrix
>>> from scipy.sparse.linalg import inv
>>> A = csc_matrix([[1., 0.], [1., 2.]])
>>> Ainv = inv(A)
>>> Ainv
<2x2 sparse matrix of type '<class 'numpy.float64'>'
    with 3 stored elements in Compressed Sparse Column format>
>>> A.dot(Ainv)
<2x2 sparse matrix of type '<class 'numpy.float64'>'
    with 2 stored elements in Compressed Sparse Column format>
>>> A.dot(Ainv).todense()
matrix([[ 1.,  0.],
        [ 0.,  1.]])


##Example - linear solver 
>>> from scipy.sparse import csc_matrix
>>> from scipy.sparse.linalg import gmres
>>> A = csc_matrix([[3, 2, 0], [1, -1, 0], [0, 5, 1]], dtype=float)
>>> b = np.array([2, 4, -1], dtype=float)
>>> x, exitCode = gmres(A, b)
>>> print(exitCode)            # 0 indicates successful convergence
0
>>> np.allclose(A.dot(x), b)
True

##Example - least square , lsqr and lsmr
Returns:
    x : ndarray of float
        The final solution.
    istop : int
        Gives the reason for termination. 1 means x is an approximate solution to Ax = b. 2 means x approximately solves the least-squares problem.
    itn : int
        Iteration number upon termination.
    r1norm : float
        norm(r), where r = b - Ax.
    r2norm : float
        sqrt( norm(r)^2  +  damp^2 * norm(x)^2 ). Equal to r1norm if damp == 0.
    anorm : float
        Estimate of Frobenius norm of Abar = [[A]; [damp*I]].
    acond : float
        Estimate of cond(Abar).
    arnorm : float
        Estimate of norm(A'*r - damp^2*x).
    xnorm : float
        norm(x)
    var : ndarray of float
        If calc_var is True, estimates all diagonals of (A'A)^{-1} (if damp == 0) or more generally (A'A + damp^2*I)^{-1}. This is well defined if A has full column rank or damp > 0. (Not sure what var means if rank(A) < n and damp = 0.)
     
from scipy.sparse import csc_matrix
from scipy.sparse.linalg import lsqr
A = csc_matrix([[1., 0.], [1., 1.], [0., 1.]], dtype=float)

#The first example has the trivial solution [0, 0]
>>> b = np.array([0., 0., 0.], dtype=float)
>>> x, istop, itn, normr = lsqr(A, b)[:4]
The exact solution is  x = 0
>>> istop
0
>>> x
array([ 0.,  0.])

#The next example has a non-trivial solution:
>>> b = np.array([1., 0., -1.], dtype=float)
>>> x, istop, itn, r1norm = lsqr(A, b)[:4]
>>> istop  #As indicated by istop=1, lsqr found a solution obeying the tolerance limits. 
1
>>> x
array([ 1., -1.])
>>> itn
1
>>> r1norm
4.440892098500627e-16


#in the case where there is no solution for the equation:
>>> b = np.array([1., 0.01, -1.], dtype=float)
>>> x, istop, itn, r1norm = lsqr(A, b)[:4]
>>> istop  #istop indicates that the system is inconsistent and thus x is rather an approximate solution
2
>>> x
array([ 1.00333333, -0.99666667])
>>> A.dot(x)-b
array([ 0.00333333, -0.00333333,  0.00333333])
>>> r1norm
0.005773502691896255


##Find 6 eigenvectors of the identity matrix:
>>> import scipy.sparse as sparse
>>> id = np.eye(13)
>>> vals, vecs = sparse.linalg.eigs(id, k=6)
>>> vals
array([ 1.+0.j,  1.+0.j,  1.+0.j,  1.+0.j,  1.+0.j,  1.+0.j])
>>> vecs.shape
(13, 6)

##Compute the largest k singular values/vectors for a sparse matrix.
>>> from scipy.sparse import csc_matrix
>>> from scipy.sparse.linalg import svds, eigs
>>> A = csc_matrix([[1, 0, 0], [5, 0, 2], [0, -1, 0], [0, 0, 3]], dtype=float)
>>> u, s, vt = svds(A, k=2)
>>> s
array([ 2.75193379,  5.6059665 ])
>>> np.sqrt(eigs(A.dot(A.T), k=2)[0]).real
array([ 5.6059665 ,  2.75193379])

#Compute the LU decomposition of a sparse, square matrix- splu and spilu
Returns:
    invA : scipy.sparse.linalg.SuperLU
    Object, which has a solve method.
 
>>> from scipy.sparse import csc_matrix
>>> from scipy.sparse.linalg import splu
>>> A = csc_matrix([[1., 0., 0.], [5., 0., 2.], [0., -1., 0.]], dtype=float)
>>> B = splu(A)
>>> x = np.array([1., 2., 3.], dtype=float)
>>> B.solve(x)
array([ 1. , -3. , -1.5])
>>> A.dot(B.solve(x))
array([ 1.,  2.,  3.])
>>> B.solve(A.dot(x))
array([ 1.,  2.,  3.])
#Compute an incomplete LU decomposition for a sparse, square matrix
#The resulting object is an approximation to the inverse of A.
>>> from scipy.sparse import csc_matrix
>>> from scipy.sparse.linalg import spilu
>>> A = csc_matrix([[1., 0., 0.], [5., 0., 2.], [0., -1., 0.]], dtype=float)
>>> B = spilu(A)
>>> x = np.array([1., 2., 3.], dtype=float)
>>> B.solve(x)
array([ 1. , -3. , -1.5])
>>> A.dot(B.solve(x))
array([ 1.,  2.,  3.])
>>> B.solve(A.dot(x))
array([ 1.,  2.,  3.])



###SciPy - Parse - Compressed Sparse Graph Routines (scipy.sparse.csgraph)

connected_components(csgraph[, directed, ...])  Analyze the connected components of a sparse graph 
laplacian(csgraph[, normed, return_diag, ...])  Return the Laplacian matrix of a directed graph. 
shortest_path(csgraph[, method, directed, ...]) Perform a shortest-path graph search on a positive directed or undirected graph. 
dijkstra(csgraph[, directed, indices, ...])     Dijkstra algorithm using Fibonacci Heaps 
floyd_warshall(csgraph[, directed, ...])        Compute the shortest path lengths using the Floyd-Warshall algorithm 
bellman_ford(csgraph[, directed, indices, ...]) Compute the shortest path lengths using the Bellman-Ford algorithm. 
johnson(csgraph[, directed, indices, ...])      Compute the shortest path lengths using Johnson's algorithm. 

breadth_first_order(csgraph, i_start[, ...])    Return a breadth-first ordering starting with specified node. 
depth_first_order(csgraph, i_start[, ...])      Return a depth-first ordering starting with specified node. 
breadth_first_tree(csgraph, i_start[, directed]) Return the tree generated by a breadth-first search 
depth_first_tree(csgraph, i_start[, directed])  Return a tree generated by a depth-first search. 
minimum_spanning_tree(csgraph[, overwrite])     Return a minimum spanning tree of an undirected graph 
reverse_cuthill_mckee(graph[, symmetric_mode])  Returns the permutation array that orders a sparse CSR or CSC matrix in Reverse-Cuthill McKee ordering. 
maximum_bipartite_matching(graph[, perm_type])  Returns an array of row or column permutations that makes the diagonal of a nonsingular square CSC sparse matrix zero free. 
structural_rank(graph)                          Compute the structural rank of a graph (matrix) with a given sparsity pattern. 

construct_dist_matrix(graph, predecessors[, ...])   Construct distance matrix from a predecessor matrix 
csgraph_from_dense(graph[, null_value, ...])        Construct a CSR-format sparse graph from a dense matrix. 
csgraph_from_masked(graph)                          Construct a CSR-format graph from a masked array. 
csgraph_masked_from_dense(graph[, ...])             Construct a masked array graph representation from a dense matrix. 
csgraph_to_dense(csgraph[, null_value])             Convert a sparse graph representation to a dense representation 
csgraph_to_masked(csgraph)                          Convert a sparse graph representation to a masked array representation 
reconstruct_path(csgraph, predecessors[, ...])      Construct a tree from a graph and a predecessor list. 



##Graph Representations

#A graph with N nodes can be represented by an (N x N) adjacency matrix G. 
#If there is a connection from node i to node j, then G[i, j] = w, 
#where w is the weight of the connection. 

#For nodes i and j which are not connected, 
#the value depends on the representation:
•for dense array representations, non-edges are represented by G[i, j] = 0, infinity, or NaN.
•for dense masked representations (of type np.ma.MaskedArray), non-edges are represented by masked values. 
 This can be useful when graphs with zero-weight edges are desired.
•for sparse array representations, non-edges are represented 
 by non-entries in the matrix. 
 This sort of sparse representation also allows for edges with zero weights.

#Example graph 
      G
     (0)
    /   \
   1     2
  /       \
(2)       (1)


#This graph has three nodes, 
#where node 0 and 1 are connected by an edge of weight 2, 
#and nodes 0 and 2 are connected by an edge of weight 1. 


>>> G_dense = np.array([[0, 2, 1],
                        [2, 0, 0],
                        [1, 0, 0]])
>>> G_masked = np.ma.masked_values(G_dense, 0)
>>> from scipy.sparse import csr_matrix
>>> G_sparse = csr_matrix(G_dense)


#This becomes more difficult when zero edges are significant. 
     G2
     (0)
    /   \
   0     2
  /       \
(2)       (1)


#nodes 0 and 2 are connected by an edge of zero weight. 
#use either a masked or sparse representation 

>>> G2_data = np.array([[np.inf, 2,      0     ],
                        [2,      np.inf, np.inf],
                        [0,      np.inf, np.inf]])
>>> G2_masked = np.ma.masked_invalid(G2_data)
>>> from scipy.sparse.csgraph import csgraph_from_dense
>>> # G2_sparse = csr_matrix(G2_data) would give the wrong result
>>> G2_sparse = csgraph_from_dense(G2_data, null_value=np.inf)
>>> G2_sparse.data
array([ 2.,  0.,  2.,  0.])


##Directed vs. Undirected
#This is specified throughout the csgraph module by a boolean keyword. 
#Graphs are assumed to be directed by default. 

#In a directed graph, traversal from node i to node j can be accomplished 
#over the edge G[i, j], but not the edge G[j, i]. 

#In a non-directed graph, traversal from node i to node j 
#can be accomplished over either G[i, j] or G[j, i]. 

#If both edges are not null, and the two have unequal weights, 
#then the smaller of the two is used



##Examples
#computation of a minimum spanning tree over a simple four-component graph:
# input graph             minimum spanning tree

     (0)                         (0)
    /   \                       /
   3     8                     3
  /       \                   /
(3)---5---(1)               (3)---5---(1)
  \       /                           /
   6     2                           2
    \   /                           /
     (2)                         (2)

>>> from scipy.sparse import csr_matrix
>>> from scipy.sparse.csgraph import minimum_spanning_tree
>>> X = csr_matrix([[0, 8, 0, 3],
                    [0, 0, 2, 5],
                    [0, 0, 0, 6],
                    [0, 0, 0, 0]])
>>> Tcsr = minimum_spanning_tree(X)
>>> Tcsr.toarray().astype(int)
array([[0, 0, 0, 3],
       [0, 0, 2, 5],
       [0, 0, 0, 0],
       [0, 0, 0, 0]])

##Examples
#computation of a depth-first tree over a simple four-component graph, 
#starting at node 0:
# input graph          breadth first tree from (0)

     (0)                         (0)
    /   \                       /   \
   3     8                     3     8
  /       \                   /       \
(3)---5---(1)               (3)       (1)
  \       /                           /
   6     2                           2
    \   /                           /
     (2)                         (2)


>>> from scipy.sparse import csr_matrix
>>> from scipy.sparse.csgraph import breadth_first_tree
>>> X = csr_matrix([[0, 8, 0, 3],
                    [0, 0, 2, 5],
                    [0, 0, 0, 6],
                    [0, 0, 0, 0]])
>>> Tcsr = breadth_first_tree(X, 0, directed=False)
>>> Tcsr.toarray().astype(int)
array([[0, 8, 0, 3],
       [0, 0, 2, 0],
       [0, 0, 0, 0],
       [0, 0, 0, 0]])




##scipy.sparse.csgraph.shortest_path
scipy.sparse.csgraph.shortest_path(csgraph, method='auto', directed=True, return_predecessors=False, unweighted=False, overwrite=False, indices=None)
Parameters:
    csgraph : array, matrix, or sparse matrix, 2 dimensions
        The N x N array of distances representing the input graph.
    method : string ['auto'|'FW'|'D'], optional
        Algorithm to use for shortest paths. Options are:
        'auto' – (default) select the best among 'FW', 'D', 'BF', or 'J' based on the input data.
        'FW' – Floyd-Warshall algorithm. 
               Computational cost is approximately O[N^3]. 
               The input csgraph will be converted to a dense representation.
        'D' – Dijkstra's algorithm with Fibonacci heaps. 
             Computational cost is approximately O[N(N*k + N*log(N))], 
             where k is the average number of connected edges per node. 
             The input csgraph will be converted to a csr representation.
        'BF' – Bellman-Ford algorithm. 
            This algorithm can be used when weights are negative. 
            If a negative cycle is encountered, an error will be raised. 
            Computational cost is approximately O[N(N^2 k)], where k is the average number of connected edges per node. 
            The input csgraph will be converted to a csr representation.
        'J' – Johnson's algorithm. Like the Bellman-Ford algorithm,
            Johnson's algorithm is designed for use when the weights are negative. 
            It combines the Bellman-Ford algorithm with Dijkstra's algorithm for faster computation.
    directed : bool, optional
        If True (default), then find the shortest path on a directed graph: 
        only move from point i to point j along paths csgraph[i, j]. 
        If False, then find the shortest path on an undirected graph: 
        the algorithm can progress from point i to j along csgraph[i, j] or csgraph[j, i]
    return_predecessors : bool, optional
        If True, return the size (N, N) predecesor matrix
    unweighted : bool, optional
        If True, then find unweighted distances. 
        That is, rather than finding the path between each point 
        such that the sum of weights is minimized, 
        find the path such that the number of edges is minimized.
    overwrite : bool, optional
        If True, overwrite csgraph with the result. 
        This applies only if method == 'FW' and csgraph is a dense, c-ordered array with dtype=float64.
    indices : array_like or int, optional
        If specified, only compute the paths for the points at the given indices. 
        Incompatible with method == 'FW'.
Returns:
    dist_matrix : ndarray
        The N x N matrix of distances between graph nodes. 
        dist_matrix[i,j] gives the shortest distance from point i to point j 
        along the graph.
    predecessors : ndarray
        Returned only if return_predecessors == True. 
        The N x N matrix of predecessors, which can be used to reconstruct the shortest paths. 
        Row i of the predecessor matrix contains information on the shortest paths 
        from point i: each entry predecessors[i, j] 
        gives the index of the previous node in the path from point i to point j. 
        If no path exists between point i and j, then predecessors[i, j] = -9999
 
#Example 
from __future__ import division, print_function, absolute_import

import numpy as np
from numpy.testing import assert_array_almost_equal, assert_array_equal
from pytest import raises as assert_raises
from scipy.sparse.csgraph import (shortest_path, dijkstra, johnson,
    bellman_ford, construct_dist_matrix, NegativeCycleError)


directed_G = np.array([[0, 3, 3, 0, 0],
                       [0, 0, 0, 2, 4],
                       [0, 0, 0, 0, 0],
                       [1, 0, 0, 0, 0],
                       [2, 0, 0, 2, 0]], dtype=float)

undirected_G = np.array([[0, 3, 3, 1, 2],
                         [3, 0, 0, 2, 4],
                         [3, 0, 0, 0, 0],
                         [1, 2, 0, 0, 2],
                         [2, 4, 0, 2, 0]], dtype=float)

unweighted_G = (directed_G > 0).astype(float)

directed_SP = [[0, 3, 3, 5, 7],
               [3, 0, 6, 2, 4],
               [np.inf, np.inf, 0, np.inf, np.inf],
               [1, 4, 4, 0, 8],
               [2, 5, 5, 2, 0]]

directed_pred = np.array([[-9999, 0, 0, 1, 1],
                          [3, -9999, 0, 1, 1],
                          [-9999, -9999, -9999, -9999, -9999],
                          [3, 0, 0, -9999, 1],
                          [4, 0, 0, 4, -9999]], dtype=float)

undirected_SP = np.array([[0, 3, 3, 1, 2],
                          [3, 0, 6, 2, 4],
                          [3, 6, 0, 4, 5],
                          [1, 2, 4, 0, 2],
                          [2, 4, 5, 2, 0]], dtype=float)

undirected_SP_limit_2 = np.array([[0, np.inf, np.inf, 1, 2],
                                  [np.inf, 0, np.inf, 2, np.inf],
                                  [np.inf, np.inf, 0, np.inf, np.inf],
                                  [1, 2, np.inf, 0, 2],
                                  [2, np.inf, np.inf, 2, 0]], dtype=float)

undirected_SP_limit_0 = np.ones((5, 5), dtype=float) - np.eye(5)
undirected_SP_limit_0[undirected_SP_limit_0 > 0] = np.inf

undirected_pred = np.array([[-9999, 0, 0, 0, 0],
                            [1, -9999, 0, 1, 1],
                            [2, 0, -9999, 0, 0],
                            [3, 3, 0, -9999, 3],
                            [4, 4, 0, 4, -9999]], dtype=float)

methods = ['auto', 'FW', 'D', 'BF', 'J']


def test_directed():
    def check(method):
        SP = shortest_path(directed_G, method=method, directed=True,
                           overwrite=False)
        assert_array_almost_equal(SP, directed_SP)

    for method in methods:
        check(method)


def test_undirected():
    def check(method, directed_in):
        if directed_in:
            SP1 = shortest_path(directed_G, method=method, directed=False,
                                overwrite=False)
            assert_array_almost_equal(SP1, undirected_SP)
        else:
            SP2 = shortest_path(undirected_G, method=method, directed=True,
                                overwrite=False)
            assert_array_almost_equal(SP2, undirected_SP)

    for method in methods:
        for directed_in in (True, False):
            check(method, directed_in)









###SciPy stats (scyipy.stats) - Continuous dist 
#has many, https://docs.scipy.org/doc/scipy/reference/stats.html
#Note all these have addl 'params' (mentioned against each)
#along with loc(mean),scale(sd) which can be supplied in args 
#By default loc, scale are 0,1 ie standardised   
beta                A beta continuous random variable. params =  a, b
cauchy              A Cauchy continuous random variable. params = none
chi                 A chi continuous random variable. params= df
expon               An exponential continuous random variable. param=none 
f                   An F continuous random variable. params = dfn, dfd, ie df1, df2
gamma               A gamma continuous random variable, params= a
norm                A normal continuous random variable. params=none
pareto              A Pareto continuous random variable. parms = b
t                   A Students T continuous random variable , params= df
uniform             A uniform continuous random variable. params = none

#Each distribution  has below methods , **kwds depends on particular dist 
Density (.pdf)				Returns probability Pr of a random variable X, ie Pr(x), 
Distribution (.cdf)  		Returns cummulative Pr ie Pr(x <= q) or Pr(x >=q) with lower.tail = FALSE
Quantile (.ppf)				Inverse of cdf, Given Probability p, returns x, value of X ie what is the value of x given p
Random generation(.rvs)		Generates n random number based on this distribution 

#x is taken as X variable, axis x and  q, Pr is taken as y axis in PDF graph
#Common Methods of distributions 
#Note all these have addl 'params' (mentioned against distribution each above)
#along with loc(mean),scale(sd) which can be supplied in args 
#By default loc, scale are 0,1 ie standardised   
#for example for norm, params=None, hence complete signature pdf(x, loc=0, scale=1)
pdf(x, params)       Probability density function at x of the given RV. 
cdf(x, params)       Cumulative distribution function of the given RV. 
ppf(q, params)       Percent point function (inverse of cdf) at q of the given RV. 
rvs(params, size)    Generates size(could be tuple for MD) random number based on this distribution 

logpdf(x, params)    Log of the probability density function at x of the given RV. 
logcdf(x, params)    Log of the cumulative distribution function at x of the given RV. 
sf(x, params)        Survival function (1 - cdf) at x of the given RV. 
logsf(x, params)     Log of the survival function of the given RV. 
isf(q, params)       Inverse survival function (inverse of sf) at q of the given RV. 

moment(n, params)    n-th order non-central moment of distribution. 
stats(params, mask)  Some statistics of the given RV. 
                     Mask is string , Mean('m'), variance('v'), skew('s'), and/or kurtosis('k').
                     Can be combined. eg 'mv'
entropy(params)      Differential entropy of the RV. 

median(params)       Median of the distribution. 
mean(params)         Mean of the distribution. 
std(params)          Standard deviation of the distribution. 
var(params)          Variance of the distribution. 

fit(data, params)    Return MLEs for shape, location, and scale parameters from data. 
nnlf(theta, x)       Return negative loglikelihood function. 

fit_loc_scale(data, params)                     Estimate loc and scale parameters from data using 1st and 2nd moments. 
expect([func, args, loc, scale, lb, ub, ...])   Calculate expected value of a function with respect to the distribution. 
interval(alpha, params)                         Confidence interval with equal areas around the median. 



##Example of norm distribution 

from scipy.stats import norm
import matplotlib.pyplot as plt
fig, ax = plt.subplots(1, 1)

#Calculate a few first moments:
mean, var, skew, kurt = norm.stats(moments='mvsk')


#Display the probability density function (pdf):
#ppf - given cummulative p, output x , pdf= Pr(x) given x , cdf = cummulative Pr
x = np.linspace(norm.ppf(0.01), norm.ppf(0.99), 100)
ax.plot(x, norm.pdf(x),'r-', lw=5, alpha=0.6, label='norm pdf')

#Check accuracy of cdf and ppf
vals = norm.ppf([0.001, 0.5, 0.999])
np.allclose([0.001, 0.5, 0.999], norm.cdf(vals)) #True

#Generate random numbers:
r = norm.rvs(size=1000)

#And compare the histogram:
ax.hist(r, normed=True, histtype='stepfilled', alpha=0.2)
ax.legend(loc='best', frameon=False)
plt.show()

#example - fit 
import numpy as np
from scipy.stats import norm
import matplotlib.pyplot as plt


# Generate some data for this demonstration.
data = norm.rvs(10.0, 2.5, size=500) #loc,scale, size 

# Fit a normal distribution to the data:
>>> mu, std = norm.fit(data)  
(9.811694740931252, 2.6595778507346335)
# Plot the histogram.
plt.hist(data, bins=25, normed=True, alpha=0.6, color='g')

# Plot the PDF.
xmin, xmax = plt.xlim() #get xlimit 
x = np.linspace(xmin, xmax, 100)
p = norm.pdf(x, mu, std)
plt.plot(x, p, 'k', linewidth=2)
title = "Fit results: mu = %.2f,  std = %.2f" % (mu, std)
plt.title(title)

plt.show()



        
###SciPy stats (scyipy.stats) - Discrete dist 
#has many, few are 
#Note all these have addl 'params' (mentioned against each)
#along with loc which can be supplied in args 
#By default loc is  0 ie standardised   

bernoulli       A Bernoulli discrete random variable. params= p
binom           A binomial discrete random variable. , params =n, p
poisson         A Poisson discrete random variable. params= mu
randint         A uniform discrete random variable, params= low, high 



#All have below methods  (note pdf is replaced by pmf)
#k is taken as X variable, axis x, and q is taken as y axis in PMF graph
#Note all these have addl 'params' (mentioned against each given above)
#along with loc which can be supplied in args 
#By default loc is  0 ie standardised   
pmf(k, params )      Probability mass function at k of the given RV. 
cdf(k, params)       Cumulative distribution function of the given RV. 
ppf(q, params )      Percent point function (inverse of cdf) at q of the given RV. 
rvs(params, size)    Generates size(could be tuple for MD) random number based on this distribution 


logpmf(k, params)    Log of the probability mass function at k of the given RV. 
logcdf(k, params)    Log of the cumulative distribution function at k of the given RV. 
sf(k, params)        Survival function (1 - cdf) at k of the given RV. 
logsf(k, params)     Log of the survival function of the given RV. 
isf(q, params)       Inverse survival function (inverse of sf) at q of the given RV. 

moment(n, params)    n-th order non-central moment of distribution. 
stats(params, mask)  Some statistics of the given RV. 
                     mask: Mean('m'), variance('v'), skew('s'), and/or kurtosis('k').
                     can be combined
entropy(params)      Differential entropy of the RV. 

median(params)       Median of the distribution. 
mean(params)         Mean of the distribution. 
std(params)          Standard deviation of the distribution. 
var(params)          Variance of the distribution. 

interval(alpha, *args, **kwds)          Confidence interval with equal areas around the median. 
expect([func, args, loc, lb, ub, ...])  Calculate expected value of a function with respect to the distribution for discrete distribution. 

#Example 

from scipy.stats import binom
import matplotlib.pyplot as plt
fig, ax = plt.subplots(1, 1)

#Calculate a few first moments:
n, p = 5, 0.4
mean, var, skew, kurt = binom.stats(n, p, moments='mvsk')


#Display the probability mass function (pmf):
#ppf - given cumulative p, output x , pmf= Pr(x) given x , cdf = cummulative Pr
x = np.arange(binom.ppf(0.01, n, p),binom.ppf(0.99, n, p))
ax.plot(x, binom.pmf(x, n, p), 'bo', ms=8, label='binom pmf')
ax.vlines(x, 0, binom.pmf(x, n, p), colors='b', lw=5, alpha=0.5)

#Check accuracy of cdf and ppf:
prob = binom.cdf(x, n, p)
np.allclose(x, binom.ppf(prob, n, p))#True

#Generate random numbers:
r = binom.rvs(n, p, size=1000)









###SciPy stats (scyipy.stats) -   Meaning of p-value and H0 - null hypothesis 

"null hypothesis" is a general statement or default position 
stated as an objective of a particular test 
eg coefficient of regression is not significant(does not add value to the effect )
e.g. no difference between blood pressures in group A and group B(ie same mean)

The p-value is the probability of the test statistic being at least 
as extreme as the one observed given that the null hypothesis is true
And is used to accept or reject truthness of null hypothesis
    •High P values: your data are likely with a true null.
    •Low P values: your data are unlikely with a true null.


    
The null hypothesis is generally assumed to be true 
until evidence indicates otherwise( ie rejectig H0 when p-value < 0.05)

A result is said to be statistically significant 
if it allows us to reject the null hypothesis

If p value > .10    -> 'not significant'
If p value <= .10   -> 'marginally significant'
If p value <= .05   -> 'significant'
If p value <= .01   -> 'highly significant.'

Set the significance level, α, (based on domain expert's prior knowledge)
-probability of making a Type I error, to be small
for example  0.05(5%), 
implying that it is acceptable to have a 5% probability of incorrectly rejecting the null hypothesis

Compare the P-value to α. 
If the P-value is less than (or equal to) α, reject the null hypothesis 
in favor of the alternative hypothesis. 
If the P-value is greater than α, do not reject the null hypothesis.

Critical values are essentially cut-off values 
that define regions where the test statistic is unlikely to lie; 
for example, a region where the critical value is exceeded 
with probability α  if the null hypothesis is true.
 
We decide either to reject the null hypothesis 
if the test statistic exceeds the critical value (for α = 0.05) 
or analagously to reject the null hypothesis if the p-value is smaller than 0.05

Type I error is the incorrect rejection of a true null hypothesis 
(also known as a "false positive" finding)
A test's probability of making a type I error is denoted by α

Type II error is incorrectly retaining a false null hypothesis 
(also known as a "false negative" finding
A test's probability of making a type II error is denoted by β
and related to the power of a test (which equals 1−β).

For any given sample set, 
the effort to reduce one type of error generally results in 
increasing the other type of error. 

For a given test, the only way to reduce both error rates is 
to increase the sample size
 

A two-tailed('two-sided') test is appropriate 
if the estimated value may be more than or less than the reference value
For example, to compare the mean of a sample to a given value x using a t-test.  
Our null hypothesis is that the mean is equal to x. 
A two-tailed test will test both if the mean is significantly greater than x 
and if the mean significantly less than x. 
The mean is considered significantly different from x 
if the test statistic is in the top 2.5% or bottom 2.5% of its probability distribution, 
resulting in a p-value less than 0.05(resulting rejection of H0)    
 

A one-tailed/sided test is appropriate 
if the estimated value may depart from the reference value in only one direction,
for example either:
    'greater' : above or equal to a certain value, or
    'less' :below/less or equal to a certain value.
For example, to compare the mean of a sample to a given value x using a t-test.  
Our null hypothesis is that the mean is equal to x.  
A one-tailed test will test either if the mean is significantly greater than x 
or if the mean is significantly less than x, but not both. 
Then, depending on the chosen tail, the mean is significantly greater than 
or less than x if the test statistic is in the top 5% of its probability distribution 
or bottom 5% of its probability distribution, 
resulting in a p-value less than 0.05.


Note in Scipy, few tests have 
alternative : {'two-sided', 'less','greater'} function parameter 
which means , 
For 'two-sided', Alternative hypothesis is two-sided meaning H0 is 'equal-to'
For 'less','greater': Alternate Hypothesis is less or greater than test parameter 
However, when Alternate Hypothesis is 'greater', meaning H0 is 'less-than' 
and when Alternate Hypothesis is 'less', meaning H0 is 'greater-than'
And rejecting H0 means truthifying  Alternate Hypothesis
and vice versa 


If the test statistic follows a Student's t-distribution in the null hypothesis 
– when underlying variable follows a normal distribution 
with unknown scaling factor(var), 
then the test is referred to as a one-tailed or two-tailed t-test. 

If the test is performed using the actual population mean and variance, 
rather than an estimate from a sample, 
it would be called a one-tailed or two-tailed Z-test.

Note in Scipy, p-value of t-test  are always two-sided
This means that given p and t values from a two-tailed test, 
you would reject the null hypothesis of a greater-than test 
when p/2 < alpha and t > 0, 
and of a less-than test when p/2 < alpha and t < 0.


### Scipy - statistical tests - Kolmogorov-Smirnov test for goodness of fit
#(non-parametric)(for continuous dist)
#non-parameteric - no assumption of pdf (parameteric means normal dist)
scipy.stats.kstest(rvs, cdf, args=(), N=20, alternative='two-sided', mode='approx')
#H0:rvs is drawn from cdf
#cdf: If a string, it should be the name of a distribution in scipy.stats
#or a python callable which gives the cdf
#Returns: (D, p-value)

 

#Example 
from scipy import stats
x = np.linspace(-15, 15, 9)
>>> stats.kstest(x, 'norm')
(0.44435602715924361, 0.038850142705171065)  #<0.05, reject H0
np.random.seed(987654321)
>>> stats.kstest(stats.norm.rvs(size=100), 'norm')  
(0.058352892479417884, 0.88531190944151261)  #>0.05, dont reject H0


#Test against one-sided alternative hypothesis
#In the one-sided test, 
#the alternative is True pdf, G(x)  is 'less' or 'greater' than the given F(x) of the hypothesis
#ie G(x)<=F(x), resp. G(x)>=F(x).
np.random.seed(987654321)
x = stats.norm.rvs(loc=0.2, size=100)
stats.kstest(x,'norm', alternative = 'less') #H0:greater as alternative is less
(0.12464329735846891, 0.040989164077641749) #<0.05, reject H0



### Scipy - statistical tests - Kolmogorov-Smirnov statistic on 2 samples 
#(non parametric test)(continuous distribution)
scipy.stats.ks_2samp(data1, data2)
#non-parameteric - no assumption of pdf (parameteric means normal dist)
#H0: data1,data2 are drawn from the same continuous distribution.
#Returns (statistic, pvalue)

#Example 
from scipy import stats
np.random.seed(12345678)  #fix random seed to get the same result
n1 = 200  # size of first sample
n2 = 300  # size of second sample

rvs1 = stats.norm.rvs(size=n1, loc=0., scale=1)
rvs2 = stats.norm.rvs(size=n2, loc=0.5, scale=1.5)
>>> stats.ks_2samp(rvs1, rvs2)
(0.20833333333333337, 4.6674975515806989e-005)  #<0.05, reject H0 



### Scipy - statistical tests - Mann-Whitney rank test on samples x and y
#(non-parametric, n > 20)
#non-parameteric - no assumption of pdf (parameteric means normal dist)
scipy.stats.mannwhitneyu(x, y, use_continuity=True, alternative=None)
#H0: x,y come from the same population(ie same distribution/mean etc)
#returns (statistics, p-value)


#Frank Wilcoxon's 1945 paperdescribed two tests -- 
#for "Unpaired Experiments" and "Paired Comparisons" 
#which have come to be called the (Wilcoxon) rank sum test 
#and the (Wilcoxon) signed rank test respectively
#The test for comparing unpaired samples was extended by Mann and Whitney in 1947

from scipy.stats import mannwhitneyu
import numpy as np 
a = np.arange(100)
b = np.arange(100)
np.random.shuffle(b)
>>> np.corrcoef(a,b)
   array([[ 1.        , -0.07155116],
          [-0.07155116,  1.        ]])
>>> mannwhitneyu(a, b, alternative='two-sided')
MannwhitneyuResult(statistic=5000.0, pvalue=0.9990251925510822) # result for almost not correlated, >0.05, don't reject H0
>>> mannwhitneyu(a, a, alternative='two-sided')
MannwhitneyuResult(statistic=5000.0, pvalue=0.9990251925510822) # result for perfectly correlated


### Scipy - statistical tests - Wilcoxon signed-rank test
#(non-parametric , n>20)
scipy.stats.wilcoxon(x, y=None, zero_method='wilcox', correction=False)
#H0: x,y,  paired samples come from the same distribution(ie same mean etc)
#paired means same objects are subjected to two tests 
#returns (statistics, p-value)



### Scipy - statistical tests - Kruskal-Wallis H-test 
#(non-parametric, like anova,Analysis of variance , n>5)
scipy.stats.kruskal(sample1, sample2,... )
#H0: population median of all of the groups are equal.
#returns (statistics, p-value)

#Example 
from scipy import stats
x = [1, 3, 5, 7, 9]
y = [2, 4, 6, 8, 10]
>>> stats.kruskal(x, y)
KruskalResult(statistic=0.27272727272727337, pvalue=0.60150813444058948) #>0.05, dont reject H0


### Scipy - statistical tests - Friedman test 
#(non-parametric, like one way anova with repeated measures, n>10 and repeated>6)
scipy.stats.friedmanchisquare(sample1, sample2,...  )
#H0: repeated measurements of the same individuals have the same distribution
#repeated measures is used to compare three or more group(atleast three samples must be given)
#where the participants are the same in each group

#For example, if two measurement techniques are used on the same set of individuals, 
#the Friedman test can be used to determine if the two measurement techniques are consistent.
#returns (statistics, p-value)





### Scipy - statistical tests - Combine p-values 
scipy.stats.combine_pvalues(pvalues, method='fisher', weights=None)
#method : {'fisher, 'stouffer}, 
#returns (statistics, p-value)




### Scipy - statistical tests - one-way chi square test 
#( non-parametric, n>5)
scipy.stats.chisquare(f_obs, f_exp=None, ddof=0, axis=0)
#H0: f_obs data has the f_exp frequencies.
#"One way" means that units are classified according to a single categorical variable
#ie f_obs is array (dimension-1)
#returns (statistics, p-value)

#Example 
# with only f_obs is given,  expected frequencies are uniform 
#and = the mean of the observed frequencies.

from scipy.stats import chisquare
>>> chisquare([16, 18, 16, 14, 12, 12])
(2.0, 0.84914503608460956)  #last one is p_value 


#With f_exp the expected frequencies can be given.
>>> chisquare([16, 18, 16, 14, 12, 12], f_exp=[16, 16, 16, 16, 16, 8])
(3.5, 0.62338762774958223)


#When f_obs is 2-D, by default the test is applied to each column.
obs = np.array([[16, 18, 16, 14, 12, 12], [32, 24, 16, 28, 20, 24]]).T
>>> obs.shape
(6, 2)
>>> chisquare(obs)
(array([ 2.        ,  6.66666667]), array([ 0.84914504,  0.24663415])) #last one is array of p_value 

#By setting axis=None, 
#the test is applied to all data in the array, 
#which is equivalent to applying the test to the flattened array.
>>> chisquare(obs, axis=None)
(23.31034482758621, 0.015975692534127565)
>>> chisquare(obs.ravel())
(23.31034482758621, 0.015975692534127565)

#ddof is the change to make to the default degrees of freedom.
>>> chisquare([16, 18, 16, 14, 12, 12], ddof=1)
(2.0, 0.73575888234288467)






### Scipy - statistical tests - Cressie-Read power divergence statistic and goodness of fit test
#( non-parametric, n>5)
#generalization of pearson chi square test(when lambda_ = 1)
scipy.stats.power_divergence(f_obs, f_exp=None, ddof=0, axis=0, lambda_=None)
#H0: f_obs data has the f_exp frequencies.
#returns (statistics, p-value)
#lambda_              Value Description
"pearson"             1     Pearson's chi-squared statistic.
                            In this case, the function is
                            equivalent to `stats.chisquare`.
"log-likelihood"      0     Log-likelihood ratio. Also known as
                            the G-test [R557].
"freeman-tukey"      -1/2   Freeman-Tukey statistic.
"mod-log-likelihood" -1     Modified log-likelihood ratio.
"neyman"             -2     Neyman's statistic.
"cressie-read"        2/3   The power recommended in [R559]


#Example 
# with onlyf_obs is given,  expected frequencies are uniform 
#and given by the mean of the observed frequencies.

from scipy.stats import power_divergence
>>> power_divergence([16, 18, 16, 14, 12, 12], lambda_='log-likelihood')
(2.006573162632538, 0.84823476779463769) #last one is p-value 


#The expected frequencies can be given with the f_exp argument:
>>> power_divergence([16, 18, 16, 14, 12, 12],
            f_exp=[16, 16, 16, 16, 16, 8],
            lambda_='log-likelihood')
(3.3281031458963746, 0.6495419288047497) #last one is p-value 




### Scipy - statistical tests - Chi-square test of independence of variables in a contingency table.
scipy.stats.chi2_contingency(contingency_table, correction=True, lambda_=None)
#(non-parameteric, n>5)
#H0:observed frequencies in the contingency table are independent
#lambda_ as same as from power_divergence
#contingency_table could be RxC in 2 dimensions or higher dimensions
#Returns:
    chi2 : float,The test statistic.
    p : float,The p-value of the test
    dof : int,Degrees of freedom
    expected : ndarray, same shape as observed,
              The expected frequencies, based on the marginal sums of the table
 
#Example of contigency table 
#Suppose that we have two variables, 
#sex (male or female) and handedness (right or left handed). 
#Further suppose that 100 individuals are randomly sampled 
#from a very large population as part of a study of sex differences in handedness
        Handedness
Gender  Right handed    Left handed     Total
Male        43          9               52
Female      44          4               48 
Total       87          13              100 
#H0: male-female's  right or left handed are independent 
obs = np.array([[43,9], [44,4]])
>>> stats.chi2_contingency(obs)
(1.0724852071005921, 
0.300384770390566,  #>0.05, don't reject H0 
1, array([[45.24,  6.76],
       [41.76,  6.24]]))
       
       

#A two-way example (2 x 3)- 2D
from scipy.stats import chi2_contingency
obs = np.array([[10, 10, 20], [20, 20, 20]])
>>> chi2_contingency(obs)
(2.7777777777777777,
 0.24935220877729619,   #p-value 
 2,
 array([[ 12.,  12.,  16.],
        [ 18.,  18.,  24.]]))


#Perform the test using the log-likelihood ratio (i.e. the 'G-test') 
g, p, dof, expctd = chi2_contingency(obs, lambda_="log-likelihood")
>>> g, p
(2.7688587616781319, 0.25046668010954165)

#A four-way example (2 x 2 x 2 x 2)-4D
obs = np.array(
        [[[[12, 17],
        [11, 16]],
        [[11, 12],
        [15, 16]]],
        [[[23, 15],
        [30, 22]],
        [[14, 17],
        [15, 16]]]])
>>> chi2_contingency(obs)
(8.7584514426741897,
 0.64417725029295503,  #p value 
 11,
 array([[[[ 14.15462386,  14.15462386],
          [ 16.49423111,  16.49423111]],
         [[ 11.2461395 ,  11.2461395 ],
          [ 13.10500554,  13.10500554]]],
        [[[ 19.5591166 ,  19.5591166 ],
          [ 22.79202844,  22.79202844]],
         [[ 15.54012004,  15.54012004],
          [ 18.10873492,  18.10873492]]]]))




### Scipy - statistical tests - Fisher exact test on a 2x2 contingency table
scipy.stats.fisher_exact(contingency_table, alternative='two-sided')
#H0:observed frequencies in the contingency table are independent
#returns (statistics, p-value)

#Example 
        Atlantic  Indian
whales     8        2
sharks     1        5
#H0: whales-sharks from Atlantic and Indian ocean are independent

import scipy.stats as stats
oddsratio, pvalue = stats.fisher_exact([[8, 2], [1, 5]])
>>> pvalue   #<0.05, reject H0
0.0349...




### Scipy - statistical tests - Jarque-Bera goodness of fit test on sample data
#(parametric, n>2000)
scipy.stats.jarque_bera(x)
#H0: sample data has the skewness and kurtosis matching a normal distribution.
#returns (statistics, p-value)

#Example 
from scipy import stats
np.random.seed(987654321)
x = np.random.normal(0, 1, 100000)
y = np.random.rayleigh(1, 100000)
>>> stats.jarque_bera(x)
(4.7165707989581342, 0.09458225503041906)  #last one is p-value 
>>> stats.jarque_bera(y)
(6713.7098548143422, 0.0)


### Scipy - statistical tests - Shapiro-Wilk test for normality
scipy.stats.shapiro(x, a=None, reta=False)
#H0: x is from normal distribution
#returns (statistics, p-value)

from scipy import stats
np.random.seed(12345678)
x = stats.norm.rvs(loc=5, scale=3, size=100)
>>> stats.shapiro(x)
(0.9902572631835938, 0.685400664806366)  #last one is p-value


### Scipy - statistical tests - Anderson-Darling test- 1 sample 
scipy.stats.anderson(x, dist='norm')
#H0: x is from 'dist'
#dist : {'norm,expon,logistic,gumbel,extreme1}
#returns (statistic, critical_values=array([one float for each significance_level]), 
#significance_level=array([15. , 10. ,  5. ,  2.5,  1.]))
#significance_level is in % 

>>> x = stats.norm.rvs(loc=5, scale=3, size=100)
>>> stats.shapiro(x)
(0.9902572631835938, 0.685400664806366)   #>0.5, don't reject H0 
>>> stats.anderson(x)
AndersonResult(statistic=0.20901515717881125, critical_values=array([0.555, 0.63
2, 0.759, 0.885, 1.053]), significance_level=array([15. , 10. ,  5. ,  2.5,  1.
])) #statistic < critical_values, hence don't reject H0


### Scipy - statistical tests - Anderson-Darling test for k-samples
#(non-Paramteric, continuous and discrete data)
scipy.stats.anderson_ksamp(array_of_samples, midrank=True)
#H0: k-samples are drawn from the same population
#Returns 
statistic : float
    Normalized k-sample Anderson-Darling test statistic.
critical_values : array
    The critical values for significance levels 25%, 10%, 5%, 2.5%, 1%.
significance_level : float
    An approximate significance level 
    at which the null hypothesis for the provided samples can be rejected.
 
#statistic < critical_values, hence don't reject H0
#statistic > critical_values, hence reject H0
#Example 
>>> stats.anderson_ksamp([np.random.normal(size=50),
    np.random.normal(loc=0.5, size=30)])
(2.4615796189876105,
  array([ 0.325,  1.226,  1.961,  2.718,  3.752]),
  0.03134990135800783)  #last one: 3% significance level where H0 can be rejected



### Scipy - statistical tests - Binomial test
scipy.stats.binom_test(x, n=None, p=0.5, alternative='two-sided')
#H0: probability of success given x out of n trials is p for 'two-sided'
#probability of success given x out of n trials is <= p for 'greater'
#probability of success given x out of n trials is >= p for 'less'
#x: the number of successes, and give n 
#or if x has length 2, it is the number of successes and the number of failures, and ignore n 
#Returns p-value 

#Example 
#Problem - A soft drink company has invented a new drink, 
#and would like to find out if it will be as popular as the existing favorite drink. 
#For this purpose, its research department arranges 18 participants for taste testing. 
#Each participant tries both drinks in random order before giving his or her opinion. 

#It turns out that 5 of the participants like the new drink better, and the rest prefer the old one. 
#At .05 significance level, can we reject the notion that the two drinks are equally popular? 

 
> scipy.stats.binom_test(5, 18)              #H0 : two drinks are equally popular ie p=0.5
0.096252441406249986             #>0.05, accept H0




### Scipy - statistical tests - Moods test for equal scale parameters
#(non-parametric)
scipy.stats.mood(x, y, axis=0)
#H0: x,y have same distribution with same scale(for norm, it is var) parameter
#For multi-dimensional arrays, if the inputs are of shapes (n0, n1, n2, n3) 
#and (n0, m1, n2, n3), then if axis=1, 
#the resulting z and p values will have shape (n0, n2, n3). 
#Note that n1 and m1 don't have to be equal, but the other dimensions do.

#Returns:
z : scalar or ndarray
    The z-score for the hypothesis test. For 1-D inputs a scalar is returned.
p-value : scalar ndarray
    The p-value for the hypothesis test.
 
 
#Example 

from scipy import stats
np.random.seed(1234)
x2 = np.random.randn(2, 45, 6, 7) #from the 'standard normal' distribution., args: The dimensions of the returned array
x1 = np.random.randn(2, 30, 6, 7) #The dimensions of the returned array
z, p = stats.mood(x1, x2, axis=1)
>>> p.shape
(2, 6, 7)


#Find the number of points where the difference in scale is not significant(p-value> 0.05)
>>> (p > 0.1).sum()
74

#Perform the test with different scales:
x1 = np.random.randn(2, 30)
x2 = np.random.randn(2, 35) * 10.0
>>> stats.mood(x1, x2, axis=1)
(array([-5.7178125 , -5.25342163]), array([  1.07904114e-08,   1.49299218e-07])) #last one p-value 




### Scipy - statistical tests - Ansari-Bradley test for equal scale parameters
#(A non-parametric test for the equality of 2 variances, exact for n<55, else approx)
scipy.stats.ansari(x, y)
#H0: x,y have equal scale parameter (similar in shape ie variances)
#Returns (statistic, p-value)



### Scipy - statistical tests - Bartletts test for equal variances of k samples 
#(A parametric(normal) test for equality of k variances in normal samples)
scipy.stats.bartlett(sample1, sample2,... )
#H0: all have equal variance
#For samples from significantly non-normal populations,
#Levenes test is more robust.
#Returns (statistic, p-value)



### Scipy - statistical tests - Levene test for equal variances of k samples 
#(A parametric test for equality of k variances)
scipy.stats.levene(sample1, sample2, ...,center ,proportiontocut =0.05 )
#H0: all have equal variance
#Returns (statistic, p-value)
#center : {'mean', 'median', 'trimmed'}, optional
    •'median' : Recommended for skewed (non-normal) distributions>
    •'mean' : Recommended for symmetric, moderate-tailed distributions.
    •'trimmed' : Recommended for heavy-tailed distributions.



### Scipy - statistical tests - Fligner-Killeen test for equality of variance of k samples 
#(A non-parametric test for the equality of k variances)
scipy.stats.fligner(sample1, sample2, ...,center ,proportiontocut =0.05)
#H0: all have equal variance
#Returns (statistic, p-value)
#center : {'mean', 'median', 'trimmed'}, optional
    •'median' : Recommended for skewed (non-normal) distributions>
    •'mean' : Recommended for symmetric, moderate-tailed distributions.
    •'trimmed' : Recommended for heavy-tailed distributions.




### Scipy - statistical tests - Moods median test 
#(non-parametric)
scipy.stats.median_test(sample1, sample2, ..., lambda_ )
#H0: two or more samples come from populations with the same median
#By default, the statistic computed in this test is Pearson's chi-squared statistic. 
#lambda_ allows a statistic from the Cressie-Read power divergence family to be used instead
#Returns 
stat : float
    The test statistic. The statistic that is returned is determined by lambda_. 
    The default is Pearson's chi-squared statistic.
p : float
    The p-value of the test.
m : float
    The grand median.
table : ndarray
    The contingency table. The shape of the table is (2, n), 
    where n is the number of samples. 
    The first row holds the counts of the values above the grand median, 
    and the second row holds the counts of the values below the grand median




#Example 
#A biologist runs an experiment in which there are three groups of plants. 
#Group 1 has 16 plants, group 2 has 15 plants, and group 3 has 17 plants. 
#Each plant produces a number of seeds. The seed counts for each group are:
Group 1: 10 14 14 18 20 22 24 25 31 31 32 39 43 43 48 49
Group 2: 28 30 31 33 34 35 36 40 44 55 57 61 91 92 99
Group 3:  0  3  9 22 23 25 25 33 34 34 40 45 46 48 62 67 84
#Ho: g1, g2, g3 have same median 

g1 = [10, 14, 14, 18, 20, 22, 24, 25, 31, 31, 32, 39, 43, 43, 48, 49]
g2 = [28, 30, 31, 33, 34, 35, 36, 40, 44, 55, 57, 61, 91, 92, 99]
g3 = [0, 3, 9, 22, 23, 25, 25, 33, 34, 34, 40, 45, 46, 48, 62, 67, 84]
from scipy.stats import median_test
stat, p, med, tbl = median_test(g1, g2, g3)
#The median is
>>> med
34.0
#and the contingency table is
>>> tbl
array([[ 5, 10,  7],
       [11,  5, 10]])

#p is too large to conclude that the medians are not the same
>>> p
0.12609082774093244  #>0.5, don't reject H0 


#The 'G-test' can be performed by passing lambda_="log-likelihood" to median_test.
g, p, med, tbl = median_test(g1, g2, g3, lambda_="log-likelihood")
>>> p
0.12224779737117837




### Scipy - statistical - boxcox transformations to convert to normal dist 
#Normality is an important assumption for many statistical techniques
#A Box Cox transformation is a way to transform non-normal dependent variables into a normal shape
boxcox(x[, lmbda, alpha])           Return a positive dataset transformed by a Box-Cox power transformation. 
boxcox_normmax(x[, brack, method])  Compute optimal Box-Cox transform parameter for input data. 
boxcox_llf(lmb, data)               The boxcox log-likelihood function. 
entropy(pk[, qk, base])             Calculate the entropy of a distribution for given probability values. 
boxcox_normplot(x, la, lb[, plot, N]) Compute parameters for a Box-Cox normality plot, optionally show it. 
probplot(x[, sparams, dist, fit, plot, rvalue])     Calculate quantiles for a probability plot, and optionally show the plot. 

#boxcox: Transformation depends on lambda (λ), which varies from -5 to 5
#selects the best lambda 
#actula transformation is given by 
y = (x**lmbda - 1) / lmbda,  for lmbda > 0
    log(x),                  for lmbda = 0
#If alpha is not None, 
#return the 100 * (1-alpha)% confidence interval for lmbda 
#Returns 
boxcox : ndarray
    Box-Cox power transformed array.
maxlog : float, optional
    If the lmbda parameter is None, 
    the second returned argument is the lambda that maximizes the log-likelihood function.
(min_ci, max_ci) : tuple of float, optional, 
    minimum and maximum confidence limits



#Example 
from scipy import stats
import matplotlib.pyplot as plt
np.random.seed(1234)  # make this example reproducible


#Generate some data and determine optimal lmbda in various ways:
x = stats.loggamma.rvs(5, size=30) + 5
y, lmax_mle = stats.boxcox(x)  #y is transformed of x
lmax_pearsonr = stats.boxcox_normmax(x)
>>> lmax_mle
7.177...
>>> lmax_pearsonr
7.916...

>>> stats.boxcox_normmax(x, method='all')
array([ 7.91667384,  7.17718692])


fig = plt.figure()
ax = fig.add_subplot(111)
prob = stats.boxcox_normplot(x, -10, 10, plot=ax)
ax.axvline(lmax_mle, color='r')
ax.axvline(lmax_pearsonr, color='g', ls='--')
plt.show()

#Or draw stats.probplot
scipy.stats.probplot(x, sparams=(), dist='norm', fit=True, plot=None, rvalue=False)
#Generates a probability plot of sample data 
#against the quantiles of a specified theoretical distribution 
#(the normal distribution by default). 
#Parameters:
    x : array_like
        Sample/response data from which probplot creates the plot.
    sparams : tuple, optional
        Distribution-specific shape parameters (shape parameters plus location and scale).
#Even if plot is given, 
#the figure is not shown or saved by probplot; plt.show() or plt.savefig('figname.png') should be used after calling probplot.
#probplot generates a probability plot, 
#which should not be confused with a Q-Q or a P-P plot
#Returns:
(osm, osr) : tuple of ndarrays
    Tuple of theoretical quantiles (osm, or order statistic medians) 
    and ordered responses (osr). 
    osr is simply sorted input x. 
(slope, intercept, r) : tuple of floats, optional
    Tuple containing the result of the least-squares fit, 
    if that is performed by probplot. 
    r is the square root of the coefficient of determination. 
    If fit=False and plot=None, this tuple is not returned.
 
#Example 
from scipy import stats
import matplotlib.pyplot as plt
nsample = 100
np.random.seed(7654321)
fig = plt.figure()
ax1 = fig.add_subplot(511)
x = stats.loggamma.rvs(5, size=500) + 5
prob = stats.probplot(x, dist=stats.norm, plot=ax1)
ax1.set_xlabel('')
ax1.set_title('Probplot against normal distribution')
#after transformation 
ax2 = fig.add_subplot(512)
xt, _ = stats.boxcox(x)
prob = stats.probplot(xt, dist=stats.norm, plot=ax2)
ax2.set_title('Probplot after Box-Cox transformation')
#Then QQ plot 
#qqplot(data, dist=<scipy.stats._continuous_distns.norm_gen object>, distargs=(), a=0, loc=0, scale=1, fit=False, line=None, ax=None)
#dist : A scipy.stats or statsmodels distribution
ax2 = fig.add_subplot(513)
import statsmodels.api as sm
sm.qqplot(xt, line='45', ax=ax2)
ax3.set_title('Q-Q after Box-Cox transformation')
#qqplot of the residuals against quantiles of t-distribution with 4 degrees of freedom:
import scipy.stats as stats
ax3 = fig.add_subplot(514)
fig = sm.qqplot(xt, stats.t, distargs=(4,), , ax=ax3)
#qqplot against same as above, but with mean 3 and std 10:
ax4 = fig.add_subplot(515)
fig = sm.qqplot(xt, stats.t, distargs=(4,), loc=3, scale=10, , ax=ax4)
plt.show()











### Scipy - statistical tests - 1-way(2way) ANOVA(F-test) 
#(parametric/assumes normal)
scipy.stats.f_oneway(sample1, sample2,...)
#H0:two or more groups have the same population mean.
#"One way"(1D) means that units are classified according to a single categorical variable
#"Two way"(2D) means that units are classified according to a Two categorical variable(ie contigency table)
#Returns (statistic, p-value)

ANOVA is a means of comparing the ratio of systematic variance 
to unsystematic variance in an experimental study. 

Variance in the ANOVA is partitioned in to total variance(SS-T), 
variance due to groups(SS-Between or SS-A), 
and variance due to individual differences(SS-Within)

The "Between Groups"  represents what is often called "explained variance" 
or "systematic variance". 
We can think of this as variance that is due to the independent variable, 
the difference among  groups of IV/treatment 

The "Within Groups" variance represents what is often called "error variance". 
This is the variance within the groups, 
variance that is not due to the independent variable/treatment . 


The ratio obtained when doing this comparison is known as the F-ratio. 

A one-way ANOVA can be seen as a regression model 
with a single categorical predictor. 
This predictor usually has two plus categories. 
A one-way ANOVA has a single factor with J levels

Sum of Squares Between((SS-Between) is the variability due to interaction between the groups
Also called Treatment Sum of Squares or "Within groups Sum of Squares"

Sum of Squares Within(SS-Within) - The variability in the data due to differences within people
Also called Error Sum of Squares or Residual Sum of Squares

Sum of Squares Total(SS-T)- This is the total variability in the data.

Note: Effect size(eta-squared) is a value which allows you to see 
how much your independent variable (IV)(also called treatment)
has affected the dependent variable (DV) in an experimental study
•Small effect: 0.01
•Medium effect: 0.059
•Large effect: 0.138
For example , eta-squared=0.498
Means- a very large effect size; 49.8% of the variance was caused by the IV (treatment).
#Effect size for a between groups ANOVA
eta_sqrd = SSbetween/SStotal

Omega squared is widely viewed as a lesser biased alternative to eta-squared, 
especially when sample sizes are small.
•Omega squared can have values between ± 1. 
•Zero indicates no effect. 
•If the observed F is less than one, Omega squared will be negative.



##Assumptions
1.The samples are independent.
2.Each sample is from a normally distributed population.
3.The population standard deviations of the groups are all equal(homoscedasticity)

#Example 

import scipy.stats as stats

#Here are some data on a shell measurement 
#(the length of the anterior adductor muscle scar, standardized by dividing by length) 
#in the mussel Mytilus trossulus from five locations:
#Tillamook, Oregon; Newport, Oregon; Petersburg, Alaska; Magadan, Russia; and Tvarminne, Finland, 
#taken from a much larger data set used in McDonald et al. (1991).

#H0: all shells from these have same mean 
tillamook = [0.0571, 0.0813, 0.0831, 0.0976, 0.0817, 0.0859, 0.0735,
    0.0659, 0.0923, 0.0836]
newport = [0.0873, 0.0662, 0.0672, 0.0819, 0.0749, 0.0649, 0.0835,
    0.0725]
petersburg = [0.0974, 0.1352, 0.0817, 0.1016, 0.0968, 0.1064, 0.105]
magadan = [0.1033, 0.0915, 0.0781, 0.0685, 0.0677, 0.0697, 0.0764,
        0.0689]
tvarminne = [0.0703, 0.1026, 0.0956, 0.0973, 0.1039, 0.1045]
>>> stats.f_oneway(tillamook, newport, petersburg, magadan, tvarminne)
(7.1210194716424473, 0.00028122423145345439) #<0.5, reject H0


##Comparison Scipy vs  statsmodel 
#PlantGrowth.csv - "weight" , "group"("ctrl", "trt1","trt2")
#H0: all groups have same mean weight 
import pandas as pd
datafile="PlantGrowth.csv"
data = pd.read_csv(datafile)
 
#Create a boxplot- shows each group's weight with minimum, first quartile, median, third quartile, and maximum
data.boxplot('weight', by='group', figsize=(12, 8))
 
ctrl = data['weight'][data.group == 'ctrl']
 
grps = pd.unique(data.group.values)
d_data = {grp:data['weight'][data.group == grp] for grp in grps}
 
k = len(pd.unique(data.group))  # number of conditions
N = len(data.values)  # conditions times participants
n = data.groupby('group').size()[0] #Participants in each condition

#scipy 
from scipy import stats
F, p = stats.f_oneway(d_data['ctrl'], d_data['trt1'], d_data['trt2'])
#above gives  p-value 
#Note ANOVA assumes all groups have same variance 
#test it via scipy.stats.bartlett,
F, p =stats.bartlett(d_data['ctrl'], d_data['trt1'], d_data['trt2'])
#p <0.05, reject H0=all groups have same variance 
#or via scipy.stats.obrientransform
from scipy.stats import obrientransform
tx, ty, tz = obrientransform(d_data['ctrl'], d_data['trt1'], d_data['trt2'])
from scipy.stats import f_oneway
F, p = f_oneway(tx, ty, tz)
#p <0.05, reject H0=all groups have same variance 




##To get manually 
DFbetween = k - 1
DFwithin = N - k
DFtotal = N - 1
#Sum  Square 
SSbetween = (sum(data.groupby('group').sum()['weight']**2)/n) - (data['weight'].sum()**2)/N
sum_y_squared = sum([value**2 for value in data['weight'].values])
SSwithin = sum_y_squared - sum(data.groupby('group').sum()['weight']**2)/n
SStotal = sum_y_squared - (data['weight'].sum()**2)/N
#Mean Square 
MSbetween = SSbetween/DFbetween
MSwithin = SSwithin/DFwithin

F = MSbetween/MSwithin
p = stats.f.sf(F, DFbetween, DFwithin) #p-value 
#Effect size for a between groups ANOVA
eta_sqrd = SSbetween/SStotal
#we can use the less biased effect size measure Omega squared
om_sqrd = (SSbetween - (DFbetween * MSwithin))/(SStotal + MSwithin)
#Reporting style 
F(2, 27) = 4.846, p =  .016, eta-squared =  .264, omega-squared = .204



##statsmodels 
#H0: all groups have same mean weight 
import statsmodels.api as sm
from statsmodels.formula.api import ols
#IV(treatment) - group, DV- weight 
mod = ols('weight ~ group',data=data).fit()
aov_table = sm.stats.anova_lm(mod, typ=2)
effect_size = aov_table['sum_sq'][0]/(aov_table['sum_sq'][0]+aov_table['sum_sq'][1])
print(aov_table)
            sum_sq      df      F           PR(>F)
group       3.76634     2       4.846088    0.01591  
Residual    10.49209    27   
#PR<0.05 reject H0, means all groups are not same 
#To know which group has effect , Turky HSD is required(statsmodels) 
#reject (array of boolean, True if we reject Null(Ho=same mean pairwise) for group pair) 
import numpy as np
from scipy import stats
from statsmodels.stats.multicomp import (pairwise_tukeyhsd,MultiComparison)
res2 = pairwise_tukeyhsd(data['weight'], data['group']) #TukeyHSDResults
res2.groupsunique #to get group index 
print(res2.summary())
#'crt' group is taken reference 
#Plot a universal confidence interval of each group mean
#If some mean box overlapps, mean difference is not significant 
res2.plot_simultaneous(comparison_name='crtl', ax=None, figsize=(10, 6), xlabel=None, ylabel=None)
#Or 
mod = MultiComparison(dta2['StressReduction'], dta2['Treatment'])
mod.groupsunique 
res3 = mod.tukeyhsd() #TukeyHSDResults
res3.groupsunique #to get group index 
print(res3.summary())
res3.plot_simultaneous(comparison_name='ctrl', ax=None, figsize=(10, 6), xlabel=None, ylabel=None)
#Or 
print(mod.allpairtest(stats.ttest_rel, method='Holm'))
#or 
print(mod.allpairtest(stats.ttest_rel, method='b'))





#or use pyvttbl(not maintained)
#Requires numpy 1.11.x 
#setup conda/virtualenv with below 
#pip install virtualenv
#mkdir pyvttbl_env
#cd pyvttbl_env
#virtualenv ./
#pyvttbl_env\Scripts\activate
#pip pip install numpy-1.11.3+mkl-cp27-cp27m-win32.whl scipy-0-19.1-cp27-cp27m-win32.whl
#pip install jupyter matplotlib seaborn
#to run our ANOVA in a notebook 
#ipython kernel install --name "pyvttbl_env" --user


from pyvttbl import DataFrame
 
df=DataFrame()
df.read_tbl(datafile)
aov_pyvttbl = df.anova1way('weight', 'group')
print aov_pyvttbl  #O'BRIEN TEST , H0: all groups have same variance 
Anova: Single Factor on weight
 
SUMMARY
Groups   Count    Sum     Average   Variance 
============================================
ctrl        10   50.320     5.032      0.340 
trt1        10   46.610     4.661      0.630 
trt2        10   55.260     5.526      0.196 
 
O'BRIEN TEST FOR HOMOGENEITY OF VARIANCE
Source of Variation    SS     df    MS       F     P-value   eta^2   Obs. power 
===============================================================================
Treatments            0.977    2   0.489   1.593     0.222   0.106        0.306 
Error                 8.281   27   0.307                                        
===============================================================================
Total                 9.259   29                                                
 
ANOVA
Source of Variation     SS     df    MS       F     P-value   eta^2   Obs. power 
================================================================================
Treatments             3.766    2   1.883   4.846     0.016   0.264        0.661 
Error                 10.492   27   0.389                                        
================================================================================
Total                 14.258   29                                                
 
POSTHOC MULTIPLE COMPARISONS
 
Tukey HSD: Table of q-statistics
       ctrl     trt1       trt2   
=================================
ctrl   0      1.882 ns   2.506 ns 
trt1          0          4.388 *  
trt2                     0        
=================================
  + p < .10 (q-critical[3, 27] = 3.0301664694)
  * p < .05 (q-critical[3, 27] = 3.50576984879)
 ** p < .01 (q-critical[3, 27] = 4.49413305084)
ns - non significant 
#above show that trt1's mean is different than trt2  significantly 
 





##Note 2way annova not part of Scipy, use statsmodel 
#Unlike One-Way ANOVA, 
#it enables us to test the effect of two factors at the same time
#The only restriction is that the number of observations in each cell has to be equal 
import pandas as pd
from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm
from statsmodels.graphics.factorplots import interaction_plot
import matplotlib.pyplot as plt
from scipy import stats

datafile="ToothGrowth.csv" #"len","supp","dose"
data = pd.read_csv(datafile)

#visualising factorial data
fig = interaction_plot(data.dose, data.supp, data.len,
             colors=['red','blue'], markers=['D','^'], ms=10)
             
def eta_squared(aov):
    aov['eta_sq'] = 'NaN'
    aov['eta_sq'] = aov[:-1]['sum_sq']/sum(aov['sum_sq'])
    return aov
 
def omega_squared(aov):
    mse = aov['sum_sq'][-1]/aov['df'][-1]
    aov['omega_sq'] = 'NaN'
    aov['omega_sq'] = (aov[:-1]['sum_sq']-(aov[:-1]['df']*mse))/(sum(aov['sum_sq'])+mse)
    return aov


#C(data) means Categorical values in data 
#A:B means take interaction terms betwen A and B 
formula = 'len ~ C(supp) + C(dose) + C(supp):C(dose)'
model = ols(formula, data).fit()
aov_table = anova_lm(model, typ=2)
eta_squared(aov_table)
omega_squared(aov_table)
print(aov_table)
#note all terms are significant , does effect is largest 
Output ANOVA table
                sum_sq      df    F         PR(>F)          eta_sq      omega_sq
C(supp)         205.350000  1   15.571979   2.311828e-04    0.059484    0.055452 
C(dose)         2426.434333 2   91.999965   4.046291e-18    0.702864    0.692579 
C(supp):C(dose) 108.319000  2   4.106991    2.186027e-02    0.031377    0.023647 
Residual        712.106000  54  

#residual must be normal, check 
res = model.resid 
fig = sm.qqplot(res, line='s', ax=None)
plt.show()


#or 
from pyvttbl import DataFrame
df=DataFrame()
df.read_tbl(datafile)
df['id'] = xrange(len(df['len']))
print(df.anova('len', sub='id', bfactors=['supp', 'dose']))



















### Scipy - statistical tests - T-Test 
#(parametric)(equal variances)
#All returns (statistic, p_value)

ttest_1samp(a, popmean)
#H0: onesameple a has mean 'popmean'

ttest_ind(a, b, equal_var=True)
#H0:2 independent samples have identical average (expected) values

ttest_ind_from_stats(mean1, std1, nobs1, mean2, std2, nobs2)
#H0: 2 independent samples have identical average (expected) values
#mean1, std1, nobs1, mean2, std2, nobs2 are arraylike

ttest_rel(a,  b)
#H0:TWO RELATED(paired) samples  a and b have equal mean

#Example of ttest_1samp 
from scipy import stats
np.random.seed(7654567)  # fix seed to get the same result
rvs = stats.norm.rvs(loc=5, scale=10, size=(50,2))
>>> stats.ttest_1samp(rvs,5.0)
(array([-0.68014479, -0.04323899]), array([ 0.49961383,  0.96568674])) #last one is p-value 
>>> stats.ttest_1samp(rvs,0.0)
(array([ 2.77025808,  4.11038784]), array([ 0.00789095,  0.00014999]))


#Example of ttest_ind 
#Test with sample with identical means:
rvs1 = stats.norm.rvs(loc=5,scale=10,size=500)
rvs2 = stats.norm.rvs(loc=5,scale=10,size=500)
>>> stats.ttest_ind(rvs1,rvs2)
(0.26833823296239279, 0.78849443369564776)  #last one is p-value 
>>> stats.ttest_ind(rvs1,rvs2, equal_var = False)
(0.26833823296239279, 0.78849452749500748)

#ttest_ind underestimates p for unequal variances:
rvs3 = stats.norm.rvs(loc=5, scale=20, size=500)
>>> stats.ttest_ind(rvs1, rvs3)
(-0.46580283298287162, 0.64145827413436174)
>>> stats.ttest_ind(rvs1, rvs3, equal_var = False)
(-0.46580283298287162, 0.64149646246569292)

#When n1 != n2, 
#the equal variance t-statistic is no longer equal to the unequal variance t-statistic:
rvs4 = stats.norm.rvs(loc=5, scale=20, size=100)
>>> stats.ttest_ind(rvs1, rvs4)
(-0.99882539442782481, 0.3182832709103896)
>>> stats.ttest_ind(rvs1, rvs4, equal_var = False)
(-0.69712570584654099, 0.48716927725402048)


#T-test with different means, variance, and n:
rvs5 = stats.norm.rvs(loc=8, scale=20, size=100)
>>> stats.ttest_ind(rvs1, rvs5)
(-1.4679669854490653, 0.14263895620529152)
>>> stats.ttest_ind(rvs1, rvs5, equal_var = False)
(-0.94365973617132992, 0.34744170334794122)

#Example of ttest_rel (paired)
from scipy import stats
np.random.seed(12345678) # fix random seed to get same numbers
rvs1 = stats.norm.rvs(loc=5,scale=10,size=500)
rvs2 = (stats.norm.rvs(loc=5,scale=10,size=500) +
            stats.norm.rvs(scale=0.2,size=500))
>>> stats.ttest_rel(rvs1,rvs2)
(0.24101764965300962, 0.80964043445811562)
>>> rvs3 = (stats.norm.rvs(loc=8,scale=10,size=500) +
            stats.norm.rvs(scale=0.2,size=500))
>>> stats.ttest_rel(rvs1,rvs3)
(-3.9995108708727933, 7.3082402191726459e-005)







### Scipy - statistical - Correlation coefficient
#returns (r, p_value)
# r is from -1 to +1, ie inverse propotional to direct proportional, 
#=0 means not related 
pearsonr(x, y)          parametric, 
spearmanr(a,b)          non-Paramteric
pointbiserialr(x, y)    parametric, same value as pearsonr
kendalltau(x, y)        Calculates Kendalls tau, a correlation measure for ordinal dat a.
np.corrcoef(a, b)       parametric


>>> from scipy import stats
>>> stats.spearmanr([1,2,3,4,5], [5,6,7,8,7])
(0.82078268166812329, 0.088587005313543798)
>>> np.random.seed(1234321)
>>> x2n = np.random.randn(100, 2)
>>> y2n = np.random.randn(100, 2)
>>> stats.spearmanr(x2n)
(0.059969996999699973, 0.55338590803773591)



### Scipy - statistical tests - Other tests
kurtosistest(a) H0:a has normal kurtosis
normaltest(a)   H0:a is normal distribution
skewtest(a)     H0:a has normal skew

#Example 
>>> from scipy import stats
>>> pts = 1000
>>> np.random.seed(28041990)
>>> a = np.random.normal(0, 1, size=pts)
>>> b = np.random.normal(2, 1, size=pts)
>>> x = np.concatenate((a, b))
>>> k2, p = stats.normaltest(x)



### Scipy - statistical - Confidence interval and SE(standard error) of mean, var, std
#each result is of (center, (lower, upper))
mean_cntr, var_cntr, std_cntr = scipy.stats.bayes_mvs(data, alpha=0.9) #90% CI

#Calculates the standard error of the mean
s = sem(a, axis=0, ddof=1, nan_policy='propagate')


#Example 
from scipy import stats
data = [6, 9, 12, 7, 8, 8, 13]
mean, var, std = stats.bayes_mvs(data)
>>> mean
Mean(statistic=9.0, minmax=(7.1036502226125329, 10.896349777387467))
>>> var
Variance(statistic=10.0, minmax=(3.176724206..., 24.45910382...))
>>> std
Std_dev(statistic=2.9724954732045084, minmax=(1.7823367265645143, 4.9456146050146295))


##Alternate - How to calculate CI (Confidence interval)

#CI of p of Binom
#python - CI of binom  is beta distribution 
>>> statsmodels.stats.proportion.proportion_confint(2,3, method='beta')
(0.094299324050246075, 0.99159624134038737)
 
#CI of mean of normal dist 
import statsmodels.stats.api as sms

sms.DescrStatsW(a).tconfint_mean()  #t-dist because variance is unknown 
#OR
import numpy as np, scipy.stats as st
st.t.interval(0.95, len(a)-1, loc=np.mean(a), scale=st.sem(a)) #sem is SE of mean 

#The underlying assumptions for both are that the sample (array a) (size is small)
#was drawn independently from a normal distribution 
#with unknown standard deviation (T-Test).

#Basically it calculates SE of Mean and then from t distribution find 

import numpy as np
import scipy as sp
import scipy.stats

def mean_confidence_interval(data, confidence=0.95):
    a = 1.0*np.array(data)
    n = len(a)
    m, se = np.mean(a), scipy.stats.sem(a)
    h = se * sp.stats.t.ppf((1+confidence)/2., n-1)
    return m, m-h, m+h
    
#for large size   
#For large sample size n, the sample mean is normally distributed, (central limit theorem)
#and one can calculate its confidence interval using st.norm.interval()
stats.norm.interval(0.95, loc=mu, scale=sigma)

#The 95% confidence interval for the mean of N draws from a normal distribution with mean mu and std deviation sigma is
stats.norm.interval(0.95, loc=mu, scale=sigma/sqrt(N))





### Scipy - statistical - descriptive statistics - mean, variance etc
#use prefix scipy.stats.
describe(a)             Compute mean, var etc
gmean(a)                Compute the geometric mean
hmean(a)                Calculates the harmonic mean
kurtosis(a)             Computes  kurtosis
mode(a)                 Returns an array of the modal (most common) value in the passed arra y.
moment(a,moment)        Calculates the nth moment about the mean for a sample.
skew(a)                 Computes the skewness of a data se t.
kstat(data, n)          Return the nth k-statistic (1<=n<=4 so far ).
zscore(a)               Calculates the z score of each value in the sample, relative to the sample mean and standard deviatio n.
iqr(x)                  Compute the interquartile range of the data along the specified axis.

#The z-scores, standardized by mean and standard deviation of input array a.
a = np.array([ 0.7972,  0.0767,  0.4383,  0.7866,  0.8091,
        0.1954,  0.6307,  0.6599,  0.1065,  0.0508])
>>> from scipy import stats
>>> stats.zscore(a,axis=0, ddof=0)
array([ 1.1273, -1.247 , -0.0552,  1.0923,  1.1664, -0.8559,  0.5786,
        0.6748, -1.1488, -1.3324])

#scipy.stats.describe(a, axis=0, ddof=1, bias=True, nan_policy='propagate')
>>> from scipy import stats
>>> a = np.arange(10)
>>> stats.describe(a)
DescribeResult(nobs=10, minmax=(0, 9), mean=4.5, variance=9.1666666666666661,
               skewness=0.0, kurtosis=-1.2242424242424244)



### Scipy - statistical - Descriptive statistics of 'a' 
#only inside limits = None or (lower limit, upper limit)
#Values in the input array less than the lower limit or greater than the upper limit will be ignored
tmean(a,limits=None, inclusive=(True, True), axis=None)
tvar(a, limits=None, inclusive=(True, True), axis=0, ddof=1)
tmin(a, lowerlimit=None, axis=0, inclusive=True, nan_policy='propagate') #Values in the input array less than the given limit will be ignored. 
tmax(a, lowerlimit=None, axis=0, inclusive=True, nan_policy='propagate')
tstd(a, limits=None, inclusive=(True, True), axis=0, ddof=1)
tsem(a, limits=None, inclusive=(True, True), axis=0, ddof=1)




### Scipy - statistical - Plotting - plot-tests
ppcc_max(x[, brack, dist])                  Calculate the shape parameter that maximizes the PPCC 
ppcc_plot(x, a, b[, dist, plot, N])         Calculate and optionally plot probability plot correlation coefficient. 
probplot(x[, sparams, dist, fit, plot, rvalue]) Calculate quantiles for a probability plot, and optionally show the plot. 
boxcox_normplot(x, la, lb[, plot, N])       Compute parameters for a Box-Cox normality plot, optionally show it. 


#scipy.stats.ppcc_max(x, brack=(0.0, 1.0), dist='tukeylambda')[source]
#The probability plot correlation coefficient (PPCC) plot can be used 
#to determine the optimal shape parameter for a one-parameter family 
#of distributions. 
#ppcc_max returns the shape parameter that would maximize 
#the probability plot correlation coefficient for the given data to a one-parameter family of distributions.

dist : str or stats.distributions instance, optional
    Distribution or distribution function name
    The default is 'tukeylambda'
Returns:
    shape_value : float
 

from scipy import stats
x = stats.tukeylambda.rvs(-0.7, loc=2, scale=0.5, size=10000,
                         random_state=1234567) + 1e4
import matplotlib.pyplot as plt
fig = plt.figure(figsize=(8, 6))
ax = fig.add_subplot(111)
res = stats.ppcc_plot(x, -5, 5, plot=ax)
#The line should coincide with the highest point in the ppcc_plot.
max = stats.ppcc_max(x)
ax.vlines(max, 0, 1, colors='r', label='Expected shape value')
plt.show()














































###Statsmodel -  QuickIntro in general steps 
#requires patsy 
•Linear regression models
•Generalized linear models
•Discrete choice models
•Robust linear models
•Many models and functions for time series analysis
•Nonparametric estimators
•Input-output tools for producing tables in a number of formats (Text, LaTex, HTML) 
and for reading Stata files into NumPy and Pandas.
•Plotting functions

##The statistical model is assumed to be
Y = X*beta + mu, where mu ~ N(0,SIGMA)

#Depending on the properties of SIGMA, four classes available:
•GLS : generalized least squares for arbitrary covariance SIGMA
•OLS : ordinary least squares for i.i.d. errors SIGMA = I
•WLS : weighted least squares for heteroskedastic errors in diag(SIGMA)
•GLSAR : feasible generalized least squares with autocorrelated AR(p) errors SIGMA=SIGMA(p)

#All regression models define the same methods and follow the same structure, 
#and can be used in a similar fashion. 
#Some of them contain additional model specific methods and attributes.

#GLS is the superclass of the other regression classes except for RecursiveLS.

##LinearRegression
    elasticNetParam corresponds to L1/L2 ratio, alpha 
    regParam corresponds to regularization parameter (called lambda),  
        controls the overall strength of the penalty
    elasticParam in range [0, 1]. 
        For elasticParam = 0, the penalty is an L2 penalty(ridge). 
        For elasticParam = 1, it is an L1 penalty(lasso)
    the larger the value of lambda, alpha , 
        the greater the amount of shrinkage 
        and thus the coefficients become more robust to collinearity(features are corelated)
        but coefficients become sparse 
        
##GeneralizedLinearRegression
    #Family     Response Type       Links(* default/canonical)
    Gaussian    Continuous          Identity*, Log, Inverse 
    Binomial    Binary              Logit*, Probit, CLogLog 
    Poisson     Count               Log*, Identity, Sqrt 
    Gamma       Continuous          Inverse*, Idenity, Log 

#Note it is Different than General Linear Model 
#The general linear model or multivariate(more than one y) regression model is a statistical linear model. 
#It may be written as
Y  = X*B  + U  ,   
#where Y is a matrix with series of multivariate measurements (each column being a set of measurements on one of the dependent variables), 
#X is a matrix of observations on independent variables (each column being a set of observations on one of the independent variables), 
#B is a matrix containing parameters that are usually to be estimated and U is a matrix containing errors (noise). The errors are usually assumed to be uncorrelated across measurements, and follow a multivariate normal distribution. If the errors do not follow a multivariate normal distribution, generalized linear models may be used to relax assumptions about Y and U.


#The generalized linear model (GLM) is a generalization of ordinary linear regression 
#that allows for response variables that have error distribution models other than a normal distribution

#In a generalized linear model (GLM), each outcome Y of the dependent variables is assumed to be generated 
#from a particular distribution in the exponential family, that includes the normal, binomial, Poisson and gamma distributions, among others. 
#The mean, mu, of the distribution depends on the independent variables, X, through:
E ⁡ (Y) = mu  = g^(-1)(X*beta)  
#where E(Y) is the expected value of Y; X*beta is the linear predictor, 
#a linear combination of unknown parameters beta; g is the link function.

#the variance is typically a function, V, of the mean:
Var ⁡ (Y ) = V ⁡ (mu) = V ⁡ (g^(-1)(X*beta)) 
#The unknown parameters, beta, are typically estimated with maximum likelihood,

#The GLM consists of three elements:
1. A probability distribution from the exponential family.
2. A linear predictor  X*beta like OLS
3. A link function g such that E(Y) = mu = g^(-1)(X*beta) 

##Link function
#The link function provides the relationship between the linear predictor and the mean of the distribution function. There are many commonly used link functions, 
#There is always a well-defined canonical link function which is derived from the exponential of the response's density function

#Distribution   Support of distribution     Link name           Link function, X*beta=g(mu)     Mean function       Typical uses
Normal          real:(-Inf, +Inf)           Identity            X*beta = mu, ie g(mu)=mu        mu=X*beta           Linear-response data
Exponential     real:(0, +Inf)              Negative inverse    g(mu) = -mu^(-1)                mu=(X*beta)^(-1)    Exponential-response data, scale parameters
Gamma           real:(0, +Inf)              Negative inverse    g(mu) = -mu^(-1)                mu=(X*beta)^(-1)    Exponential-response data, scale parameters
InverseGaussian real:(0, +Inf)              Inverse squared     g(mu) = mu^(-2)                 mu=(X*beta)^(-1/2)
Poisson         integer: 0,1,2,..           Log                 g(mu)=ln(mu)                    mu=exp(X*beta)        count of occurrences in fixed amount of time/space  
Bernoulli       integer:{0,1}               Logit               g(mu)=ln(mu/(1-mu))             mu=1/(1+exp(-X*beta)) outcome of single yes/no occurrence                
Binomial        integer: 0,1,2,..           Logit               g(mu)=ln(mu/(1-mu))             mu=1/(1+exp(-X*beta)) count of # of "yes" occurrences out of N yes/no occurrences 
Categorical     integer: [0,K )             Logit               g(mu)=ln(mu/(1-mu))             mu=1/(1+exp(-X*beta)) outcome of single K-way occurrence 
Categorical     K-vector of integer:[0,1],  Logit               g(mu)=ln(mu/(1-mu))             mu=1/(1+exp(-X*beta)) outcome of single K-way occurrence 
                where exactly one element 
                in the vector has 
                the value 1 
Multinomial     K-vector of integer:[0,N]   Logit               g(mu)=ln(mu/(1-mu))             mu=1/(1+exp(-X*beta)) count of occurrences of different types (1 .. K) out of N total K-way occurrences 
                


##Asumptions of GLM 
Correlated or clustered data
    The standard GLM assumes that the observations are uncorrelated. 
    Extensions have been developed to allow for correlation between observations, 
    1. Generalized estimating equations (GEEs) allow for the correlation between observations without the use 
       of an explicit probability model for the origin of the correlations, so there is no explicit likelihood
    2.Generalized linear mixed models (GLMMs) are an extension to GLMs that includes random effects in the 
      linear predictor, giving an explicit probability model that explains the origin of the correlations



##Import 
import statsmodels.api as sm           #General imports 
import statsmodels.formula.api as smf  #for formula support in various regression 

>>> dir(sm)
>>> dir(smf)

#Note 'smf' contains Capital letters class(eg GLS) and small letters method
#Capital letter class is a Model based on data.exog, data.endog 
#small letter is defined as CLASS_NAME.from_formula(..) 
#which is formula based Model 

#eg, in statsmodels.formula.api.py
from statsmodels.regression.linear_model import GLS
gls = GLS.from_formula




##General Steps in using statsmodel 

import statsmodels.api as sm
import statsmodels.formula.api as smf

#load ur data or use exmaples from dataset 
data = sm.datasets.longley.load()  #data.data is full data (np.recarray)
#or load as pandas DF 
data = sm.datasets.longley.load_pandas()  #data.data is pandas DF 
#data.exog is x ie independent variable 
#data.endog is y ie dependent variable 
>>> data.exog_name  #features name 
['GNPDEFL', 'GNP', 'UNEMP', 'ARMED', 'POP', 'YEAR']
>>> data.endog_name #dependent/response variable 
'TOTEMP'
>>> data.data  #numpy recarray data 
X = data.exog
y = data.endog

#or directly with pandas 
df = pd.read_csv('http://vincentarelbundock.github.io/Rdatasets/csv/datasets/longley.csv', index_col=0)
#or with stats model tools 
#check package names , https://vincentarelbundock.github.io/Rdatasets/datasets.html
df = sm.datasets.get_rdataset("longley", package='datasets', cache=True).data

#findout X and Y 
>>> df.columns
Index(['GNP.deflator', 'GNP', 'Unemployed', 'Armed.Forces', 'Population',
       'Year', 'Employed'],
      dtype='object')
X = df[ ['GNP.deflator', 'GNP', 'Unemployed', 'Armed.Forces', 'Population', 'Year']  ].dropna()
y = df['TOTEMP']

#In statsmodel, many Model  do not include intercept by default. 
#User is expected to manually add one if required by using add_constant
#add_constant: returns original values with a constant (column of ones) as the first column
X = sm.add_constant(X)
#instantiate some model 
model = sm.MODEL_CLASS(y,X)

#formula is based on endog_name ~ combination of exog_name 
model = smf.MODEL_CLASS("formula", data.data)

#or with pandas , Note "formula" automatically includes intercept term 
#formula is based on df.columns 
model = smf.MODEL_CLASS("formula", data = df) #Note data:E.g., a numpy structured or rec array, a dictionary, or a pandas DataFrame.

#fit 
results = model.fit()

#resullts contain many important stats 
dir(results)
results.params  #for params 

#Check regression diagnostics, - http://www.statsmodels.org/dev/diagnostic.html
#Heteroscedasticity, Autocorrelation,Non-Linearity ,Mutlicollinearity
#Normality, Outlier and Influence 

#get summary . Note the P-value<0.05 are significant ie CI does not cross zero
print(results.summary())

#given x , find y 
predicted_endog = model.predict(exog)

#Quick measurement of performance
#Split the data into train and test(use sklearn) and check with Test(true_endog)
#Continuous :statsmodels.tools.eval_measures
mse = statsmodels.tools.eval_measures.mse(predicted_endog, true_endog)

#Discreet: Quick measurement of performance 
#(there is no direct method), note result has .pred_table() but with only train data
np.mean(predicted_endog == true_endog)
#or crosstab 
pd.crosstab(predicted_endog ,true_endog,predicted_endog==true_endog,rownames=['predicted'], colnames=['true'],aggfunc=np.sum,, margins=False, normalize=False)# normalize: boolean, {'all', 'index', 'columns'},  for normalizing output 
#or 
import numpy as np
pred = np.array(mod_fit.predict(test_X) > threshold, dtype=float)
table = np.histogram2d(test_Y, pred, bins=2)[0] 



##RegressionResults generally has below attributes 
aic             Akaike's information criteria, small the better 
bic             Bayes' information criteria, small the better 
fvalue          F-statistic of the fully specified model
f_pvalue        p-value of the F-statistic, <0.05, model is significant 
fittedvalues    The predicted the values for the original 
mse_model       Mean squared error the model
mse_resid       Mean squared error of the residuals
mse_total       Total mean squared error
params          Model Parameters 
pvalues         The two-tailed p values for  params., <0.05, those params are significants 
resid           The residuals of the model.
rsquared        R-squared of a model with an intercept, near 1 is better 
rsquared_adj    Adjusted R-squared.  near 1 is better 


##Models generally have below attributes and methods 
df_model            The model degree of freedom, 
                    defined as the rank of the regressor matrix minus 1 if a constant is included. 
df_resid            The residual degree of freedom, 
                    defined as the number of observations minus the rank of the regressor matrix. 
endog_names         Names of endogenous variables 
exog_names          Names of exogenous variables 

#Important methods 
fit([method, cov_type, cov_kwds, use_t])            
    Full fit of the model. 
    Returns RegressionResults or it's subclss eg OLSResults,QuantRegResults,RecursiveLSResults 
fit_regularized([method, alpha, L1_wt, ...])        
    Return a regularized fit to a linear regression model. 
    Use this for overfitting problem.
    To know overfitting, split data into test/train(use sklearn) and check on test. 
    method : string
        Only the 'elastic_net' approach is currently implemented.
    alpha : scalar or array-like
        The penalty weight. 
        If a scalar, the same penalty weight applies to all variables in the model. 
        If a vector, it must have the same length as params, 
        and contains a penalty weight for each coefficient.
    L1_wt: scalar
        The fraction of the penalty given to the L1 penalty term. 
        Must be between 0 and 1 (inclusive). 
        If 0, the fit is a ridge fit, if 1 it is a lasso fit
from_formula(formula, data[, subset, drop_cols])    
    Create a Model from a formula and dataframe. 
get_distribution(params, scale[, exog, ...])        
    Returns a random number generator for the predictive distribution. 
predict(params[, exog])                             
    Return linear predicted values from a design matrix. 
whiten(X)                                           
    Whiten a series of columns 




###Statsmodel -  QuickIntro - with/without formula OLS  and Regression test
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
# Load data
dat = sm.datasets.get_rdataset("Guerry", "HistData").data
# Fit regression model (using the natural log of one of the regressors)
results = smf.ols('Lottery ~ Literacy + np.log(Pop1831)', data=dat).fit()
# Inspect the results
>>> print(results.summary())
                            OLS Regression Results                            
==============================================================================
Dep. Variable:                Lottery   R-squared:                       0.348
Model:                            OLS   Adj. R-squared:                  0.333
Method:                 Least Squares   F-statistic:                     22.20
Date:                Tue, 28 Feb 2017   Prob (F-statistic):           1.90e-08
Time:                        21:38:05   Log-Likelihood:                -379.82
No. Observations:                  86   AIC:                             765.6
Df Residuals:                      83   BIC:                             773.0
Df Model:                           2                                         
Covariance Type:            nonrobust                                         
===================================================================================
                      coef    std err          t      P>|t|      [0.025      0.975]
-----------------------------------------------------------------------------------
Intercept         246.4341     35.233      6.995      0.000     176.358     316.510
Literacy           -0.4889      0.128     -3.832      0.000      -0.743      -0.235
np.log(Pop1831)   -31.3114      5.977     -5.239      0.000     -43.199     -19.424
==============================================================================
Omnibus:                        3.713   Durbin-Watson:                   2.019
Prob(Omnibus):                  0.156   Jarque-Bera (JB):                3.394
Skew:                          -0.487   Prob(JB):                        0.183
Kurtosis:                       3.003   Cond. No.                         702.
==============================================================================
#Understanding 
Coef 
    the estimates of  mean values of the coefficients  
    
coefficientStandardErrors            
    = estimate of  standard deviation of parameter estimate    
    If GeneralizedLinearRegression.fitIntercept is set to True, 
    then the last element returned corresponds to the intercep
[....]              
    95% CI        
   =  mean +/- 2* std err ie sd  
   = coef  +/-  2* coefficientStandardErrors
   
rank
    The numeric rank of the fitted linear model.
    the number of linearly-independent columns in the model matrix
    Should be equal to no of predicator variables, if less, then some features are dependent 
    A condition known as  multicollinearity in the predictor variables
    multicollinearity means having two or more perfectly correlated predictor variables 
    
residuals(residualsType='deviance')
    Get the residuals of the fitted model by type.
    that is response minus fitted values for response type 
    Supported options: deviance (default), pearson, working, and response
    
Df Total            
    These are the degrees of freedom associated with the sources of variance
    ie no of observation 
Df Model            
    No of independent variables (excluding intercept), more the better
residualDegreeOfFreedom, Df Residuals        
    Df total - Df Model 
residualDegreeOfFreedomNull
    The residual degrees of freedom for the null model.

R-squared           
     How model fits the data? Towards 1 is better 
     x= independent variable 
     y = dependent variable 
     y^ = predicted y for each y 
     Ey = mean of y 
     1.SSR is the "regression sum of squares" 
         =Sum(y^ - Ey)**2 for i=1..n
     2.SSE is the "error sum of squares" 
         =Sum(y - y^)**2 for i=1..n
     3.SSTO is the "total sum of squares" 
       . =Sum(y - Ey)^2  for i=1..n
     #interpretation
     r2 = SSR/SSTO=1-SSE/SSTO
     "r2 ×100 percent of the variation in y is reduced by taking into account predictor x
     or:
     "r2 ×100 percent of the variation in y is 'explained by' the variation in predictor x."
Adj. R-squared      
    adjusts for the number of terms in a model. 
    If you add more and more useless variables to a model, 
    adjusted r-squared will decrease. 
    If you add more useful variables, adjusted r-squared will increase
                    
Prob (F-statistic)  
    <0.05, model is significant 
AIC, BIC            
    Akaike’s “An Information Criterion”(AIC) for the fitted model
    lower the better. Used for comparing two models 
    Note  one model needs to be a subset of the other
    
Log-Likelihood   
    Value where model iteration is stopped, This is maximised 
    maximum likelihood estimation (MLE) attempts to find the parameter values(theta) that maximize 
    the log of likelihood function, given the observation
    likelihood function, check https://www.statlect.com/glossary/log-likelihood
    When the joint probability mass (or density) function is considered as a function of theta 
    for fixed xi (i.e., for the sample xi  we have observed), it is called likelihood (or likelihood function) 
    and it is denoted by L(theta;xi) eg for Normal distribution, pdf, hence likelihood function  is given as 
        f(xi; mu, var ) = (2*Pi*var)^(-1/2)*exp(-0.5*(xi-mu)^2/var)
     Then for all observations, the joint probability density is when theta=[mu, var]
            F(all xi; theta) = PRODUCT(f(xi; mu, var )), xi=1,2,...
     because the joint density of a set of independent variables is equal to the product of their marginal densities
     Hence 
     L(theta;xi) = F(all xi; theta) 
     or 
     ln(L(theta;xi)) = ln( F(all xi; theta) ) 
                     = ln (PRODUCT(f(xi; mu, var )))
                     =-n/2(Pi)-n/2(var)-1/(2*var)*SUM((xi-mu)^2 for i =1,2,3 
                      
    
    
t   , tValues                
    These are the t-statistics used in testing 
    Dividing the coefficient by its standard error calculates a t-value
    If GeneralizedLinearRegression.fitIntercept is set to True, 
    then the last element returned corresponds to the intercept.    
P>|t|   , pValues             
    < 0.05, coefficient is significant , H0= coefficinet is zero 
    If GeneralizedLinearRegression.fitIntercept is set to True, 
    then the last element returned corresponds to the intercept.

       
Omnibus test  
    The omnibus test is an overall test that examines model fit, 
    thus failure to reject the null hypothesis implies 
    that the suggested linear model is not significally suitable to the data 
    H0: Model does not fit well 
    Prob < 0.05, means H0 is rejected 

Jarque-Bera     
    a goodness-of-fit test with normal distribution (normality test of data)
    HO: sample data have the skewness and kurtosis matching a normal distribution
    Samples from a normal distribution have an expected skewness of 0 and an expected  kurtosis of 3
    Prob < 0.05, reject H0 
                
Durbin-Watson   
    The Durbin Watson Test is a measure of autocorrelation (also called serial correlation) 
    in residuals from regression analysis. 
    Autocorrelation is the similarity of a time series over successive time intervals. 
    It can lead to underestimates of the standard error 
    and can cause you to think predictors are significant when they are not
    The Durbin Watson test reports a test statistic, with a value from 0 to 4, where:
        •2 is no autocorrelation.
        •0 to <2 is positive autocorrelation (common in time series data).
        •>2 to 4 is negative autocorrelation (less common in time series data).

Condition no    
    This is used to measure how sensitive a Model is to changes or errors in the input,
    lower the better , very very large is worrysome as system becomes unstable(use regularization, then )

dispersion
    The dispersion of the fitted model. 
    It is taken as 1.0 for the “binomial” and “poisson” families, 
    and otherwise estimated by the residual Pearson’s Chi-Squared statistic 
    (which is defined as sum of the squares of the Pearson residuals) divided by the residual degrees of freedom
    For normal distribution , it is actually variance 
    
explainedVariance
    Returns the explained variance regression score. explainedVariance = 1 - variance(y - hat{y}) / variance(y)
    Measures the proportion to which a mathematical model accounts for the variation (dispersion) 
    of a given data set(1 : the best)
    The complementary part of the total variation is called unexplained or residual variation
    
nullDeviance
    The deviance for the null model.
    the null model is all the regression parameters are 0 
    best estimate/predictor of a new observation is the average of the response variable 
    Deviance for NullModel is used for comparing with deviance of full Model 
    nullDeviance should higher than 'deviance'
    
deviance
    The deviance for the fitted model. (lower the better)
    Measurement of Goodness-of-fit statistic for a statistical model      
    The deviance is used to compare two models
    •The Deviance Statistic is used to test the hypothesis that additional model predictors 
     do not improve the fit of the model. 
     The null hypothesis is that the coefficients of the additional predictors are 0.
    •To use the Deviance Statistic, one model must be nested in the other. 
     That is, the smaller model can be derived from the bigger model by setting certain coefficients 
     in the bigger model equal to 0.
    •Deviance = -2 * (Log Likelihood (LL) of model)
    •Deviance Statistic = -2 * (LL of model nested in bigger model – LL of bigger model)
    •Smaller Deviance is better
    •The distribution of the deviance statistic is chi-square with DF equal to the number of extra parameters in the bigger model.
    •Deviance obtained under Restricted Maximum Likelihood (REML) should only be used if the two models compared have the same fixed effects and differ only in their random effects. If this is not the case, the deviance obtained using Full ML should be used instead
    • If the deviance of the bigger model is smaller than the deviance of the nested model. 
       Is the reduction in deviance significant? 
       To carry out the test,
       dev = deviance of the smaller nested model - the deviance of the bigger model. 
       The difference is then compared to a chi-square distribution for significance. 
       For example, compare the difference to a chi-square distribution with 2 degrees of freedom 
       since the bigger model has two extra coefficients. 
         1 - pchisq(dev,2)
        Ans = 0.0004509163, <0.5, rejet H0 , H0= additional model predictors  do not improve the fit of the model
           
##Understanding 
1.low R-square and low p-value (p-value <= 0.05)
    This means that the model doesn't explain much of the variation in the response variable, 
    but still this is considered better than having no model to explain the response variable 
    as it is significant as per the p-value.
2.low R-square and high p-value (p-value > 0.05)
    This means that model doesn't explain much variation in the data and is not significant. 
    We should discard such model as this is the worst scenario.
3.high R-square and low p-value
    This means that model explains a lot of variation in the data and is also significant. 
    This scenario is best of the four and the model is considered to be good in this case.
4.high R-square and high p-value
    This means that variance in the data is explained by the model but it is not significant. 
    We should not use such model for predictions.
  
##Assumptions of LM 
Weak exogeneity. 
    This essentially means that the predictor variables x can be treated as fixed values, rather than random variables. 
    This means, for example, that the predictor variables are assumed to be error-free—
     Although this assumption is not realistic in many settings, dropping it leads to significantly 
     more difficult errors-in-variables models.
Linearity. 
    This means that the mean of the response variable is a linear combination of the parameters (regression coefficients) 
    and the predictor variables
    Because the predictor variables are treated as fixed values , linearity is really only a restriction on the parameters. 
    The predictor variables themselves can be arbitrarily transformed,  and in fact multiple copies 
    of the same underlying predictor variable can be added,  each one transformed differently, 
    for example, in polynomial regression, which uses linear regression to fit the response variable 
    as an arbitrary polynomial function (up to a given degree) of a predictor variable. 
    Hence they tend to overfit the data. 
    As a result, some kind of regularization must typically be used to prevent unreasonable solutions 
    Common examples are ridge regression and lasso regression.  
Constant variance (a.k.a. homoscedasticity). 
    This means that different values of the response variable have the same variance in their errors, 
    regardless of the values of the predictor variables. 
    When absolute or squared residuals when plotted against the predictive variables,
    Errors will not be evenly distributed across the regression line. 
    Various estimation techniques (e.g. weighted least squares and heteroscedasticity-consistent standard errors)
    can handle heteroscedasticity in a quite general way.
    In Spark, Currently Iiteratively reweighted least squares (IRLS) is used as the default solver of GeneralizedLinearRegression.
    it also requires the number of features to be no more than 4096. 
Independence of errors. 
    This assumes that the errors of the response variables are uncorrelated with each other. 
    Some methods (e.g. generalized least squares) are capable of handling correlated errors, 
    although they typically require significantly more data 
    unless some sort of regularization is used to bias the model towards assuming uncorrelated errors.
No multicollinearity in the predictors. 
    For standard least squares estimation methods, 
    the design matrix X must have full column rank p; otherwise, we have a condition known as multicollinearity in the predictor variables. 
    This can be triggered by having two or more perfectly correlated predictor variables 


                
                
##Normality of the residuals
#Jarque-Bera test:
name = ['Jarque-Bera', 'Chi^2 two-tail prob.', 'Skew', 'Kurtosis']
test = sms.jarque_bera(results.resid)
>>> lzip(name, test)
[('Jarque-Bera', 3.3936080248431706),
 ('Chi^2 two-tail prob.', 0.18326831231663335),
 ('Skew', -0.486580343112234),
 ('Kurtosis', 3.003417757881633)]

#Omni test:
name = ['Chi^2', 'Two-tail probability']
test = sms.omni_normtest(results.resid)
>>> lzip(name, test)
[('Chi^2', 3.7134378115971831), ('Two-tail probability', 0.15618424580304813)]



##Influence tests
#OLSInfluence holds attributes and methods that allow users 
#to assess the influence of each observation. 
#For example, we can compute and extract the first few rows of DFbetas by:
from statsmodels.stats.outliers_influence import OLSInfluence
test_class = OLSInfluence(results)
import math 
2/math.sqrt(86)
0.21566554640687682
print(test_class.dfbetas[:5,:] ) #> 2/sqrt(N) outliers
print("outliers is values > 2/sqrt(N) ie >",2/math.sqrt(86))

where = test_class.dfbetas > 2/math.sqrt(86)
print("find index labels where that satisfies")
print(test_class.dfbetas.index[where])
print("then drop those if required ")
new_dat = dat.drop(index=test_class.dfbetas.index[~where], inplace=False)

#Explore other options by typing 
>>> dir(influence_test)

#Useful information on leverage can also be plotted:
#leverage is a measure of how far away the independent variable values 
#of an observation are from those of the other observations.
from statsmodels.graphics.regressionplots import plot_leverage_resid2
fig, ax = plt.subplots(figsize=(8,6))
fig = plot_leverage_resid2(results, ax = ax)


##Multicollinearity- Condition number:
#multicollinearity (also collinearity) : one predictor variable in a multiple regression model 
#can be linearly predicted from the others - which is bad 
>>> np.linalg.cond(results.model.exog)
702.17921454900659

##Autocorrelation Tests
#H0: the errors are uncorrelated between observations
#durbin_watson from summary() 
#or ,Ljung-Box test also the Box-Pierce test results are returned
ljung_test_stats, its_p_value, pierce_test_stats, its_p_value = sms.acorr_ljungbox(results.resid, boxpierce=True)
#or Breusch Godfrey Lagrange Multiplier tests for residual autocorrelation
lagrange_test_stats, its_p_value, f_test_stats, its_p_value = sms.acorr_breusch_godfrey(results)


##Heteroskedasticity tests
#Ho:error term has the same variance  in each observation
#Breush-Pagan test:
name = ['Lagrange multiplier statistic', 'p-value', 
        'f-value', 'f p-value']
test = sms.het_breushpagan(results.resid, results.model.exog)
>>> lzip(name, test)
[('Lagrange multiplier statistic', 4.8932133740940333),
 ('p-value', 0.086586905023518804),
 ('f-value', 2.5037159462564778),
 ('f p-value', 0.087940287826726846)]

#Goldfeld-Quandt test
name = ['F statistic', 'p-value']
test = sms.het_goldfeldquandt(results.resid, results.model.exog)
>>> lzip(name, test)
[('F statistic', 1.1002422436378141), ('p-value', 0.38202950686925286)]

##Linearity
#H0:  the linear specification is correct:
name = ['t value', 'p value']
test = sms.linear_harvey_collier(results)
>>> lzip(name, test)
[('t value', -1.0796490077784473), ('p value', 0.28346392475582971)]







###Statsmodel-QuickIntro - sm.OLS, smf.ols -  ordinary least squares model
#also called lm 
#Simple linear regression model
1. Objective: model the expected value of a continuous variable, Y, as a linear function of the continuous predictor, X, E(Yi) = β0 + β1xi 
2. Model structure: Yi = β0 + β1xi +  ei 
3. Model assumptions: Y is is normally distributed, 
   errors are normally distributed, ei ~ N(0, σ^2), and independent, 
   and X is fixed, and constant variance σ^2. 
4. Model fit: R 2, residual analysis, F-statistic

#important methods 
    •linreg.summary()          # summary of the model
    •linreg.fittedvalues       # fitted value from the model
    •linreg.predict()          # predict
    •linreg.rsquared_adj       # adjusted r-square
#Example 
import numpy as np
import statsmodels.api as sm
Y = [1,3,4,5,2,3,4]
X = range(1,8)
X = sm.add_constant(X)
model = sm.OLS(Y,X)
results = model.fit()
>>> results.params
array([ 2.14285714,  0.25      ])

#H0: coeffcients of intercept and one independent variable are unequal 
>>> print(results.t_test([1, 0]))
<T test: effect=array([ 2.14285714]), sd=array([[ 1.14062282]]), t=array([[ 1.87867287]]), p=array([[ 0.05953974]]), df_denom=5>

#H0: intercept and one independent variable is independent 
>>> print(results.f_test(np.identity(2)))
<F test: F=array([[ 19.46078431]]), p=[[ 0.00437251]], df_denom=5, df_num=2>


#With formula 
df = sm.datasets.get_rdataset("Guerry", "HistData").data
df = df[['Lottery', 'Literacy', 'Wealth', 'Region']].dropna()
df.head()
#C() means Categorical 
res = smf.ols(formula='Lottery ~ Literacy + Wealth + C(Region) -1 ', data=df).fit()
print(res.params)
#':' is interaction , a*b = a+b+a:b , -1 means exclude intercept term 
res1 = smf.ols(formula='Lottery ~ Literacy : Wealth - 1', data=df).fit()
res2 = smf.ols(formula='Lottery ~ Literacy * Wealth - 1', data=df).fit()
print(res1.params, res2.params)



##Example - OLS can have non-linear curve but linear in parameters
#because
#y = a*f1(x) + b*f2(x)  +... + e
#OLS is applicable as long as a, b, c ... are linear (ie there is no a*b or a^2 etc)
#f1(x), f2(x) could be non linear
##OLS - Without formula 
%matplotlib inline
from __future__ import print_function
import numpy as np
import statsmodels.api as sm
nsample = 50
sig = 0.25
x1 = np.linspace(0, 20, nsample)
#Take a sequence of 1-D arrays and stack them as columns to make a single 2-D array
X = np.column_stack((x1, np.sin(x1), (x1-5)**2))
X = sm.add_constant(X)

beta = [5., 0.5, 0.5, -0.02] #actual coffiecients 
y_true = np.dot(X, beta)
y = y_true + sig * np.random.normal(size=nsample) #error term 

olsmod = sm.OLS(y, X)
olsres = olsmod.fit()
>>> print(olsres.summary())
                            OLS Regression Results                            
==============================================================================
Dep. Variable:                      y   R-squared:                       0.975
Model:                            OLS   Adj. R-squared:                  0.973
Method:                 Least Squares   F-statistic:                     600.0
Date:                Tue, 28 Feb 2017   Prob (F-statistic):           7.17e-37
Time:                        21:33:42   Log-Likelihood:                -9.5061
No. Observations:                  50   AIC:                             27.01
Df Residuals:                      46   BIC:                             34.66
Df Model:                           3                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
const          5.0395      0.104     48.462      0.000       4.830       5.249
x1             0.4963      0.016     30.946      0.000       0.464       0.529
x2             0.5288      0.063      8.388      0.000       0.402       0.656
x3            -0.0199      0.001    -14.100      0.000      -0.023      -0.017
==============================================================================
Omnibus:                        0.820   Durbin-Watson:                   2.161
Prob(Omnibus):                  0.664   Jarque-Bera (JB):                0.796
Skew:                           0.038   Prob(JB):                        0.672
Kurtosis:                       2.387   Cond. No.                         221.
==============================================================================
#In-sample prediction
ypred = olsres.predict(X)
print(ypred)
#predict out of sample
x1n = np.linspace(20.5,25, 10)
#Take a sequence of 1-D arrays and stack them as columns to make a single 2-D array
Xnew = np.column_stack((x1n, np.sin(x1n), (x1n-5)**2)) 
Xnew = sm.add_constant(Xnew)

ynewpred =  olsres.predict(Xnew) # predict out of sample
print(ynewpred)

#Plot comparison
import matplotlib.pyplot as plt
fig, ax = plt.subplots()
ax.plot(x1, y, 'o', label="Data")
ax.plot(x1, y_true, 'b-', label="True")
#hstack - appending a,b 
ax.plot(np.hstack((x1, x1n)), np.hstack((ypred, ynewpred)), 'r', label="OLS prediction")
ax.legend(loc="best");

##Predicting with Formulas
from statsmodels.formula.api import ols
data = {"x1" : x1, "y" : y}
#use the I to indicate use of the Identity transform. 
#Ie., we don't want any expansion magic from using **2
res = ols("y ~ x1 + np.sin(x1) + I((x1-5)**2)", data=data).fit()

>>> res.params
Intercept           5.039514
x1                  0.496312
np.sin(x1)          0.528829
I((x1 - 5) ** 2)   -0.019855
dtype: float64
>>> res.predict(exog=dict(x1=x1n))
0    10.970907
1    10.821642
2    10.554124
3    10.215613
4     9.868320
5     9.574176
6     9.379671
7     9.304465
8     9.336582
9     9.435338
dtype: float64

 



###Statsmodel-QuickIntro - sm.GLM, smf.glm - Generalized Linear Models

1.Linear regression assumes that the response variable is normally distributed. 
  Generalized linear models can have response variables with distributions 
  other than the Normal distribution– they may even be categorical rather than continuous.
2.Relationship between the response and explanatory variables need not be 
  of the simple linear form.

#Imp methods 
    •linreg.summary()          # summary of the model
    •linreg.fittedvalues       # fitted value from the model
    •linreg.predict()          # predict
    •linreg.rsquared_adj       # adjusted r-square
    
#The distribution families (response variable distribution)
Family(link, variance)          The parent class for one-parameter exponential families. 
Binomial([link])                Binomial exponential family distribution. 
Gamma([link])                   Gamma exponential family distribution. 
Gaussian([link])                Gaussian exponential family distribution. 
InverseGaussian([link])         InverseGaussian exponential family. 
NegativeBinomial([link, alpha]) Negative Binomial exponential family. 
Poisson([link])                 Poisson exponential family. 
#Each family has few link functions 
#link function is transformation of response variable 
#such that transformed response variable is linked to independent variables linearly 

#Terminology
The variance function is a smooth function 
which depicts the variance of a random quantity as a function of its mean
A smooth function is a function that has derivatives 
of all orders everywhere in its domain

In parametric modeling, variance functions take on a parametric form 
and explicitly describe the relationship between the variance and the mean of a random quantity. 
In a non-parametric setting, the variance function is assumed 
to be a smooth function.

#Model                  Random              Link                Systematic 
Linear Regression       Normal              Identity            Continuous 
ANOVA                   Normal              Identity            Categorical 
ANCOVA                  Normal              Identity            Mixed 
Logistic Regression     Binomial            Logit               Mixed 
Loglinear               Poisson             Log                 Categorical 
Poisson Regression      Poisson             Log                 Mixed 
Multinomial response    Multinomial         Generalized Logit   Mixed 

#There are three components to any GLM:
1. Random Component – refers to the probability distribution of the response variable (Y); 
   e.g. normal distribution for Y in the linear regression, 
   or binomial distribution for Y in the binary logistic regression.  
   Also called a noise model or error model.  
   How is random error added to the prediction that comes out of the link function?
   Name of the family (such as binomial) specifies the conditional distribution 
   for example, for binomial it is  μ(1−μ)
2. Systematic Component - specifies the explanatory variables (X1, X2, ... Xk) 
   in the model, more specifically their linear combination in creating 
   the so called linear predictor; e.g., β0 + β1x1 + β2x2    
3. Link Function, η or g(μ) - specifies the link between random 
   and systematic components. 
   It says how the expected value of the response relates 
   to the linear predictor of explanatory variables; 
   e.g., η = g(E(Yi)) = E(Yi) for linear regression, 
   or  η = logit(π) for logistic regression.

#Assumptions:
1.The data Y1, Y2, ..., Yn are independently distributed, 
  i.e., cases are independent. 
2.The dependent variable Yi does NOT need to be normally distributed, 
  but it typically assumes a distribution from an exponential family 
  (e.g. binomial, Poisson, multinomial, normal,...) 
3.GLM does NOT assume a linear relationship between the dependent variable 
  and the independent variables, 
  but it does assume linear relationship between the transformed response 
  in terms of the link function and the explanatory variables; 
  e.g., for binary logistic regression logit(π) = β0 + βX. 
4.Independent (explanatory) variables can be even the power terms 
  or some other nonlinear transformations of the original independent variables. 
5.The homogeneity of variance does NOT need to be satisfied. 
  In fact, it is not even possible in many cases given the model structure, 
  and overdispersion (when the observed variance is larger than what the model assumes) 
  maybe present. 
6.Errors need to be independent but NOT normally distributed. 
7.It uses maximum likelihood estimation (MLE) 
  rather than ordinary least squares (OLS) to estimate the parameters, 
  and thus relies on large-sample approximations. 
8.Goodness-of-fit measures rely on sufficiently large samples, 
  where a heuristic rule is that not more than 20% of the expected cells counts 
  are less than 5. 

    
##Example 
import statsmodels.api as sm
data = sm.datasets.scotland.load()
data.exog = sm.add_constant(data.exog)
>>> dir(sm.families.family)
['Binomial', 'FLOAT_EPS', 'Family', 'Gamma', 'Gaussian', 'InverseGaussian', 'L',
 'NegativeBinomial', 'Poisson', 'Tweedie', 'V', '__builtins__', '__cached__', '_
_doc__', '__file__', '__loader__', '__name__', '__package__', '__spec__', 'np',
'special']
>>> sm.families.family.<familyname>.links
# Instantiate a gamma family model with the default link function.
gamma_model = sm.GLM(data.endog, data.exog, family=sm.families.Gamma())
gamma_results = gamma_model.fit()
>>> print(gamma_results.summary())
                 Generalized Linear Model Regression Results                  
==============================================================================
Dep. Variable:                      y   No. Observations:                   32
Model:                            GLM   Df Residuals:                       24
Model Family:                   Gamma   Df Model:                            7
Link Function:          inverse_power   Scale:                0.00358428317349
Method:                          IRLS   Log-Likelihood:                -83.017
Date:                Tue, 28 Feb 2017   Deviance:                     0.087389
Time:                        21:38:03   Pearson chi2:                   0.0860
No. Iterations:                     4                                         
==============================================================================
                 coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
const         -0.0178      0.011     -1.548      0.122      -0.040       0.005
x1          4.962e-05   1.62e-05      3.060      0.002    1.78e-05    8.14e-05
x2             0.0020      0.001      3.824      0.000       0.001       0.003
x3         -7.181e-05   2.71e-05     -2.648      0.008      -0.000   -1.87e-05
x4             0.0001   4.06e-05      2.757      0.006    3.23e-05       0.000
x5         -1.468e-07   1.24e-07     -1.187      0.235   -3.89e-07    9.56e-08
x6            -0.0005      0.000     -2.159      0.031      -0.001   -4.78e-05
x7         -2.427e-06   7.46e-07     -3.253      0.001   -3.89e-06   -9.65e-07
==============================================================================


##GLM -  with formula for logit regression 
from __future__ import print_function
import statsmodels.api as sm
import statsmodels.formula.api as smf
star98 = sm.datasets.star98.load_pandas().data
formula = 'SUCCESS ~ LOWINC + PERASIAN + PERBLACK + PERHISP + PCTCHRT + \
           PCTYRRND + PERMINTE*AVYRSEXP*AVSALK + PERSPENK*PTRATIO*PCTAF'
dta = star98[['NABOVE', 'NBELOW', 'LOWINC', 'PERASIAN', 'PERBLACK', 'PERHISP',
              'PCTCHRT', 'PCTYRRND', 'PERMINTE', 'AVYRSEXP', 'AVSALK',
              'PERSPENK', 'PTRATIO', 'PCTAF']].copy()
endog = dta['NABOVE'] / (dta['NABOVE'] + dta.pop('NBELOW'))
del dta['NABOVE']
dta['SUCCESS'] = endog
mod1 = smf.glm(formula=formula, data=dta, family=sm.families.Binomial()).fit()
mod1.summary()
#doubling LOWINC
def double_it(x):
    return 2 * x
formula = 'SUCCESS ~ double_it(LOWINC) + PERASIAN + PERBLACK + PERHISP + PCTCHRT + \
           PCTYRRND + PERMINTE*AVYRSEXP*AVSALK + PERSPENK*PTRATIO*PCTAF'
mod2 = smf.glm(formula=formula, data=dta, family=sm.families.Binomial()).fit()
mod2.summary()
>>> print(mod1.params[1])
>>> print(mod2.params[1] * 2)
-0.0203959871548
-0.0203959871548



 



##GLM -  Binomial response data 
#dependent variable is binary/categorical( logistic regression, or logit regression, or logit model)



#Check all variables of the data 
print(sm.datasets.star98.NOTE)


#Load data
data = sm.datasets.star98.load()
data.exog = sm.add_constant(data.exog, prepend=False)  #add a constant term , Note by default, statsmodels does not have intercept term included into model. Add it explicitly

#The dependent variable is N x 2 (Success: NABOVE, Failure: NBELOW):
print(data.endog[:5,:])
[[ 452.  355.] 
[ 144.   40.] 
[ 337.  234.] 
[ 395.  178.] 
[   8.   57.]]

#The independent variables include all the other variables 


#Fit 
glm_binom = sm.GLM(data.endog, data.exog, family=sm.families.Binomial())
res = glm_binom.fit()
print(res.summary())
                 
Generalized Linear Model Regression Results
==============================================================================
Dep. Variable:           ['y1', 'y2']   No. Observations:                  303
Model:                            GLM   Df Residuals:                      282
Model Family:                Binomial   Df Model:                           20
Link Function:                  logit   Scale:                             1.0
Method:                          IRLS   Log-Likelihood:                -2998.6
Date:                Mon, 17 Nov 2014   Deviance:                       4078.8
Time:                        13:07:02   Pearson chi2:                 4.05e+03
No. Iterations:                     7
==============================================================================                 
                 coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1            -0.0168      0.000    -38.749      0.000        -0.018    -0.016
x2             0.0099      0.001     16.505      0.000         0.009     0.011
x3            -0.0187      0.001    -25.182      0.000        -0.020    -0.017
x4            -0.0142      0.000    -32.818      0.000        -0.015    -0.013
x5             0.2545      0.030      8.498      0.000         0.196     0.313
x6             0.2407      0.057      4.212      0.000         0.129     0.353
x7             0.0804      0.014      5.775      0.000         0.053     0.108
x8            -1.9522      0.317     -6.162      0.000        -2.573    -1.331
x9            -0.3341      0.061     -5.453      0.000        -0.454    -0.214
x10           -0.1690      0.033     -5.169      0.000        -0.233    -0.105
x11            0.0049      0.001      3.921      0.000         0.002     0.007
x12           -0.0036      0.000    -15.878      0.000        -0.004    -0.003
x13           -0.0141      0.002     -7.391      0.000        -0.018    -0.010
x14           -0.0040      0.000     -8.450      0.000        -0.005    -0.003
x15           -0.0039      0.001     -4.059      0.000        -0.006    -0.002
x16            0.0917      0.015      6.321      0.000         0.063     0.120
x17            0.0490      0.007      6.574      0.000         0.034     0.064
x18            0.0080      0.001      5.362      0.000         0.005     0.011
x19            0.0002   2.99e-05      7.428      0.000         0.000     0.000
x20           -0.0022      0.000     -6.445      0.000        -0.003    -0.002
const          2.9589      1.547      1.913      0.056        -0.073     5.990
==============================================================================



#Quantities of interest
print('Total number of trials:',  data.endog[0].sum())
print('Parameters: ', res.params)
print('T-values: ', res.tvalues)

Total number of trials: 807.0
Parameters:  [-0.01681504  0.00992548 -0.01872421 -0.01423856  0.25448717  0.24069366  
0.08040867 -1.9521605  -0.33408647 -0.16902217  0.0049167  -0.00357996 
-0.01407656 -0.00400499 -0.0039064   0.0917143   0.04898984  0.00804074  
0.00022201 -0.00224925  2.95887793]
T-values:  [-38.74908321  16.50473627 -25.1821894  -32.81791308   8.49827113   
4.21247925   5.7749976   -6.16191078  -5.45321673  -5.16865445   
3.92119964 -15.87825999  -7.39093058  -8.44963886  -4.05916246   
6.3210987    6.57434662   5.36229044   7.42806363  -6.44513698   
1.91301155]



#It uses below methods 
#scipy.stats.scoreatpercentile(a, per )
#Calculate the score at a given percentile of the input sequence, a.
#For example, the score at per=50 is the median

#First differences: 
#We hold all explanatory variables constant at their means 
#and manipulate the percentage of low income households to assess its impact on the response variables:

means = data.exog.mean(axis=0) #DF's mean , axis =0 means each column's means 

means25 = means.copy()
means25[0] = stats.scoreatpercentile(data.exog[:,0], 25)
means75 = means.copy()
means75[0] = lowinc_75per = stats.scoreatpercentile(data.exog[:,0], 75)
resp_25 = res.predict(means25)
resp_75 = res.predict(means75)
diff = resp_75 - resp_25

#The interquartile first difference for the percentage of low income households 
print("%2.4f%%" % (diff*100))
-11.8753%


#Plots
nobs = res.nobs
y = data.endog[:,0]/data.endog.sum(1)  #axis=1
yhat = res.mu


from statsmodels.graphics.api import abline_plot
fig, ax = plt.subplots()
ax.scatter(yhat, y)
line_fit = sm.OLS(y, sm.add_constant(yhat, prepend=True)).fit()
abline_plot(model_results=line_fit, ax=ax)  #Plots a line given an intercept and slope.

ax.set_title('Model Fit Plot')
ax.set_ylabel('Observed values')
ax.set_xlabel('Fitted values');



#Plot yhat vs. Pearson residuals:
fig, ax = plt.subplots()
ax.scatter(yhat, res.resid_pearson)
ax.hlines(0, 0, 1)
ax.set_xlim(0, 1)
ax.set_title('Residual Dependence Plot')
ax.set_ylabel('Pearson Residuals')
ax.set_xlabel('Fitted values')


#Histogram of standardized deviance residuals:
from scipy import stats
fig, ax = plt.subplots()
resid = res.resid_deviance.copy()
resid_std = stats.zscore(resid)
ax.hist(resid_std, bins=25)
ax.set_title('Histogram of standardized deviance residuals');


#QQ Plot of Deviance Residuals:
from statsmodels import graphics
graphics.gofplots.qqplot(resid, line='r')  #Q-Q plot of the quantiles of x versus the quantiles/ppf of a distribution., by default, checks how data matches norm dist 





##GLM - Gamma for proportional count response

#check data
print(sm.datasets.scotland.DESCRLONG)
#Load 
data2 = sm.datasets.scotland.load()
data2.exog = sm.add_constant(data2.exog, prepend=False)
print(data2.exog[:5,:])  #x 
print(data2.endog[:5])   #y 
[[   712.      21.     105.      82.4  13566.      12.3  14952.       1. ] 
[   643.      26.5     97.      80.2  13566.      15.3  17039.5      1. ] 
[   679.      28.3    113.      86.3   9611.      13.9  19215.7      1. ] 
[   801.      27.1    109.      80.4   9483.      13.6  21707.1      1. ] 
[   753.      22.     115.      64.7   9265.      14.6  16566.       1. ]]
[ 60.3  52.3  53.4  57.   68.7]

#fit and summary 
glm_gamma = sm.GLM(data2.endog, data2.exog, family=sm.families.Gamma())
glm_results = glm_gamma.fit()
print(glm_results.summary())                 
Generalized Linear Model Regression Results
==============================================================================
Dep. Variable:                      y   No. Observations:                   32
Model:                            GLM   Df Residuals:                       24
Model Family:                   Gamma   Df Model:                            7
Link Function:          inverse_power   Scale:                0.00358428317349
Method:                          IRLS   Log-Likelihood:                -83.017
Date:                Mon, 17 Nov 2014   Deviance:                     0.087389
Time:                        13:07:07   Pearson chi2:                   0.0860
No. Iterations:                     6
==============================================================================                 
                coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1          4.962e-05   1.62e-05      3.060      0.002      1.78e-05  8.14e-05
x2             0.0020      0.001      3.824      0.000         0.001     0.003
x3         -7.181e-05   2.71e-05     -2.648      0.008        -0.000 -1.87e-05
x4             0.0001   4.06e-05      2.757      0.006      3.23e-05     0.000
x5         -1.468e-07   1.24e-07     -1.187      0.235     -3.89e-07  9.56e-08
x6            -0.0005      0.000     -2.159      0.031        -0.001 -4.78e-05
x7         -2.427e-06   7.46e-07     -3.253      0.001     -3.89e-06 -9.65e-07
const         -0.0178      0.011     -1.548      0.122        -0.040     0.005
==============================================================================






##GLM-  Gaussian distribution with a noncanonical link(link identity for OLS)

>>> sm.families.family.Gaussian.links
[<class 'statsmodels.genmod.families.links.log'>, 
<class 'statsmodels.genmod.families.links.identity'>, 
<class 'statsmodels.genmod.families.links.inverse_power'>]

#generate data 

nobs2 = 100
x = np.arange(nobs2)
np.random.seed(54321)
X = np.column_stack((x,x**2))
X = sm.add_constant(X, prepend=False)

#each response is transformed with exp(), hence use log as link function 
lny = np.exp(-(.03*x + .0001*x**2 - 1.0)) + .001 * np.random.rand(nobs2) 

#fit 
gauss_log = sm.GLM(lny, X, family=sm.families.Gaussian(sm.families.links.log))
gauss_log_results = gauss_log.fit()
print(gauss_log_results.summary())
                 
Generalized Linear Model Regression Results
==============================================================================
Dep. Variable:                      y   No. Observations:                  100
Model:                            GLM   Df Residuals:                       97
Model Family:                Gaussian   Df Model:                            2
Link Function:                    log   Scale:               1.05311425588e-07
Method:                          IRLS   Log-Likelihood:                 662.92
Date:                Mon, 17 Nov 2014   Deviance:                   1.0215e-05
Time:                        13:07:07   Pearson chi2:                 1.02e-05
No. Iterations:                     7
==============================================================================                 
coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1            -0.0300    5.6e-06  -5361.316      0.000        -0.030    -0.030
x2         -9.939e-05   1.05e-07   -951.091      0.000     -9.96e-05 -9.92e-05
const          1.0003   5.39e-05   1.86e+04      0.000         1.000     1.000
==============================================================================












###Statsmodel-QuickIntro - sm.GLS, smf.gls 
#Generalized least squares model with a general covariance structure.
#GLS can be used to perform linear regression 
#when there is a certain degree of correlation between the residuals in a regression model.


#Example 
import numpy as np
import statsmodels.api as sm
data = sm.datasets.longley.load()
data.exog = sm.add_constant(data.exog)
ols_resid = sm.OLS(data.endog, data.exog).fit().resid
res_fit = sm.OLS(ols_resid[1:], ols_resid[:-1]).fit()
>>> data.data.shape #16 observations 
(16,)
>>> ols_resid.shape #for each observations 
(16,)

rho = res_fit.params
#rho is a consistent estimator of the correlation of the residuals 
#from an OLS fit of the longley data. 
#It is assumed that this is the true rho of the AR process data.
from scipy.linalg import toeplitz
order = toeplitz(np.arange(16))
sigma = rho**order

#sigma is an n x n matrix of the autocorrelation structure of the data.
gls_model = sm.GLS(data.endog, data.exog, sigma=sigma)
gls_results = gls_model.fit()
print(gls_results.summary())




###Statsmodel-QuickIntro - sm.GLSAR, smf.glsar
#A regression model with an autoregressive , AR(p) covariance structure
#The autoregressive model specifies that the output variable depends linearly on its own previous values 
#when there is a AR(p) correlation between the residuals in a regression model.


#Example 
import statsmodels.api as sm
X = range(1,8)
X = sm.add_constant(X)  #X= intercepts, one_var 
Y = [1,3,4,5,8,10,9]
model = sm.GLSAR(Y, X, rho=2) #rho : Order(p) of the autoregressive covariance, AR coefficients
for i in range(6):
    results = model.fit()
    print("AR coefficients: {0}".format(model.rho))
    rho, sigma = sm.regression.yule_walker(results.resid,order=model.order) #Estimate AR(p) parameters from a sequence X using Yule-Walker equation.
    model = sm.GLSAR(Y, X, rho)
#Output 
AR coefficients: [ 0.  0.]
AR coefficients: [-0.52571491 -0.84496178]
AR coefficients: [-0.6104153  -0.86656458]
AR coefficients: [-0.60439494 -0.857867  ]
AR coefficients: [-0.6048218  -0.85846157]
AR coefficients: [-0.60479146 -0.85841922]
>>> results.params
array([-0.66661205,  1.60850853])
>>> results.tvalues
array([ -2.10304127,  21.8047269 ])

#H0:coeffcients of intercept and one independent variable are unequal 
>>> print(results.t_test([1, 0]))
<T test: effect=array([-0.66661205]), sd=array([[ 0.31697526]]), t=array([[-2.10304127]]), p=array([[ 0.06309969]]), df_denom=3>

#H0: intercept and one independent variable is independent 
>>> print(results.f_test(np.identity(2)))
<F test: F=array([[ 1815.23061844]]), p=[[ 0.00002372]], df_denom=3, df_num=2>

#Or, equivalently
model2 = sm.GLSAR(Y, X, rho=2)
res = model2.iterative_fit(maxiter=6)
>>> model2.rho
array([-0.60479146, -0.85841922])


   
###Statsmodel-QuickIntro - sm.WLS, smf.wls
#Weighted Least square 
#A regression model with diagonal but non-identity covariance structure
#A special case of generalized least squares 
#when all the off-diagonal entries of correlation matrix of the residuals) are null; 
#the variances of the observations (along the covariance matrix diagonal) may still be unequal (heteroscedasticity).


#Example 
%matplotlib inline
from __future__ import print_function
import numpy as np
from scipy import stats
import statsmodels.api as sm
import matplotlib.pyplot as plt
from statsmodels.sandbox.regression.predstd import wls_prediction_std
from statsmodels.iolib.table import (SimpleTable, default_txt_fmt)
np.random.seed(1024)

#Artificial data: Heteroscedasticity 2 groups
#Model assumptions:
#•Misspecification: true model is quadratic, estimate only linear
#•Independent noise/error term
#•Two groups for error variance, low and high variance groups

nsample = 50
x = np.linspace(0, 20, nsample)
X = np.column_stack((x, (x - 5)**2)) #convert 1D arrays to 2D array via columnwise appending 
X = sm.add_constant(X)
beta = [5., 0.5, -0.01] #actual intercept, x1, x2
sig = 0.5

w = np.ones(nsample)
w[nsample * 6//10:] = 3   #first few elements  1, next elements 3 
y_true = np.dot(X, beta)
e = np.random.normal(size=nsample)
y = y_true + sig * w * e  #Heteroscedasticity 2 groups
X = X[:,[0,1]]

#WLS knowing the true variance ratio of heteroscedasticity
mod_wls = sm.WLS(y, X, weights=1./w)
res_wls = mod_wls.fit()
>>> print(res_wls.summary())
                            WLS Regression Results                            
==============================================================================
Dep. Variable:                      y   R-squared:                       0.910
Model:                            WLS   Adj. R-squared:                  0.909
Method:                 Least Squares   F-statistic:                     487.9
Date:                Tue, 28 Feb 2017   Prob (F-statistic):           8.52e-27
Time:                        21:35:25   Log-Likelihood:                -57.048
No. Observations:                  50   AIC:                             118.1
Df Residuals:                      48   BIC:                             121.9
Df Model:                           1                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
const          5.2726      0.185     28.488      0.000       4.900       5.645
x1             0.4379      0.020     22.088      0.000       0.398       0.478
==============================================================================
Omnibus:                        5.040   Durbin-Watson:                   2.242
Prob(Omnibus):                  0.080   Jarque-Bera (JB):                6.431
Skew:                           0.024   Prob(JB):                       0.0401
Kurtosis:                       4.756   Cond. No.                         17.0
==============================================================================

#Estimate an OLS model for comparison:
In [4]:
res_ols = sm.OLS(y, X).fit()
print(res_ols.params)
print(res_wls.params)
[ 5.24256099  0.43486879]
[ 5.27260714  0.43794441]

#Compare the WLS standard errors to heteroscedasticity corrected OLS standard errors:
#vertically stack 
#bse : standard errors of the parameter estimates.
#HCn_se : heteroskedasticity robust standard errors
se = np.vstack([[res_wls.bse], [res_ols.bse], [res_ols.HC0_se], 
                [res_ols.HC1_se], [res_ols.HC2_se], [res_ols.HC3_se]])
se = np.round(se,4)
colnames = ['x1', 'const']
rownames = ['WLS', 'OLS', 'OLS_HC0', 'OLS_HC1', 'OLS_HC3', 'OLS_HC3']
tabl = SimpleTable(se, colnames, rownames, txt_fmt=default_txt_fmt)
>>> print(tabl)
=====================
          x1   const 
---------------------
WLS     0.1851 0.0198
OLS     0.2707 0.0233
OLS_HC0 0.194  0.0281
OLS_HC1 0.198  0.0287
OLS_HC3 0.2003 0.029 
OLS_HC3 0.207   0.03 
---------------------

#Calculate OLS prediction interval:

#Returns the variance/covariance matrix of  the estimates of params 
covb = res_ols.cov_params()
#mse_resid:Mean squared error of the residuals
prediction_var = res_ols.mse_resid + (X * np.dot(covb,X.T).T).sum(1) #axis=1 , rowwise 
prediction_std = np.sqrt(prediction_var)
tppf = stats.t.ppf(0.975, res_ols.df_resid)  #Percent point function (inverse of cdf) , given q, gives x 

'''
def wls_prediction_std(res, exog=None, weights=None, alpha=0.05):
    calculate standard deviation and confidence interval for prediction

    applies to WLS and OLS, not to general GLS,
    that is independently but not identically distributed observations

    Parameters
    ----------
    res : regression result instance
        results of WLS or OLS regression required attributes see notes
    exog : array_like (optional)
        exogenous variables for points to predict
    weights : scalar or array_like (optional)
        weights as defined for WLS (inverse of variance of observation)
    alpha : float (default: alpha = 0.05)
        confidence level for two-sided hypothesis

    Returns
    -------
    predstd : array_like, 1d
        standard error of prediction
        same length as rows of exog
    interval_l, interval_u : array_like
        lower und upper confidence bounds
'''
prstd_ols, iv_l_ols, iv_u_ols = wls_prediction_std(res_ols)

#Draw a plot to compare predicted values in WLS and OLS:
prstd, iv_l, iv_u = wls_prediction_std(res_wls)

fig, ax = plt.subplots(figsize=(8,6))
ax.plot(x, y, 'o', label="Data")
ax.plot(x, y_true, 'b-', label="True")
# OLS
ax.plot(x, res_ols.fittedvalues, 'r--')
ax.plot(x, iv_u_ols, 'r--', label="OLS")
ax.plot(x, iv_l_ols, 'r--')
# WLS
ax.plot(x, res_wls.fittedvalues, 'g--.')
ax.plot(x, iv_u, 'g--', label="WLS")
ax.plot(x, iv_l, 'g--')
ax.legend(loc="best");
 
##Feasible Weighted Least Squares (2-stage FWLS)
resid1 = res_ols.resid[w==1.]
var1 = resid1.var(ddof=int(res_ols.df_model)+1)
resid2 = res_ols.resid[w!=1.]
var2 = resid2.var(ddof=int(res_ols.df_model)+1)
w_est = w.copy()
w_est[w!=1.] = np.sqrt(var2) / np.sqrt(var1)

res_fwls = sm.WLS(y, X, 1./w_est).fit()
>>> print(res_fwls.summary())
                            WLS Regression Results                            
==============================================================================
Dep. Variable:                      y   R-squared:                       0.914
Model:                            WLS   Adj. R-squared:                  0.912
Method:                 Least Squares   F-statistic:                     507.1
Date:                Tue, 28 Feb 2017   Prob (F-statistic):           3.65e-27
Time:                        21:35:26   Log-Likelihood:                -55.777
No. Observations:                  50   AIC:                             115.6
Df Residuals:                      48   BIC:                             119.4
Df Model:                           1                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
const          5.2710      0.177     29.828      0.000       4.916       5.626
x1             0.4390      0.019     22.520      0.000       0.400       0.478
==============================================================================
Omnibus:                        4.076   Durbin-Watson:                   2.251
Prob(Omnibus):                  0.130   Jarque-Bera (JB):                4.336
Skew:                           0.003   Prob(JB):                        0.114
Kurtosis:                       4.443   Cond. No.                         16.5
==============================================================================
Warnings:
[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.




###Statsmodel-QuickIntro - sm.RecursiveLS
#Recursive least squares is an expanding window version of ordinary least squares. 
#regression coefficients are computed recursively, 

#the RLS exhibits extremely fast convergence. 
#However, this benefit comes at the cost of high computational complexity

#This model applies the Kalman filter to compute recursive estimates of the coefficients and recursive residuals

#Example 
%matplotlib inline
import numpy as np
import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt
from pandas_datareader.data import DataReader
np.set_printoptions(suppress=True)

#Example 1: Copper
#We first consider parameter stability in the copper dataset (description below).

print(sm.datasets.copper.DESCRLONG)
dta = sm.datasets.copper.load_pandas().data
dta.index = pd.date_range('1951-01-01', '1975-01-01', freq='AS')
endog = dta['WORLDCONSUMPTION']
# To the regressors in the dataset, we add a column of ones for an intercept
exog = sm.add_constant(dta[['COPPERPRICE', 'INCOMEINDEX', 'ALUMPRICE', 'INVENTORYINDEX']])


mod = sm.RecursiveLS(endog, exog)
res = mod.fit()
>>> print(res.summary())
                           Statespace Model Results                           
==============================================================================
Dep. Variable:       WORLDCONSUMPTION   No. Observations:                   25
Model:                    RecursiveLS   Log Likelihood                -153.737
Date:                Tue, 28 Feb 2017   AIC                            317.474
Time:                        21:33:53   BIC                            323.568
Sample:                    01-01-1951   HQIC                           319.164
                         - 01-01-1975                                         
Covariance Type:            nonrobust                                         
==================================================================================
                     coef    std err          z      P>|z|      [0.025      0.975]
----------------------------------------------------------------------------------
const          -6513.9917   2367.677     -2.751      0.006   -1.12e+04   -1873.430
COPPERPRICE      -13.6553     15.035     -0.908      0.364     -43.123      15.813
INCOMEINDEX     1.209e+04    762.598     15.853      0.000    1.06e+04    1.36e+04
ALUMPRICE         70.1441     32.668      2.147      0.032       6.117     134.171
INVENTORYINDEX   275.2802   2120.295      0.130      0.897   -3880.423    4430.983
===================================================================================
Ljung-Box (Q):                       14.53   Jarque-Bera (JB):                 1.91
Prob(Q):                              0.75   Prob(JB):                         0.39
Heteroskedasticity (H):               3.48   Skew:                            -0.74
Prob(H) (two-sided):                  0.12   Kurtosis:                         2.65
===================================================================================
Warnings:
[1] Parameters and covariance matrix estimates are RLS estimates conditional on the entire sample.


#recursive_coefficients:Estimates of regression coefficients, recursively estimated 
#.filtered[n] - gives Estimates of regression coefficients at iteration=n
print(res.recursive_coefficients.filtered[0])
res.plot_recursive_coefficient(range(mod.k_exog), alpha=None, figsize=(10,6));
#Output 
[    2.88890056     4.94425548  1505.26965677  1856.55054283  1598.00138036
  2171.98758114  -889.37441819   122.17728201 -4184.25981611 -6242.72030126
 -7111.44631736 -6400.3801834  -6090.45249953 -7154.96507467 -6290.92418756
 -5805.25729045 -6219.31739926 -6684.49572441 -6430.13765533 -5957.57703202
 -6407.05926045 -5983.49245301 -5224.7166129  -5286.62118319 -6513.99172374]
 
#CUSUM : Cumulative sum of standardized recursive residuals statistics
#but usually it is more convenient to visually check 
#for parameter stability using the plot_cusum method. 

#In the plot below, the CUSUM statistic does not move outside of the 5% significance bands, 
#so we fail to reject the null hypothesis of stable parameters at the 5% level.

print(res.cusum)
fig = res.plot_cusum();
#output 
[ 0.27819009  0.51898841  1.05399638  1.94931307  2.44814772  3.37264805
  3.04780591  2.47334163  2.96189656  2.58229863  1.49435136 -0.50007183
 -2.01111298 -1.75501921 -0.90602604 -1.41034654 -0.8038184   0.71255314
  1.19153109 -0.93368668]
 
#cusum_squares: Cumulative sum of squares of standardized recursive residuals statistics
#but it is similarly more convenient to check it visually, 
#using the plot_cusum_squares method. 

#In the plot below, the CUSUM of squares statistic does not move outside of the 5% significance bands, 
#so we fail to reject the null hypothesis of stable parameters at the 5% level.
res.plot_cusum_squares();




###Statsmodel-QuickIntro - Discrete Choice Models
sm.Logit, smf.logit                       Binary choice logit model
                                          Uses the cumulative distribution function of the logistic distribution
sm.MNLogit, smf.mnlogit                   Multinomial logit model
                                          Generalizes logistic regression to multiclass problems, i.e. with more than two possible discrete outcomes
sm.NegativeBinomial,smt.negativebinomial  Discreet model for count data
                                          Assumes that the mean and variance are not the same 
                                          Note it is a generalized linear model with a NegativeBinomial
sm.Poisson,smf.poisson                    Discreet model for count data 
                                          Assumes that the mean and variance are the same
                                          Note it is a generalized linear model with a Poisson distribution and a log link
sm.Probit, smf.probit                     Binary choice probit model
                                          Uses the  cumulative distribution function of the standard normal distribution

#important methods 
•logitreg.summary()          # summary of the model
•logitreg.fittedvalues       # fitted value from the model
•logitreg.predict()          # predict
•logfitreg.pred_table()      # confusion matrix


##Example with non-formula 
from __future__ import print_function
import numpy as np
import statsmodels.api as sm
#Load data from Spector and Mazzeo (1980). 
#Examples follow Greene's Econometric Analysis Ch. 21 (5th Edition).
spector_data = sm.datasets.spector.load()
spector_data.exog = sm.add_constant(spector_data.exog, prepend=False)
print(spector_data.exog[:5,:])
print(spector_data.endog[:5])
#Linear Probability Model (OLS)
lpm_mod = sm.OLS(spector_data.endog, spector_data.exog)
lpm_res = lpm_mod.fit()
>>> print('Parameters: ', lpm_res.params[:-1])
Parameters:  [ 0.46385168  0.01049512  0.37855479]

#Logit Model
logit_mod = sm.Logit(spector_data.endog, spector_data.exog)
logit_res = logit_mod.fit(disp=0)
>>> print('Parameters: ', logit_res.params)
Parameters:  [  2.82611259   0.09515766   2.37868766 -13.02134686]
>>> print(logit_res.summary())
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                      y   No. Observations:                   32
Model:                          Logit   Df Residuals:                       28
Method:                           MLE   Df Model:                            3
Date:                Tue, 28 Feb 2017   Pseudo R-squ.:                  0.3740
Time:                        21:32:53   Log-Likelihood:                -12.890
converged:                       True   LL-Null:                       -20.592
                                        LLR p-value:                  0.001502
==============================================================================
                 coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
x1             2.8261      1.263      2.238      0.025       0.351       5.301
x2             0.0952      0.142      0.672      0.501      -0.182       0.373
x3             2.3787      1.065      2.234      0.025       0.292       4.465
const        -13.0213      4.931     -2.641      0.008     -22.687      -3.356
==============================================================================

#Marginal Effects
#measure of the instantaneous effect that a change in a particular independent variable 
#has on the predicted probability of , when the other covariates are kept fixed
#H0: no effect.
margeff = logit_res.get_margeff()
>>> print(margeff.summary())
        Logit Marginal Effects       
=====================================
Dep. Variable:                      y
Method:                          dydx
At:                           overall
==============================================================================
                dy/dx    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
x1             0.3626      0.109      3.313      0.001       0.148       0.577
x2             0.0122      0.018      0.686      0.493      -0.023       0.047
x3             0.3052      0.092      3.304      0.001       0.124       0.486
==============================================================================



##l1 regularized logit
#The regularization parameter alpha should be a scalar 
#or have the same shape as results.params


alpha = 0.1 * len(spector_data.endog) * np.ones(spector_data.exog.shape[1])
#Choose not to regularize the constant
alpha[-1] = 0

logit_l1_res = logit_mod.fit_regularized(method='l1', alpha=alpha)
Optimization terminated successfully.    (Exit mode 0)
            Current function value: 0.610664637583
            Iterations: 13
            Function evaluations: 15
            Gradient evaluations: 13

print(logit_l1_res.summary())
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                      y   No. Observations:                   32
Model:                          Logit   Df Residuals:                       30
Method:                           MLE   Df Model:                            1
Date:                Wed, 14 Aug 2013   Pseudo R-squ.:                 0.07470
Time:                        17:18:27   Log-Likelihood:                -19.054
converged:                       True   LL-Null:                       -20.592
                                        LLR p-value:                   0.07944
==============================================================================
                 coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1                  0        nan        nan        nan           nan       nan
x2             0.1524      0.112      1.361      0.174        -0.067     0.372
x3                  0        nan        nan        nan           nan       nan
const         -4.0457      2.566     -1.577      0.115        -9.075     0.984
==============================================================================


#Probit Model
probit_mod = sm.Probit(spector_data.endog, spector_data.exog)
probit_res = probit_mod.fit()
probit_margeff = probit_res.get_margeff()
print('Parameters: ', probit_res.params)
print('Marginal effects: ')
print(probit_margeff.summary())
#Output 
#the partial effects of each explanatory variable 
#on the probability of the observed dependent variable

Optimization terminated successfully.
         Current function value: 0.400588
         Iterations 6
Parameters:  [ 1.62581004  0.05172895  1.42633234 -7.45231965]
Marginal effects: 
       Probit Marginal Effects       
=====================================
Dep. Variable:                      y
Method:                          dydx
At:                           overall
==============================================================================
                dy/dx    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
x1             0.3608      0.113      3.182      0.001       0.139       0.583
x2             0.0115      0.018      0.624      0.533      -0.025       0.048
x3             0.3165      0.090      3.508      0.000       0.140       0.493
==============================================================================

#Multinomial Logit
#Load data from the American National Election Studies:
anes_data = sm.datasets.anes96.load()
anes_exog = anes_data.exog
anes_exog = sm.add_constant(anes_exog, prepend=False)

mlogit_mod = sm.MNLogit(anes_data.endog, anes_exog)
mlogit_res = mlogit_mod.fit()
>>> print(mlogit_res.params)
#Output 
Optimization terminated successfully.
         Current function value: 1.548647
         Iterations 7
[[ -1.15359746e-02  -8.87506530e-02  -1.05966699e-01  -9.15567017e-02
   -9.32846040e-02  -1.40880692e-01]
 [  2.97714352e-01   3.91668642e-01   5.73450508e-01   1.27877179e+00
    1.34696165e+00   2.07008014e+00]
 [ -2.49449954e-02  -2.28978371e-02  -1.48512069e-02  -8.68134503e-03
   -1.79040689e-02  -9.43264870e-03]
 [  8.24914421e-02   1.81042758e-01  -7.15241904e-03   1.99827955e-01
    2.16938850e-01   3.21925702e-01]
 [  5.19655317e-03   4.78739761e-02   5.75751595e-02   8.44983753e-02
    8.09584122e-02   1.08894083e-01]
 [ -3.73401677e-01  -2.25091318e+00  -3.66558353e+00  -7.61384309e+00
   -7.06047825e+00  -1.21057509e+01]]
   


#Marginal Effects #p-value >0.05, that variable not significant 
mlogit_margeff = mlogit_res.get_margeff()
#the partial effects of each explanatory variable 
#on the probability of the observed dependent variable
print(mlogit_margeff.summary())
       MNLogit Marginal Effects      
=====================================
Dep. Variable:                      y
Method:                          dydx
At:                           overall
==============================================================================
       y=0      dy/dx    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1             0.0087      0.004      2.250      0.024         0.001     0.016
x2            -0.0978      0.008    -12.153      0.000        -0.114    -0.082
x3             0.0027      0.001      3.856      0.000         0.001     0.004
x4            -0.0199      0.008     -2.420      0.016        -0.036    -0.004
x5            -0.0060      0.002     -2.977      0.003        -0.010    -0.002
------------------------------------------------------------------------------
       y=1      dy/dx    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1             0.0070      0.004      1.791      0.073        -0.001     0.015
x2            -0.0502      0.007     -6.824      0.000        -0.065    -0.036
x3            -0.0021      0.001     -2.789      0.005        -0.004    -0.001
x4            -0.0054      0.008     -0.636      0.525*        -0.022     0.011
x5            -0.0055      0.002     -2.707      0.007        -0.010    -0.002
------------------------------------------------------------------------------
       y=2      dy/dx    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1            -0.0039      0.003     -1.246      0.213*        -0.010     0.002
x2            -0.0282      0.006     -4.972      0.000        -0.039    -0.017
x3            -0.0010      0.001     -1.523      0.128*        -0.002     0.000
x4             0.0066      0.007      0.964      0.335*        -0.007     0.020
x5             0.0010      0.002      0.530      0.596*        -0.003     0.005
------------------------------------------------------------------------------
       y=3      dy/dx    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1            -0.0018      0.002     -0.940      0.347*       -0.006     0.002
x2            -0.0057      0.003     -1.798      0.072*        -0.012     0.001
x3         -4.249e-05      0.000     -0.110      0.912*        -0.001     0.001
x4            -0.0055      0.004     -1.253      0.210*        -0.014     0.003
x5             0.0005      0.001      0.469      0.639*        -0.002     0.003
------------------------------------------------------------------------------
       y=4      dy/dx    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1            -0.0010      0.003     -0.330      0.741        -0.007     0.005
x2             0.0199      0.005      3.672      0.000         0.009     0.030
x3             0.0005      0.001      0.815      0.415        -0.001     0.002
x4             0.0017      0.006      0.268      0.789        -0.011     0.014
x5             0.0021      0.002      1.119      0.263        -0.002     0.006
------------------------------------------------------------------------------
       y=5      dy/dx    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1            -0.0015      0.004     -0.429      0.668        -0.009     0.005
x2             0.0376      0.007      5.404      0.000         0.024     0.051
x3            -0.0007      0.001     -0.949      0.343        -0.002     0.001
x4             0.0047      0.008      0.604      0.546        -0.011     0.020
x5             0.0025      0.002      1.140      0.254        -0.002     0.007
------------------------------------------------------------------------------
       y=6      dy/dx    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1            -0.0074      0.003     -2.205      0.027        -0.014    -0.001
x2             0.1246      0.008     14.875      0.000         0.108     0.141
x3             0.0006      0.001      0.942      0.346        -0.001     0.002
x4             0.0177      0.007      2.403      0.016         0.003     0.032
x5             0.0054      0.002      2.490      0.013         0.001     0.010
==============================================================================

##l1 regularized Multinomial Logit
#The regularization parameter alpha should be a scalar or have the same shape as as results.params

alpha = 10 * np.ones((mlogit_mod.K, mlogit_mod.J - 1))

#Choose not to regularize the constant
alpha[-1, :] = 0
mlogit_mod2 = sm.MNLogit(anes_data.endog, anes_exog)
mlogit_l1_res = mlogit_mod2.fit_regularized(method='l1', alpha=alpha)
Optimization terminated successfully.    (Exit mode 0)
            Current function value: 1.61249508025
            Iterations: 122
            Function evaluations: 144
            Gradient evaluations: 122

print(mlogit_l1_res.summary())  #>0.05, that value not significant 
                          MNLogit Regression Results                          
==============================================================================
Dep. Variable:                      y   No. Observations:                  944
Model:                        MNLogit   Df Residuals:                      912
Method:                           MLE   Df Model:                           26
Date:                Wed, 14 Aug 2013   Pseudo R-squ.:                  0.1558
Time:                        17:18:35   Log-Likelihood:                -1477.7
converged:                       True   LL-Null:                       -1750.3
                                        LLR p-value:                 1.464e-98
==============================================================================
       y=1       coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1             0.0010      0.033      0.030      0.976        -0.065     0.067
x2                  0        nan        nan        nan           nan       nan
x3            -0.0218      0.006     -3.494      0.000        -0.034    -0.010
x4                  0        nan        nan        nan           nan       nan
x5                  0        nan        nan        nan           nan       nan
const          0.9100      0.328      2.774      0.006         0.267     1.553
------------------------------------------------------------------------------
       y=2       coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1            -0.0586      0.038     -1.530      0.126        -0.134     0.017
x2             0.0319      0.090      0.353      0.724        -0.145     0.208
x3            -0.0199      0.008     -2.577      0.010        -0.035    -0.005
x4             0.0331      0.075      0.440      0.660        -0.114     0.180
x5             0.0445      0.020      2.197      0.028         0.005     0.084
const         -0.5008      0.686     -0.730      0.466        -1.846     0.845
------------------------------------------------------------------------------
       y=3       coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1            -0.0615      0.057     -1.086      0.277        -0.172     0.049
x2             0.1205      0.139      0.868      0.385        -0.151     0.392
x3            -0.0081      0.011     -0.741      0.459        -0.029     0.013
x4                  0        nan        nan        nan           nan       nan
x5             0.0325      0.029      1.108      0.268        -0.025     0.090
const         -2.0828      0.929     -2.242      0.025        -3.904    -0.262
------------------------------------------------------------------------------
       y=4       coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1            -0.0477      0.042     -1.144      0.252        -0.129     0.034
x2             0.8321      0.105      7.918      0.000         0.626     1.038
x3            -0.0049      0.008     -0.613      0.540        -0.020     0.011
x4             0.0236      0.082      0.288      0.774        -0.137     0.185
x5             0.0766      0.024      3.233      0.001         0.030     0.123
const         -5.2613      0.842     -6.246      0.000        -6.912    -3.610
------------------------------------------------------------------------------
       y=5       coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1            -0.0522      0.037     -1.413      0.158        -0.125     0.020
x2             0.9233      0.092     10.012      0.000         0.743     1.104
x3            -0.0140      0.007     -1.972      0.049        -0.028 -8.34e-05
x4             0.0549      0.071      0.769      0.442        -0.085     0.195
x5             0.0727      0.020      3.618      0.000         0.033     0.112
const         -4.8678      0.727     -6.693      0.000        -6.293    -3.442
------------------------------------------------------------------------------
       y=6       coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1            -0.0952      0.039     -2.442      0.015        -0.172    -0.019
x2             1.5681      0.116     13.472      0.000         1.340     1.796
x3            -0.0056      0.007     -0.752      0.452        -0.020     0.009
x4             0.1466      0.076      1.925      0.054        -0.003     0.296
x5             0.0968      0.022      4.376      0.000         0.053     0.140
const         -9.3154      0.913    -10.207      0.000       -11.104    -7.527
==============================================================================

  
   

##Poisson
#Load the Rand data
rand_data = sm.datasets.randhie.load()
rand_exog = rand_data.exog.view(float).reshape(len(rand_data.exog), -1)
rand_exog = sm.add_constant(rand_exog, prepend=False)
poisson_mod = sm.Poisson(rand_data.endog, rand_exog)
poisson_res = poisson_mod.fit(method="newton")
>>> print(poisson_res.summary())
Optimization terminated successfully.
         Current function value: 3.091609
         Iterations 12
                          Poisson Regression Results                          
==============================================================================
Dep. Variable:                      y   No. Observations:                20190
Model:                        Poisson   Df Residuals:                    20180
Method:                           MLE   Df Model:                            9
Date:                Tue, 28 Feb 2017   Pseudo R-squ.:                 0.06343
Time:                        21:32:54   Log-Likelihood:                -62420.
converged:                       True   LL-Null:                       -66647.
                                        LLR p-value:                     0.000
==============================================================================
                 coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
x1            -0.0525      0.003    -18.216      0.000      -0.058      -0.047
x2            -0.2471      0.011    -23.272      0.000      -0.268      -0.226
x3             0.0353      0.002     19.302      0.000       0.032       0.039
x4            -0.0346      0.002    -21.439      0.000      -0.038      -0.031
x5             0.2717      0.012     22.200      0.000       0.248       0.296
x6             0.0339      0.001     60.098      0.000       0.033       0.035
x7            -0.0126      0.009     -1.366      0.172      -0.031       0.005
x8             0.0541      0.015      3.531      0.000       0.024       0.084
x9             0.2061      0.026      7.843      0.000       0.155       0.258
const          0.7004      0.011     62.741      0.000       0.678       0.722
==============================================================================

#Marginal Effects
poisson_margeff = poisson_res.get_margeff()
#the partial effects of each explanatory variable 
#on the probability of the observed dependent variable
print poisson_margeff.summary()
       Poisson Marginal Effects      
=====================================
Dep. Variable:                      y
Method:                          dydx
At:                           overall
==============================================================================
                dy/dx    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
x1            -0.1503      0.008    -18.164      0.000        -0.166    -0.134
x2            -0.7068      0.031    -23.164      0.000        -0.767    -0.647
x3             0.1009      0.005     19.240      0.000         0.091     0.111
x4            -0.0989      0.005    -21.354      0.000        -0.108    -0.090
x5             0.7772      0.035     22.106      0.000         0.708     0.846
x6             0.0971      0.002     58.303      0.000         0.094     0.100
x7            -0.0361      0.026     -1.366      0.172        -0.088     0.016
x8             0.1546      0.044      3.530      0.000         0.069     0.240
x9             0.5896      0.075      7.839      0.000         0.442     0.737
==============================================================================


#l1 regularized Poisson model

poisson_mod2 = sm.Poisson(rand_data.endog, rand_exog)
alpha = 0.1 * len(rand_data.endog) * np.ones(rand_exog.shape[1])
alpha[-1] = 0

poisson_l1_res = poisson_mod2.fit_regularized(method='l1', alpha=alpha)
Optimization terminated successfully.    (Exit mode 0)
            Current function value: 3.13647450062
            Iterations: 19
            Function evaluations: 35
            Gradient evaluations: 19









#Negative Binomial
mod_nbin = sm.NegativeBinomial(rand_data.endog, rand_exog)
res_nbin = mod_nbin.fit(disp=False)
>>> print(res_nbin.summary())
/private/tmp/statsmodels/statsmodels/base/model.py:496: ConvergenceWarning: Maximum Likelihood optimization failed to converge. Check mle_retvals
  "Check mle_retvals", ConvergenceWarning)
                     NegativeBinomial Regression Results                      
==============================================================================
Dep. Variable:                      y   No. Observations:                20190
Model:               NegativeBinomial   Df Residuals:                    20180
Method:                           MLE   Df Model:                            9
Date:                Tue, 28 Feb 2017   Pseudo R-squ.:                 0.01845
Time:                        21:32:56   Log-Likelihood:                -43384.
converged:                      False   LL-Null:                       -44199.
                                        LLR p-value:                     0.000
==============================================================================
                 coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
x1            -0.0580      0.006     -9.517      0.000      -0.070      -0.046
x2            -0.2678      0.023    -11.802      0.000      -0.312      -0.223
x3             0.0412      0.004      9.937      0.000       0.033       0.049
x4            -0.0381      0.003    -11.219      0.000      -0.045      -0.031
x5             0.2690      0.030      8.981      0.000       0.210       0.328
x6             0.0382      0.001     26.081      0.000       0.035       0.041
x7            -0.0441      0.020     -2.200      0.028      -0.083      -0.005
x8             0.0172      0.036      0.477      0.633      -0.054       0.088
x9             0.1780      0.074      2.397      0.017       0.032       0.324
const          0.6636      0.025     26.787      0.000       0.615       0.712
alpha          1.2930      0.019     69.477      0.000       1.256       1.329
==============================================================================

##Alternative solvers
#The default method for fitting discrete data MLE models is Newton-Raphson. 
#You can use other solvers by using the method argument:
mlogit_res = mlogit_mod.fit(method='bfgs', maxiter=100)
>>> print(mlogit_res.summary())
Warning: Maximum number of iterations has been exceeded.
         Current function value: 1.548650
         Iterations: 100
         Function evaluations: 106
         Gradient evaluations: 106
                          MNLogit Regression Results                          
==============================================================================
Dep. Variable:                      y   No. Observations:                  944
Model:                        MNLogit   Df Residuals:                      908
Method:                           MLE   Df Model:                           30
Date:                Tue, 28 Feb 2017   Pseudo R-squ.:                  0.1648
Time:                        21:32:56   Log-Likelihood:                -1461.9
converged:                      False   LL-Null:                       -1750.3
                                        LLR p-value:                1.827e-102
==============================================================================
       y=1       coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
x1            -0.0116      0.034     -0.338      0.735      -0.079       0.056
x2             0.2973      0.094      3.175      0.001       0.114       0.481
x3            -0.0250      0.007     -3.825      0.000      -0.038      -0.012
x4             0.0821      0.074      1.116      0.264      -0.062       0.226
x5             0.0052      0.018      0.294      0.769      -0.029       0.040
const         -0.3689      0.630     -0.586      0.558      -1.603       0.866
------------------------------------------------------------------------------
       y=2       coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
x1            -0.0888      0.039     -2.269      0.023      -0.166      -0.012
x2             0.3913      0.108      3.615      0.000       0.179       0.603
x3            -0.0229      0.008     -2.897      0.004      -0.038      -0.007
x4             0.1808      0.085      2.120      0.034       0.014       0.348
x5             0.0478      0.022      2.145      0.032       0.004       0.091
const         -2.2451      0.763     -2.942      0.003      -3.741      -0.749
------------------------------------------------------------------------------
       y=3       coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
x1            -0.1062      0.057     -1.861      0.063      -0.218       0.006
x2             0.5730      0.159      3.614      0.000       0.262       0.884
x3            -0.0149      0.011     -1.313      0.189      -0.037       0.007
x4            -0.0075      0.126     -0.060      0.952      -0.255       0.240
x5             0.0575      0.034      1.711      0.087      -0.008       0.123
const         -3.6592      1.156     -3.164      0.002      -5.926      -1.393
------------------------------------------------------------------------------
       y=4       coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
x1            -0.0914      0.044     -2.085      0.037      -0.177      -0.005
x2             1.2826      0.129      9.937      0.000       1.030       1.536
x3            -0.0085      0.008     -1.008      0.314      -0.025       0.008
x4             0.2012      0.094      2.136      0.033       0.017       0.386
x5             0.0850      0.026      3.240      0.001       0.034       0.136
const         -7.6589      0.960     -7.982      0.000      -9.540      -5.778
------------------------------------------------------------------------------
       y=5       coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
x1            -0.0934      0.039     -2.374      0.018      -0.170      -0.016
x2             1.3451      0.117     11.485      0.000       1.116       1.575
x3            -0.0180      0.008     -2.362      0.018      -0.033      -0.003
x4             0.2161      0.085      2.542      0.011       0.049       0.383
x5             0.0808      0.023      3.517      0.000       0.036       0.126
const         -7.0401      0.844     -8.344      0.000      -8.694      -5.387
------------------------------------------------------------------------------
       y=6       coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
x1            -0.1409      0.042     -3.345      0.001      -0.224      -0.058
x2             2.0686      0.143     14.433      0.000       1.788       2.349
x3            -0.0095      0.008     -1.164      0.244      -0.025       0.006
x4             0.3216      0.091      3.532      0.000       0.143       0.500
x5             0.1087      0.025      4.299      0.000       0.059       0.158
const        -12.0913      1.059    -11.415      0.000     -14.167     -10.015
==============================================================================
/private/tmp/statsmodels/statsmodels/base/model.py:496: ConvergenceWarning: Maximum Likelihood optimization failed to converge. Check mle_retvals
  "Check mle_retvals", ConvergenceWarning)

##Formula based Discrete choice model 
#Fair's Affair data
#A survey of women only was conducted in 1974 by Redbook 
#asking about extramarital affairs.

%matplotlib inline
from __future__ import print_function
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.formula.api import logit, probit, poisson, ols

>>> print(sm.datasets.fair.SOURCE)
Fair, Ray. 1978. "A Theory of Extramarital Affairs," `Journal of Political
Economy`, February, 45-61.
The data is available at http://fairmodel.econ.yale.edu/rayfair/pdf/2011b.htm
In [3]:
print( sm.datasets.fair.NOTE)
::
    Number of observations: 6366
    Number of variables: 9
    Variable name definitions:
        rate_marriage   : How rate marriage, 1 = very poor, 2 = poor, 3 = fair,
                        4 = good, 5 = very good
        age             : Age
        yrs_married     : No. years married. Interval approximations. See
                        original paper for detailed explanation.
        children        : No. children
        religious       : How relgious, 1 = not, 2 = mildly, 3 = fairly,
                        4 = strongly
        educ            : Level of education, 9 = grade school, 12 = high
                        school, 14 = some college, 16 = college graduate,
                        17 = some graduate school, 20 = advanced degree
        occupation      : 1 = student, 2 = farming, agriculture; semi-skilled,
                        or unskilled worker; 3 = white-colloar; 4 = teacher
                        counselor social worker, nurse; artist, writers;
                        technician, skilled worker, 5 = managerial,
                        administrative, business, 6 = professional with
                        advanced degree
        occupation_husb : Husband's occupation. Same as occupation.
        affairs         : measure of time spent in extramarital affairs
    See the original paper for more details.


dta = sm.datasets.fair.load_pandas().data
dta['affair'] = (dta['affairs'] > 0).astype(float)

>>> print(dta.head(10))
   rate_marriage   age  yrs_married  children  religious  educ  occupation  \
0            3.0  32.0          9.0       3.0        3.0  17.0         2.0   
1            3.0  27.0         13.0       3.0        1.0  14.0         3.0   
2            4.0  22.0          2.5       0.0        1.0  16.0         3.0   
3            4.0  37.0         16.5       4.0        3.0  16.0         5.0   
4            5.0  27.0          9.0       1.0        1.0  14.0         3.0   
5            4.0  27.0          9.0       0.0        2.0  14.0         3.0   
6            5.0  37.0         23.0       5.5        2.0  12.0         5.0   
7            5.0  37.0         23.0       5.5        2.0  12.0         2.0   
8            3.0  22.0          2.5       0.0        2.0  12.0         3.0   
9            3.0  27.0          6.0       0.0        1.0  16.0         3.0   
   occupation_husb   affairs  affair  
0              5.0  0.111111     1.0  
1              4.0  3.230769     1.0  
2              5.0  1.400000     1.0  
3              5.0  0.727273     1.0  
4              4.0  4.666666     1.0  
5              4.0  4.666666     1.0  
6              4.0  0.852174     1.0  
7              3.0  1.826086     1.0  
8              3.0  4.799999     1.0  
9              5.0  1.333333     1.0  

>>> print(dta.describe())
       rate_marriage          age  yrs_married     children    religious  \
count    6366.000000  6366.000000  6366.000000  6366.000000  6366.000000   
mean        4.109645    29.082862     9.009425     1.396874     2.426170   
std         0.961430     6.847882     7.280120     1.433471     0.878369   
min         1.000000    17.500000     0.500000     0.000000     1.000000   
25%         4.000000    22.000000     2.500000     0.000000     2.000000   
50%         4.000000    27.000000     6.000000     1.000000     2.000000   
75%         5.000000    32.000000    16.500000     2.000000     3.000000   
max         5.000000    42.000000    23.000000     5.500000     4.000000   
              educ   occupation  occupation_husb      affairs       affair  
count  6366.000000  6366.000000      6366.000000  6366.000000  6366.000000  
mean     14.209865     3.424128         3.850141     0.705374     0.322495  
std       2.178003     0.942399         1.346435     2.203374     0.467468  
min       9.000000     1.000000         1.000000     0.000000     0.000000  
25%      12.000000     3.000000         3.000000     0.000000     0.000000  
50%      14.000000     3.000000         4.000000     0.000000     0.000000  
75%      16.000000     4.000000         5.000000     0.484848     1.000000  
max      20.000000     6.000000         6.000000    57.599991     1.000000  

affair_mod = logit("affair ~ occupation + educ + occupation_husb" 
                   "+ rate_marriage + age + yrs_married + children"
                   " + religious", dta).fit()

>>> print(affair_mod.summary())
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                 affair   No. Observations:                 6366
Model:                          Logit   Df Residuals:                     6357
Method:                           MLE   Df Model:                            8
Date:                Tue, 28 Feb 2017   Pseudo R-squ.:                  0.1327
Time:                        21:32:44   Log-Likelihood:                -3471.5
converged:                       True   LL-Null:                       -4002.5
                                        LLR p-value:                5.807e-224
===================================================================================
                      coef    std err          z      P>|z|      [0.025      0.975]
-----------------------------------------------------------------------------------
Intercept           3.7257      0.299     12.470      0.000       3.140       4.311
occupation          0.1602      0.034      4.717      0.000       0.094       0.227
educ               -0.0392      0.015     -2.533      0.011      -0.070      -0.009
occupation_husb     0.0124      0.023      0.541      0.589      -0.033       0.057
rate_marriage      -0.7161      0.031    -22.784      0.000      -0.778      -0.655
age                -0.0605      0.010     -5.885      0.000      -0.081      -0.040
yrs_married         0.1100      0.011     10.054      0.000       0.089       0.131
children           -0.0042      0.032     -0.134      0.893      -0.066       0.058
religious          -0.3752      0.035    -10.792      0.000      -0.443      -0.307
===================================================================================

#How well are we predicting?
#pred_table[i,j] refers to the number of times 'i' was observed and the model predicted 'j'. 
#Correct predictions are along the diagonal
>>> affair_mod.pred_table() 
array([[ 3882.,   431.],
       [ 1326.,   727.]])
       
#The coefficients of the discrete choice model do not tell us much. 
#But  marginal effects.
#Ho: no effect 
mfx = affair_mod.get_margeff()
>>> print(mfx.summary())
        Logit Marginal Effects       
=====================================
Dep. Variable:                 affair
Method:                          dydx
At:                           overall
===================================================================================
                     dy/dx    std err          z      P>|z|      [0.025      0.975]
-----------------------------------------------------------------------------------
occupation          0.0293      0.006      4.744      0.000       0.017       0.041
educ               -0.0072      0.003     -2.538      0.011      -0.013      -0.002
occupation_husb     0.0023      0.004      0.541      0.589      -0.006       0.010
rate_marriage      -0.1308      0.005    -26.891      0.000      -0.140      -0.121
age                -0.0110      0.002     -5.937      0.000      -0.015      -0.007
yrs_married         0.0201      0.002     10.327      0.000       0.016       0.024
children           -0.0008      0.006     -0.134      0.893      -0.012       0.011
religious          -0.0685      0.006    -11.119      0.000      -0.081      -0.056
===================================================================================

respondent1000 = dta.ix[1000]
>>> print(respondent1000)
rate_marriage       4.000000
age                37.000000
yrs_married        23.000000
children            3.000000
religious           3.000000
educ               12.000000
occupation          3.000000
occupation_husb     4.000000
affairs             0.521739
affair              1.000000
Name: 1000, dtype: float64


resp = dict(zip(range(1,9), respondent1000[["occupation", "educ", 
                                            "occupation_husb", "rate_marriage", 
                                            "age", "yrs_married", "children", 
                                            "religious"]].tolist()))
resp.update({0 : 1})
>>> print(resp)
{1: 3.0, 2: 12.0, 3: 4.0, 4: 4.0, 5: 37.0, 6: 23.0, 7: 3.0, 8: 3.0, 0: 1}
In [13]:
mfx = affair_mod.get_margeff(atexog=resp)
>>> print(mfx.summary())
        Logit Marginal Effects       
=====================================
Dep. Variable:                 affair
Method:                          dydx
At:                           overall
===================================================================================
                     dy/dx    std err          z      P>|z|      [0.025      0.975]
-----------------------------------------------------------------------------------
occupation          0.0400      0.008      4.711      0.000       0.023       0.057
educ               -0.0098      0.004     -2.537      0.011      -0.017      -0.002
occupation_husb     0.0031      0.006      0.541      0.589      -0.008       0.014
rate_marriage      -0.1788      0.008    -22.743      0.000      -0.194      -0.163
age                -0.0151      0.003     -5.928      0.000      -0.020      -0.010
yrs_married         0.0275      0.003     10.256      0.000       0.022       0.033
children           -0.0011      0.008     -0.134      0.893      -0.017       0.014
religious          -0.0937      0.009    -10.722      0.000      -0.111      -0.077
===================================================================================

>>> affair_mod.predict(respondent1000)
#ERROR 
>>> affair_mod.fittedvalues[1000]
0.075161592850562342

>>> affair_mod.model.cdf(affair_mod.fittedvalues[1000])
0.51878155721214692

##probit 
affair_mod_prob = probit("affair ~ occupation + educ + occupation_husb" 
                   "+ rate_marriage + age + yrs_married + children"
                   " + religious", dta).fit()

>>> print(affair_mod_prob.summary())

#The coefficients of the discrete choice model do not tell us much. 
#But  marginal effects.
#Ho: no effect 
mfx = affair_mod_prob.get_margeff()
>>> print(mfx.summary())

##Logit vs Probit
fig = plt.figure(figsize=(12,8))
ax = fig.add_subplot(111)
support = np.linspace(-6, 6, 1000)
ax.plot(support, stats.logistic.cdf(support), 'r-', label='Logistic')
ax.plot(support, stats.norm.cdf(support), label='Probit')
ax.legend();
 

fig = plt.figure(figsize=(12,8))
ax = fig.add_subplot(111)
support = np.linspace(-6, 6, 1000)
ax.plot(support, stats.logistic.pdf(support), 'r-', label='Logistic')
ax.plot(support, stats.norm.pdf(support), label='Probit')
ax.legend();
 
##Genarlized Linear Model Example

>>> print(sm.datasets.star98.SOURCE)
Jeff Gill's `Generalized Linear Models: A Unified Approach`
http://jgill.wustl.edu/research/books.html

>>> print(sm.datasets.star98.DESCRLONG)
This data is on the California education policy and outcomes (STAR program
results for 1998.  The data measured standardized testing by the California
Department of Education that required evaluation of 2nd - 11th grade students
by the the Stanford 9 test on a variety of subjects.  This dataset is at
the level of the unified school district and consists of 303 cases.  The
binary response variable represents the number of 9th graders scoring
over the national median value on the mathematics exam.
The data used in this example is only a subset of the original source.

>>> print(sm.datasets.star98.NOTE)
::
    Number of Observations - 303 (counties in California).
    Number of Variables - 13 and 8 interaction terms.
    Definition of variables names::
        NABOVE   - Total number of students above the national median for the
                   math section.
        NBELOW   - Total number of students below the national median for the
                   math section.
        LOWINC   - Percentage of low income students
        PERASIAN - Percentage of Asian student
        PERBLACK - Percentage of black students
        PERHISP  - Percentage of Hispanic students
        PERMINTE - Percentage of minority teachers
        AVYRSEXP - Sum of teachers' years in educational service divided by the
                number of teachers.
        AVSALK   - Total salary budget including benefits divided by the number
                   of full-time teachers (in thousands)
        PERSPENK - Per-pupil spending (in thousands)
        PTRATIO  - Pupil-teacher ratio.
        PCTAF    - Percentage of students taking UC/CSU prep courses
        PCTCHRT  - Percentage of charter schools
        PCTYRRND - Percentage of year-round schools
        The below variables are interaction terms of the variables defined
        above.
        PERMINTE_AVYRSEXP
        PEMINTE_AVSAL
        AVYRSEXP_AVSAL
        PERSPEN_PTRATIO
        PERSPEN_PCTAF
        PTRATIO_PCTAF
        PERMINTE_AVTRSEXP_AVSAL
        PERSPEN_PTRATIO_PCTAF

dta = sm.datasets.star98.load_pandas().data
>>> print(dta.columns)
Index(['NABOVE', 'NBELOW', 'LOWINC', 'PERASIAN', 'PERBLACK', 'PERHISP',
       'PERMINTE', 'AVYRSEXP', 'AVSALK', 'PERSPENK', 'PTRATIO', 'PCTAF',
       'PCTCHRT', 'PCTYRRND', 'PERMINTE_AVYRSEXP', 'PERMINTE_AVSAL',
       'AVYRSEXP_AVSAL', 'PERSPEN_PTRATIO', 'PERSPEN_PCTAF', 'PTRATIO_PCTAF',
       'PERMINTE_AVYRSEXP_AVSAL', 'PERSPEN_PTRATIO_PCTAF'],
      dtype='object')

>>> print(dta[['NABOVE', 'NBELOW', 'LOWINC', 'PERASIAN', 'PERBLACK', 'PERHISP', 'PERMINTE']].head(10))
   NABOVE  NBELOW    LOWINC   PERASIAN   PERBLACK    PERHISP   PERMINTE
0   452.0   355.0  34.39730  23.299300  14.235280  11.411120  15.918370
1   144.0    40.0  17.36507  29.328380   8.234897   9.314884  13.636360
2   337.0   234.0  32.64324   9.226386  42.406310  13.543720  28.834360
3   395.0   178.0  11.90953  13.883090   3.796973  11.443110  11.111110
4     8.0    57.0  36.88889  12.187500  76.875000   7.604167  43.589740
5  1348.0   899.0  20.93149  28.023510   4.643221  13.808160  15.378490
6   477.0   887.0  53.26898   8.447858  19.374830  37.905330  25.525530
7   565.0   347.0  15.19009   3.665781   2.649680  13.092070   6.203008
8   205.0   320.0  28.21582  10.430420   6.786374  32.334300  13.461540
9   469.0   598.0  32.77897  17.178310  12.484930  28.323290  27.259890


formula = 'NABOVE + NBELOW ~ LOWINC + PERASIAN + PERBLACK + PERHISP + PCTCHRT '
formula += '+ PCTYRRND + PERMINTE*AVYRSEXP*AVSALK + PERSPENK*PTRATIO*PCTAF'

##Using GLM and Binomial distribution
#Toss a six-sided die 5 times, what's the probability of exactly 2 fours?
>>> stats.binom(5, 1./6).pmf(2)  #pdf=pmf in discrete model 
0.16075102880658435

from scipy.misc import comb
>>> comb(5,2) * (1/6.)**2 * (5/6.)**3 #comb(n,k): The number of combinations of N things taken k at a time
0.1607510288065844

from statsmodels.formula.api import glm
glm_mod = glm(formula, dta, family=sm.families.Binomial()).fit()

>>> print(glm_mod.summary())
                  Generalized Linear Model Regression Results                   
================================================================================
Dep. Variable:     ['NABOVE', 'NBELOW']   No. Observations:                  303
Model:                              GLM   Df Residuals:                      282
Model Family:                  Binomial   Df Model:                           20
Link Function:                    logit   Scale:                             1.0
Method:                            IRLS   Log-Likelihood:                -2998.6
Date:                  Tue, 28 Feb 2017   Deviance:                       4078.8
Time:                          21:32:46   Pearson chi2:                     9.60
No. Iterations:                       5                                         
============================================================================================
                               coef    std err          z      P>|z|      [0.025      0.975]
--------------------------------------------------------------------------------------------
Intercept                    2.9589      1.547      1.913      0.056      -0.073       5.990
LOWINC                      -0.0168      0.000    -38.749      0.000      -0.018      -0.016
PERASIAN                     0.0099      0.001     16.505      0.000       0.009       0.011
PERBLACK                    -0.0187      0.001    -25.182      0.000      -0.020      -0.017
PERHISP                     -0.0142      0.000    -32.818      0.000      -0.015      -0.013
PCTCHRT                      0.0049      0.001      3.921      0.000       0.002       0.007
PCTYRRND                    -0.0036      0.000    -15.878      0.000      -0.004      -0.003
PERMINTE                     0.2545      0.030      8.498      0.000       0.196       0.313
AVYRSEXP                     0.2407      0.057      4.212      0.000       0.129       0.353
PERMINTE:AVYRSEXP           -0.0141      0.002     -7.391      0.000      -0.018      -0.010
AVSALK                       0.0804      0.014      5.775      0.000       0.053       0.108
PERMINTE:AVSALK             -0.0040      0.000     -8.450      0.000      -0.005      -0.003
AVYRSEXP:AVSALK             -0.0039      0.001     -4.059      0.000      -0.006      -0.002
PERMINTE:AVYRSEXP:AVSALK     0.0002   2.99e-05      7.428      0.000       0.000       0.000
PERSPENK                    -1.9522      0.317     -6.162      0.000      -2.573      -1.331
PTRATIO                     -0.3341      0.061     -5.453      0.000      -0.454      -0.214
PERSPENK:PTRATIO             0.0917      0.015      6.321      0.000       0.063       0.120
PCTAF                       -0.1690      0.033     -5.169      0.000      -0.233      -0.105
PERSPENK:PCTAF               0.0490      0.007      6.574      0.000       0.034       0.064
PTRATIO:PCTAF                0.0080      0.001      5.362      0.000       0.005       0.011
PERSPENK:PTRATIO:PCTAF      -0.0022      0.000     -6.445      0.000      -0.003      -0.002
============================================================================================

#The number of trials
>>> glm_mod.model.data.orig_endog.sum(1) #axis =1, rowwise 
0      807.0
1      184.0
2      571.0
3      573.0
4       65.0
       ...  
298    342.0
299    154.0
300    595.0
301    709.0
302    156.0
dtype: float64

>>> glm_mod.fittedvalues * glm_mod.model.data.orig_endog.sum(1)
0      470.732584
1      138.266178
2      285.832629
3      392.702917
4       20.963146
          ...    
298    111.464708
299     61.037884
300    235.517446
301    290.952508
302     53.312851

##First differences: 
#We hold all explanatory variables constant at their means 
#and manipulate the percentage of low income households 
#to assess its impact on the response variables:
>>> exog = glm_mod.model.data.orig_exog # get the dataframe
means25 = exog.mean()
>>> print(means25)
Intercept                    1.000000
LOWINC                      41.409877
PERASIAN                     5.896335
PERBLACK                     5.636808
PERHISP                     34.398080
                             ...     
PERSPENK:PTRATIO            96.295756
PCTAF                       33.630593
PERSPENK:PCTAF             147.235740
PTRATIO:PCTAF              747.445536
PERSPENK:PTRATIO:PCTAF    3243.607568
dtype: float64

means25['LOWINC'] = exog['LOWINC'].quantile(.25)
>>> print(means25)
Intercept                    1.000000
LOWINC                      26.683040
PERASIAN                     5.896335
PERBLACK                     5.636808
PERHISP                     34.398080
                             ...     
PERSPENK:PTRATIO            96.295756
PCTAF                       33.630593
PERSPENK:PCTAF             147.235740
PTRATIO:PCTAF              747.445536
PERSPENK:PTRATIO:PCTAF    3243.607568
dtype: float64

means75 = exog.mean()
means75['LOWINC'] = exog['LOWINC'].quantile(.75)
>>> print(means75)
Intercept                    1.000000
LOWINC                      55.460075
PERASIAN                     5.896335
PERBLACK                     5.636808
PERHISP                     34.398080
                             ...     
PERSPENK:PTRATIO            96.295756
PCTAF                       33.630593
PERSPENK:PCTAF             147.235740
PTRATIO:PCTAF              747.445536
PERSPENK:PTRATIO:PCTAF    3243.607568
dtype: float64

resp25 = glm_mod.predict(means25)
resp75 = glm_mod.predict(means75)
diff = resp75 - resp25

#The interquartile first difference for the percentage of low income households 
#in a school district is:
>>> print("%2.4f%%" % (diff[0]*100))


nobs = glm_mod.nobs
y = glm_mod.model.endog
yhat = glm_mod.mu

from statsmodels.graphics.api import abline_plot
fig = plt.figure(figsize=(12,8))
ax = fig.add_subplot(111, ylabel='Observed Values', xlabel='Fitted Values')
ax.scatter(yhat, y)
y_vs_yhat = sm.OLS(y, sm.add_constant(yhat, prepend=True)).fit()
fig = abline_plot(model_results=y_vs_yhat, ax=ax)
 
##Plot fitted values vs Pearson residuals
fig = plt.figure(figsize=(12,8))
ax = fig.add_subplot(111, title='Residual Dependence Plot', xlabel='Fitted Values',
                          ylabel='Pearson Residuals')
ax.scatter(yhat, stats.zscore(glm_mod.resid_pearson))
ax.axis('tight')
ax.plot([0.0, 1.0],[0.0, 0.0], 'k-');
 
#Histogram of standardized deviance residuals with Kernel Density Estimate overlayed

resid = glm_mod.resid_deviance
resid_std = stats.zscore(resid) 
kde_resid = sm.nonparametric.KDEUnivariate(resid_std)
kde_resid.fit()

fig = plt.figure(figsize=(12,8))
ax = fig.add_subplot(111, title="Standardized Deviance Residuals")
ax.hist(resid_std, bins=25, normed=True);
ax.plot(kde_resid.support, kde_resid.density, 'r');
 
##QQ-plot of deviance residuals
fig = plt.figure(figsize=(12,8))
ax = fig.add_subplot(111)
fig = sm.graphics.qqplot(resid, line='r', ax=ax)





###Statsmodel-QuickIntro - sm.MixedLM, smf.mixedlm
#Linear mixed-effects models are extensions of linear regression models for data 
#that are collected and summarized in groups. 
#These models describe the relationship between a response variable 
#and independent variables, with coefficients that can vary 
#with respect to one or more grouping variables

#Example 
import statsmodels.api as sm
import statsmodels.formula.api as smf
data = sm.datasets.get_rdataset("dietox", "geepack").data
md = smf.mixedlm("Weight ~ Time", data, groups=data["Pig"])
mdf = md.fit()
>>> print(mdf.summary())
         Mixed Linear Model Regression Results
========================================================
Model:            MixedLM Dependent Variable: Weight    
No. Observations: 861     Method:             REML      
No. Groups:       72      Scale:              11.3669   
Min. group size:  11      Likelihood:         -2404.7753
Max. group size:  12      Converged:          Yes       
Mean group size:  12.0                                  
--------------------------------------------------------
             Coef.  Std.Err.    z    P>|z| [0.025 0.975]
--------------------------------------------------------
Intercept    15.724    0.788  19.952 0.000 14.179 17.268
Time          6.943    0.033 207.939 0.000  6.877  7.008
groups RE    40.394    2.149                            
========================================================






###Statsmodel-QuickIntro - sm.GEE,smf.gee, sm.cov_struct - Generalized Estimating Equations

#Note GLM assumes that data are independent given the covariates( independent variable)
#Instead, there will almost certainly be autocorrelations, 
#for example, two observations of the same individual closer in time 
#will be more similar than two observations further apart in time

#Second, GLM uses an enormous number of degrees of freedom(ie no of observations)
#estimating a parameter for each covariate

#GEE  is specified with a correlational structure (such as AR(1)), 
#GEE estimates the population mean association, , 
#hence does not uses huge degree of freedom for each covariate

#Assumptions 
1.The responses Y1,Y2,…,Yn  are correlated or clustered
2.There is a linear relationship between the covariates 
   and a transformation of the response, described by the link function g 
3.Within-subject covariance has some structure ('working covariance'):
  Note coefficients would be estimated correctly 
  even if the working covariance structure is wrong
  But the standard errors computed from this will be wrong
  To fix this , use GEE with the Huber-White 'sandwich estimator' for robustness. 
  Few structures are 
    •independence (observations over time are independent)
    •exchangeable (all observations over time have the same correlation)
    •AR(1) (correlation decreases as a power of how many timepoints apart two observations are)
    •unstructured (correlation between all timepoints may be different)


#The dependence structures currently implemented are
#sm.cov_struct
#check detailed help via help(sm.cov_struct.CLASS_NAME)
CovStruct([cov_nearest_method])         A base class for correlation and covariance structures of grouped data. 
Autoregressive([dist_func])             A first-order autoregressive working dependence structure. 
Exchangeable()                          An exchangeable working dependence structure. 
GlobalOddsRatio(endog_type)             Estimate the global odds ratio for a GEE with ordinal or nominal data. 
Independence([cov_nearest_method])      An independence working dependence structure. 
Nested([cov_nearest_method])            A nested working dependence structure. 
Equivalence                             A covariance structure defined in terms of equivalence classes
NominalIndependence                     An independence covariance structure for ordinal models.
OrdinalIndependence                     An independence covariance structure for ordinal models.
Stationary                              A stationary covariance structure.




#Example 
import statsmodels.api as sm
import statsmodels.formula.api as smf
data = sm.datasets.get_rdataset('epil', package='MASS').data
>>> dir(sm.families.family)
['Binomial', 'FLOAT_EPS', 'Family', 'Gamma', 'Gaussian', 'InverseGaussian', 'L',
 'NegativeBinomial', 'Poisson', 'Tweedie', 'V', '__builtins__', '__cached__', '_
_doc__', '__file__', '__loader__', '__name__', '__package__', '__spec__', 'np',
'special']
>>> sm.families.family.<familyname>.links
fam = sm.families.Poisson()
ind = sm.cov_struct.Exchangeable()
mod = smf.gee("y ~ age + trt + base", "subject", data,cov_struct=ind, family=fam)
res = mod.fit()
>>> print(res.summary())
                               GEE Regression Results                              
===================================================================================
Dep. Variable:                           y   No. Observations:                  236
Model:                                 GEE   No. clusters:                       59
Method:                        Generalized   Min. cluster size:                   4
                      Estimating Equations   Max. cluster size:                   4
Family:                            Poisson   Mean cluster size:                 4.0
Dependence structure:         Exchangeable   Num. iterations:                    51
Date:                     Tue, 28 Feb 2017   Scale:                           1.000
Covariance type:                    robust   Time:                         21:36:10
====================================================================================
                       coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------------
Intercept            0.5730      0.361      1.589      0.112      -0.134       1.280
trt[T.progabide]    -0.1519      0.171     -0.888      0.375      -0.487       0.183
age                  0.0223      0.011      1.960      0.050    2.11e-06       0.045
base                 0.0226      0.001     18.451      0.000       0.020       0.025
==============================================================================
Skew:                          3.7823   Kurtosis:                      28.6672
Centered skew:                 2.7597   Centered kurtosis:             21.9865
==============================================================================

##Marginal effect 
marg = result.get_margeff()
#or 
from statsmodels.genmod.generalized_estimating_equations import GEEMargins
geem = GEEMargins(results)
print(geem.summary())



###Statsmodel-QuickIntro - sm.NominalGEE, smf.nominal_gee
#GEE for nominal response variable(ie categorical - binomial or multimonial)
#nominal scales are kind of like 'names' or labels or class


#Example 
#np.r_ : appending all elements 
endog = np.r_[0, 0, 0, 0, 1, 1, 1, 1]
#8 observations of two features , 8x2
exog = np.ones((8, 2))
#all rows, second column 
exog[:, 1] = np.r_[1, 2, 1, 1, 2, 1, 2, 2]

groups = np.arange(8)
model = sm.NominalGEE(endog, exog, groups)
result = model.fit(cov_type='naive', start_params=[3.295837, -2.197225])
marg = result.get_margeff()
fig = result.plot_distribution()





###Statsmodel-QuickIntro - sm.OrdinalGEE, smf.ordinal_gee
#GEE for ordinal response variable 
#ordinal : order of the values is what's important and significant, 
#          but the differences between each one is not really known
#Ordinal scales are typically measures of non-numeric concepts like satisfaction, happiness, discomfort, etc.
#http://www.mymarketresearchmethods.com/types-of-data-nominal-ordinal-interval-ratio/

from statsmodels.compat import lrange
from statsmodels.compat.testing import skipif

import numpy as np
import os

from numpy.testing import (assert_almost_equal, assert_equal, assert_allclose,
                           assert_array_less, assert_raises, assert_, dec)
from statsmodels.genmod.generalized_estimating_equations import (
    GEE, OrdinalGEE, NominalGEE, NominalGEEResults, OrdinalGEEResults,
    NominalGEEResultsWrapper, OrdinalGEEResultsWrapper)
from statsmodels.genmod.families import Gaussian, Binomial, Poisson
from statsmodels.genmod.cov_struct import (Exchangeable, Independence,
                                           GlobalOddsRatio, Autoregressive,
                                           Nested, Stationary)
import pandas as pd
import statsmodels.formula.api as smf
import statsmodels.api as sm
from scipy.stats.distributions import norm
import warnings
def load_data(fname, icept=True):
    """
    Load a data set from the results directory.  The data set should
    be a CSV file with the following format:

    Column 0: Group indicator
    Column 1: endog variable
    Columns 2-end: exog variables

    If `icept` is True, an intercept is prepended to the exog
    variables.
    """
    cur_dir = os.path.dirname(os.path.abspath(__file__))
    Z = np.genfromtxt(os.path.join(cur_dir, 'results', fname), delimiter=",")
    group = Z[:, 0]
    endog = Z[:, 1]
    exog = Z[:, 2:]
    if icept:
        exog = np.concatenate((np.ones((exog.shape[0], 1)), exog),axis=1)
    return endog, exog, group

#Example 
family = Binomial()
endog, exog, groups = load_data("gee_ordinal_1.csv",icept=False)

va = GlobalOddsRatio("ordinal")
mod = OrdinalGEE(endog, exog, groups, None, family, va)
rslt = mod.fit()
>>> rslt.params
[1.09250002, 0.0217443, -0.39851092, -0.01812116, 0.03023969, 1.18258516, 0.01803453, -1.10203381]
fig = rslt.plot_distribution()
marg = rslt.get_margeff()
        
#Another example 
np.random.seed(434)
n = 40
y = np.random.randint(0, 3, n)
groups = np.arange(n)
x1 = np.random.normal(size=n)
x2 = np.random.normal(size=n)

df = pd.DataFrame({"y": y, "groups": groups, "x1": x1, "x2": x2})

# smoke test
model = OrdinalGEE.from_formula("y ~ 0 + x1 + x2", groups, data=df)
model.fit()
fig = rslt.plot_distribution()


        
        
        
        
        
        
        
###Statsmodel-QuickIntro - sm.SurvfuncRight
#Estimation and inference for a survival function for right censored data 


#A typical example is a medical study in which the origin is the time 
#at which a subject is diagnosed with some condition, 
#and the event of interest is death (or disease progression, recovery, etc.).
#Right censored means some subjects  do not achieve event of interest during duration of obs

#http://blog.minitab.com/blog/michelle-paret/the-difference-between-right-left-and-interval-censored-data


#Example 
import statsmodels.api as sm
data = sm.datasets.get_rdataset("flchain", "survival").data
#all columns for rows where sex is 'F' 
df = data.loc[data.sex == "F", :]
sf = sm.SurvfuncRight(df["futime"], df["death"])

#Summary 
sf.summary().head()

#point estimates and confidence intervals for quantiles of the survival distribution. 
#Since only around 30% of the subjects died during this study, 
#we can only estimate quantiles below the 0.3 probability point:
sf.quantile(0.25)
sf.quantile_ci(0.25)

#To plot a single survival function
sf.plot()

#Since this is a large dataset with a lot of censoring, 
#we may wish to not plot the censoring symbols:
fig = sf.plot()
ax = fig.get_axes()[0]
pt = ax.get_lines()[1]
pt.set_visible(False)

#We can also add a 95% simultaneous confidence band to the plot.
#Typically these bands only plotted for central part of the distribution.
fig = sf.plot()
lcb, ucb = sf.simultaneous_cb()
ax = fig.get_axes()[0]
ax.fill_between(sf.surv_times, lcb, ucb, color='lightgrey')
ax.set_xlim(365, 365*10)
ax.set_ylim(0.7, 1)
ax.set_ylabel("Proportion alive")
ax.set_xlabel("Days since enrollment")

#Here we plot survival functions for two groups (females and males) 
#on the same axes:
gb = data.groupby("sex")
ax = plt.axes()
sexes = []
for g in gb:
    sexes.append(g[0])
    sf = sm.SurvfuncRight(g[1]["futime"], g[1]["death"])
    sf.plot(ax)
li = ax.get_lines()
li[1].set_visible(False)
li[3].set_visible(False)
plt.figlegend((li[0], li[2]), sexes, "center right")
plt.ylim(0.6, 1)
ax.set_ylabel("Proportion alive")
ax.set_xlabel("Days since enrollment")


#compare two survival distributions with survdiff, 
#The default procedure is the logrank test:
stat, pv = sm.duration.survdiff(data.futime, data.death, data.sex)

# Fleming-Harrington with p=1, i.e. weight by pooled survival time
stat, pv = sm.duration.survdiff(data.futime, data.death, data.sex, weight_type='fh', fh_p=1)

# Gehan-Breslow, weight by number at risk
stat, pv = sm.duration.survdiff(data.futime, data.death, data.sex, weight_type='gb')
# Tarone-Ware, weight by the square root of the number at risk
stat, pv = sm.duration.survdiff(data.futime, data.death, data.sex, weight_type='tw')




###Statsmodel-QuickIntro - sm.PHReg, smf.phreg
#Fit the Cox proportional hazards regression model for right censored data.
#Right censoring means during study time, failures don't happen 


#Survival models relate the time that passes before some event occurs to one 
#or more covariates that may be associated with that quantity of time. 

#In a proportional hazards model, the effect of  unit increase in a covariate 
#is multiplicative with respect to the hazard rate. 

#For example, taking a drug may halve one's hazard rate for a stroke occurring, 
#or, changing the material from which a manufactured component is constructed 
#may double its hazard rate for failure. 

#Other types of survival models such as accelerated failure time models 
#do not exhibit proportional hazards. 

#The accelerated failure time model describes a situation 
#where the biological or mechanical life history of an event is accelerated.

#It has similar methods fo any regression class 
statsmodels.duration.hazard_regression.PHReg(endog, exog[, status, entry, strata, ...])
    Fit the Cox proportional hazards regression model for right censored data. 
    ties : string,The method used to handle tied times, must be either 'breslow' or 'efron'.
    status : array-like,The censoring status values; status=1 indicates that an event occured (e.g. failure or death), status=0 indicates that the observation was right censored.


#The result class is- It has similar methods of any result class 
statsmodels.duration.hazard_regression.PHRegResults(model, params, cov_params[, ...]) 
#methods of result 
bse()                                               Returns the standard errors of the parameter estimates. 
conf_int([alpha, cols, method])                     Returns the confidence interval of the fitted parameters. 
cov_params([r_matrix, column, scale, cov_p, ...])   Returns the variance/covariance matrix. 
normalized_cov_params() 
weighted_covariate_averages()                       The average covariate values within the at-risk set at each event time point, weighted by hazard. 
f_test(r_matrix[, cov_p, scale, invcov])            Compute the F-test for a joint linear hypothesis. 
t_test(r_matrix[, cov_p, scale, use_t])             Compute a t-test for a each linear hypothesis of the form Rb = q 
wald_test(r_matrix[, cov_p, scale, invcov, ...])    Compute a Wald-test for a joint linear hypothesis. 
martingale_residuals()                              The martingale residuals. 
schoenfeld_residuals()                              A matrix containing the Schoenfeld residuals. 
score_residuals()                                   A matrix containing the score residuals. 
standard_errors()                                   Returns the standard errors of the parameter estimates.
predict([endog, exog, strata, offset, pred_type])   Returns predicted values from the fitted proportional hazards regression model. 
pvalues()  
tvalues()                                           Return the t-statistic for a given parameter estimate. 
summary([yname, xname, title, alpha])               Summarize the proportional hazards regression results. 


##Example 
import statsmodels.api as sm
import statsmodels.formula.api as smf
data = sm.datasets.get_rdataset("flchain", "survival").data
del data["chapter"]
data = data.dropna()
data["lam"] = data["lambda"]
data["female"] = (data["sex"] == "F").astype(int)
data["year"] = data["sample.yr"] - min(data["sample.yr"])
status = data["death"].values
mod = smf.phreg("futime ~ 0 + age + female + creatinine + "
                "np.sqrt(kappa) + np.sqrt(lam) + year + mgus",
                data, status=status, ties="efron")
rslt = mod.fit()
print(rslt.summary())







##Another Example  -with dummy data 
#check other data sets - https://vincentarelbundock.github.io/Rdatasets/datasets.html




import numpy as np
import pandas as pd
from statsmodels.duration.hazard_regression import PHReg




#simulated data set with 1000 observations and no censoring. 
#The event times for the first 500 observations are distributed as standard exponential values, 
#which implies that the hazard function has a constant value of 1, 
#and the cumulative hazard function has the graph y = x. 

#The event times in the second set of 500 values are exponentially distributed 
#with mean 2, which implies that the hazard function has a constant value of 1/2, 
#and the cumulative hazard function follows the graph y = x/2.


exog = np.zeros(1000)
exog[500:] = 1
endog = -np.exp(np.log(2)*exog) * np.log(np.random.uniform(size=1000))

mod = PHReg(endog, exog)
rslt = mod.fit()
>>> print(rslt.summary())
                     Results: PHReg
========================================================
Model:                   PH Reg     Sample size:    1000
Dependent variable:      y          Num. events:    1000
Ties:                    Breslow                        
--------------------------------------------------------
    log HR log HR SE   HR      t    P>|t|  [0.025 0.975]
--------------------------------------------------------
x1 -0.6573    0.0664 0.5183 -9.8917 0.0000 0.4550 0.5904
========================================================
Confidence intervals are for the hazard ratios


#The baseline hazard function corresponds to a subject with exog == 0, 
#and having a cumulative hazard function equal to y = x.
bch = rslt.baseline_cumulative_hazard
bch = bch[0] # Only one stratum here
time, cumhaz, surv = tuple(bch)
plt.clf()
plt.plot(time, cumhaz, '-o', alpha=0.6)
plt.grid(True)
plt.xlabel("Time")
plt.ylabel("Cumulative hazard")

# we can use the predict function to recover the cumulative hazard functions 
#for the two subgroups of the data corresponding to exog == 0 and exog == 1.
chaz = rslt.predict(pred_type='cumhaz')
chaz = chaz.predicted_values
plt.clf()
plt.plot(endog[0:500], chaz[0:500], 'o', label='x=0')
plt.plot(endog[500:], chaz[500:], 'o', label='x=1')
leg = plt.legend(numpoints=1, handletextpad=0.0001, loc='lower right')
leg.draw_frame(False)
plt.grid(True)
plt.xlabel("Time")
plt.ylabel("Cumulative hazard")


#Here are plots of the estimated survival functions for these two groups.
chaz = rslt.predict(pred_type='surv')
chaz = chaz.predicted_values
plt.clf()
plt.plot(endog[0:500], chaz[0:500], 'o', label='x=0')
plt.plot(endog[500:], chaz[500:], 'o', label='x=1')
leg = plt.legend(numpoints=1, handletextpad=0.0001, loc='upper right')
leg.draw_frame(False)
plt.grid(True)
plt.xlabel("Time")
plt.ylabel("Survival probability")










###Statsmodel-QuickIntro - sm.QuantReg, smf.quantreg
#Estimate a quantile regression model using iterative reweighted least squares

#Whereas the method of least squares results in 
#estimates of the conditional mean of the response variable 
#given certain values of the predictor variables, 
#quantile regression aims at estimating either the conditional median 
#or other quantiles of the response variable. 

#quantile regression estimates are more robust against outliers in the response measurements

#Example 
%matplotlib inline
from __future__ import print_function
import patsy
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
import matplotlib.pyplot as plt
from statsmodels.regression.quantile_regression import QuantReg
data = sm.datasets.engel.load_pandas().data
data.head()
mod = smf.quantreg('foodexp ~ income', data)
res = mod.fit(q=.5)
print(res.summary())

#Prepare data for plotting

quantiles = np.arange(.05, .96, .1)
def fit_model(q):
    res = mod.fit(q=q)
    return [q, res.params['Intercept'], res.params['income']] + \
            res.conf_int().ix['income'].tolist()
    
models = [fit_model(x) for x in quantiles]
models = pd.DataFrame(models, columns=['q', 'a', 'b','lb','ub'])
ols = smf.ols('foodexp ~ income', data).fit()
ols_ci = ols.conf_int().ix['income'].tolist()
ols = dict(a = ols.params['Intercept'],
           b = ols.params['income'],
           lb = ols_ci[0],
           ub = ols_ci[1])
print(models)
print(ols)

##First plot
#This plot compares best fit lines for 10 quantile regression models 
#to the least squares fit. 
#result 
1.Food expenditure increases with income
2.The dispersion of food expenditure increases with income
3.The least squares estimates fit low income observations quite poorly (i.e. the OLS line passes over most low income households)

x = np.arange(data.income.min(), data.income.max(), 50)
get_y = lambda a, b: a + b * x
fig, ax = plt.subplots(figsize=(8, 6))
for i in range(models.shape[0]):
    y = get_y(models.a[i], models.b[i])
    ax.plot(x, y, linestyle='dotted', color='grey')
    
y = get_y(ols['a'], ols['b'])
ax.plot(x, y, color='red', label='OLS')
ax.scatter(data.income, data.foodexp, alpha=.2)
ax.set_xlim((240, 3000))
ax.set_ylim((240, 2000))
legend = ax.legend()
ax.set_xlabel('Income', fontsize=16)
ax.set_ylabel('Food expenditure', fontsize=16);

##Second plot
#The dotted black lines form 95% point-wise confidence band around 10 quantile regression estimates (solid black line). 
#The red lines represent OLS regression results along with their 95% confindence interval.
#In most cases, the quantile regression point estimates lie outside the OLS confidence interval, 
#which suggests that the effect of income on food expenditure may not be constant across the distribution.

n = models.shape[0]
p1 = plt.plot(models.q, models.b, color='black', label='Quantile Reg.')
p2 = plt.plot(models.q, models.ub, linestyle='dotted', color='black')
p3 = plt.plot(models.q, models.lb, linestyle='dotted', color='black')
p4 = plt.plot(models.q, [ols['b']] * n, color='red', label='OLS')
p5 = plt.plot(models.q, [ols['lb']] * n, linestyle='dotted', color='red')
p6 = plt.plot(models.q, [ols['ub']] * n, linestyle='dotted', color='red')
plt.ylabel(r'$\beta_{income}$')
plt.xlabel('Quantiles of the conditional food expenditure distribution')
plt.legend()
plt.show()




###Statsmodel-QuickIntro - sm.RLM, smf.rlm
#Robust linear models with support for the M-estimators listed under Norms
#robust against outliers
#eg Heteroscedasticity allows the variance of error term to be dependent on x


#It requires Norm and SCale 
#M-estimator  minimizes a function of influence observations based on residuals with a scale
#robust estimates are computed by the iterative WLS of M-Estimators
#These weights of WLS are called Norms , each norm has default scale function
norms = sm.robust.norms


#Norms - use with prefix sm.robust.norms.
AndrewWave([a])         Andrew's wave for M estimation. 
Hampel([a, b, c])       Hampel function for M-estimation. 
HuberT([t])             Huber's T for M estimation. 
LeastSquares            Least squares rho for M-estimation and its derived functions. 
RamsayE([a])            Ramsay's Ea for M estimation. 
RobustNorm              The parent class for the norms used for robust regression. 
TrimmedMean([c])        Trimmed mean function for M-estimation. 
TukeyBiweight([c])      Tukey's biweight function for M-estimation. 
estimate_location(a, scale[, norm, axis, ...]) M-estimator of location using self.norm and a current estimator of scale. 


#Scale - use with sm.robust.scale 
Huber([c, tol, maxiter, norm])      Huber's proposal 2 for estimating location and scale jointly. 
HuberScale([d, tol, maxiter])       Huber's scaling for fitting robust linear models. 
mad(a[, c, axis, center])           The Median Absolute Deviation along given axis of an array 
huber                               Huber's proposal 2 for estimating location and scale jointly. 
hubers_scale                        Huber's scaling for fitting robust linear models. 
stand_mad(a[, c, axis]) 




##Example 
from __future__ import print_function
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
from statsmodels.sandbox.regression.predstd import wls_prediction_std


data = sm.datasets.stackloss.load()
data.exog = sm.add_constant(data.exog)

#Huber's T norm with the (default) median absolute deviation scaling
huber_t = sm.RLM(data.endog, data.exog, M=sm.robust.norms.HuberT())
hub_results = huber_t.fit()
print(hub_results.params)
print(hub_results.bse)
print(hub_results.summary(yname='y',
            xname=['var_%d' % i for i in range(len(hub_results.params))]))

#uber's T norm with 'H2' covariance matrix
hub_results2 = huber_t.fit(cov="H2")
print(hub_results2.params)
print(hub_results2.bse)
#output 
[-41.02649835   0.82938433   0.92606597  -0.12784672]
[ 9.08950419  0.11945975  0.32235497  0.11796313]

#Andrew's Wave norm with Huber's Proposal 2 scaling and 'H3' covariance matrix
andrew_mod = sm.RLM(data.endog, data.exog, M=sm.robust.norms.AndrewWave())
andrew_results = andrew_mod.fit(scale_est=sm.robust.scale.HuberScale(), cov="H3")
print('Parameters: ', andrew_results.params)
Parameters:  [-40.8817957    0.79276138   1.04857556  -0.13360865]

>>> help(sm.RLM.fit) for more options 
>>> dir(sm.robust.scale) # for scale options


##Comparing OLS and RLM

nsample = 50
x1 = np.linspace(0, 20, nsample)
X = np.column_stack((x1, (x1-5)**2))
X = sm.add_constant(X)
sig = 0.3   # smaller error variance makes OLS<->RLM contrast bigger
beta = [5, 0.5, -0.0]
y_true2 = np.dot(X, beta)
y2 = y_true2 + sig*1. * np.random.normal(size=nsample)
y2[[39,41,43,45,48]] -= 5   # add some outliers (10% of nsample)

#Example 1: quadratic function with linear truth
#Note that the quadratic term in OLS regression will capture outlier effects.
res = sm.OLS(y2, X).fit()
print(res.params)
print(res.bse)
print(res.predict())

#Estimate RLM:
resrlm = sm.RLM(y2, X).fit()
print(resrlm.params)
print(resrlm.bse)  #SE terms ie std deviation of each parameter estimation(ie mean)
[  4.98830133e+00   5.21124476e-01  -3.95637732e-03]
[ 0.1177946   0.0181859   0.00160917]

#Draw a plot to compare OLS estimates to the robust estimates:
fig = plt.figure(figsize=(12,8))
ax = fig.add_subplot(111)
ax.plot(x1, y2, 'o',label="data")
ax.plot(x1, y_true2, 'b-', label="True")
prstd, iv_l, iv_u = wls_prediction_std(res)
ax.plot(x1, res.fittedvalues, 'r-', label="OLS")
ax.plot(x1, iv_u, 'r--')
ax.plot(x1, iv_l, 'r--')
ax.plot(x1, resrlm.fittedvalues, 'g.-', label="RLM")
ax.legend(loc="best")


#Example 2: linear function with linear truth
#Fit a new OLS model using only the linear term and the constant:
X2 = X[:,[0,1]] 
res2 = sm.OLS(y2, X2).fit()
print(res2.params)
print(res2.bse)
#output 
[ 5.59260775  0.39611497]
[ 0.39150044  0.03373326]
#Estimate RLM:
resrlm2 = sm.RLM(y2, X2).fit()
print(resrlm2.params)
print(resrlm2.bse)
#output 
[ 5.11833224  0.48612219]
[ 0.09516649  0.00819993]
#Draw a plot to compare OLS estimates to the robust estimates:
prstd, iv_l, iv_u = wls_prediction_std(res2)
fig, ax = plt.subplots(figsize=(8,6))
ax.plot(x1, y2, 'o', label="data")
ax.plot(x1, y_true2, 'b-', label="True")
ax.plot(x1, res2.fittedvalues, 'r-', label="OLS")
ax.plot(x1, iv_u, 'r--')
ax.plot(x1, iv_l, 'r--')
ax.plot(x1, resrlm2.fittedvalues, 'g.-', label="RLM")
legend = ax.legend(loc="best")
    
    
    
    
 

###Statsmodel-QuickIntro - sm.MICE, sm.MICEData
#Multiple Imputation with Chained Equations.
#(to impute - to assign )


#Note (imputed data set - missing value is assigned via some method(called MICE) )
* If the goal is only to produce imputed data sets, the MICEData class
can be used to wrap a data frame, providing facilities for doing the
imputation.  Summary plots are available for assessing the performance
of the imputation.

* If the imputed data sets are to be used to fit an additional
'analysis model', a MICE instance can be used.  After specifying the
MICE instance and running it, the results are combined using the
`combine` method.  Results and various summary plots are then
available.

#Note below data is used 
def gendat():
    """
    Create a data set with missing values.
    """
    np.random.seed(34243)
    n = 200
    p = 5
    exog = np.random.normal(size=(n, p))
    exog[:, 0] = exog[:, 1] - exog[:, 2] + 2*exog[:, 4]
    exog[:, 0] += np.random.normal(size=n)
    exog[:, 2] = 1*(exog[:, 2] > 0)
    endog = exog.sum(1) + np.random.normal(size=n)

    df = pd.DataFrame(exog)
    df.columns = ["x%d" % k for k in range(1, p+1)]
    df["y"] = endog
    df.x1[0:60] = np.nan
    df.x2[0:40] = np.nan
    df.x3[10:30:2] = np.nan
    df.x4[20:50:3] = np.nan
    df.x5[40:45] = np.nan
    df.y[30:100:2] = np.nan

    return df
    
    
data = gendat()


#sm.MICE can be used to fit most Statsmodels models to data sets 
#with missing values using the 'multiple imputation with chained equations' (MICE) approach..

#Run all MICE steps and obtain results
#Fit fml to the model OLS, but with imputed data, imp
>>> imp = sm.MICEData(data)
>>> fml = 'y ~ x1 + x2 + x3 + x4'
>>> mice = sm.MICE(fml, sm.OLS, imp)
#Or another example 
mice = sm.MICE("x3 ~ x1 + x2", sm.GLM, imp,init_kwds={"family": sm.families.Binomial()})

#n_burnin : int,The number of burn-in cycles to skip.
#n_imputations : int,The number of data sets to impute
>>> results = mice.fit(10, 10)  #MICEResults, subclass of LikelihoodModelResults
>>> print(results.summary())



                              Results: MICE
    =================================================================
    Method:                    MICE       Sample size:           1000
    Model:                     OLS        Scale                  1.00
    Dependent variable:        y          Num. imputations       10
    -----------------------------------------------------------------
               Coef.  Std.Err.    t     P>|t|   [0.025  0.975]  FMI
    -----------------------------------------------------------------
    Intercept -0.0234   0.0318  -0.7345 0.4626 -0.0858  0.0390 0.0128
    x1         1.0305   0.0578  17.8342 0.0000  0.9172  1.1437 0.0309
    x2        -0.0134   0.0162  -0.8282 0.4076 -0.0451  0.0183 0.0236
    x3        -1.0260   0.0328 -31.2706 0.0000 -1.0903 -0.9617 0.0169
    x4        -0.0253   0.0336  -0.7520 0.4521 -0.0911  0.0406 0.0269
    =================================================================


#Example 
>>> imp = mice.MICEData(data)
>>> fml = 'y ~ x1 + x2 + x3 + x4'
>>> mice = mice.MICE(fml, sm.OLS, imp)
>>> results = []
>>> for k in range(10):
        #A single MICE iteration updates all missing values using their
        #respective imputation models, then fits the analysis model to the imputed data.
        #Use `fit` to run all MICE steps together and obtain summary results
        x = mice.next_sample()
        results.append(x)

#Draw 20 imputations from a data set called `data` and save them in
#separate files with filename pattern `dataXX.csv`.  The variables
#other than x1,x2,x3 are imputed using linear models fit with OLS, with
#mean structures containing main effects of all other variables in
#`data`.  The variable named `x1`,x2,x3 are imputed with given formula 
>>> imp = sm.MICEData(data)
imp.set_imputer('x1', 'x3 + x4 + x3*x4')
imp.set_imputer('x2', 'x4 + I(x5**2)')
imp.set_imputer('x3', model_class=sm.GLM, init_kwds={"family": sm.families.Binomial()})
>>> for j in range(20):
        imp.update_all()
        imp.data.to_csv('data%02d.csv' % j)

#Impute using default models, using the MICEData object as an iterator.
>>> imp = sm.MICEData(data)
>>> j = 0
>>> for data in imp:
        imp.data.to_csv('data%02d.csv' % j)
        j += 1
        
##Methods of sm.MICEData
next_sample()        
    Returns the next imputed dataset in the imputation process.
set_imputer(endog_name, formula=None, init_kwds={})
    Specify the imputation process for a single variable.
    endog_name : string
        Name of the variable to be imputed.
    formula : string
        Conditional formula for imputation. Defaults to a formula
        with main effects for all other variables in dataset.  The
        formula should only include an expression for the mean
        structure, e.g. use 'x1 + x2' not 'x4 ~ x1 + x2'     
update_all(n_iter=1):
    Perform a specified number of MICE iterations  
    The imputed values are stored in the class attribute self.data
plot_missing_pattern(ax=None)
    A figure containing a plot of the missing data pattern.
plot_bivariate(self, col1_name, col2_name,ax=None):
    Plot observed and imputed values for two variables.
    Displays a scatterplot of one variable against another.  The
    points are colored according to whether the values are
    observed or imputed.       
plot_fit_obs(self, col_name, ax=None):
    Plot fitted versus imputed or observed values as a scatterplot.        
def plot_imputed_hist(self, col_name, ax=None)
    Display imputed values for one variable as a histogram.   

    
###Statsmodel -QuickIntro - cross validation 
statsmodels.sandbox.tools.cross_val
    class LeaveOneOut(n):
        Leave-One-Out cross validation iterator:
        Provides train/test indexes to split data in train test sets
            Parameters
            ----------
            n: int
                Total number of elements

            Examples
            --------
            >>> from scikits.learn import cross_val
            >>> X = [[1, 2], [3, 4]]
            >>> y = [1, 2]
            >>> loo = cross_val.LeaveOneOut(2)
            >>> for train_index, test_index in loo:
            ...    print "TRAIN:", train_index, "TEST:", test_index
            ...    X_train, X_test, y_train, y_test = cross_val.split(train_index, test_index, X, y)
            ...    print X_train, X_test, y_train, y_test
            TRAIN: [False  True] TEST: [ True False]
            [[3 4]] [[1 2]] [2] [1]
            TRAIN: [ True False] TEST: [False  True]
            [[1 2]] [[3 4]] [1] [2]
            
    class LeavePOut(n, p):
        Leave-P-Out cross validation iterator:
        Provides train/test indexes to split data in train test sets
            Parameters
            ----------
            n: int
                Total number of elements
            p: int
                Size test sets

            Examples
            --------
            >>> from scikits.learn import cross_val
            >>> X = [[1, 2], [3, 4], [5, 6], [7, 8]]
            >>> y = [1, 2, 3, 4]
            >>> lpo = cross_val.LeavePOut(4, 2)
            >>> for train_index, test_index in lpo:
            ...    print "TRAIN:", train_index, "TEST:", test_index
            ...    X_train, X_test, y_train, y_test = cross_val.split(train_index, test_index, X, y)
            TRAIN: [False False  True  True] TEST: [ True  True False False]
            TRAIN: [False  True False  True] TEST: [ True False  True False]
            TRAIN: [False  True  True False] TEST: [ True False False  True]
            TRAIN: [ True False False  True] TEST: [False  True  True False]
            TRAIN: [ True False  True False] TEST: [False  True False  True]
            TRAIN: [ True  True False False] TEST: [False False  True  True]
            
    class KFold(n, k):
        K-Folds cross validation iterator:
        Provides train/test indexes to split data in train test sets
            Parameters
            ----------
            n: int
                Total number of elements
            k: int
                number of folds

            Examples
            --------
            >>> from scikits.learn import cross_val
            >>> X = [[1, 2], [3, 4], [1, 2], [3, 4]]
            >>> y = [1, 2, 3, 4]
            >>> kf = cross_val.KFold(4, k=2)
            >>> for train_index, test_index in kf:
            ...    print "TRAIN:", train_index, "TEST:", test_index
            ...    X_train, X_test, y_train, y_test = cross_val.split(train_index, test_index, X, y)
            TRAIN: [False False  True  True] TEST: [ True  True False False]
            TRAIN: [ True  True False False] TEST: [False False  True  True]

            
    class LeaveOneLabelOut(labels):
        Leave-One-Label_Out cross-validation iterator:
        Provides train/test indexes to split data in train test sets
            Parameters
            ----------
            labels : list
                    List of labels

            Examples
            --------
            >>> from scikits.learn import cross_val
            >>> X = [[1, 2], [3, 4], [5, 6], [7, 8]]
            >>> y = [1, 2, 1, 2]
            >>> labels = [1, 1, 2, 2]
            >>> lol = cross_val.LeaveOneLabelOut(labels)
            >>> for train_index, test_index in lol:
            ...    print "TRAIN:", train_index, "TEST:", test_index
            ...    X_train, X_test, y_train, y_test = cross_val.split(train_index, \
                test_index, X, y)
            ...    print X_train, X_test, y_train, y_test
            TRAIN: [False False  True  True] TEST: [ True  True False False]
            [[5 6]
            [7 8]] [[1 2]
            [3 4]] [1 2] [1 2]
            TRAIN: [ True  True False False] TEST: [False False  True  True]
            [[1 2]
            [3 4]] [[5 6]
            [7 8]] [1 2] [1 2]

            
    class KStepAhead( n, k=1, start=None, kall=True, return_slice=True):
        KStepAhead cross validation iterator:
        Provides fit/test indexes to split data in sequential sets
            Parameters
            ----------
            n: int
                Total number of elements
            k : int
                number of steps ahead
            start : int
                initial size of data for fitting
            kall : boolean
                if true. all values for up to k-step ahead are included in the test index.
                If false, then only the k-th step ahead value is returnd

            Examples
            --------
            >>> from scikits.learn import cross_val
            >>> X = [[1, 2], [3, 4]]
            >>> y = [1, 2]
            >>> loo = cross_val.LeaveOneOut(2)
            >>> for train_index, test_index in loo:
            ...    print "TRAIN:", train_index, "TEST:", test_index
            ...    X_train, X_test, y_train, y_test = cross_val.split(train_index, test_index, X, y)
            ...    print X_train, X_test, y_train, y_test
            TRAIN: [False  True] TEST: [ True False]
            [[3 4]] [[1 2]] [2] [1]
            TRAIN: [ True False] TEST: [False  True]
            [[1 2]] [[3 4]] [1] [2]

        
        

###Statsmodel-QuickIntro - sm.PCA
#Principal Component Analysis

PCA(data, ncomp=None, standardize=True, demean=True, normalize=True, 
            gls=False, weights=None, method='svd', missing=None, tol=5e-08, max_iter=1000, tol_em=5e-08, max_em_iter=100)[source]
    Parameters:
        data : array-like
            Variables in columns, observations in rows
        ncomp : int, optional
            Number of components to return. 
            If None, returns the as many as the smaller of the number of rows or columns in data
        standardize: bool, optional
            Flag indicating to use standardized data with mean 0 and unit variance. 
            standardized being True implies demean. 
            Using standardized data is equivalent to computing principal components 
            from the correlation matrix of data
        demean : bool, optional
            Flag indicating whether to demean data before computing principal components.
            demean is ignored if standardize is True. 
            Demeaning data but not standardizing is equivalent to computing 
            principal components from the covariance matrix of data
        normalize : bool , optional
            Indicates whether th normalize the factors to have unit inner product. 
            If False, the loadings will have unit inner product.
#Attributes 
factors (array or DataFrame) nobs by ncomp array of of principal components (scores) 
scores ( array or DataFrame) nobs by ncomp array of of principal components - identical to factors 
cols (array)                Array of indices indicating columns used in the PCA 
rows (array)                Array of indices indicating rows used in the PCA 
rsquare (array or Series)   ncomp array where the element in the ith position is the R-square of including the first i principal components. Note: values are calculated on the transformed data, not the original data 
ic (array or DataFrame)     ncomp by 3 array containing the Bai and Ng (2003) Information criteria. Each column is a different criteria, and each row represents the number of included factors. 


plot_scree([ncomp, log_scale, cumulative, ax])  Plot of the ordered eigenvalues 
plot_rsquare([ncomp, ax])                       Box plots of the individual series R-square against the number of PCs 
project([ncomp, transform, unweight])           Project series onto a specific number of factors 
                                                ie returns orginal data if used with infinite ncomp
                                                Returns:nobs by nvar array of the projection onto ncomp factors
 



#Example 
import statsmodels.api as sm

data = sm.datasets.fertility.load_pandas().data

columns = list(map(str, range(1960, 2012)))  #'1960'...'2012'
data.set_index('Country Name', inplace=True)

dta = data[columns]
dta = dta.dropna()
pca_model = sm.PCA(dta.T, standardize=False, demean=True)
pca_model.plot_scree()
>>> pca_model.factors.shape
>>> pca_model.project() # wth pcomp=None , get back original data 

#with 5 most important comp 
>>> pca_model = sm.PCA(dta.T, ncomp = 5, standardize=False, demean=True)
>>> pca_model.factors.shape
(52, 5)
>>> dta.head()
                       1960   1961   1962   1963   1964   1965   1966   1967  \
Country Name
Aruba                 4.820  4.655  4.471  4.271  4.059  3.842  3.625  3.417
Afghanistan           7.671  7.671  7.671  7.671  7.671  7.671  7.671  7.671
Angola                7.316  7.354  7.385  7.410  7.425  7.430  7.422  7.403
Albania               6.186  6.076  5.956  5.833  5.711  5.594  5.483  5.376
United Arab Emirates  6.928  6.910  6.893  6.877  6.861  6.841  6.816  6.783

>>> pca_model.project().T.head()
                          1960      1961      1962      1963      1964  \
Country Name
Aruba                 4.680162  4.585257  4.469843  4.318748  4.137293
Afghanistan           7.673737  7.664769  7.666142  7.653747  7.656124
Angola                7.394137  7.395607  7.394740  7.389772  7.383758
Albania               5.999994  5.979182  5.942319  5.884406  5.807943
United Arab Emirates  6.862526  6.891905  6.903761  6.909959  6.898611

>>> pca_model.rsquare
ncomp
0    0.000000
1    0.889399
2    0.969752
3    0.986427
4    0.992945
5    0.995896
Name: rsquare, dtype: float64
>>> pca_model.ic
          IC_p1     IC_p2     IC_p3
ncomp
0      9.366278  9.366278  9.366278
1      7.255162  7.261019  7.240440
2      6.049370  6.061085  6.019926
3      5.338730  5.356302  5.294564
4      4.775056  4.798486  4.716168
5      4.323965  4.353252  4.250355



#Principal Component Regression
statsmodels.sandbox.tools.pca(data, keepdim=0, normalize=0, demean=True)
    principal components with eigenvector decomposition
    similar to princomp in matlab
statsmodels.sandbox.tools.pcasvd(data, keepdim=0, demean=True)
    principal components with svd
    
    Parameters
    ----------
    data : ndarray, 2d
        data with observations by rows and variables in columns
    keepdim : integer
        number of eigenvectors to keep
        if keepdim is zero, then all eigenvectors are included
    normalize : boolean
        if true, then eigenvectors are normalized by sqrt of eigenvalues
    demean : boolean
        if true, then the column mean is subtracted from the data
    Returns
    -------
    xreduced : ndarray, 2d, (nobs, nvars)
        projection of the data x on the kept eigenvectors
    factors : ndarray, 2d, (nobs, nfactors) ** this is reduced factors 
        factor matrix, given by np.dot(x, evecs)
    evals : ndarray, 2d, (nobs, nfactors)
        eigenvalues
    evecs : ndarray, 2d, (nobs, nfactors)
        eigenvectors, normalized if normalize is true


#Example 
* simulate model with 2 factors and 4 explanatory variables
* use pca to extract factors from data,
* run OLS on factors,
* use information criteria to choose "best" model

#Warning: pca sorts factors by explaining variance in explanatory variables,
#which are not necessarily the most important factors for explaining the
#endogenous variable.

# try out partial correlation for dropping (or adding) factors
# get algorithm for partial least squares as an alternative to PCR

import numpy as np
from numpy.testing import assert_array_almost_equal
import statsmodels.api as sm
from statsmodels.sandbox.tools import pca
from statsmodels.sandbox.tools.cross_val import LeaveOneOut

nobs = 1000
#np.c_=columnwise append 
f0 = np.c_[np.random.normal(size=(nobs,2)), np.ones((nobs,1))]
#np.repeat(array,repeats,axis)
f2xcoef = np.c_[np.repeat(np.eye(2),2,0),np.arange(4)[::-1]].T 
f2xcoef = np.array([[ 1.,  1.,  0.,  0.],
                    [ 0.,  0.,  1.,  1.],
                    [ 3.,  2.,  1.,  0.]])
f2xcoef = np.array([[ 0.1,  3.,  1.,    0.],
                    [ 0.,  0.,  1.5,   0.1],
                    [ 3.,  2.,  1.,    0.]])
x0 = np.dot(f0, f2xcoef)
x0 += 0.1*np.random.normal(size=x0.shape)
ytrue = np.dot(f0,[1., 1., 1.])  #actual coeff 
y0 = ytrue + 0.1*np.random.normal(size=ytrue.shape)
xred, fact, eva, eve  = pca(x0, keepdim=0)
print(eve)
print(fact[:5])
print(f0[:5])
import statsmodels.api as sm
res = sm.OLS(y0, sm.add_constant(x0, prepend=False)).fit()
print('OLS on original data')
print(res.params)
print(res.aic)
print(res.rsquared)
#print 'OLS on Factors'
#for k in range(x0.shape[1]):
#    xred, fact, eva, eve  = pca(x0, keepdim=k, normalize=1)
#    fact_wconst = sm.add_constant(fact)
#    res = sm.OLS(y0, fact_wconst).fit()
#    print 'k =', k
#    print res.params
#    print 'aic:  ', res.aic
#    print 'bic:  ', res.bic
#    print 'llf:  ', res.llf
#    print 'R2    ', res.rsquared
#    print 'R2 adj', res.rsquared_adj
print('OLS on Factors')
results = []
xred, fact, eva, eve  = pca(x0, keepdim=0, normalize=1)
for k in range(0, x0.shape[1]+1):
    #xred, fact, eva, eve  = pca(x0, keepdim=k, normalize=1)
    # this is faster and same result
    fact_wconst = sm.add_constant(fact[:,:k], prepend=False)
    res = sm.OLS(y0, fact_wconst).fit()
##    print 'k =', k
##    print res.params
##    print 'aic:  ', res.aic
##    print 'bic:  ', res.bic
##    print 'llf:  ', res.llf
##    print 'R2    ', res.rsquared
##    print 'R2 adj', res.rsquared_adj
    prederr2 = 0.
    for inidx, outidx in LeaveOneOut(len(y0)):
        resl1o = sm.OLS(y0[inidx], fact_wconst[inidx,:]).fit()
        #print data.endog[outidx], res.model.predict(data.exog[outidx,:]),
        prederr2 += (y0[outidx] - resl1o.predict(fact_wconst[outidx,:]))**2.
    results.append([k, res.aic, res.bic, res.rsquared_adj, prederr2])
results = np.array(results)
print(results)
print('best result for k, by AIC, BIC, R2_adj, L1O')
print(np.r_[(np.argmin(results[:,1:3],0), np.argmax(results[:,3],0),
             np.argmin(results[:,-1],0))])
from statsmodels.iolib.table import (SimpleTable, default_txt_fmt,
                        default_latex_fmt, default_html_fmt)
headers = 'k, AIC, BIC, R2_adj, L1O'.split(', ')
numformat = ['%6d'] + ['%10.3f']*4 #'%10.4f'
txt_fmt1 = dict(data_fmts = numformat)
tabl = SimpleTable(results, headers, None, txt_fmt=txt_fmt1)
print("PCA regression on simulated data,")
print("DGP: 2 factors and 4 explanatory variables")
print(tabl)
print("Notes: k is number of components of PCA,")
print("       constant is added additionally")
print("       k=0 means regression on constant only")
print("       L1O: sum of squared prediction errors for leave-one-out")








###Statsmodel-QuickIntro - sm.add_constant

statsmodels.tools.tools.add_constant(data, prepend=True, has_constant='skip')
    Adds a column of ones to an array
    Required because linear model does not add intercept term. 
    Manually needs to be added by this class 
    When the input is recarray or a pandas Series or DataFrame,
    the added column's name is 'const'.
    data : array-like
    data is the column-ordered design matrix
    prepend : bool
        If true, the constant is in the first column. 
        Else the constant is appended (last column).
    has_constant : str {'raise', 'add', 'skip'}
        Behavior if data already has a constant. 
        The default will return data without adding another constant. 
        If 'raise', will raise an error if a constant is present. 
        Using 'add' will duplicate the constant, if one is present.
 

 
 
###Statsmodel-QuickIntro - sm.categorical
statsmodels.tools.tools.categorical(data, col=None, dictnames=False, drop=False)
    Returns a dummy matrix given an array of categorical variables.
    Parameters:
    data : array
        A structured array, recarray, or array. 
        This can be either a 1d vector of the categorical variable 
        or a 2d array with the column specifying the categorical variable 
        specified by the col argument.
    col : 'string', int, or None
        If data is a structured array or a recarray, 
        col can be a string that is the name of the column 
        that contains the variable. 
        For all arrays col can be an int that is the (zero-based) column index number. col can only be None for a 1d array. The default is None.
    dictnames : bool, optional
        If True, a dictionary mapping the column number to the categorical name is returned. 
        Used to have information about plain arrays.
    drop : bool
        Whether or not keep the categorical variable in the returned matrix.
    Returns:
        dummy_matrix, [dictnames, optional]
            A matrix of dummy (indicator/binary) float variables 
            for the categorical data. 
            If dictnames is True, then the dictionary is returned as well.
            This returns a dummy variable for EVERY distinct variable. 
            So if the a variable 'vote' had answers as 'yes' or 'no' 
            then the returned array would have to new variables– 'vote_yes' and 'vote_no'. 

#Examples
>>> import numpy as np
>>> import statsmodels.api as sm

#Univariate examples
>>> import string
>>> string_var = [string.ascii_lowercase[0:5],string.ascii_lowercase[5:10],                       string.ascii_lowercase[10:15],                       string.ascii_lowercase[15:20],                         string.ascii_lowercase[20:25]]
>>> string_var *= 5
>>> string_var = np.asarray(sorted(string_var))
>>> design = sm.tools.categorical(string_var, drop=True)

#Or for a numerical categorical variable
>>> instr = np.floor(np.arange(10,60, step=2)/10)
>>> design = sm.tools.categorical(instr, drop=True)

#With a structured array
>>> num = np.random.randn(25,2)
>>> struct_ar = np.zeros((25,1), dtype=[('var1', 'f4'),('var2', 'f4'),                      ('instrument','f4'),('str_instr','a5')])
>>> struct_ar['var1'] = num[:,0][:,None]
>>> struct_ar['var2'] = num[:,1][:,None]
>>> struct_ar['instrument'] = instr[:,None]
>>> struct_ar['str_instr'] = string_var[:,None]
>>> design = sm.tools.categorical(struct_ar, col='instrument', drop=True)
#Or
>>> design2 = sm.tools.categorical(struct_ar, col='str_instr', drop=True)




###Statsmodel-QuickIntro - sm.datasets
#provides data sets (i.e. data and meta-data) 

#from STATA
webuse(data[, baseurl, as_df])      Download and return an example dataset from Stata. 


#Using Datasets from R
import statsmodels.api as sm
duncan_prestige = sm.datasets.get_rdataset("Duncan", "car")
print(duncan_prestige.__doc__)


#Available Datasets in stats model 
    •American National Election Survey 1996
    •Breast Cancer Data
    •Bill Greene's credit scoring data.
    •Smoking and lung cancer in eight cities in China.
    •Mauna Loa Weekly Atmospheric CO2 Data
    •First 100 days of the US House of Representatives 1995
    •World Copper Market 1951-1975 Dataset
    •US Capital Punishment dataset.
    •El Nino - Sea Surface Temperatures
    •Engel (1857) food expenditure data
    •Affairs dataset
    •World Bank Fertility Data
    •Grunfeld (1950) Investment Data
    •Transplant Survival Data
    •Longley dataset
    •United States Macroeconomic data
    •Travel Mode Choice
    •Nile River flows at Ashwan 1871-1970
    •RAND Health Insurance Experiment Data
    •Taxation Powers Vote for the Scottish Parliamant 1997
    •Spector and Mazzeo (1980) - Program Effectiveness Data
    •Stack loss data
    •Star98 Educational Dataset
    •Statewide Crime Data 2009
    •U.S. Strike Duration Data
    •Yearly sunspots data 1700-2008

import statsmodels.api as sm
data = sm.datasets.longley.load()
#View Code
#The full dataset is available in the data attribute.
data.data

#attributes endog and exog for y and x
>>> data.endog[:5]
array([ 60323.,  61122.,  60171.,  61187.,  63221.])
data.exog[:5,:]

#Univariate datasets, however, do not have an exog attribute.
>>> data.endog_name
'TOTEMP'
>>> data.exog_name
['GNPDEFL', 'GNP', 'UNEMP', 'ARMED', 'POP', 'YEAR']
>>> type(data.data)
numpy.recarray
>>> type(data.raw_data)
numpy.recarray
>>> data.names
['TOTEMP', 'GNPDEFL', 'GNP', 'UNEMP', 'ARMED', 'POP', 'YEAR']

#Loading data as pandas objects
data = sm.datasets.longley.load_pandas()
data.exog
data.endog
data.data  #DF


#Extra Information
>>> dir(sm.datasets.longley)[:6]
['COPYRIGHT', 'DESCRLONG', 'DESCRSHORT', 'NOTE', 'SOURCE', 'TITLE']






###Statsmodel-QuickIntro - sm.distributions
#various additional functions and methods for statistical distributions.

#Empirical Distributions
ECDF(x[, side])                             Return the Empirical CDF of an array as a step function. 
StepFunction(x, y[, ival, sorted, side])    A basic step function. 
monotone_fn_inverter(fn, x[, vectorized])   Given a monotone function fn (no checking is done to verify monotonicity) and a set of x values, return an linearly interpolated approximation to its inverse from its values on x. 
#Example 
import numpy as np
from statsmodels.distributions.empirical_distribution import ECDF

ecdf = ECDF([3, 3, 1, 4])
>>> ecdf([3, 55, 0.5, 1.5])
array([ 0.75,  1.  ,  0.  ,  0.25])


#Skew Distributions
SkewNorm_gen()                              univariate Skew-Normal distribution of Azzalini 
SkewNorm2_gen([momtype, a, b, xtol, ...])   univariate Skew-Normal distribution of Azzalini 
ACSkewT_gen()                               univariate Skew-T distribution of Azzalini 
skewnorm2                                   univariate Skew-Normal distribution of Azzalini 

#Distributions based on Gram-Charlier expansion
pdf_moments_st(cnt)             Return the Gaussian expanded pdf function given the list of central moments (first one is mean). 
pdf_mvsk(mvsk)                  Return the Gaussian expanded pdf function given the list of 1st, 2nd moment and skew and Fisher (excess) kurtosis. 
pdf_moments(cnt)                Return the Gaussian expanded pdf function given the list of central moments (first one is mean). 
NormExpan_gen(args, **kwds)     Gram-Charlier Expansion of Normal distribution 

#cdf of multivariate normal wrapper for scipy.stats
mvstdnormcdf(lower, upper, corrcoef, **kwds)    standardized multivariate normal cumulative distribution function 
mvnormcdf(upper, mu, cov[, lower])              multivariate normal cumulative distribution function 

#Univariate Distributions by non-linear Transformations
#Univariate distributions can be generated 
#from a non-linear transformation of an existing univariate distribution. 

#Transf_gen is a class that can generate a new distribution 
#from a monotonic transformation, 

#TransfTwo_gen can use hump-shaped or u-shaped transformation, 
#such as abs or square. The remaining objects are special cases.
 
TransfTwo_gen(kls, func, funcinvplus, ...)      Distribution based on a non-monotonic (u- or hump-shaped transformation) 
Transf_gen(kls, func, funcinv, *args, **kwargs) a class for non-linear monotonic transformation of a continuous random variable 
ExpTransf_gen(kls, *args, **kwargs)             Distribution based on log/exp transformation 
LogTransf_gen(kls, *args, **kwargs)             Distribution based on log/exp transformation 

SquareFunc          class to hold quadratic function with inverse function and derivative 
absnormalg          Distribution based on a non-monotonic (u- or hump-shaped transformation) 
invdnormalg         a class for non-linear monotonic transformation of a continuous random variable 
loggammaexpg        univariate distribution of a non-linear monotonic transformation of a 
lognormalg a        class for non-linear monotonic transformation of a continuous random variable 
negsquarenormalg    Distribution based on a non-monotonic (u- or hump-shaped transformation) 
squarenormalg       Distribution based on a non-monotonic (u- or hump-shaped transformation) 
squaretg            Distribution based on a non-monotonic (u- or hump-shaped transformation) 




###Statsmodel-QuickIntro - sm.duration
#Survival function and duration analysis 

SurvfuncRight(time, status[, entry, title, ...]) 
    Estimation and inference for a survival function. 
survdiff(time, status, group, weight_type=None, strata=None,
             entry=None, **kwargs):
    Test for the equality of two survival distributions.
    
PHReg(endog, exog[, status, entry, strata, ...]) 
    Fit the Cox proportional hazards regression model for right censored data. 
PHRegResults(model, params, cov_params[, ...]) 
    The proportional hazards regression result


    
    
###Statsmodel-QuickIntro - sm.emplike
#Empirical likelihood is a method of nonparametric inference 
#and estimation that lifts the obligation of having to specify 
#a family of underlying distributions

#Module Reference
descriptive.DescStat(endog)     Returns an instance to conduct inference on descriptive statistics via empirical likelihood. 
descriptive.DescStatUV(endog)   A class to compute confidence intervals and hypothesis tests involving mean, variance, kurtosis and skewness of a univariate random variable. 
descriptive.DescStatMV(endog)   A class for conducting inference on multivariate means and correlation. 


import numpy as np
import statsmodels.api as sm
# Generate Data
x = np.random.standard_normal(50)
# initiate EL
el = sm.emplike.DescStat(x)
# confidence interval for the mean
>>> el.ci_mean()
(-0.284592989912553, 0.32792432989204601)
# test variance is 1
>>> el.test_var(1)
(1.5489915746765002, 0.21328437351474738)

#SV and MV 
from statsmodels.datasets import star98
data = star98.load()
desc_stat_data = data.exog[:50, 5]   #UV 
mv_desc_stat_data = data.exog[:50, 5:7]  # mv = multivariate
res1 = DescStat(desc_stat_data)
mvres1 = DescStat(mv_desc_stat_data)
#Check methods 
>>> dir(mvres1)
res1.test_mean(14)
res1.ci_mean()
res1.test_var(3)
res1.ci_var()
res1.test_skew(0)
res1.ci_skew()
res1.test_kurt(0)
res1.ci_kurt(upper_bound=.5, lower_bound=-1.5)
res1.test_joint_skew_kurt(0, 0)

mvres1.mv_test_mean(np.array([14, 56]))
mvres1.test_corr(.5)
mvres1.ci_corr()

#Other functionalities in empLike 
ANOVA(endog)
    A class for ANOVA and comparing means.
    endog : list of arrays
        endog should be a list containing 1 dimensional arrays.  Each array
        is the data collected from a certain group.
    Methods 
    ----------
    compute_ANOVA(self, mu=None, mu_start=0, return_weights=0):
        returns The log-likelihood, p-value and estimate for the common mean.
        mu : float
            If a mu is specified, ANOVA is conducted with mu as the
            common mean.  Otherwise, the common mean is the maximum
            empirical likelihood estimate of the common mean.
            Default is None.

        mu_start : float
            Starting value for commean mean if specific mu is not specified.
            Default = 0

        return_weights : bool
            if TRUE, returns the weights on observations that maximize the
            likelihood.  Default is FALSE

#Example 
from statsmodels.datasets import star98
from statsmodels.emplike.elanova import ANOVA

self.data = star98.load().exog[:30, 1:3]
self.res1 = ANOVA([self.data[:, 0], self.data[:, 1]])
self.res1.compute_ANOVA()
        
        
ELOriginRegress(endog, exog)
    This module implements empirical likelihood regression that is forced through the origin.
    This class inherits from RegressionResults but inference is
    conducted via empirical likelihood.  Therefore, any methods that
    require an estimate of the covariance matrix will not function.  Instead
    use el_test and conf_int_el to conduct inference.

#Examples
import statsmodels.api as sm
data = sm.datasets.bc.load()
model = sm.emplike.ELOriginRegress(data.endog, data.exog)
fitted = model.fit()
>>> fitted.params #  0 is the intercept term.
array([ 0.        ,  0.00351813])
#b0_vals : 1darray,The hypothesized value of the parameter to be tested
#param_nums : 1darray,The parameter number to be tested
#returns -2 times the log-likelihood ratio for the hypothesized values and p-value 
>>> fitted.el_test(np.array([.0034]), np.array([1])) #0.0034 for x1
(3.6696503297979302, 0.055411808127497755)
#param_num : float,The parameter for which the confidence interval is desired
>>> fitted.conf_int_el(1) #for x1
(0.0033971871114706867, 0.0036373150174892847)

# No covariance matrix so normal inference is not valid
>>> fitted.conf_int()
TypeError: unsupported operand type(s) for *: 'instancemethod' and 'float'
    
    
    
emplikeAFT(endog, exog, censors) 
    Accelerated Failure Time (AFT) Model with empirical likelihood inference.
    AFT regression analysis is applicable when the researcher has access
    to a randomly right censored dependent variable, a matrix of exogenous
    variables and an indicatior variable (delta) that takes a value of 0 if the
    observation is censored and 1 otherwise.
        endog: nx1 array
            Response variables that are subject to random censoring

        exog: nxk array
            Matrix of covariates

        censors: nx1 array
            array with entries 0 or 1.  0 indicates a response was
            censored.

    Methods 
    ----------        
    fit(): 
        Fits an AFT model and returns AFTResults instance
    predict(params, endog=None)
    
    #AFTResults Methods 
        test_beta(b0_vals, param_nums, ftol=10 ** - 5, maxiter=30,print_weights=1):
            Tests if beta = b0 for any vector b0.
            Returns the log likelihood and p_value for regression parameters 'param_num' at 'b0_vals.'
        ci_beta(param_num, beta_high, beta_low, sig=.05):
            Returns the confidence interval for a regression parameter in the AFT model.
        
#Example 
import statsmodels.api as sm
import numpy as np

# Test parameter is .05 in one regressor no intercept model
data=sm.datasets.heart.load()
y = np.log10(data.endog)
x = data.exog
cens = data.censors
model = sm.emplike.emplikeAFT(y, x, cens)
res1 = model.fit()
res1.params()
res1.test_beta([-.04], [1])  #-0.04 for x1
res1.test_beta([3.5, -.035], [0, 1]) #3.5 for intercept and -0.35 for x1
ci = self.res1.ci_beta(1, -.06, 0) 
ll = ci[0]
ul = ci[1]
ll_pval = res1.test_beta([ll], [1])[1]
ul_pval = res1.test_beta([ul], [1])[1]





###Statsmodel-QuickIntro - sm.families
#contains families for GLM 
>>> dir(sm.families)
['Binomial', 'Family', 'Gamma', 'Gaussian', 'InverseGaussian', 'NegativeBinomial
', 'Poisson', 'Tweedie', '__builtins__', '__cached__', '__doc__', '__file__', '_



###Statsmodel-QuickIntro - sm.formula
#Contains implementation of formula based regression analysis 
>>> dir(sm.formula)
[ 'gee', 'glm', 'gls', 'glsar', 'logit', 'm
ixedlm', 'mnlogit', 'negativebinomial', 'nominal_gee', 'ols', 'ordinal_gee', 'ph
reg', 'poisson', 'probit', 'quantreg', 'rlm', 'wls']



###Statsmodel-QuickIntro - sm.genmod
#contains cov_struct, GEE and GLM 







###Statsmodel-QuickIntro - sm.ProbPlot
#Class for convenient construction of Q-Q, P-P, and probability plots.

#Example 
import statsmodels.api as sm
from matplotlib import pyplot as plt
# example 1
data = sm.datasets.longley.load()
data.exog = sm.add_constant(data.exog)
model = sm.OLS(data.endog, data.exog)
mod_fit = model.fit()
res = mod_fit.resid # residuals
probplot = sm.ProbPlot(res)
probplot.qqplot()
plt.show()


#qqplot of the residuals against quantiles of t-distribution 
#with 4 degrees of freedom:
# example 2
import scipy.stats as stats
probplot = sm.ProbPlot(res, stats.t, distargs=(4,))
fig = probplot.qqplot()
plt.show()

#qqplot against same as above, but with mean 3 and std 10:
# example 3
probplot = sm.ProbPlot(res, stats.t, distargs=(4,), loc=3, scale=10)
fig = probplot.qqplot()
plt.show()

#Automatically determine parameters for t distribution including the loc and scale:
# example 4
probplot = sm.ProbPlot(res, stats.t, fit=True)
fig = probplot.qqplot(line='45')
plt.show()

#A second ProbPlot object can be used to compare two seperate sample sets 
#by using the other kwarg in the qqplot and ppplot methods.
# example 5
import numpy as np
x = np.random.normal(loc=8.25, scale=2.75, size=37)
y = np.random.normal(loc=8.75, scale=3.25, size=37)
pp_x = sm.ProbPlot(x, fit=True)
pp_y = sm.ProbPlot(y, fit=True)
fig = pp_x.qqplot(line='45', other=pp_y)
plt.show()


###Statsmodel-QuickIntro - sm.qqline,sm.qqplot,sm.qqplot_2samples
#Goodness of Fit Plots
gofplots.qqplot(data[, dist, distargs, a, ...]) Q-Q plot of the quantiles of x versus the quantiles/ppf of a distribution. 
gofplots.qqline(ax, line[, x, y, dist, fmt])    Plot a reference line for a qqplot. 
gofplots.qqplot_2samples(data1, data2[, ...])   Q-Q Plot of two samples' quantiles. 

#Example 
import numpy as np
import statsmodels.api as sm
import matplotlib.pyplot as plt
test = np.random.normal(0, 1, 1000)
pp = sm.ProbPlot(test, fit=True)
qq = pp.qqplot(marker='.', markerfacecolor='k', markeredgecolor='k', alpha=0.3)
sm.qqline(qq.axes[0], line='45', fmt='k--')
plt.show()

#Example of qqplot_2samples
x = np.random.normal(loc=8.5, scale=2.5, size=37)
y = np.random.normal(loc=8.0, scale=3.0, size=37)
pp_x = sm.ProbPlot(x)
pp_y = sm.ProbPlot(y)
qqplot_2samples(pp_x, pp_y)


###Statsmodel-QuickIntro - sm.graphics
#Goodness of Fit Plots
gofplots.qqplot(data[, dist, distargs, a, ...])     Q-Q plot of the quantiles of x versus the quantiles/ppf of a distribution. 
gofplots.qqline(ax, line[, x, y, dist, fmt])        Plot a reference line for a qqplot. 
gofplots.qqplot_2samples(data1, data2[, ...])       Q-Q Plot of two samples' quantiles. 
gofplots.ProbPlot(data[, dist, fit, ...])           Class for convenient construction of Q-Q, P-P, and probability plots. 

#Boxplots
boxplots.violinplot(data[, ax, labels, ...])    Make a violin plot of each dataset in the data sequence. 
boxplots.beanplot(data[, ax, labels, ...])      Make a bean plot of each dataset in the data sequence. 

#Correlation Plots
correlation.plot_corr(dcorr[, xnames, ...])         Plot correlation of many variables in a tight color grid. 
correlation.plot_corr_grid(dcorrs[, titles, ...])   Create a grid of correlation plots. 
plot_grids.scatter_ellipse(data[, level, ...])  Create a grid of scatter plots with confidence ellipses. 

#Functional Plots
functional.fboxplot(data[, xdata, labels, ...])     Plot functional boxplot. 
functional.rainbowplot(data[, xdata, depth, ...])   Create a rainbow plot for a set of curves. 
functional.banddepth(data[, method])                Calculate the band depth for a set of functional curves. 


#Time Series Plots
tsaplots.plot_acf(x[, ax, lags, alpha, ...])    Plot the autocorrelation function 
tsaplots.plot_pacf(x[, ax, lags, alpha, ...])   Plot the partial autocorrelation function 
tsaplots.month_plot(x[, dates, ylabel, ax])     Seasonal plot of monthly data 
tsaplots.quarter_plot(x[, dates, ylabel, ax])   Seasonal plot of quarterly data 

#Other Plots
factorplots.interaction_plot(x, trace, response) Interaction plot for factor level statistics. 
mosaicplot.mosaic(data[, index, ax, ...])       Create a mosaic plot from a contingency table. 



#Example - qqplot
import statsmodels.api as sm
from matplotlib import pyplot as plt
data = sm.datasets.longley.load()
data.exog = sm.add_constant(data.exog)
mod_fit = sm.OLS(data.endog, data.exog).fit()
res = mod_fit.resid # residuals
fig = sm.qqplot(res)
plt.show()

#qqplot of the residuals against quantiles of t-distribution with 4 degrees of freedom:
import scipy.stats as stats
fig = sm.qqplot(res, stats.t, distargs=(4,))
plt.show()

#qqplot against same as above, but with mean 3 and std 10:
fig = sm.qqplot(res, stats.t, distargs=(4,), loc=3, scale=10)
plt.show()

#Automatically determine parameters for t distribution including the loc and scale:
>>> fig = sm.qqplot(res, stats.t, fit=True, line='45')
>>> plt.show()

#Example - beanplot 
#We use the American National Election Survey 1996 dataset, 
#which has Party Identification of respondents as independent variable 
#and (among other data) age as dependent variable.
>>> data = sm.datasets.anes96.load_pandas()
>>> party_ID = np.arange(7)
>>> labels = ["Strong Democrat", "Weak Democrat", "Independent-Democrat",
           "Independent-Indpendent", "Independent-Republican",
           "Weak Republican", "Strong Republican"]
#Group age by party ID, and create a violin plot with it:
plt.rcParams['figure.subplot.bottom'] = 0.23  # keep labels visible
age = [data.exog['age'][data.endog == id] for id in party_ID]
fig = plt.figure()
ax = fig.add_subplot(111)
sm.graphics.beanplot(age, ax=ax, labels=labels,
                     plot_opts={'cutoff_val':5, 'cutoff_type':'abs',
                                'label_fontsize':'small',
                                'label_rotation':30})
ax.set_xlabel("Party identification of respondent.")
ax.set_ylabel("Age")
plt.show()

#Exmaple - plot_corr
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.graphics.api as smg
hie_data = sm.datasets.randhie.load_pandas()
corr_matrix = np.corrcoef(hie_data.data.T)
smg.plot_corr(corr_matrix, xnames=hie_data.names)
plt.show()

#Examples of rainbowplot
#Load the El Nino dataset. 
#Consists of 60 years worth of Pacific Ocean sea surface temperature data.
import matplotlib.pyplot as plt
import statsmodels.api as sm
data = sm.datasets.elnino.load()

fig = plt.figure()
ax = fig.add_subplot(111)
res = sm.graphics.rainbowplot(data.raw_data[:, 1:], ax=ax)
ax.set_xlabel("Month of the year")
ax.set_ylabel("Sea surface temperature (C)")
ax.set_xticks(np.arange(13, step=3) - 1)
ax.set_xticklabels(["", "Mar", "Jun", "Sep", "Dec"])
ax.set_xlim([-0.2, 11.2])
plt.show()

#Examples of month_plot
import statsmodels.api as sm
import pandas as pd
dta = sm.datasets.elnino.load_pandas().data
dta['YEAR'] = dta.YEAR.astype(int).astype(str)
dta = dta.set_index('YEAR').T.unstack()
dates = pd.to_datetime(list(map(lambda x : '-'.join(x) + '-1',
                                       dta.index.values)))
dta.index = pd.DatetimeIndex(dates, freq='MS')
fig = sm.graphics.tsa.month_plot(dta)

#Examples of mosiac
#The most simple use case is to take a dictionary and plot the result
data = {'a': 10, 'b': 15, 'c': 16}
mosaic(data, title='basic dictionary')
pylab.show()

#A more useful example is given by a dictionary with multiple indices. 
#In this case we use a wider gap to a better visual separation of the resulting plot
data = {('a', 'b'): 1, ('a', 'c'): 2, ('d', 'b'): 3, ('d', 'c'): 4}
mosaic(data, gap=0.05, title='complete dictionary')
pylab.show()

#The same data can be given as a simple or hierarchical indexed Series
rand = np.random.random
from itertools import product

tuples = list(product(['bar', 'baz', 'foo', 'qux'], ['one', 'two']))
index = pd.MultiIndex.from_tuples(tuples, names=['first', 'second'])
data = pd.Series(rand(8), index=index)
mosaic(data, title='hierarchical index series')
pylab.show()

#The third accepted data structureis the np array, 
#for which a very simple index will be created.
rand = np.random.random
data = 1+rand((2,2))
mosaic(data, title='random non-labeled array')
pylab.show()

#If you need to modify the labeling and the coloring 
#you can give a function tocreate the labels 
#and one with the graphical properties starting from the key tuple
data = {'a': 10, 'b': 15, 'c': 16}
props = lambda key: {'color': 'r' if 'a' in key else 'gray'}
labelizer = lambda k: {('a',): 'first', ('b',): 'second',                                ('c',): 'third'}[k]
mosaic(data, title='colored dictionary',                 properties=props, labelizer=labelizer)
pylab.show()


#Using a DataFrame as source, specifying the name of the columns of interest 
gender = ['male', 'male', 'male', 'female', 'female', 'female'] 
pet = ['cat', 'dog', 'dog', 'cat', 'dog', 'cat'] 
data = pandas.DataFrame({'gender': gender, 'pet': pet}) 
mosaic(data, ['pet', 'gender']) 
pylab.show()

#Exmaple of interaction_plot
import numpy as np
np.random.seed(12345)
weight = np.random.randint(1,4,size=60)
duration = np.random.randint(1,3,size=60)
days = np.log(np.random.randint(1,30, size=60))
fig = interaction_plot(weight, duration, days,
            colors=['red','blue'], markers=['D','^'], ms=10)
import matplotlib.pyplot as plt
plt.show()


###Statsmodel -  QuickIntro - sm.graphics - Regression Plots
#Regression Plots
regressionplots.plot_fit(results, exog_idx)     Plot fit against one regressor. 
regressionplots.plot_regress_exog(results, ...) Plot regression results against one regressor. 
regressionplots.plot_partregress(endog, ...)    Plot partial regression for a single regressor. 
regressionplots.plot_ccpr(results, exog_idx)    Plot CCPR against one regressor. 
regressionplots.abline_plot([intercept, ...])   Plots a line given an intercept and slope. 
regressionplots.influence_plot(results[, ...])  Plot of influence in regression. 
regressionplots.plot_leverage_resid2(results)   Plots leverage statistics vs. 
#Example 
%matplotlib inline
from __future__ import print_function
from statsmodels.compat import lzip
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.formula.api import ols

#Duncan's Prestige Dataset
prestige = sm.datasets.get_rdataset("Duncan", "car", cache=True).data
prestige.head()
prestige_model = ols("prestige ~ income + education", data=prestige).fit()
>>> print(prestige_model.summary())
                            OLS Regression Results                            
==============================================================================
Dep. Variable:               prestige   R-squared:                       0.828
Model:                            OLS   Adj. R-squared:                  0.820
Method:                 Least Squares   F-statistic:                     101.2
Date:                Tue, 28 Feb 2017   Prob (F-statistic):           8.65e-17
Time:                        21:34:02   Log-Likelihood:                -178.98
No. Observations:                  45   AIC:                             364.0
Df Residuals:                      42   BIC:                             369.4
Df Model:                           2                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     -6.0647      4.272     -1.420      0.163     -14.686       2.556
income         0.5987      0.120      5.003      0.000       0.357       0.840
education      0.5458      0.098      5.555      0.000       0.348       0.744
==============================================================================
Omnibus:                        1.279   Durbin-Watson:                   1.458
Prob(Omnibus):                  0.528   Jarque-Bera (JB):                0.520
Skew:                           0.155   Prob(JB):                        0.771
Kurtosis:                       3.426   Cond. No.                         163.
==============================================================================
Warnings:
[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.

#Influence plots
#Influence plots show the (externally) studentized residuals 
#vs. the leverage of each observation as measured by the hat matrix.
#The influence of each point can be visualized by the criterion keyword argument. Options are Cook's distance and DFFITS, two measures of influence.
fig, ax = plt.subplots(figsize=(12,8))
fig = sm.graphics.influence_plot(prestige_model, ax=ax, criterion="cooks")
 
#As you can see there are a few worrisome observations. 
#Both contractor and reporter have low leverage but a large residual. 
#RR.engineer has small residual and large leverage. 
#Conductor and minister have both high leverage and large residuals, and, therefore, large influence.


#Partial Regression Plots
#Since we are doing multivariate regressions, 
#we cannot just look at individual bivariate plots to discern relationships. 
#Instead, we want to look at the relationship of the dependent variable 
#and independent variables conditional on the other independent variables. 
#We can do this through using partial regression plots, 

fig, ax = plt.subplots(figsize=(12,8))
fig = sm.graphics.plot_partregress("prestige", "income", ["income", "education"], data=prestige, ax=ax)
 

fix, ax = plt.subplots(figsize=(12,14))
fig = sm.graphics.plot_partregress("prestige", "income", ["education"], data=prestige, ax=ax)
 
#As you can see the partial regression plot confirms 
#the influence of conductor, minister, and RR.engineer 
#on the partial relationship between income and prestige. 
#The cases greatly decrease the effect of income on prestige. 
#Dropping these cases confirms this.

subset = ~prestige.index.isin(["conductor", "RR.engineer", "minister"])
prestige_model2 = ols("prestige ~ income + education", data=prestige, subset=subset).fit()
>>> print(prestige_model2.summary())
                            OLS Regression Results                            
==============================================================================
Dep. Variable:               prestige   R-squared:                       0.876
Model:                            OLS   Adj. R-squared:                  0.870
Method:                 Least Squares   F-statistic:                     138.1
Date:                Tue, 28 Feb 2017   Prob (F-statistic):           2.02e-18
Time:                        21:34:04   Log-Likelihood:                -160.59
No. Observations:                  42   AIC:                             327.2
Df Residuals:                      39   BIC:                             332.4
Df Model:                           2                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     -6.3174      3.680     -1.717      0.094     -13.760       1.125
income         0.9307      0.154      6.053      0.000       0.620       1.242
education      0.2846      0.121      2.345      0.024       0.039       0.530
==============================================================================
Omnibus:                        3.811   Durbin-Watson:                   1.468
Prob(Omnibus):                  0.149   Jarque-Bera (JB):                2.802
Skew:                          -0.614   Prob(JB):                        0.246
Kurtosis:                       3.303   Cond. No.                         158.
==============================================================================
Warnings:
[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.

#For a quick check of all the regressors, you can use plot_partregress_grid. 
#These plots will not label the  points, but you can use them to identify problems 
#and then use plot_partregress to get more information.
fig = plt.figure(figsize=(12,8))
fig = sm.graphics.plot_partregress_grid(prestige_model, fig=fig)
 
#Component-Component plus Residual (CCPR) Plots
#The CCPR plot provides a way to judge the effect of one regressor on the 
#response variable by taking into account the effects of the other 
#independent variables. The partial residuals plot is defined as 

fig, ax = plt.subplots(figsize=(12, 8))
fig = sm.graphics.plot_ccpr(prestige_model, "education", ax=ax)
 
#As you can see the relationship between the variation in prestige 
#explained by education conditional on income seems to be linear, 
#though you can see there are some observations 
#that are exerting considerable influence on the relationship. 

#We can quickly look at more than one variable by using plot_ccpr_grid.
fig = plt.figure(figsize=(12, 8))
fig = sm.graphics.plot_ccpr_grid(prestige_model, fig=fig)
 
#Regression Plots
#The plot_regress_exog function is a convenience function 
#that gives a 2x2 plot containing the dependent variable 
#and fitted values with confidence intervals vs. the independent variable chosen, 
#the residuals of the model vs. the chosen independent variable, 
#a partial regression plot, and a CCPR plot. 

#This function can be used for quickly checking modeling assumptions 
#with respect to a single regressor.

fig = plt.figure(figsize=(12,8))
fig = sm.graphics.plot_regress_exog(prestige_model, "education", fig=fig)
 
#Fit Plot
#The plot_fit function plots the fitted values versus a chosen independent variable. 
#It includes prediction confidence intervals and optionally plots the true dependent variable.

fig, ax = plt.subplots(figsize=(12, 8))
fig = sm.graphics.plot_fit(prestige_model, "education", ax=ax)
 
#Regresssion plot example 
#Statewide Crime 2009 Dataset

dta = sm.datasets.statecrime.load_pandas().data
crime_model = ols("murder ~ urban + poverty + hs_grad + single", data=dta).fit()
>>> print(crime_model.summary())
                            OLS Regression Results                            
==============================================================================
Dep. Variable:                 murder   R-squared:                       0.813
Model:                            OLS   Adj. R-squared:                  0.797
Method:                 Least Squares   F-statistic:                     50.08
Date:                Tue, 28 Feb 2017   Prob (F-statistic):           3.42e-16
Time:                        21:34:09   Log-Likelihood:                -95.050
No. Observations:                  51   AIC:                             200.1
Df Residuals:                      46   BIC:                             209.8
Df Model:                           4                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept    -44.1024     12.086     -3.649      0.001     -68.430     -19.774
urban          0.0109      0.015      0.707      0.483      -0.020       0.042
poverty        0.4121      0.140      2.939      0.005       0.130       0.694
hs_grad        0.3059      0.117      2.611      0.012       0.070       0.542
single         0.6374      0.070      9.065      0.000       0.496       0.779
==============================================================================
Omnibus:                        1.618   Durbin-Watson:                   2.507
Prob(Omnibus):                  0.445   Jarque-Bera (JB):                0.831
Skew:                          -0.220   Prob(JB):                        0.660
Kurtosis:                       3.445   Cond. No.                     5.80e+03
==============================================================================
Warnings:
[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.
[2] The condition number is large, 5.8e+03. This might indicate that there are
strong multicollinearity or other numerical problems.

#Partial Regression Plots
fig = plt.figure(figsize=(12,8))
fig = sm.graphics.plot_partregress_grid(crime_model, fig=fig)
 
fig, ax = plt.subplots(figsize=(12,8))
fig = sm.graphics.plot_partregress("murder", "hs_grad", ["urban", "poverty", "single"],  ax=ax, data=dta)
 
#Leverage-Resid2 Plot
#Closely related to the influence_plot is the leverage-resid2 plot.

fig, ax = plt.subplots(figsize=(8,6))
fig = sm.graphics.plot_leverage_resid2(crime_model, ax=ax)
 
#Influence Plot
fig, ax = plt.subplots(figsize=(8,6))
fig = sm.graphics.influence_plot(crime_model, ax=ax)
 
#Using robust regression to correct for outliers.

from statsmodels.formula.api import rlm

rob_crime_model = rlm("murder ~ urban + poverty + hs_grad + single", data=dta, 
                      M=sm.robust.norms.TukeyBiweight(3)).fit(conv="weights")
>>> print(rob_crime_model.summary())
                    Robust linear Model Regression Results                    
==============================================================================
Dep. Variable:                 murder   No. Observations:                   51
Model:                            RLM   Df Residuals:                       46
Method:                          IRLS   Df Model:                            4
Norm:                   TukeyBiweight                                         
Scale Est.:                       mad                                         
Cov Type:                          H1                                         
Date:                Tue, 28 Feb 2017                                         
Time:                        21:34:12                                         
No. Iterations:                    50                                         
==============================================================================
                 coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     -4.2986      9.494     -0.453      0.651     -22.907      14.310
urban          0.0029      0.012      0.241      0.809      -0.021       0.027
poverty        0.2753      0.110      2.499      0.012       0.059       0.491
hs_grad       -0.0302      0.092     -0.328      0.743      -0.211       0.150
single         0.2902      0.055      5.253      0.000       0.182       0.398
==============================================================================

#There isn't yet an influence diagnostics method as part of RLM, but we can recreate them. 
#(This depends on the status of issue #888)
weights = rob_crime_model.weights
idx = weights > 0
X = rob_crime_model.model.exog[idx.values]
ww = weights[idx] / weights[idx].mean()
hat_matrix_diag = ww*(X*np.linalg.pinv(X).T).sum(1)
resid = rob_crime_model.resid
resid2 = resid**2
resid2 /= resid2.sum()
nobs = int(idx.sum())
hm = hat_matrix_diag.mean()
rm = resid2.mean()

from statsmodels.graphics import utils
fig, ax = plt.subplots(figsize=(12,8))
ax.plot(resid2[idx], hat_matrix_diag, 'o')
ax = utils.annotate_axes(range(nobs), labels=rob_crime_model.model.data.row_labels[idx], 
                    points=lzip(resid2[idx], hat_matrix_diag), offset_points=[(-5,5)]*nobs,
                    size="large", ax=ax)
ax.set_xlabel("resid2")
ax.set_ylabel("leverage")
ylim = ax.get_ylim()
ax.vlines(rm, *ylim)
xlim = ax.get_xlim()
ax.hlines(hm, *xlim)
ax.margins(0,0)





###Statsmodel-QuickIntro - sm.iolib
#statsmodels offers some functions for input and output

foreign.StataReader(fname[, missing_values, ...]) Stata .dta file reader. 
foreign.StataWriter(fname, data[, ...])         A class for writing Stata binary dta files from array-like objects 
foreign.genfromdta(fname[, missing_flt, ...])   Returns an ndarray or DataFrame from a Stata .dta file. 
foreign.savetxt(fname, X[, names, fmt, ...])    Save an array to a text file. 
table.SimpleTable(data[, headers, stubs, ...])  Produce a simple ASCII, CSV, HTML, or LaTeX table from a rectangular (2d!) array of data, not necessarily numerical. 
table.csv2st(csvfile[, headers, stubs, title])  Return SimpleTable instance, created from the data in csvfile, which is in comma separated values format. 
smpickle.save_pickle(obj, fname)                Save the object to file via pickling. 
smpickle.load_pickle(fname)                     Load a previously saved object from file 
summary.Summary()                               class to hold tables for result summary presentation 

#Example  
mydata = [[11,12],[21,22]]  # data MUST be 2-dimensional
myheaders = [ "Column 1", "Column 2" ]
mystubs = [ "Row 1", "Row 2" ]
tbl = text.SimpleTable(mydata, myheaders, mystubs, title="Title")
print( tbl )
print( tbl.as_html() )
# set column specific data formatting
tbl = text.SimpleTable(mydata, myheaders, mystubs,
    data_fmts=["%3.2f","%d"])
print( tbl.as_csv() )
with open('c:/temp/temp.tex','w') as fh:
    fh.write( tbl.as_latex_tabular() )
 
 
 
 
class statsmodels.iolib.summary2.Summary
    Any result.summary() returns instance of Summary
    add_array(array[, align, float_format])         Add the contents of a Numpy array to summary table 
    add_base(results[, alpha, float_format, ...])   Try to construct a basic summary instance. 
    add_df(df[, index, header, float_format, align]) Add the contents of a DataFrame to summary table 
    add_dict(d[, ncols, align, float_format])       Add the contents of a Dict to summary table 
    add_text(string)                                Append a note to the bottom of the summary table. 
    add_title([title, results])                     Insert a title on top of the summary table. 
    as_html()   Generate HTML Summary Table 
    as_latex()  Generate LaTeX Summary Table 
    as_text()   Generate ASCII Summary Table 

 
 
 
###Statsmodel-QuickIntro - sm.load
#equivalent to smpickle.load_pickle(fname)

#Example 
import statsmodels.api as sm
data = sm.datasets.longley.load_pandas()
data.exog['constant'] = 1
results = sm.OLS(data.endog, data.exog).fit()
results.save("longley_results.pickle")

from statsmodels.regression.linear_model import OLSResults
new_results = OLSResults.load("longley_results.pickle")
# or
from statsmodels.iolib.smpickle import load_pickle
new_results = load_pickle("longley_results.pickle")
#or 
new_results = sm.load('longley_results.pickle')



###Statsmodel-QuickIntro - sm.nonparametric
#This includes kernel density estimation for univariate and multivariate data, 
#kernel regression and locally weighted scatterplot smoothing (lowess).

smoothers_lowess.lowess(endog, exog[, frac, ...]) LOWESS (Locally Weighted Scatterplot Smoothing) 
kde.KDEUnivariate(endog)                          Univariate Kernel Density Estimator. 
kernel_density.KDEMultivariate(data, var_type)    Multivariate kernel density estimator. 
kernel_density.KDEMultivariateConditional(...)    Conditional multivariate kernel density estimator. 
kernel_density.EstimatorSettings([...])           Object to specify settings for density estimation or regression. 
kernel_regression.KernelReg(endog, exog, ...)     Nonparametric kernel regression class. 
kernel_regression.KernelCensoredReg(endog, ...)   Nonparametric censored regression. 

#helper functions for kernel bandwidths
bandwidths.bw_scott(x[, kernel])            Scott's Rule of Thumb 
bandwidths.bw_silverman(x[, kernel])        Silverman's Rule of Thumb 
bandwidths.select_bandwidth(x, bw, kernel)  Selects bandwidth for a selection rule bw 


#LOWESS (Locally Weighted Scatterplot Smoothing)
#A lowess function that outs smoothed estimates of endog 
#at the given exog values from points (exog, endog)

#The below allows a comparison between how different the fits 
#from lowess for different values of frac can be.
import numpy as np
import statsmodels.api as sm
lowess = sm.nonparametric.lowess
x = np.random.uniform(low = -2*np.pi, high = 2*np.pi, size=500)
y = np.sin(x) + np.random.normal(size=len(x))
z = lowess(y, x)
w = lowess(y, x, frac=1./3)

#This gives a similar comparison for when it is 0 vs not.
import numpy as np
import scipy.stats as stats
import statsmodels.api as sm
lowess = sm.nonparametric.lowess
x = np.random.uniform(low = -2*np.pi, high = 2*np.pi, size=500)
y = np.sin(x) + stats.cauchy.rvs(size=len(x))
z = lowess(y, x, frac= 1./3, it=0)
w = lowess(y, x, frac=1./3)


class statsmodels.nonparametric.kde.KDEUnivariate(endog)
    Univariate Kernel Density Estimator.
    Methods
    cdf()           Returns the cumulative distribution function evaluated at the support. 
    cumhazard()     Returns the hazard function evaluated at the support. 
    entropy()       Returns the differential entropy evaluated at the support 
    evaluate(point) Evaluate density at a single point. 
    fit([kernel, bw, fft, weights, gridsize, ...])  Attach the density estimate to the KDEUnivariate class. 
    icdf()      Inverse Cumulative Distribution (Quantile) Function 
    sf()        Returns the survival function evaluated at the support.

#Exmaple 
import statsmodels.api as sm
import matplotlib.pyplot as plt
nobs = 300
np.random.seed(1234)  # Seed random generator
dens = sm.nonparametric.KDEUnivariate(np.random.normal(size=nobs))
dens.fit()
plt.plot(dens.cdf)
plt.show()
 
class statsmodels.nonparametric.kernel_density.KDEMultivariate(data, var_type, bw=None, defaults=<statsmodels.nonparametric._kernel_base.EstimatorSettings object>)
    Multivariate kernel density estimator.
    Methods
    cdf([data_predict])     Evaluate the cumulative distribution function. 
    imse(bw)                Returns the Integrated Mean Square Error for the unconditional KDE. 
    loo_likelihood(bw[, func]) Returns the leave-one-out likelihood function. 
    pdf([data_predict])     Evaluate the probability density function.

#Example 
import statsmodels.api as sm
nobs = 300
np.random.seed(1234)  # Seed random generator
c1 = np.random.normal(size=(nobs,1))
c2 = np.random.normal(2, 1, size=(nobs,1))
#Estimate a bivariate distribution and display the bandwidth found:
dens_u = sm.nonparametric.KDEMultivariate(data=[c1,c2],
    var_type='cc', bw='normal_reference')
>>> dens_u.bw
array([ 0.39967419,  0.38423292])



 

###Statsmodel-QuickIntro - sm.regression
#implementation of OLS,GLS etc 


###Statsmodel-QuickIntro - sm.robust
#Implementation of RLM 


###Statsmodel-QuickIntro - sm.show_versions
>>> sm.show_versions()
INSTALLED VERSIONS
------------------
Python: 3.5.2.final.0
Statsmodels
===========
Installed: 0.8.0 (c:\python35\lib\site-packages\statsmodels)

###Statsmodel-QuickIntro - sm.version
>>> help(sm.version)
Help on module statsmodels.version in statsmodels:
NAME
    statsmodels.version - # THIS FILE IS GENERATED FROM SETUP.PY
DATA
    full_version = '0.8.0'
    git_revision = 'Unknown'
    release = True
    short_version = '0.8.0'
    version = '0.8.0'

###Statsmodel-QuickIntro - sm.test
#Running the Test Suite
#You can run all the tests by:
import statsmodels.api as sm
sm.test()
#You can test submodules by:
sm.discrete.test()



###Statsmodel-QuickIntro - sm.tools

#Basic tools tools
tools.add_constant(data[, prepend, has_constant])   Adds a column of ones to an array 
tools.categorical(data[, col, dictnames, drop])     Returns a dummy matrix given an array of categorical variables. 
tools.clean0(matrix)    Erase columns of zeros: can save some time in pseudoinverse. 
tools.fullrank(X[, r])  Return a matrix whose column span is the same as X. 
tools.isestimable(C, D) True if (Q, P) contrast C is estimable for (N, P) design D 
tools.rank(X[, cond])   Return the rank of a matrix X based on its generalized inverse, not the SVD. 
tools.recipr(X)         Return the reciprocal of an array, setting all entries less than or equal to 0 to 0. 
tools.recipr0(X)        Return the reciprocal of an array, setting all entries equal to 0 as 0. 
tools.unsqueeze(data, axis, oldshape)   Unsqueeze a collapsed array 

#Numerical Differentiation
numdiff.approx_fprime(x, f[, epsilon, args, ...])   Gradient of function, or Jacobian if function f returns 1d array 
numdiff.approx_fprime_cs(x, f[, epsilon, ...])      Calculate gradient or Jacobian with complex step derivative approximation 
numdiff.approx_hess1(x, f[, epsilon, args, ...])    Calculate Hessian with finite difference derivative approximation 
numdiff.approx_hess2(x, f[, epsilon, args, ...])    Calculate Hessian with finite difference derivative approximation 
numdiff.approx_hess3(x, f[, epsilon, args, ...])    Calculate Hessian with finite difference derivative approximation 
numdiff.approx_hess_cs(x, f[, epsilon, ...])        Calculate Hessian with complex-step derivative approximation 

#Measure for fit performance eval_measures
#The function with _sigma suffix take the error sum of squares as argument, 
#those without, take the value of the log-likelihood, llf, as argument.
eval_measures.aic(llf, nobs, df_modelwc)            Akaike information criterion 
eval_measures.aic_sigma(sigma2, nobs, df_modelwc)   Akaike information criterion 
eval_measures.aicc(llf, nobs, df_modelwc)           Akaike information criterion (AIC) with small sample correction 
eval_measures.aicc_sigma(sigma2, nobs, ...)         Akaike information criterion (AIC) with small sample correction 
eval_measures.bic(llf, nobs, df_modelwc)            Bayesian information criterion (BIC) or Schwarz criterion 
eval_measures.bic_sigma(sigma2, nobs, df_modelwc)   Bayesian information criterion (BIC) or Schwarz criterion 
eval_measures.hqic(llf, nobs, df_modelwc)           Hannan-Quinn information criterion (HQC) 
eval_measures.hqic_sigma(sigma2, nobs, ...)         Hannan-Quinn information criterion (HQC) 

eval_measures.bias(x1, x2[, axis])          bias, mean error 
eval_measures.iqr(x1, x2[, axis])           interquartile range of error 
eval_measures.maxabs(x1, x2[, axis])        maximum absolute error 
eval_measures.meanabs(x1, x2[, axis])       mean absolute error 
eval_measures.medianabs(x1, x2[, axis])     median absolute error 
eval_measures.medianbias(x1, x2[, axis])    median bias, median error 
eval_measures.mse(x1, x2[, axis])           mean squared error 
eval_measures.rmse(x1, x2[, axis])          root mean squared error 
eval_measures.stde(x1, x2[, ddof, axis])    standard deviation of error 
eval_measures.vare(x1, x2[, ddof, axis])    variance of error 


#Example 
from statsmodels.compat.python import zip
import numpy as np
from numpy.testing import assert_equal, assert_almost_equal, assert_
from statsmodels.tools.eval_measures import (
    maxabs, meanabs, medianabs, medianbias, mse, rmse, stde, vare,
    aic, aic_sigma, aicc, aicc_sigma, bias, bic, bic_sigma,
    hqic, hqic_sigma, iqr)
x = np.arange(20).reshape(4,5)
y = np.ones((4,5))
assert_equal(iqr(x, y), 5*np.ones(5))
assert_equal(iqr(x, y, axis=1), 2*np.ones(4))
assert_equal(iqr(x, y, axis=None), 9)
assert_equal(mse(x, y),
             np.array([  73.5,   87.5,  103.5,  121.5,  141.5]))
assert_equal(mse(x, y, axis=1),
             np.array([   3.,   38.,  123.,  258.]))
assert_almost_equal(rmse(x, y),
                    np.array([  8.5732141 ,   9.35414347,  10.17349497,
                               11.02270384,  11.89537725]))
assert_almost_equal(rmse(x, y, axis=1),
                    np.array([  1.73205081,   6.164414,
                               11.09053651,  16.0623784 ]))
assert_equal(maxabs(x, y),
             np.array([ 14.,  15.,  16.,  17.,  18.]))
assert_equal(maxabs(x, y, axis=1),
             np.array([  3.,   8.,  13.,  18.]))
assert_equal(meanabs(x, y),
             np.array([  7. ,   7.5,   8.5,   9.5,  10.5]))
assert_equal(meanabs(x, y, axis=1),
             np.array([  1.4,   6. ,  11. ,  16. ]))
assert_equal(meanabs(x, y, axis=0),
             np.array([  7. ,   7.5,   8.5,   9.5,  10.5]))
assert_equal(medianabs(x, y),
             np.array([  6.5,   7.5,   8.5,   9.5,  10.5]))
assert_equal(medianabs(x, y, axis=1),
             np.array([  1.,   6.,  11.,  16.]))
assert_equal(bias(x, y),
             np.array([  6.5,   7.5,   8.5,   9.5,  10.5]))
assert_equal(bias(x, y, axis=1),
             np.array([  1.,   6.,  11.,  16.]))
assert_equal(medianbias(x, y),
             np.array([  6.5,   7.5,   8.5,   9.5,  10.5]))
assert_equal(medianbias(x, y, axis=1),
             np.array([  1.,   6.,  11.,  16.]))
assert_equal(vare(x, y),
             np.array([ 31.25,  31.25,  31.25,  31.25,  31.25]))
assert_equal(vare(x, y, axis=1),
             np.array([ 2.,  2.,  2.,  2.]))
                 


##Statsmodel-QuickIntro - sm.webdoc
webdoc(arg=None, stable=None)
    Opens a browser and displays online documentation
    Parameters
    ----------
    arg, optional : string or statsmodels function
        Either a string to search the documentation or a function
        
#Example 
>>> import statsmodels.api as sm
>>> sm.webdoc()  # Documention site
>>> sm.webdoc('glm')  # Search for glm in docs
>>> sm.webdoc(sm.OLS, stable=False)  # Go to generated help for OLS, devel
             
                 

###Statsmodel- Statistics- sm.stats

#Residual Diagnostics and Specification Tests
#Examples in 'QuickIntro - with/without formula OLS  and Regression test'
durbin_watson(resids[, axis])       Calculates the Durbin-Watson statistic 
jarque_bera(resids[, axis])         Calculates the Jarque-Bera test for normality 
omni_normtest(resids[, axis])       Omnibus test for normality 

medcouple(y[, axis])                Calculates the medcouple robust measure of skew. 
robust_skewness(y[, axis])          Calculates the four skewness measures in Kim & White 
robust_kurtosis(y[, axis, ab, dg, excess])  Calculates the four kurtosis measures in Kim & White 
expected_robust_kurtosis([ab, dg])  Calculates the expected value of the robust kurtosis measures in Kim and White assuming the data are normally distributed. 
 
acorr_ljungbox(x[, lags, boxpierce])            Ljung-Box test for no autocorrelation 
acorr_breusch_godfrey(results[, nlags, store])  Breusch Godfrey Lagrange Multiplier tests for residual autocorrelation 
HetGoldfeldQuandt                               test whether variance is the same in 2 subsamples 
het_goldfeldquandt                              see class docstring 
het_breuschpagan(resid, exog_het)               Breusch-Pagan Lagrange Multiplier test for heteroscedasticity 
het_white(resid, exog[, retres])                White's Lagrange Multiplier Test for Heteroscedasticity 
het_arch(resid[, maxlag, autolag, store, ...])  Engle's Test for Autoregressive Conditional Heteroscedasticity (ARCH) 
linear_harvey_collier(res)                      Harvey Collier test for linearity 
linear_rainbow(res[, frac])                     Rainbow test for linearity 
linear_lm(resid, exog[, func])                  Lagrange multiplier test for linearity against functional alternative 
breaks_cusumolsresid(olsresidual[, ddof])       cusum test for parameter stability based on ols residuals 
breaks_hansen(olsresults)                       test for model stability, breaks in parameters for ols, Hansen 1992 
recursive_olsresiduals(olsresults[, skip, ...]) calculate recursive ols with residuals and cusum test statistic 

CompareCox Cox          Test for non-nested models 
compare_cox Cox         Test for non-nested models 
CompareJ                J-Test for comparing non-nested models 
compare_j               J-Test for comparing non-nested models 
unitroot_adf(x[, maxlag, trendorder, ...])  
normal_ad(x[, axis])            Anderson-Darling test for normal distribution unknown mean and variance 
kstest_normal(x[, pvalmethod])  lilliefors test for normality, 
lilliefors(x[, pvalmethod])     lilliefors test for normality, 

#Outliers and influence measures
#Examples in 'QuickIntro - with/without formula OLS  and Regression test'
OLSInfluence(results)                       class to calculate outlier and influence measures for OLS result 
variance_inflation_factor(exog, exog_idx)   variance inflation factor, VIF, for one exogenous variable 



#Goodness of Fit Tests and Measures
#some tests for goodness of fit for univariate distributions
powerdiscrepancy(observed, expected[, ...])     Calculates power discrepancy, a class of goodness-of-fit tests as a measure of discrepancy between observed and expected data. 
gof_chisquare_discrete(distfn, arg, rvs, ...)   perform chisquare test for random sample of a discrete distribution 
gof_binning_discrete(rvs, distfn, arg[, nsupp]) get bins for chisquare type gof tests for a discrete distribution 
chisquare_effectsize(probs0, probs1[, ...])     effect size for a chisquare goodness-of-fit test 
normal_ad(x[, axis])                            Anderson-Darling test for normal distribution unknown mean and variance 
kstest_normal(x[, pvalmethod])                  lilliefors test for normality, 
lilliefors(x[, pvalmethod])                     lilliefors test for normality, 


#Interrater Reliability and Agreement
cohens_kappa(table[, weights, ...])     Compute Cohen's kappa with variance and equal-zero test 
fleiss_kappa(table)                     Fleiss' kappa multi-rater agreement measure 
to_table(data[, bins])                  convert raw data with shape (subject, rater) to (rater1, rater2) 
aggregate_raters(data[, n_cat])         convert raw data with shape (subject, rater) to (subject, cat_counts) 

#Sandwich Robust Covariances
#The following functions calculate covariance matrices 
#and standard errors for the parameter estimates 
#that are robust to heteroscedasticity and autocorrelation in the errors. 

#these methods are designed for use with OLSResults
sandwich_covariance.cov_hac(results[, ...])         heteroscedasticity and autocorrelation robust covariance matrix (Newey-West) 
sandwich_covariance.cov_nw_panel(results, ...)      Panel HAC robust covariance matrix 
sandwich_covariance.cov_nw_groupsum(results, ...)   Driscoll and Kraay Panel robust covariance matrix 
sandwich_covariance.cov_cluster(results, group)     cluster robust covariance matrix 
sandwich_covariance.cov_cluster_2groups(...)        cluster robust covariance matrix for two groups/clusters 
sandwich_covariance.cov_white_simple(results)       heteroscedasticity robust covariance matrix (White) 

sandwich_covariance.cov_hc0(results) 
sandwich_covariance.cov_hc1(results) 
sandwich_covariance.cov_hc2(results) 
sandwich_covariance.cov_hc3(results) 
sandwich_covariance.se_cov(cov)             get standard deviation from covariance matrix 




#Moment Helpers
#The following three functions can be used to find a correlation or covariance 
#matrix that is positive definite and close to the original matrix.
corr_clipped(corr[, threshold])             Find a near correlation matrix that is positive semi-definite 
corr_nearest(corr[, threshold, n_fact])     Find the nearest correlation matrix that is positive semi-definite. 
corr_nearest_factor(corr, rank[, ctol, ...]) Find the nearest correlation matrix with factor structure to a given square matrix. 
corr_thresholded(data[, minabs, max_elt])   Construct a sparse matrix containing the thresholded row-wise correlation matrix from a data array. 
cov_nearest(cov[, method, threshold, ...])  Find the nearest covariance matrix that is postive (semi-) definite 
cov_nearest_factor_homog(cov, rank)         Approximate an arbitrary square matrix with a factor-structured matrix of the form k*I + XX'. 
FactoredPSDMatrix(diag, root)               Representation of a positive semidefinite matrix in factored form. 
#These are utility functions to convert between central 
#and non-central moments, skew, kurtosis and cummulants.
cum2mc(kappa)       convert non-central moments to cumulants 
mc2mnc(mc)          convert central to non-central moments, uses recursive formula 
mc2mvsk(args)       convert central moments to mean, variance, skew, kurtosis 
mnc2cum(mnc)        convert non-central moments to cumulants 
mnc2mc(mnc[, wmean]) convert non-central to central moments, uses recursive formula 
mnc2mvsk(args)      convert central moments to mean, variance, skew, kurtosis 
mvsk2mc(args)       convert mean, variance, skew, kurtosis to central moments 
mvsk2mnc(args)      convert mean, variance, skew, kurtosis to non-central moments 

cov2corr(cov[, return_std]) convert covariance matrix to correlation matrix 
corr2cov(corr, std) convert correlation matrix to covariance matrix given standard deviation 
se_cov(cov)         get standard deviation from covariance matrix 






###statsmodel - sm.stats - Mediation Analysis
#Rather than a direct causal relationship between the independent variable 
#and the dependent variable, 
#a mediation model proposes that the independent variable influences 
#the (non-observable) mediator variable, 
#which in turn influences the dependent variable.


#Mediation analysis focuses on the relationships among three key variables: 
#an 'outcome', a 'treatment', and a 'mediator'. 


class statsmodels.stats.mediation.Mediation(outcome_model, mediator_model, exposure, mediator=None, moderators=None, outcome_fit_kwargs=None, mediator_fit_kwargs=None)[source]
    Conduct a mediation analysis.
    Parameters:
    outcome_model : statsmodels model
        Regression model for the outcome. 
        Predictor variables include the treatment/exposure, the mediator, and any other variables of interest.
    mediator_model : statsmodels model
        Regression model for the mediator variable. 
        Predictor variables include the treatment/exposure and any other variables of interest.
    exposure : string or (int, int) tuple
        The name or column position of the treatment/exposure variable. 
        If positions are given, the first integer is the column position of the exposure variable in the outcome model 
        and the second integer is the position of the exposure variable in the mediator model. If a string is given, it must be the name of the exposure variable in both regression models.
    mediator : string or int
        The name or column position of the mediator variable in the outcome regression model. 
        If None, infer the name from the mediator model formula (if present).
    moderators : dict
        Map from variable names or index positions to values of moderator variables 
        that are held fixed when calculating mediation effects   
    Methods
    fit([method, n_rep]) 
        Fit a regression model to assess mediation. 
        Returns      MediationResults
        
MediationResults(indirect_effects, ...)         
    A class for holding the results of a mediation analysis. 
        summary(alpha=0.05)
            Provide a summary of a mediation analysis.


#Example 
#A basic mediation analysis using formulas:

import statsmodels.api as sm
import statsmodels.genmod.families.links as links
import pandas as pd 

data = pd.read_csv("framing.csv")

probit = links.probit
outcome_model = sm.GLM.from_formula("cong_mesg ~ emo + treat + age + educ + gender + income",
                                    data, family=sm.families.Binomial(link=probit))
mediator_model = sm.OLS.from_formula("emo ~ treat + age + educ + gender + income", data)
med = Mediation(outcome_model, mediator_model, "treat", "emo").fit()
med.summary()


#A moderated mediation analysis.  The mediation effect is computed
#for people of age 20.

fml = "cong_mesg ~ emo + treat*age + emo*age + educ + gender + income",
outcome_model = sm.GLM.from_formula(fml, data,
                                     family=sm.families.Binomial())
mediator_model = sm.OLS.from_formula("emo ~ treat*age + educ + gender + income", data)
moderators = {"age" : 20}
med = Mediation(outcome_model, mediator_model, "treat", "emo",
                moderators=moderators).fit()
med.summary()


###statsmodel - sm.stats - Non-Parametric Tests
mcnemar(x[, y, exact, correction])          McNemar test 
symmetry_bowker(table)                      Test for symmetry of a (k, k) square contingency table 
median_test_ksample(x, groups)              chisquare test for equality of median/location 
runstest_1samp(x[, cutoff, correction])     use runs test on binary discretized data above/below cutoff 
runstest_2samp(x[, y, groups, correction])  Wald-Wolfowitz runstest for two samples 
cochrans_q(x)                               Cochran's Q test for identical effect of k treatments 
Runs(x)                                     class for runs in a binary sequence 
sign_test(samp[, mu0])                      Signs test. 



##Non parametric 1 sample/2 sample run Test for randomness-  use with statsmodels.sandbox.stats.runs.
#Non-Parametric Tests - tests not assuming uniform distribution

runstest_1samp(x[, cutoff, correction])     use runs test on binary discretized data above/below cutoff
runstest_2samp(x[, y, groups, correction])  Wald-Wolfowitz runstest for two samples                                            


statsmodels.sandbox.stats.runs.runstest_1samp(x, cutoff='mean', correction=True)
    is x (binary discretized data above/below cutoff) random?
    H0:  sequence is random, p-value < 0.05, reject H0 
    cutoff : {'mean', 'median'} or number        
        This specifies the cutoff to split the data into two values 
    Returns (statistic, p-value). Note p-value is always last like numpy/scipy

#Example
import statsmodels.api as sm
x = np.array([1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1])
>>> sms.runstest_1samp(x, cutoff=x2.mean(), correction=False)
(1.386750490563073, 0.16551785869746993) #>0.05, don't reject  H0

#add some noise and then check
x2 = x - 0.5 + np.random.uniform(-0.1, 0.1, size=len(x)) 

>>> sm.stats.runstest_1samp(x2, cutoff=0, correction=False)
(1.386750490563073, 0.16551785869746993)   #>0.05, don't reject  H0
>>> sms.runstest_1samp(x2, cutoff='mean', correction=False)
(1.386750490563073, 0.16551785869746993)   #>0.05, don't reject  H0
>>> sms.runstest_1samp(x2, cutoff=x2.mean(), correction=False)
(1.386750490563073, 0.16551785869746993) #>0.05, don't reject  H0


#2 sample- Wald-Wolfowitz runstest for two samples
statsmodels.sandbox.stats.runs.runstest_2samp(x, y=None, groups=None, correction=True)
    H0: two samples come from the same distribution(ie with same mean)
    groups 
        1-dimensional array of [0s,1s], with 0 means data from x, 
        1 means data from y 
    Returns (statistic, p-value). Note p-value is always last like numpy/scipy

#Example 
x = [31.8, 32.8, 39.2, 36, 30, 34.5, 37.4]
y = [35.5, 27.6, 21.3, 24.8, 36.7, 30]
y[-1] += 1e-6  #avoid tie that creates warning
#append zeros, ones 
groups = np.concatenate((np.zeros(len(x)), np.ones(len(y))))
>>> runs.runstest_2samp(x, y)   #H0: x,y came from same distribution
(0.022428065200812752, 0.98210649318649212)   #>0.05, don't reject  H0
>>> xy = np.concatenate((x, y))       #append x,y
>>> runs.runstest_1samp(xy)
(0.022428065200812752, 0.98210649318649212)
>>> runs.runstest_1samp(xy, xy.mean())
(0.022428065200812752, 0.98210649318649212)
>>> runs.runstest_2samp(xy, groups=groups)
(0.022428065200812752, 0.98210649318649212)



###statsmodel - sm.stats - Multiple Tests and Multiple Comparison Procedures
#multipletests is a function for p-value correction, 
#which also includes p-value correction based on fdr in fdrcorrection. 
#tukeyhsd performs simulatenous testing for the comparison of (independent) means. 

multipletests(pvals[, alpha, method, ...])          test results and p-value correction for multiple tests 
fdrcorrection0(pvals[, alpha, method, is_sorted])   pvalue correction for false discovery rate 
GroupsStats(x[, useranks, uni, intlab])             statistics by groups (another version) 
MultiComparison(data, groups[, group_order])        Tests for multiple comparisons 
TukeyHSDResults(mc_object, results_table, q_crit)   Results from Tukey HSD test, with additional plot methods 
 
pairwise_tukeyhsd(endog, groups[, alpha])           calculate all pairwise comparisons with TukeyHSD confidence intervals 
 
local_fdr(zscores[, null_proportion, ...])          Calculate local FDR values for a list of Z-scores. 
fdrcorrection_twostage(pvals[, alpha, ...])         (iterated) two stage linear step-up procedure with estimation of number of true 
NullDistribution(zscores[, null_lb, ...])           Estimate a Gaussian distribution for the null Z-scores. 


##Nonparametric comparing pairwise means   - use with statsmodels.stats.multicomp.
#TukeyHSD -  Tukey's studentized range test (HSD)
#tukeyhsd performs simulatenous testing for the comparison of (independent) means(ie from different distribution)
#Tukey's studentized range test - checks range, hence non parametric
#H0: all  pairs having same mean (ie from same distribution)

MultiComparison(data, groups[, group_order])        Tests for multiple comparisons
TukeyHSDResults(mc_object, results_table, q_crit)   Results from Tukey HSD test, with additional plot methods
pairwise_tukeyhsd(endog, groups[, alpha])           shortcut method of return MultiComparison(endog, groups).tukeyhsd(alpha=alpha)
                                                    calculate all pairwise comparisons with TukeyHSD confidence intervals
                                                    Returns TukeyHSDResults instance


#Methods of MultiComparison
allpairtest(testfunc[, alpha, method, pvalidx])     run a pairwise test on all pairs with multiple test correction 
                                                    returns tupe(SimpleTable_instance, pure_result),
                                                    SimpleTable_instance has as_csv(),as_html(), as_text() methods 
getranks()                                          convert data to rankdata and attach 
kruskal([pairs, multimethod])                       *Unfinished* pairwise comparison for kruskal-wallis test 
tukeyhsd([alpha])                                   Tukey's range test to compare means of all pairs of groups 
                                                    returns TukeyHSDResults instance

#Methods of TukeyHSDResults
plot_simultaneous([comparison_name, ax, ...])   Plot a universal confidence interval of each group mean 
summary()                                       Summary table that can be printed 


#Example - we have three different treatments,
#Test whether the differences in means for the three pairs of treatments are different.
#(means - do three threatments have different effectiveness?)
#H0: Each pairs have same mean 

#code
import numpy as np
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd, MultiComparison

#Create a record array
dta2 = np.rec.array([
(  1,   'mental',  2 ),
(  2,   'mental',  2 ),
(  3,   'mental',  3 ),
(  4,   'mental',  4 ),
(  5,   'mental',  4 ),
(  6,   'mental',  5 ),
(  7,   'mental',  3 ),
(  8,   'mental',  4 ),
(  9,   'mental',  4 ),
( 10,   'mental',  4 ),
( 11, 'physical',  4 ),
( 12, 'physical',  4 ),
( 13, 'physical',  3 ),
( 14, 'physical',  5 ),
( 15, 'physical',  4 ),
( 16, 'physical',  1 ),
( 17, 'physical',  1 ),
( 18, 'physical',  2 ),
( 19, 'physical',  3 ),
( 20, 'physical',  3 ),
( 21,  'medical',  1 ),
( 22,  'medical',  2 ),
( 23,  'medical',  2 ),
( 24,  'medical',  2 ),
( 25,  'medical',  3 ),
( 26,  'medical',  2 ),
( 27,  'medical',  3 ),
( 28,  'medical',  1 ),
( 29,  'medical',  3 ),
( 30,  'medical',  1 ) ],
dtype=[('idx', '<i4'),('Treatment', '|S8'),('StressReduction', '<i4')])


#tukeyHSD

res2 = pairwise_tukeyhsd(dta2['StressReduction'], dta2['Treatment'])
>>> print(res2) ##H0: both are same
Multiple Comparison of Means - Tukey HSD,FWER=0.05
=============================================== 
group1  group2  meandiff  lower  upper  reject
-----------------------------------------------
medical  mental    1.5     0.3217 2.6783  True   #reject H0, soe medical and mental effectivness are different 
medical physical   1.0    -0.1783 2.1783 False   #don't reject H0 
mental physical   -0.5   -1.6783 0.6783 False    #don't reject H0
-----------------------------------------------
#plot
import matplotlib.pyplot as plt
res2.plot_simultaneous()
plt.plot()
#shows medical and mental , no overlapping, hence their means are different



#OR using MultiComparison
mod = MultiComparison(dta2['StressReduction'], dta2['Treatment'])
>>> print(mod.tukeyhsd())
Multiple Comparison of Means - Tukey HSD,FWER=0.05
=============================================== 
group1  group2  meandiff  lower  upper  reject
-----------------------------------------------
medical  mental    1.5     0.3217 2.6783  True
medical physical   1.0    -0.1783 2.1783 False 
mental physical   -0.5   -1.6783 0.6783 False
-----------------------------------------------

>>> mod.groupsunique
rec.array(['medical', 'mental', 'physical'],      
dtype='|S8')




##Parameteric comparing pairwise means   - Pairwise T-tests 
#(parameteric-hence normal dist) - alternate to TukeyHSD -  Tukey's studentized range test (HSD)
#part of MultiComparison class 
#run t-tests on all pairs, calculate the p-values
#Both statsmodels has  several options to adjust the p-values.
#Use  Holm and Bonferroni adjustments.
#H0: all pairs same

from scipy import stats
mod = MultiComparison(dta2['StressReduction'], dta2['Treatment'])
rtp = mod.allpairtest(stats.ttest_rel, method='Holm') #from stats.ttest_rel, paired t-test
>>> print(rtp[0])
Test Multiple Comparison ttest_rel
FWER=0.05 method=Holm
alphacSidak=0.02, alphacBonf=0.017
================================================ 
group1  group2    stat   pval  pval_corr reject
------------------------------------------------
medical  mental  -4.0249 0.003    0.009    True    #medical and mental 's mean are significantly different 
medical physical -1.9365 0.0848   0.1696  False 
mental physical  0.8321 0.4269   0.4269  False
------------------------------------------------

#Using Independent two Samples test (T-test)

>>> print(mod.allpairtest(stats.ttest_ind, method='b')[0])
Test Multiple Comparison ttest_ind
FWER=0.05 method=b
alphacSidak=0.02, alphacBonf=0.017
================================================ 
group1  group2    stat   pval  pval_corr reject
------------------------------------------------
medical  mental   -3.737 0.0015   0.0045   True
medical physical -2.0226 0.0582   0.1747  False 
mental physical  0.9583 0.3506    1.0    False
------------------------------------------------



###statsmodel - sm.stats -  Comparing means(parametric) - use with statsmodels.stats.weightstats.
ttest_ind(x1, x2[, alternative, usevar, ...])       ttest independent sample 
ttost_ind(x1, x2, low, upp[, usevar, ...])          test of (non-)equivalence for two independent samples 
ttost_paired(x1, x2, low, upp[, transform, ...])    test of (non-)equivalence for two dependent, paired sample 
ztest(x1[, x2, value, alternative, usevar, ddof])   test for mean based on normal distribution, one or two samples 
ztost(x1, low, upp[, x2, usevar, ddof])             Equivalence test based on normal distribution 
zconfint(x1[, x2, value, alpha, ...])               confidence interval based on normal distribution z-test 


##T-Test vs Z-Test vs F-test(ANOVA) - all parameteric ie assumes normal distribution, hence mean and sd are valid
Test      sample size       sigma
Z-Test      >30             known
T-test      <30             unknown
F-Test      Comparing three or more means under normal distribution
            for 1 way, use scipy.stats.f_one_away or statsmodels.stats.anova.anova_lm
            for 2 way, use statsmodel. stats.anova.anova_lm
            
##One sample vs 2 sample
One sample -  one sample comparing with given mean , H0:mean=given mu
two sample -  One sample comparing with another sample to check thier mean difference , H0:mean1=mean2
paired two sample - Like two sample, but each observation point of both is measured on same subject ,H0:mean1=mean2

       
        
##TOST: two one-sided t tests
    H0: the difference between the two samples is larger than the thresholds 
    given by low and upp.
    H0: m1 - m2 < low or m1 - m2 > upp 
    alternative hypothesis: low < m1 - m2 < upp
    where m1, m2 are the means, expected values of the two samples.

statsmodels.stats.weightstats.ttost_ind(x1, x2, low, upp, usevar='pooled', weights=(None, None), transform=None)[source]
    for two independent samples
statsmodels.stats.weightstats.ttost_paired(x1, x2, low, upp, transform=None, weights=None)[source]
    for two dependent, paired sample
    Parameters:
    x1, x2 : array_like, 1-D or 2-D
        two independent samples, 
        If d1 and d2 have the same number of columns, 
        then each column of the data in d1 is compared with the corresponding column in d2.
    low, upp : float
        equivalence interval low < m1 - m2 < upp
    usevar : string, 'pooled' or 'unequal'
        If pooled, then the standard deviation of the samples is assumed to be the same. 
        If unequal, then Welsh ttest with Satterthwait degrees of freedom is used
    weights : tuple of None or ndarrays
        Case weights for the two samples. 
    transform : None or function
        If None (default), then the data is not transformed. 
        Given a function, sample data and thresholds are transformed. 
        If transform is log, then the equivalence interval is in ratio: low < m1 / m2 < upp
    Returns:
    pvalue : float
        pvalue of the non-equivalence test
    t1, pv1, df1(only for ttost_paired) : tuple
        test statistic, pvalue and degrees of freedom for lower threshold test
    t2, pv2, df2(only for ttost_paired) : tuple
        test statistic, pvalue and degrees of freedom for upper threshold test
 
statsmodels.stats.weightstats.ztost(x1, low, upp, x2=None, usevar='pooled', ddof=1.0)[source]
    Equivalence test based on normal distribution
    1 sample case or 2 sample case
    Parameters:
    x1 : array_like
        one sample or first sample for 2 independent samples
    low, upp : float
        equivalence interval low < m1 - m2 < upp
    x1 : array_like or None
        second sample for 2 independent samples test. 
        If None, then a one-sample test is performed.
        
##ztest
Use statsmodels.stats.weightstats.ztest to compare two means,
    assuming they are independent and have the same standard deviation.
use CompareMeans.ztest_ind to compare means from distributions
    with different standard deviation

    
statsmodels.stats.weightstats.ztest(x1, x2=None, value=0, alternative='two-sided', usevar='pooled', ddof=1.0)
    test for mean based on normal distribution, one or two samples
    Parameters:
    x1, x2 : array_like, 1-D or 2-D
        two independent samples, 
        If d1 and d2 have the same number of columns, 
        then each column of the data in d1 is compared with the corresponding column in d2.
    value : float
        In the one sample case, value is the mean of x1 under the Null hypothesis. 
        In the two sample case, value is the difference between mean of x1 and mean of x2 under the Null hypothesis. 
        The test statistic is x1_mean - x2_mean - value.
    usevar : usevar not implemented, is always pooled in two sample case use CompareMeans instead
        string, 'pooled' or 'unequal'
        If pooled, then the standard deviation of the samples is assumed to be the same. 
        If unequal, then Welsh ttest with Satterthwait degrees of freedom is used
    Returns 
    zstat : float
        test statisic
    pvalue : float
        pvalue 
 

statsmodels.stats.weightstats.zconfint(x1, x2=None, value=0, alpha=0.05, alternative='two-sided', usevar='pooled', ddof=1.0)[source]
    confidence interval of mean  based on normal distribution z-test
    Parameters:
    x1, x2 : array_like, 1-D or 2-D
        two independent samples
    value : float
        In the one sample case, value is the mean of x1 under the Null hypothesis. 
        In the two sample case, value is the difference between mean of x1 and mean of x2 under the Null hypothesis. 
        The test statistic is x1_mean - x2_mean - value.
 
##T-Test
One sample  - use scipy.stats.ttest_1samp
2 sample    - use statsmodels.stats.weightstats.ttest_ind or scipy.stats.ttest_ind
paired      - use scipy.stats.ttest_rel

statsmodels.stats.weightstats.ttest_ind(x1, x2, alternative='two-sided ',   
            usevar='pooled', weights=(None, None), value=0)
    H0 mean1 = mean2 or mean1-mean2=0 or value (true mean) #p <0.05, rejectH0
    alternative : string
        'two-sided': H1: difference in means not equal to value (default) H0:mean1=mean2
        'larger' : H1: difference in means larger than value    , H0: mean1<mean2
        'smaller' : H1: difference in means smaller than value   , H0: mean1>mean2
    Returns:
    tstat : float
        test statisic
    pvalue : float
        pvalue of the t-test
    df : int or float
        degrees of freedom used in the t-test
 
#Example
import pandas
data = pandas.read_csv('data/brain_size.csv', sep=';', na_values=".")

>>> print data.head()    
Unnamed: 0  Gender  FSIQ  VIQ  PIQ  Weight  Height  MRI_Count
0            1  Female   133  132  124     118    64.5     816932
1            2    Male   140  150  124     NaN    72.5    1001121
2            3    Male   139  123  150     143    73.3    1038437
3            4    Male   133  129  128     172    68.8     965353
4            5  Female   137  132  134     147    65.0     951545

gender_data = data.groupby('Gender')
>>> print gender_data.mean()        
Unnamed: 0   FSIQ     VIQ     PIQ      Weight     Height  MRI_Count
Gender
Female       19.65  111.9  109.45  110.45  137.200000  65.765000   862654.6
Male         21.35  115.0  115.25  111.60  166.444444  71.431579   954855.4


from pandas.tools import plotting
import matplotlib.pyplot as plt
plotting.scatter_matrix(data[ ['Weight', 'Height', 'MRI_Count']    ])
plt.show()

#We have seen above that the mean VIQ in the male and female populations were different.
#To test if this is significant
female_viq = data[data['Gender'] == 'Female']['VIQ']
male_viq = data[data['Gender'] == 'Male']['VIQ']
import  statsmodels.stats.weightstats
>>> statsmodels.stats.weightstats.ttest_ind(female_viq, male_viq)
(-0.77261617232750124, 0.44452876778583217, 38.0)  #middle value is p-value, >0.05, don't reject H0, H0: same mean

#Example of Paired tests
#Paired T-Test
from scipy import stats 
>>> stats.ttest_rel(data['FSIQ'], data['PIQ'])
Ttest_relResult(statistic=1.7842019405859857, pvalue=0.082172638183642358) #>0.05, don't reject H0, H0: same mean

#T-tests assume Gaussian errors. Use a Wilcoxon signed-rank test, that relaxes this assumption:
from scipy import stats
>>> stats.wilcoxon(data['FSIQ'], data['PIQ'])
WilcoxonResult(statistic=274.5, pvalue=0.10659492713506856)  #>0.05, don't reject H0, H0: same mean

#Example - 1-sample t-test H0: observations are drawn from a Gaussian distributions of given population mean. It returns the T statistic, and the p-value (see the function's help):
>> stats.ttest_1samp(data['VIQ'], 0)
Ttest_1sampResult(statistic=30.088099970849328, pvalue=1.3289196468728067e-28) #<0.05, reject H0, H0:Gaussian dist








###statsmodel - sm.stats - Basic Statistics and compare Means(parametric) -class based  - use with statsmodels.stats.weightstats.
DescrStatsW(data[, weights, ddof])                  descriptive statistics and tests with weights for case weights 
CompareMeans(d1, d2)                                class for two sample comparison 


class statsmodels.stats.weightstats.DescrStatsW(data, weights=None, ddof=0)
    Assumes that the data is 1d or 2d with (nobs, nvars) 
    observations in rows, variables in columns, 
    and that the same weight applies to each column.
    If degrees of freedom correction is used, 
    then weights should add up to the number of observations. 
    ttest also assumes that the sum of weights corresponds to the sample size.
    This is essentially the same as replicating each observations by its weight, 
    if the weights are integers, often called case or frequency weights.
    Parameters:
    data : array_like, 1-D or 2-D
        dataset
    weights : None or 1-D ndarray
        weights for each observation, with same length as zero axis of data
    ddof : int
        default ddof=0, degrees of freedom correction used for second moments, var, std, cov, corrcoef. 
        However, statistical tests are independent of ddof, based on the standard formulas.


#DescrStatsW Methods
asrepeats()         get array that has repeats given by floor(weights)
corrcoef()          weighted correlation with default ddof
cov()               weighted covariance of data if data is 2 dimensional
demeaned()          data with weighted mean subtracted
mean()              weighted mean of data
nobs()              alias for number of observations/cases, equal to sum of weights
std()               standard deviation with default degrees of freedom correction
std_ddof([ddof])    standard deviation of data with given ddof
std_mean()          standard deviation of weighted mean
sum()               weighted sum of data
sum_weights  ()
sumsquares()                        weighted sum of squares of demeaned data
tconfint_mean([alpha, alternative]) two-sided confidence interval for weighted mean of data
ttest_mean([value, alternative])    ttest of Null hypothesis that mean is equal to value.
ttost_mean(low, upp)                test of (non-)equivalence of one sample
var()                               variance with default degrees of freedom correction
var_ddof([ddof])                    variance of data given ddof
zconfint_mean([alpha, alternative]) two-sided confidence interval for weighted mean of data
ztest_mean([value, alternative])    z-test of Null hypothesis that mean is equal to value.
ztost_mean(low, upp)
get_compare(other[, weights])       return an instance of CompareMeans with self and other , instance DescrStatsW

#CompareMeans
statsmodels.stats.weightstats.CompareMeans(d1, d2) 
    class for two sample comparison
    d1, d2 : instances of DescrStatsW

#statsmodels.stats.weightstats.CompareMeans - Methods
dof_satt()                                      degrees of freedom of Satterthwaite for unequal variance
std_meandiff_pooledvar()                        variance assuming equal variance in both data sets
std_meandiff_separatevar  ()
tconfint_diff([alpha, alternative, usevar])     confidence interval for the difference in means
ttest_ind([alternative, usevar, value])         ttest for the null hypothesis of identical means
ttost_ind(low, upp[, usevar])                   test of equivalence for two independent samples, base on t-test
zconfint_diff([alpha, alternative, usevar])     confidence interval for the difference in means
ztest_ind([alternative, usevar, value])         z-test for the null hypothesis of identical means
ztost_ind(low, upp[, usevar])                   test of equivalence for two independent samples, based on z-test
summary([use_t, alpha, usevar, value])          summarize the results of the hypothesis test 
from_data(data1, data2[, weights1, ...])        construct a CompareMeans object from data 

#Example of descriptive statistics - statsmodels.stats.weightstats.DescrStatsW

x1_2d = 1.0 + np.random.randn(20, 3)  #20x3 std normal random number , mean=0, sd=1
w1 = np.random.randint(1,4, 20)       #20 uniform random number between 1, 4
d1 = statsmodels.stats.weightstats.DescrStatsW(x1_2d, weights=w1)
>>> d1.mean
array([ 1.42739844,  1.23174284,  1.083753  ])
>>> d1.var
array([ 0.94855633,  0.52074626,  1.12309325])
>>> d1.std_mean
array([ 0.14682676,  0.10878944,  0.15976497])

>>> tstat, pval, df = d1.ttest_mean(0) #mean =0
>>> tstat; pval; df
array([  9.72165021,  11.32226471,   6.78342055])
array([  1.58414212e-12,   1.26536887e-14,   2.37623126e-08]) #<0.05, reject H0: H0:mean=0
44.0
>>> d1.ttest_mean(1)   #>0.5, don't reject H0, H0:mean = 1
(array([-1.31663973,  0.23744113,  2.36860934]), array([ 0.19761089,  0.81387685,  0.02426928]), 31.
0)


>>> tstat, pval, df = d1.ttest_mean([0, 1, 1])
>>> tstat; pval; df
array([ 9.72165021,  2.13019609,  0.52422632])
array([  1.58414212e-12,   3.87842808e-02,   6.02752170e-01])
44.0









###statsmodel - sm.stats - Power and Sample Size Calculations - statsmodels.stats.power.
#Implements power and sample size calculations for the t-tests,
#normal based test, F-tests and Chisquare goodness of fit test.

#power of test calculation - More the better 
The power or sensitivity of hypothesis test is the probability
that the test correctly rejects the null hypothesis (H0) (ie  (H1) is true.)

A type I error, also known as an error of the first kind, occurs
when the null hypothesis (H0) is true, but is rejected(alpha)
The probability of type I error is called the significance level of the hypothesis testing

A type II error, also known as an error of the second kind, occurs
when the null hypothesis is false, but  fails to be rejected(beta)
(the power =  1-beta)

#Methods for Statistical Power calculations - statsmodels.stats.power.
TTestIndPower(**kwds)       for t-test for two independent sample
                            currently only uses pooled variance
TTestPower(**kwds)          for one sample or paired sample t-test
GofChisquarePower(**kwds)   for one sample chisquare test
NormalIndPower([ddof])      for z-test for two independent samples.
FTestAnovaPower(**kwds)     F-test for one factor balanced ANOVA
FTestPower(**kwds)          for generic F-test

#All above have below methods
plot_power([dep_var, nobs, effect_size, ...])    
    plot power with number of observations or effect size on x-axis
power(effect_size, nobs1, alpha, ratio=1)        
    Calculate the power of a t-test for two independent sample
    ratio = nobs2/nobs1, =1 means equal sample size     
solve_power(effect_size=None, nobs=None,alpha=None, power=None, alternative='two-sided') 
    solve for any one parameter of the power
    Exactly one needs to be None, all others need numeric values.
    
#Quick methods 
statsmodels.stats.power.tt_solve_power = <bound method TTestPower.solve_power of <statsmodels.stats.power.TTestPower object>>
    solve for any one parameter of the power of a one sample t-test
    This test can also be used for a paired t-test, 
    where effect size is defined in terms of the mean difference, 
    and nobs is the number of pairs
statsmodels.stats.power.tt_ind_solve_power = <bound method TTestIndPower.solve_power of <statsmodels.stats.power.TTestIndPower object>>
    solve for any one parameter of the power of a two sample t-test
statsmodels.stats.power.zt_ind_solve_power = <bound method NormalIndPower.solve_power of <statsmodels.stats.power.NormalIndPower object>>
    solve for any one parameter of the power of a two sample z-test
    
    
#The one-sided test can be either 'larger', 'smaller'.
#larger = upper-tailed test = H1: actual value > given value (eg mu0)
#smaller = lower-tailed test = H1: actual value < given value (eg mu0)
#two-sided = H1: actual value != given value(mu0)
#a one-tailed test with alpha set at .05 has approximately the same power as a two-tailed test with alpha set at .10


# Power Analysis - Confidence of correct result

#The following four quantities are related
#Given any three, we can determine the fourth.
1. sample size, nobs 
2. effect size, Effect size emphasises the size of the difference between two groups
3. significance level = P(Type I error) = alpha , low the better 
4. power = 1 - P(Type II error) = 1 - beta = confidence of correct result, high the better

#Effect size for T-tests and Z-tests(d)
Cohen suggests that d values of 0.2, 0.5, and 0.8 represent small, medium, and large effect sizes respectively.
 
#Effect size for one way Anova and F-Test(f)
Cohen suggests that f values of 0.1, 0.25, and 0.4 represent small, medium, and large effect sizes respectively.

#Effect size for Chi-square Tests(w)
Cohen suggests that w values of 0.1, 0.3, and 0.5 represent small, medium, and large effect sizes respectively.

#Example
import statsmodels.stats.power as smp
>>> smp.TTestPower().power(effect_size=0.2, nobs=60, alpha=0.1, alternative='larger')
0.601340316701

>>> smp.TTestPower().power(effect_size=0.2, nobs=160, alpha=0.1, alternative='larger')
0.89282992525257199

#Calculate Power
>>> smp.TTestPower().solve_power(effect_size =0.55, nobs=40, alpha=0.05, alternative='two-sided')
0.93152481603307669
>>> smp.TTestPower().power(effect_size =0.55, nobs=40, alpha=0.05, alternative='two-sided')
0.93152481603307669


#Calculating the sample size to achieve a given power - 2 sample T-test
>>> smp.TTestIndPower().solve_power(effect_size=0.3, power=0.75, ratio=1, alpha=0.05, alternative='larger')
array([ 120.22320279])

#For unequal sample size in 2 sample T-Test  - use ratio
#for  example with twice as many observations in group 2 as in group 1
>>> smp.TTestIndPower().solve_power(0.3, power=0.75, ratio=2, alpha=0.05, alternative='larger')
array([ 90.11015096])
# 90 observations in sample 1, and about 180 observations in sample 2


# Proportion for one sample (Normal Approximation)
from statsmodels.stats._proportion import proportion_effectsize
#proportion_effectsize(prop1, prop2[, method]) 
#effect size for a test comparing two proportions 
>>> proportion_effectsize(0.4, 0.6)
0.20135792079033088
>>> smp.NormalIndPower().solve_power(0.2013579207903309, nobs1=60, alpha=0.05, ratio=0)
0.34470140912721525

# F-test for ANOVA
>>> smp.FTestAnovaPower().power(0.28, nobs=80, alpha=0.05, k_groups=4) #in each group 20 samples
0.51498349798649223

#Solving for the sample size (for each group in pwr, for total in statsmodels
>>> smp.FTestAnovaPower().solve_power(0.28, alpha=0.05, power=0.8, k_groups=4)
array([ 143.03088865])
>>> _ / 4
array([ 35.75772216])

#F-Test for linear Model
>>> smp.FTestPower().solve_power(effect_size=np.sqrt(0.1/(1-0.1)), df_num=89, df_denom=5, alpha=0.05)
0.67358904832076627

#Chi-square goodness-of-fit

>>> p0 = np.ones(4.) / 4
>>> p1 = np.concatenate(([0.375], np.ones(3.) * (1- 0.375) / 3))
>>> import statsmodels.stats.api as sms
>>> sms.chisquare_effectsize(p0, p1)  #get effectsize as first 
>>> es = sms.chisquare_effectsize(p0, p1)
>>> es
0.28867513459481292
>>> smp.GofChisquarePower().solve_power(es, nobs=100, n_bins=4, alpha=0.05)
0.67398350421626085

#If there are no parameters in the distribution that are estimated,
#then df = nobs -  1.
#If there are parameters that are (appropriately) estimated, then df = nobs - 1 - ddof,
#where ddof is the number of estimated parameters.


#Chisquare test for contingency tables
>>> smp.GofChisquarePower().solve_power(0.346, nobs=140, n_bins=(2-1)*(3-1) + 1, alpha=0.01)
0.88540533954389766


#Finding the sample size to obtain a given power

>>> smp.GofChisquarePower().solve_power(0.1, n_bins=(5-1)*(6-1) + 1, alpha=0.05, power=0.8)
array([ 2096.07846526])

#Correlation
#with Fisher z-transform approximation
>>> smp.NormalIndPower().power(np.arctanh(0.3), nobs1=50-3, alpha=0.05, ratio=0, alternative='two-sided')
0.56436763896354003
>>> smp.NormalIndPower().power(np.arctanh(0.3), nobs1=50-3, alpha=0.05, ratio=0, alternative='larger')
0.68335663306958949

#sample size calculations:
>>> [smp.NormalIndPower().solve_power(np.arctanh(r), alpha=0.05, ratio=0,            
            power= 0.8, alternative='two-sided') + 3 for r in [0.3, 0.5, 0.1]]
[array([ 84.92761044]), array([ 29.01223669]), array([ 782.64821794])]










###statsmodel - sm.stats - Proportion test - for discrete probs -  use statsmodels.stats.proportion.
import statsmodels.stats.proportion as smprop

proportion_confint(count, nobs[, alpha, method])    confidence interval for a binomial proportion
proportion_effectsize(prop1, prop2[, method])       effect size for a test comparing two proportions

binom_test(count, nobs[, prop, alternative])        Perform a test that the probability of success is  p.
binom_test_reject_interval(value, nobs[, ...])      rejection region for binomial test for one sample proportion
binom_tost(count, nobs, low, upp)                   exact TOST test for one proportion using binomial distribution
binom_tost_reject_interval(low, upp, nobs[, ...])   rejection region for binomial TOST

proportions_ztest(count, nobs[, value, ...])        test for proportions based on normal (z) test
proportions_ztost(count, nobs, low, upp[, ...])     Equivalence test based on normal distribution
proportions_chisquare(count, nobs[, value])         test for proportions based on chisquare test
proportions_chisquare_allpairs(count, nobs)         chisquare test of proportions for all pairs of k samples
proportions_chisquare_pairscontrol(count, nobs)     chisquare test of proportions for pairs of k samples compared to control
proportion_effectsize(prop1, prop2[, method])       effect size for a test comparing two proportions

power_binom_tost(low, upp, nobs[, p_alt, alpha  ])
power_ztost_prop(low, upp, nobs, p_alt[, ...])      Power of proportions equivalence test based on normal distribution
samplesize_confint_proportion(proportion, ...)      find sample size to get desired confidence interval length


#method to use for confidence interval, currently available methods :
•normal : asymptotic normal approximation
•agresti_coull : Agresti-Coull interval
•beta : Clopper-Pearson interval based on Beta distribution
•wilson : Wilson Score interval
•jeffrey : Jeffrey's Bayesian Interval
•binom_test : experimental, inversion of binom_test 


## Compare two for same sucess rate 
statsmodels.stats.proportion.proportions_ztest(count, nobs, value=None, 
            alternative='two-sided', prop_var=False)
    count : integer or array_like
        the number of successes in nobs trials. 
        If this is array_like, then the assumption is that 
        this represents the number of successes for each independent sample
    nobs : integer or array-like
        the number of trials or observations, with the same length as count.
    value : float, array_like or None, optional
        This is the value of the null hypothesis equal to the proportion 
        in the case of a one sample test. 
        In the case of a two-sample test, the null hypothesis is that 
        prop[0] - prop[1] = value, 
        where prop is the proportion in the two samples. 
        If not provided value = 0 and the null is prop[0] = prop[1]
statsmodels.stats.proportion.proportions_chisquare(count, nobs, value=None)
    test for proportions based on chisquare test
    If value is given, then all proportions are jointly tested against this value. 
    If value is not given and count and nobs are not scalar, 
    then the null hypothesis is that all samples have the same proportion.
    Parameters:
    count : integer or array_like
        the number of successes in nobs trials. 
        If this is array_like, then the assumption is that this represents the number of successes for each independent sample
    nobs : integer
        the number of trials or observations, with the same length as count.
    value : None or float or array_like     
    Returns:
    chi2stat : float
        test statistic for the chisquare test
    p-value : float
        p-value for the chisquare test
    (table, expected)
    table is a (k, 2) contingency table, 
    expected is the corresponding table of counts that are expected 
    under independence with given margins        
        
        
        
#Example - 5 is success out of 83, 12 is success out of 99 - are they same ?
import statsmodels.stats.proportion as smprop
count = np.array([5, 12])
nobs = np.array([83, 99  ])
>>> smprop.proportions_ztest(count, nobs, value=0)
(-1.4078304151258787, 0.15918129181156992)  #2nd value = pvalue, don't reject H0 , H0:same        
>>> smprop.proportions_chisquare(count, nobs)
(1.9819864777535043, 0.15918129181156587, (array([[ 5, 78],
       [12, 87]]), array([[ 7.75274725, 75.24725275],
       [ 9.24725275, 89.75274725]])))
       
       
##test of proportions for all pairs of k samples
statsmodels.stats.proportion.proportions_chisquare_allpairs(count, nobs, multitest_method='hs')
    chisquare test of proportions for all pairs of k samples
    Performs a chisquare test for proportions for all pairwise comparisons. 
    H0: pairs have same proportion 
    The alternative is two-sided
    Parameters:
    count : integer or array_like
        the number of successes in nobs trials.
    nobs : integer
        the number of trials or observations.
    Returns:
    result : AllPairsResults instance
        Methods 
            pval_corrected([method]) p-values corrected for multiple testing problem 
            pval_table() create a (n_levels, n_levels) array with corrected p_values 
            summary() returns text summarizing the results 
 
 
#Example 
n_success = np.array([ 73,  90, 114,  75])  #index 0,1,2,3
nobs = np.array([ 86,  93, 136,  82])
ppt = smprop.proportions_chisquare_allpairs(n_success, nobs)
>>> print(ppt.summary())  #H0: pair has same proportion 
Corrected p-values using Holm-Sidak p-value correction

Pairs  p-values
(0, 1)  0.02641  #reject H0
(0, 2)  0.8328   #accept H0
(0, 3)  0.3658   #accept H0
(1, 2)  0.0121   #reject H0
(1, 3)  0.3658   #accept H0
(2, 3)  0.3658   #accept H0

## To find sample size to get desired confidence interval length
statsmodels.stats.proportion.proportion_confint(count, nobs, alpha=0.05, method='normal')[source]
    confidence interval for a binomial proportion
    Parameters:
    count : int or array
        number of successes
    nobs : int
        total number of trials 
        
statsmodels.stats.proportion.samplesize_confint_proportion(proportion, half_length, alpha=0.05, method='normal')[source]
    find sample size to get desired confidence interval length
    Parameters:
    proportion : float in (0, 1)
        proportion or quantile
    half_length : float in (0, 1)
        desired half length of the confidence interval
        
#method to use for confidence interval, currently available methods :
•normal : asymptotic normal approximation
•agresti_coull : Agresti-Coull interval
•beta : Clopper-Pearson interval based on Beta distribution
•wilson : Wilson Score interval
•jeffrey : Jeffrey's Bayesian Interval
•binom_test : experimental, inversion of binom_test 

#Example - What is the CI  of success rate 12 for 20 observations (ie p =12/20=0.6)
nobs = 20
ci = smprop.proportion_confint(12, nobs, alpha=0.05, method='normal')
samplesize = smprop.samplesize_confint_proportion(12./nobs, (ci[1] - ci[0]) / 2)
>>> ci
(0.38529670275394107, 0.81470329724605883)
>>> samplesize #== nobs 
20.0  


statsmodels.stats.proportion.multinomial_proportions_confint(counts, alpha=0.05, method='goodman')
    Confidence intervals for multinomial proportions.
    A categorical response variable can take on k different values. 
    If you have a random sample from a multinomial response, 
    the sample proportions estimate the proportion of each category in the population
Parameters:
counts : array_like of int, 1-D
    Number of observations in each category.
alpha : float in (0, 1), optional
    Significance level, defaults to 0.05.
method : {'goodman', 'sison-glaz'}, optional
    Method to use to compute the confidence intervals; available methods are:
        •goodman: based on a chi-squared approximation, valid if all values in counts are greater or equal to 5 [R53]
        •sison-glaz: less conservative than goodman, but only valid if counts has 7 or more categories (len(counts) >= 7) [R54]
Returns:
confint : ndarray, 2-D
    Array of [lower, upper] confidence levels for each category, 
    such that overall coverage is (approximately) 1-alpha.
 
#Example
data Psych is k sample where each category 
Neurotic              91
Depressed             49
Schizophrenic         37
Personality disorder  43
Other                 10

import statsmodels.stats.proportion as smprop  
proportions = [91,49,37,43,10]    
smprop.multinomial_proportions_confint(proportions, 0.05)
>>> smprop.multinomial_proportions_confint(proportions, 0.05)
array([[0.31664566, 0.48051021],
       [0.15205626, 0.29012238],
       [0.10812595, 0.23263062],
       [0.12986268, 0.26160492],
       [0.01981054, 0.09274638]])
       
       
##Perform a test that the probability of success is   p.
binom_test(count, nobs, prop=0.5, alternative='two-sided')
    exact TOST test for one proportion using binomial distribution
    Parameters:
    count : integer or array_like
        the number of successes in nobs trials.
    nobs : integer
        the number of trials or observations.
    low, upp : floats
        lower and upper limit of equivalence region
    Returns:
    pvalue : float
        p-value of equivalence test
    pval_low, pval_upp : floats
        p-values of lower and upper one-sided tests
#Example 
smprop.binom_test(51, 235, prop=1. / 6)
0.043747970182413345  #<0.05 reject H0, H0: rate = 1/6
# R binom_test returns Copper-Pearson confint
smprop.proportion_confint(51, 235, alpha=0.05, method='beta')
(0.16606332980830396, 0.27526836402892607) #barely includes 1/6=.16666


##compare two prop for effectsize and use it to get power of test 
statsmodels.stats.proportion.proportion_effectsize(prop1, prop2, method='normal')[source]
    effect size for a test comparing two proportions
    To use in power calculation
    
import statsmodels.api as sm
>>> sm.stats.proportion_effectsize(0.5, 0.4)
0.20135792079033088
>>> sm.stats.proportion_effectsize([0.3, 0.4, 0.5], 0.4)
array([-0.21015893,  0.        ,  0.20135792])
import statsmodels.stats.power as smp
#NormalIndPower([ddof])      for z-test for two independent samples.
#ratio=nobs for 1st samples/nobs for 2nd samples 
>>> smp.NormalIndPower().solve_power(0.2013579207903309, nobs1=60, alpha=0.05, ratio=1)








###statsmodel -  Formula syntax  - uses patsy 
#http://statsmodels.sourceforge.net/devel/example_formulas.html

#Formula example (from patsy)
y ~ a + a:b + np.log(x)  #  plus an invisible intercept term
   
#Syntax    
    All operations are left-associative    
    (so a - b - c means the same as (a - b) - c, not a - (b - c)).

~   Separates the left-hand side and right-hand side of a formula. Optional.    
    If not present, then the formula is considered to contain a right-hand side only.    

+   Takes the set of terms given on the left of operator and the set of terms given on the right,    
    and returns a set of terms that combines both (i.e., it computes a set union ).    
    Note that this means that a + a is just a.    

-   Takes the set of terms given on the left and removes any terms    
    which are given on the right (i.e., it computes a set difference).

*   a * b is short-hand for a + b + a: b,    
    Standard ANOVA models are of the form a * b * c * ...    

/   a / b is shorthand for a + a:b    
    a / (b + c) is equivalent to a + a:b + a:c    
    (a + b)/c is equivalent to a + b + a:b:c (not same as a/c + b/c : / is not leftward distributive over +)

:   This takes two sets of terms,    
    and computes the interaction between each term on the left 
    and each term on the right    
    (a + b):(c + d) is the same as a:c + a:d + b:c + b:d    
    : takes the union of factors within two terms,    
    while + takes the union of two sets of terms.    
    a:a is just a, and (a:b):(a:c) is the same as a:b:c.     

**  This takes a set of terms on the left, and an integer n on the right,    
    and computes the * of that set of terms with itself n times.    
    (a + b + c + d) ** 3    
    is expanded to:    
    (a + b + c + d) * (a + b + c + d) * (a + b + c + d)    
    Note that an equivalent way to write this particular expression would be    
    a*b*c*d - a:b:c:d    

#Special case
C(x)            x is Categorical 

I(x)            The identity function. Simply returns its input unchanged.                
                I(x1 + x2) inside a formula to represent the sum of x1 and x2  

Q(name)         A way to 'quote' variable names, especially ones that do not otherwise meet Python's variable name rules
                y ~ weight.in.kg is y ~ Q("weight.in.kg")  

np.method(x)    Any np.method(x) can be used, Infact any vectorised method can be used

Intercept       y ~ x  is processed like y ~ 1 + x (with intercept term)                
                y ~ x - 1 does not have intercept term                
                0 and -1  represent the 'no-intercept"                
                -1 (which means the same as 0) and -0 (which means the same as 1)                
                Below all have no intercept term                
                y ~ x - 1                
                y ~ x + -1                
                y ~ -1 + x                
                y ~ 0 + x                
                y ~ x - (-0)       

##Check the design matrix  for a equation 
from patsy import  *
data = demo_data("a", "b", "y")
mat2 = dmatrices("y ~ 1 + a + b + a:b", data)[1] #dmatrices(formula, data) 
>>> mat2
DesignMatrix with shape (8, 4)
Intercept  a[T.a2]  b[T.b2]  a[T.a2]:b[T.b2]        
1            0        0                0        
1            0        1                0        
1            1        0                0        
1            1        1                1        
1            0        0                0        
1            0        1                0        
1            1        0                0        
1            1        1                1
Terms:
'Intercept' (column 0), 'a' (column 1), 'b' (column 2), 'a:b' (column 3)  


##Utility - patsy.balanced(factor_name=num_levels[, factor_name=num_levels, ..., repeat=1])
#Create simple balanced factorial designs for testing.
#Given some factor names and the number of desired levels for each, 
#generates a balanced factorial design in the form of a data dictionary

>>> balanced(a=2, b=3)
{'a': ['a1', 'a1', 'a1', 'a2', 'a2', 'a2'],
 'b': ['b1', 'b2', 'b3', 'b1', 'b2', 'b3']}



##Categorical values - use C(data, contrast=None, levels=None)
#Marks some data as being categorical, and specifies how to interpret it.

#•To explicitly mark some data as categorical
dmatrix("a", {"a": [1, 2, 3]})  #dmatrix(formula, data)
#use below 
dmatrix("C(a)", {"a": [1, 2, 3]})

#Types of coding(contrast) for Categorical values - patsy.builtins.
Treatment               Treatment coding (also known as dummy coding)default 
Sum(omit=None)          Deviation coding (also known as sum-to-zero coding).
Poly(scores=None)       Orthogonal polynomial contrast coding.
Helmert                 Helmert contrasts.
Diff                    Backward difference coding.  




#•To explicitly set the levels or override the default level ordering for categorical data, e.g.:
dmatrix("C(a, levels=["a2", "a1"])", balanced(a=2))

#Example of various coding 

# reduced rank
>>> dmatrix("C(a, Treatment)", balanced(a=3))
DesignMatrix with shape (3, 3)
  Intercept  C(a, Treatment)[T.a2]  C(a, Treatment)[T.a3]
          1                      0                      0
          1                      1                      0
          1                      0                      1
  Terms:
    'Intercept' (column0)
    'C(a, Treatment)' (columns 1:3)

# full rank
>>> dmatrix("0 + C(a, Treatment)", balanced(a=3))
DesignMatrix with shape (3, 3)
  C(a, Treatment)[a1]  C(a, Treatment)[a2]  C(a, Treatment)[a3]
                    1                    0                    0
                    0                    1                    0
                    0                    0                    1
  Terms:
    'C(a, Treatment)' (columns 0:3)

# Reduced rank with Sum -each column sum is zero 
>>> dmatrix("C(a, Sum)", balanced(a=4))
DesignMatrix with shape (4, 4)
  Intercept  C(a, Sum)[S.a1]  C(a, Sum)[S.a2]  C(a, Sum)[S.a3]
          1                1                0                0
          1                0                1                0
          1                0                0                1
          1               -1               -1               -1
  Terms:
    'Intercept' (column 0)
    'C(a, Sum)' (columns 1:4)

# Full rank
>>> dmatrix("0 + C(a, Sum)", balanced(a=4))
DesignMatrix with shape (4, 4)
  C(a, Sum)[mean]  C(a, Sum)[S.a1]  C(a, Sum)[S.a2]  C(a, Sum)[S.a3]
                1                1                0                0
                1                0                1                0
                1                0                0                1
                1               -1               -1               -1
  Terms:
    'C(a, Sum)' (columns 0:4)

# Omit a different level
>>> dmatrix("C(a, Sum(1))", balanced(a=3))
DesignMatrix with shape (3, 3)
  Intercept  C(a, Sum(1))[S.a1]  C(a, Sum(1))[S.a3]
          1                   1                   0
          1                  -1                  -1
          1                   0                   1
  Terms:
    'Intercept' (column 0)
    'C(a, Sum(1))' (columns 1:3)

>>> dmatrix("C(a, Sum('a1'))", balanced(a=3))
DesignMatrix with shape (3, 3)
  Intercept  C(a, Sum('a1'))[S.a2]  C(a, Sum('a1'))[S.a3]
          1                     -1                     -1
          1                      1                      0
          1                      0                      1
  Terms:
    'Intercept' (column 0)
    "C(a, Sum('a1'))" (columns 1:3)







##Namespaces for executing formula
#The default is to use the caller's namespace.
#The namespace used can be controlled via the eval_env keyword.
#For example, you may want to give a custom namespace using the patsy.EvalEnvironment
#or you may want to use a 'clean' namespace, which we provide by passing eval_func=- 1. 


# Using formulas with models that do not  support them
#Use dmatrix from patsy
# Those matrices can then be fed to the fitting function as endog and exog arguments.

import patsy
f = 'Lottery ~ Literacy * Wealth'
y,X = patsy.dmatrices(f, df, return_type='dataframe')
print y[:5]
print X[:5]
print smf.OLS(y, X).fit().summary()


##Example 
import statsmodels.formula.api as smf
import statsmodels as  sm
import numpy as np
import pandas

#print a list of available models
dir(smf)

#call signature of statsmodels formula API :
small_letter_model(formula, data, subset=None, *args, **kwargs)


#OLS regression using formulas
df = sm.datasets.get_rdataset("Guerry", "HistData").data
df = df[['Lottery', 'Literacy', 'Wealth', 'Region']].dropna()
>>> df.head()   
Lottery  Literacy  Wealth Region
0       41        37      73      E
1       38        51      22      N
2       66        13      61      C
3       80        46      76      E
4       79        69      83      E



mod = smf.ols(formula='Lottery ~ Literacy + Wealth + Region', data=df)
res = mod.fit()  # check result class attributes from http://www.statsmodels.org/dev/generated/statsmodels.regression.linear_model.OLSResults.html#statsmodels.regression.linear_model.OLSResults
>>> print res.summary()

OLS Regression Results
==============================================================================
Dep. Variable:                Lottery   R-squared:                       0.338
Model:                            OLS   Adj. R-squared:                  0.287
Method:                 Least Squares   F-statistic:                     6.636
Date:                Wed, 10 Aug 2016   Prob (F-statistic):           1.07e-05
Time:                        19:13:49   Log-Likelihood:                -375.30
No. Observations:                  85   AIC:                             764.6
Df Residuals:                      78   BIC:                             781.7
Df Model:                           6
Covariance Type:            nonrobust
===============================================================================                  
               coef      std err          t      P>|t|      [95.0% Conf. Int.]
-------------------------------------------------------------------------------
Intercept      38.6517      9.456      4.087      0.000        19.826    57.478
Region[T.E]   -15.4278      9.727     -1.586      0.117       -34.793     3.938
Region[T.N]   -10.0170      9.260     -1.082      0.283       -28.453     8.419
Region[T.S]    -4.5483      7.279     -0.625      0.534       -19.039     9.943
Region[T.W]   -10.0913      7.196     -1.402      0.165       -24.418     4.235
Literacy       -0.1858      0.210     -0.886      0.378        -0.603     0.232
Wealth          0.4515      0.103      4.390      0.000         0.247     0.656
==============================================================================
Omnibus:                        3.049   Durbin-Watson:                   1.785
Prob(Omnibus):                  0.218   Jarque-Bera (JB):                2.694
Skew:                          -0.340   Prob(JB):                        0.260
Kurtosis:                       2.454   Cond. No.                         371.
==============================================================================



##Using  Categorical variables
#patsy determined that elements of Region were text strings,
#so it treated Region as a categorical variable by default

#Use C() to treat explicitly as categorical
#for example, if Region has interger category values
res = smf.ols(formula='Lottery ~ Literacy + Wealth + C(Region)', data=df).fit()
print res.params
Intercept         38.651655
C(Region)[T.E]   -15.427785   #Region == E
C(Region)[T.N]   -10.016961   #Region == N
C(Region)[T.S]    -4.548257   #Region == S
C(Region)[T.W]   -10.091276   #Region == W
Literacy          -0.185819
Wealth             0.451475


##Removing variables - for example removing intercept
res = smf.ols(formula='Lottery ~ Literacy + Wealth + C(Region) -1 ', data=df).fit()
print res.params



##Multiplicative interactions - by using :
#':' adds a new column to the design matrix with the product of the other two columns.
#'*' will also include the individual columns that were multiplied together

#lower aic/bic is bettern compare by res1.aic(), res2.bic()
res1 = smf.ols(formula='Lottery ~ Literacy : Wealth - 1', data=df).fit()
res2 = smf.ols(formula='Lottery ~ Literacy * Wealth - 1', data=df).fit()
print res1.params, '\n'
print res2.params

#Adding vectorized Functions to models
res = smf.ols(formula='Lottery ~ np.log(Literacy)', data=df).fit()
print res.params

# Adding a custom function:
def log_plus_1(x):    
    return np.log(x) + 1.    

res = smf.ols(formula='Lottery ~ log_plus_1(Literacy)', data=df).fit()
print res.params

##Another example of C ()

url = 'https://github.com/rpruim/OpenIntro/blob/master/data/hsb2.csv'
hsb2 = pd.read_table(url, delimiter=",")
hsb2 = pd.read_csv("data/hsb2.csv", delimiter=",")
>> hsb2.head()
   id  gender   race     ses  schtyp        prog  read  write  math  science  \

   70    male  white     low  public     general    57     52    41       47

  121  female  white  middle  public  vocational    68     59    53       63

   86    male  white    high  public     general    44     33    54       58

  141    male  white    high  public  vocational    63     44    47       53

  172    male  white  middle  public    academic    47     52    57       53

>>> hsb2.race.value_counts()
white               145
hispanic             24
african american     20
asian                11
Name: race, dtype: int64

from statsmodels.formula.api import ols
mod = ols("write ~ C(race, Treatment)", data=hsb2)
res = mod.fit()  # check result class attributes from http://www.statsmodels.org/dev/generated/statsmodels.regression.linear_model.OLSResults.html#statsmodels.regression.linear_model.OLSResults
print(res.summary())
#relevant section
#P>|t| if <0.05, accept that term, rest reject
#equivalent to if [95.0% Conf. Int.] contains 0 .0
>>> print(res.summary())
                            OLS Regression Results
==============================================================================
Dep. Variable:                  write   R-squared:                       0.107
Model:                            OLS   Adj. R-squared:                  0.093
Method:                 Least Squares   F-statistic:                     7.833
Date:                Mon, 29 Jan 2018   Prob (F-statistic):           5.78e-05
Time:                        10:33:30   Log-Likelihood:                -721.77
No. Observations:                 200   AIC:                             1452.
Df Residuals:                     196   BIC:                             1465.
Df Model:                           3
Covariance Type:            nonrobust
================================================================================
==================
                                     coef    std err          t      P>|t|
[0.025      0.975]
--------------------------------------------------------------------------------
------------------
Intercept                         48.2000      2.018     23.884      0.000
44.220      52.180
C(race, Treatment)[T.asian]        9.8000      3.388      2.893      0.004
 3.119      16.481
C(race, Treatment)[T.hispanic]    -1.7417      2.732     -0.637      0.525
-7.131       3.647
C(race, Treatment)[T.white]        5.8552      2.153      2.720      0.007
 1.610      10.101
==============================================================================
Omnibus:                       10.487   Durbin-Watson:                   1.779
Prob(Omnibus):                  0.005   Jarque-Bera (JB):               11.031
Skew:                          -0.551   Prob(JB):                      0.00402
Kurtosis:                       2.670   Cond. No.                         8.82
==============================================================================
#Means, race is Categorical
C(race, Treatment)[T.asian]   means when race= asian ,=A(say) , contrast=[1,0,0]
C(race, Treatment)[T.hispanic]   means when race= hispanic = B   contrast=[0,1,0]
C(race, Treatment)[T.white]   means when race= white = C  contrast=[0,0,1]

#the fitments equation would be (ignoring non significant coeff)
write = 48.2000 + 9.8000*A + 5.8552 *C

#To get full rank , remove intercept 
mod = ols("write ~ 0 + C(race, Treatment)", data=hsb2)
res = mod.fit()  # check result class attributes from http://www.statsmodels.org/dev/generated/statsmodels.regression.linear_model.OLSResults.html#statsmodels.regression.linear_model.OLSResults
print(res.summary())











###statsmodel - Linear Model - Result Class 

#Model Classes
OLS(endog[, exog, missing, hasconst])           A simple ordinary least squares model. 
GLS(endog, exog[, sigma, missing, hasconst])    Generalized least squares model with a general covariance structure. 
WLS(endog, exog[, weights, missing, hasconst])  A regression model with diagonal but non-identity covariance structure. 
GLSAR(endog[, exog, rho, missing])              A regression model with an AR(p) covariance structure. 
yule_walker(X[, order, method, df, inv, demean]) Estimate AR(p) parameters from a sequence X using Yule-Walker equation. 
QuantReg(endog, exog, **kwargs)                 Quantile Regression 
RecursiveLS(endog, exog, **kwargs)              Recursive least squares 

#Results Classes
RegressionResults(model, params[, ...])             This class summarizes the fit of a linear regression model. 
OLSResults(model, params[, ...])                    Results class for for an OLS model. 
QuantRegResults(model, params[, ...])               Results instance for the QuantReg model 
RecursiveLSResults(model, params, filter_results)   Class to hold results from fitting a recursive least squares model. 


##Result Methods and Attributes 
#Note base class is RegressionResults and other classes are derived from it
>>> sm.regression.linear_model.OLSResults.__mro__
(<class 'statsmodels.regression.linear_model.OLSResults'>, 
<class 'statsmodels.regression.linear_model.RegressionResults'>, 
<class 'statsmodels.base.model.LikelihoodModelResults'>, 
<class 'statsmodels.base.model.Results'>, <class 'object'>)
 
##Result Methods and Attributes 
ssr() :                     Sum of squared (whitened) residuals.
                            
mse_total() :               Total mean squared error. High is bad   
                            
resid() :                   The residuals of each observations
                            it's pandas.core.series.Series    
                            
fittedvalues() :            The predicted the values for the original (unwhitened) design.
                            it's pandas.core.series.Series   
                            
params() :                  The linear coefficients that minimize the least squares criterion. This is usually called Beta for the classical linear model.
                            It's pandas.core.series.Series , use accessing methods from Series 
                            
pvalues() :                 The two-tailed p values for the t-stats of the params.
                            it's pandas.core.series.Series 
                            
bse                         The standard errors of the parameter estimates
                            it's pandas.core.series.Series
                            
HC0_se() :                  White's (1980) heteroskedasticity robust standard errors, High is bad
HC1_se() :                  MacKinnon and White's (1985) alternative heteroskedasticity robust standard errors
HC2_se() :                  MacKinnon and White's (1985) alternative heteroskedasticity robust standard errors
HC3_se() :                  MacKinnon and White's (1985) alternative heteroskedasticity robust standard errors
                            
conf_int([alpha, cols])     Returns the confidence interval of the fitted parameters
                            it's pandas.core.frame.DataFrame
condition_number()          Return condition number of exogenous matrix. 
save(fname[, remove_data])  save a pickle of this instance 
load(fname)                 load a pickle, (class method) 
llf()                       Log likelihood
cov_params([r_matrix, column, scale, cov_p, ...])   
                            Returns covariance matrix of the parameter estimates 
                            or of linear combination of parameter estimates 
                            
aic                         Akaike's information criteria
bic                         Bayes' information criteria
cov_HC0                     Heteroscedasticity robust covariance matrix
cov_HC1                     Heteroscedasticity robust covariance matrix. 
cov_HC2                     Heteroscedasticity robust covariance matrix.
cov_HC3                     Heteroscedasticity robust covariance matrix.
cov_type                    Parameter covariance estimator used for standard errors and t-stats
df_model                    Model degress of freedom. The number of regressors p. Does not include the constant if one is present
df_resid                    Residual degrees of freedom. n - p - 1, if a constant is present. n - p if a constant is not included.
ess                         Explained sum of squares. 
fvalue                      F-statistic of the fully specified model. 
f_pvalue                    p-value of the F-statistic
mse_model                   Mean squared error the model. 
mse_resid                   Mean squared error of the residuals. 
mse_total                   Total mean squared error. 
params
resid                       The residuals of the model.
resid_pearson               wresid normalized to have unit variance.
rsquared                    R-squared of a model with an intercept. 
rsquared_adj                Adjusted R-squared.
ssr                         Sum of squared (whitened) residuals.


RegressionResults.summary(yname=None, xname=None, title=None, alpha=0.05)[source]
    Summarize the Regression Results
    Parameters:
    yname : string, optional
        Default is y
    xname : list of strings, optional
        Default is var_## for ## in p the number of regressors
    title : string, optional
        Title for the top table. If not None, then this replaces the default title
    alpha : float
        significance level for the confidence intervals
    Returns:
    smry : Summary instance
        this holds the summary tables and text, 
        which can be printed or converted to various output formats.
 
RegressionResults.predict(exog=None, transform=True, *args, **kwargs)
    Call self.model.predict with self.params as the first argument.
    Parameters:
    exog : array-like, optional
        The values for which you want to predict.
    transform : bool, optional
        If the model was fit via a formula, 
        do you want to pass exog through the formula. 
        Default is True. 
        E.g., if you fit a model y ~ log(x1) + log(x2), and transform is True, 
        then you can pass a data structure that contains x1 and x2 
        in their original form. Otherwise, you'd need to log the data first.
    Returns:
        prediction : ndarray, pandas.Series or pandas.DataFrame
 


RegressionResults.wald_test(r_matrix, cov_p=None, scale=1.0, 
                invcov=None, use_f=None)
    Compute a Wald-test for a joint linear hypothesis.
OLSResults.t_test(r_matrix, cov_p=None, scale=None, use_t=None)
    Compute a t-test for a each linear hypothesis of the form Rb = q
OLSResults.f_test(r_matrix, cov_p=None, scale=1.0, invcov=None)
    Compute the F-test for a joint linear hypothesis.
    This is a special case of wald_test that always uses the F distribution.
    Parameters:
    r_matrix : array-like, str, or tuple
        •array : An r x k array where r is the number of restrictions to test 
                and k is the number of regressors. 
                It is assumed that the linear combination is equal to zero.
        •str : The full hypotheses to test can be given as a string. 
        •tuple : A tuple of arrays in the form (R, q), 
                q can be either a scalar or a length k row vector.
    cov_p : array-like, optional
        An alternative estimate for the parameter covariance matrix. 
        If None is given, self.normalized_cov_params is used.
    scale : float, optional
        Default is 1.0 for no scaling.
    invcov : array-like, optional
        A q x q array to specify an inverse covariance matrix 
        based on a restrictions matrix.
    Returns:
        res : ContrastResults instance
            conf_int([alpha])               Returns the confidence interval of the value, effect of the constraint. 
            summary([xname, alpha, title])  Summarize the Results of the hypothesis test 
            summary_frame([xname, alpha])   Return the parameter table as a pandas DataFrame 
#Examples
import numpy as np
import statsmodels.api as sm
data = sm.datasets.longley.load()
data.exog = sm.add_constant(data.exog)
results = sm.OLS(data.endog, data.exog).fit()
A = np.identity(len(results.params))
A = A[1:,:]  #remove first row 

#H1: each coefficient is jointly statistically significantly different from zero.
>>> print(results.f_test(A))
<F test: F=array([[ 330.28533923]]), p=4.984030528700946e-10, df_denom=9, df_num=6>
#Compare this to
>>> results.fvalue
330.2853392346658
>>> results.f_pvalue
4.98403096572e-10

#H0: the coefficient on the 2nd and 3rd regressors are equal 
#and jointly that the coefficient on the 5th and 6th regressors are equal.
#coeff index      :0 1 2  3 4 5 6   0 1 2 3 4 5  6
B = np.array(([0,0,1,-1,0,0,0],[0,0,0,0,0,1,-1]))
>>> print(results.f_test(B))
<F test: F=array([[ 9.74046187]]), p=0.005605288531708235, df_denom=9, df_num=2>

##specify the hypothesis tests using a string
from statsmodels.datasets import longley
from statsmodels.formula.api import ols
dta = longley.load_pandas().data
formula = 'TOTEMP ~ GNPDEFL + GNP + UNEMP + ARMED + POP + YEAR'
results = ols(formula, dta).fit()
hypotheses = '(GNPDEFL = GNP), (UNEMP = 2), (YEAR/1829 = 1)' #H0
f_test = results.f_test(hypotheses)
>>> print(f_test)  #reject H0
<F test: F=array([[ 144.17976065]]), p=6.322026217355609e-08, df_denom=9, df_num=3>



#Examples of OLSResults.t_test
import numpy as np
import statsmodels.api as sm
data = sm.datasets.longley.load()
data.exog = sm.add_constant(data.exog)
results = sm.OLS(data.endog, data.exog).fit()
r = np.zeros_like(results.params)
r[5:] = [1,-1]
>>> print(r)
[ 0.  0.  0.  0.  0.  1. -1.]
#H0: coefficients on the 5th and 6th regressors are the same.
>>> T_test = results.t_test(r)
>>> print(T_test)
                             Test for Constraints
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
c0         -1829.2026    455.391     -4.017      0.003   -2859.368    -799.037
==============================================================================
>>> T_test.effect
-1829.2025687192481
>>> T_test.sd
455.39079425193762
>>> T_test.tvalue
-4.0167754636411717
>>> T_test.pvalue
0.0015163772380899498

#specify the hypothesis tests using a string
>>> from statsmodels.formula.api import ols
>>> dta = sm.datasets.longley.load_pandas().data
>>> formula = 'TOTEMP ~ GNPDEFL + GNP + UNEMP + ARMED + POP + YEAR'
>>> results = ols(formula, dta).fit()
>>> hypotheses = 'GNPDEFL = GNP, UNEMP = 2, YEAR/1829 = 1'
>>> t_test = results.t_test(hypotheses)
>>> print(t_test)
                             Test for Constraints
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
c0            15.0977     84.937      0.178      0.863    -177.042     207.238
c1            -2.0202      0.488     -8.231      0.000      -3.125      -0.915
c2             1.0001      0.249      0.000      1.000       0.437       1.563
==============================================================================


##comparison with another model which is nested inside 'this' model , 
#called restricted model
compare_f_test(restricted)      use F test to test whether restricted model is correct
compare_lm_test(restricted)     Use Lagrange Multiplier test to test whether restricted model is correct
compare_lr_test(restricted)     Likelihood ratio test to test whether restricted model is correct

OLSResults.compare_lr_test(restricted, large_sample=False)
    Likelihood ratio test to test whether restricted model is better 
    H0: both are same 
    Parameters:
    restricted : Result instance
        The restricted model is assumed to be nested in the current model. 
    large_sample : bool
        Flag indicating whether to use a heteroskedasticity robust version of the LR test, which is a modified LM test.
    Returns:
    lr_stat : float
        likelihood ratio, chisquare distributed with df_diff degrees of freedom
    p_value : float
        p-value of the test statistic
    df_diff : int
        degrees of freedom of the restriction, i.e. difference in df between models
 
 
 
OLSResults.el_test(b0_vals, param_nums, return_weights=0, ret_params=0, method='nm', stochastic_exog=1, return_params=0)
    Tests single or joint hypotheses of the regression parameters using Empirical Likelihood.
    Parameters:
    b0_vals : 1darray
        The hypothesized value of the parameter to be tested
    param_nums : 1darray
        The parameter number to be tested
    print_weights : bool
        If true, returns the weights that optimize the likelihood ratio at b0_vals. Default is False
    ret_params : bool
        If true, returns the parameter vector that maximizes the likelihood ratio at b0_vals. Also returns the weights. Default is False
    method : string
        Can either be 'nm' for Nelder-Mead or 'powell' for Powell. The optimization method that optimizes over nuisance parameters. Default is 'nm'
    stochastic_exog : bool
        When TRUE, the exogenous variables are assumed to be stochastic. When the regressors are nonstochastic, moment conditions are placed on the exogenous variables. Confidence intervals for stochastic regressors are at least as large as non-stochastic regressors. Default = TRUE
    Returns:
    res : tuple
        The p-value and -2 times the log-likelihood ratio for the hypothesized values.
     
#Examples
import statsmodels.api as sm
data = sm.datasets.stackloss.load()
endog = data.endog
exog = sm.add_constant(data.exog)
model = sm.OLS(endog, exog)
fitted = model.fit()
>>> fitted.params
>>> array([-39.91967442,   0.7156402 ,   1.29528612,  -0.15212252])
>>> fitted.rsquared
>>> 0.91357690446068196
>>> # H0: the slope on the first variable is 0
>>> fitted.el_test([0], [1])
>>> (27.248146353888796, 1.7894660442330235e-07)


OLSResults.outlier_test(method='bonf', alpha=0.05)
    Test observations for outliers according to method
    Parameters:
        method : str
            •bonferroni : one-step correction
            •sidak : one-step correction
            •holm-sidak :
            •holm :
            •simes-hochberg :
            •hommel :
            •fdr_bh : Benjamini/Hochberg
            •fdr_by : Benjamini/Yekutieli
    See statsmodels.stats.multitest.multipletests for details.
    alpha : float
        familywise error rate
    Returns:
    table : ndarray or DataFrame
        Returns either an ndarray or a DataFrame if labels is not None. 
        Will attempt to get labels from model_results if available. 
        The columns are the Studentized residuals, the unadjusted p-value, 
        and the corrected p-value according to method.
 

#Example 
import numpy as np
import statsmodels.api as sm
spector_data = sm.datasets.spector.load()
spector_data.exog = sm.add_constant(spector_data.exog, prepend=False)

# Fit and summarize OLS model
mod = sm.OLS(spector_data.endog, spector_data.exog)
res = mod.fit()
>>> print(res.outlier_test()) #H0: no outlier 
[[ 0.14357861  0.88689947  1.        ]
 [-0.19227041  0.84896922  1.        ]
 [-0.72912515  0.47220308  1.        ]
 [ 0.05198279  0.9589251   1.        ]
 [ 1.23157405  0.22872763  1.        ]
 [-0.01871656  0.98520485  1.        ]
 [ 0.10521307  0.91698449  1.        ]
 [-0.14030488  0.88946058  1.        ]
 [-0.45228749  0.65467489  1.        ]
 [ 1.09463596  0.2833455   1.        ]
 [ 0.18083173  0.85785021  1.        ]
 [-0.7488271   0.46043569  1.        ]
 [-1.08086619  0.28931688  1.        ]
 [ 2.05350432  0.04982625  1.        ]
 [-1.12947014  0.26863464  1.        ]
 [ 0.07296402  0.9423726   1.        ]
 [-0.1081957   0.91464051  1.        ]
 [-0.0370469   0.97072017  1.        ]
 [-1.56148898  0.13005455  1.        ]
 [ 1.05772986  0.2995507   1.        ]
 [-0.19804147  0.84449616  1.        ]
 [ 0.40242494  0.6905397   1.        ]
 [-1.08222827  0.28872225  1.        ]
 [-2.28529074  0.0303718   0.97189753]
 [ 0.60419872  0.55075518  1.        ]
 [ 1.50769308  0.14324589  1.        ]
 [ 1.05011971  0.30297199  1.        ]
 [-1.02423915  0.31481197  1.        ]
 [ 0.56348861  0.57775259  1.        ]
 [ 0.06388793  0.94953012  1.        ]
 [-1.47457371  0.15189302  1.        ]
 [ 2.47780029  0.01976799  0.63257573]]








###statsmodel -  Regression Diagnostics and Specification Tests


#Multicollinearity - highly correlated  variables(columns of x)
# affects the stability of  coefficient estimates

#when the independent variables are so highly correlated 
#that they contain redundant information, which confuses the regression proces


#longley - highly correlated data
#This data set contains a variety of measurements about the population of the US in an attempt to predict employment
from statsmodels.datasets.longley import load_pandas
y = load_pandas().endog
X = load_pandas().exog
X = sm.add_constant(X)  #add a constant term , Note by default, statsmodels does not have intercept term included into model. Add it explicitly

ols_model = sm.OLS(y, X)
ols_results = ols_model.fit()
print(ols_results.summary())
==============================================================================                 
                coef    std err          t      P>|t|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
const      -3.482e+06    8.9e+05     -3.911      0.004      -5.5e+06 -1.47e+06   
GNPDEFL       15.0619     84.915      0.177      0.863      -177.029   207.153
GNP           -0.0358      0.033     -1.070      0.313        -0.112     0.040
UNEMP         -2.0202      0.488     -4.136      0.003        -3.125    -0.915
ARMED         -1.0332      0.214     -4.822      0.001        -1.518    -0.549
POP           -0.0511      0.226     -0.226      0.826        -0.563     0.460
YEAR        1829.1515    455.478      4.016      0.003       798.788  2859.515
Warnings:
[2] The condition number is large, 4.86e+0 9.
This might indicate that there are strong multicollinearity or other numerical problems.



##Condition number- assess multicollinearity is to compute the condition number.
#Values over 20 are worrisome

##multicollinearity effect: 
#dropping a single observation can have a dramatic effect on the coefficient estimates:

ols_results2 = sm.OLS(y.ix[:14], X.ix[:14]).fit()  #only 14 rows 
>>> print("Percentage change %4.2f%%\n"*7 % tuple([i for i in (ols_results2.params - ols_results.params)/ols_results.params*100]))
Percentage change -13.35%
Percentage change -236.18%
Percentage change -23.69%
Percentage change -3.36%
Percentage change -7.26%
Percentage change -200.46%
Percentage change -13.34%

#Do pairwise scatter matrix to check corelation of independent variables

from pandas.plotting import scatter_matrix
import matplotlib.pyplot as plt
scatter_matrix(X.iloc[:,1:], alpha=0.2, figsize=(6, 6), color='black')
plt.show()

#check plot to find corelated Columns (eg linear relation)
#find it out by VIF 
statsmodels.stats.outliers_influence.variance_inflation_factor(exog, exog_idx)
    variance inflation factor, VIF, for one exogenous variable
    The variance inflation factor is a measure for the increase of the variance 
    of the parameter estimates if an additional variable, 
    given by exog_idx is added to the linear regression. 
    It is a measure for multicollinearity of the design matrix, exog.
    One recommendation is that if VIF is greater than 5, 
    then the explanatory variable given by exog_idx is highly collinear 
    with the other explanatory variables, 
    and the parameter estimates will have large standard errors because of this.
    Parameters:
    exog : ndarray, (nobs, k_vars)
        design matrix with all explanatory variables, 
    exog_idx : int
        index of the exogenous variable in the columns of exog
    Returns:
    vif : float
        variance inflation factor
    #Example 
    from patsy import dmatrices
    from statsmodels.stats.outliers_influence import variance_inflation_factor
    import statsmodels.api as sm
    # Break into left and right hand side; y and X
    y, X = dmatrices(formula="medv ~ crim + zn + nox + ptratio + black + rm ", data=boston, return_type="dataframe")
    # For each Xi, calculate VIF
    vif = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]
    # Fit X to y
    result = sm.OLS(y, X).fit()

        
        
#longley    data 
X_vif = X.iloc[:,1:].as_matrix()
for i in range(X_vif.shape[1]):
    print(X.columns[i+1],statsmodels.stats.outliers_influence.variance_inflation_factor(X_vif,i))
#output 
GNPDEFL 12425.514335354637
GNP 10290.435436791722
UNEMP 136.2243535629104
ARMED 39.98338558291202
POP 101193.16199321792
YEAR 84709.9504430369
#Removing two highest 
X_m = X.iloc[:,[0,2,3,4,6]]
ols_model2 = sm.OLS(y, X_m)
ols_results2 = ols_model2.fit()
print(ols_results2.summary())


##One of formal statistics for Outliers is  DFBETAS
#a standardized measure of how much each coefficient changes 
#when that observation is removed

#Calculate influence table and find out influential observations
infl = ols_results.get_influence()  #type of statsmodels.stats.outliers_influence.OLSInfluence

# DBETAS in absolute value greater than 2/sqrt{N} to be influential observations
2./len(X)**.5  #0.5

>>> print(infl.summary_frame().filter(regex="dfb")) 
#check abs(values) > 0.5 to know influencial observation    
    dfb_const  dfb_GNPDEFL   dfb_GNP  dfb_UNEMP  dfb_ARMED   dfb_POP  dfb_YEAR
0   -0.016406    -0.234566 -0.045095  -0.121513  -0.149026  0.211057  0.013388
1   -0.020608    -0.289091  0.124453   0.156964   0.287700 -0.161890  0.025958
2   -0.008382     0.007161 -0.016799   0.009575   0.002227  0.014871  0.008103
3    0.018093     0.907968 -0.500022  -0.495996   0.089996  0.711142 -0.040056
4    1.871260    -0.219351  1.611418   1.561520   1.169337 -1.081513 -1.864186
5   -0.321373    -0.077045 -0.198129  -0.192961  -0.430626  0.079916  0.323275
6    0.315945    -0.241983  0.438146   0.471797  -0.019546 -0.448515 -0.307517
7    0.015816    -0.002742  0.018591   0.005064  -0.031320 -0.015823 -0.015583
8   -0.004019    -0.045687  0.023708   0.018125   0.013683 -0.034770  0.005116
9   -1.018242    -0.282131 -0.412621  -0.663904  -0.715020 -0.229501  1.035723
10   0.030947    -0.024781  0.029480   0.035361   0.034508 -0.014194 -0.030805
11   0.005987    -0.079727  0.030276  -0.008883  -0.006854 -0.010693 -0.005323
12  -0.135883     0.092325 -0.253027  -0.211465   0.094720  0.331351  0.129120
13   0.032736    -0.024249  0.017510   0.033242   0.090655  0.007634 -0.033114
14   0.305868     0.148070  0.001428   0.169314   0.253431  0.342982 -0.318031
15  -0.538323     0.432004 -0.261262  -0.143444  -0.360890 -0.467296  0.552421

[16 rows x 7 columns]
>>> print(np.abs(infl.summary_frame().filter(regex="dfb")) > 0.5)
    dfb_const  dfb_GNPDEFL  dfb_GNP  dfb_UNEMP  dfb_ARMED  dfb_POP  dfb_YEAR
0       False        False    False      False      False    False     False
...

>>> indexes = (np.abs(infl.summary_frame().filter(regex="dfb")) > 0.5).astype(np.float).sum(1)
0     0.0
1     0.0
2     0.0
3     3.0
4     6.0
5     0.0
6     0.0
7     0.0
8     0.0
9     4.0
10    0.0
11    0.0
12    0.0
13    0.0
14    0.0
15    2.0
dtype: float64

# the discovery of an influential observation in a regression provides 
#no justification for removing that point from the model; 
#it simply helps to identify observations which may deserve further study; 
#in fact, the influential points are often perfectly valid observations 
#that simply do a good job of representing the relationships 
#that occur in the data. 
#So when an influential point is identified, it simply means that it should be examined more closely to see whether or not it is a potential problem. 

#Drop them and then try fitting 
X1 = X.drop(indexes[ indexes > 0 ].index.tolist(), axis=0).reset_index(drop=True)
y1 = y.drop(indexes[ indexes > 0 ].index.tolist(), axis=0).reset_index(drop=True)
ols_model1 = sm.OLS(y1, X1)
ols_results1 = ols_model1.fit()
print(ols_results1.summary())
infl1 = ols_results1.get_influence()
print(infl1.summary_frame().filter(regex="dfb")) 
indexes1 = (np.abs(infl1.summary_frame().filter(regex="dfb")) > 0.5).astype(np.float).sum(1)
#Not improved!!!
>>> indexes1
0     0.0
1     0.0
2     0.0
3     5.0
4     3.0
5     0.0
6     1.0
7     7.0
8     0.0
9     0.0
10    1.0
11    6.0
dtype: float64
#Use Other eg RLM 
rlm_model = sm.RLM(y, X, M=sm.robust.norms.HuberT())
rlm_results = rlm_model.fit()
print(rlm_results.summary())  #not imporved 

#Other methods of statsmodels.stats.outliers_influence.OLSInfluence
#when comparing take absolute values, 
#N = number of observations, p= number of parameters

cooks_distance()                Cooks distance , > 4/(N-p-1) outliers

cov_ratio()                     covariance ratio between LOOO and original                                
                                Uses leave-one-observation-out (LOOO) auxiliary regression                                
                                COVRATIO statistic measures the change in the determinant of the covariance matr ix                                
                                of the estimates by deleting the ith observation                                
                                Use if dataset is not large , >(1+3P/N) requires attiontion
                                
det_cov_params_not_obsi()       determinant of cov_params of all LOOO regressions
params_not_obsi()               parameter estimates for all LOOO regressions
sigma2_not_obsi()               error variance for all LOOO regressions

dfbetas()                       dfbetas , > 2/sqrt(N) outtliers
dffits()                        dffits measure for influence of an observation                                
                                > 2/sqrt(p/N) requires attention
                                
dffits_internal()               dffits measure for influence of an observation

resid_press()                   PRESS residuals
ess_press()                     predicted residual error sum of squares (PRESS) statistic                                
                                each observation in turn is removed and the model is refitted using the remaining observation s.                                
                                The out-of-sample predicted value is calculated for the omitted observation in each cas e,                                
                                and the PRESS statistic is calculated as the sum of the squares of all the resulting prediction errors                                
                                Lower PRESS statistic is better (can be used to compare two models)                                

get_resid_studentized_external([sigma])     calculate studentized residuals                                            
                                             >2 is outliers
                                             
resid_studentized_external()                studentized residuals using LOOO varian ce
resid_studentized_internal()                studentized residuals using variance from O LS

hat_diag_factor()               factor of diagonal of hat_matrix used in influence
hat_matrix_diag()               diagonal of the hat_matrix for OLS                                
                                Maps the vector of dependent variable values to the vector of  predicted value s.                                
                                It describes the influence each response value has on each fitted value.                                
                                The diagonal elements of the hat matrix are the leverages,                                
                                which describe the influence each response value has on the fitted val ue                                
                                for that same observation                                
                                ith diagonal > 1/N means ith observation has more levergae/influence on model                                

influence()                     influence measure

resid_std()                     estimate of standard deviation of the residua ls
resid_var()                     estimate of variance of the residuals                                
                                the variance of residuals must be constant, 
                                and they must have a mean of zero                                
                                Can be seen from plt.scatter(np.arange(i.resid_var.size),i.resid_var)                                
                                OR from scipy.stats.describe(i.resid_var)                                

summary_frame()                 Creates a DataFrame with all available influence results.
summary_table([float_fmt])      create a summary table with all influence and outlier measur es

##Also, Can use below to get outlier

statsmodels.stats.outliers_influence.outlier_test(model_results, method='bonf', alpha=.05, labels=None,  order=False ):

method : str    
- `bonferroni` : one-step correction    
- `sidak` : one-step correction    
- `holm-sidak` :    
- `holm` :    
- `simes-hochberg` :    
- `hommel` :    
- `fdr_bh` : Benjamini/Hochberg    
- `fdr_by` : Benjamini/Yekutieli    

#returns ,  each observation is tested with H0: no outlier , <0.05, reject H0
#abs(student_resid) > 2 requires attention     
     student_resid   unadj_p  bonf(p)
0        -0.227953  0.819922      1.0
1         0.548815  0.583760      1.0
2        -2.368408  0.018843      1.0  #Attention!!!




##Solution of removing outliers - use Robust Regression, RLM,

import statsmodels.api as sm

#Example for using Huber's T norm with the default
# median absolute deviation scaling

data = sm.datasets.stackloss.load()
data.exog = sm.add_constant(data.exog)   #add a constant term , Note by default, statsmodels does not have intercept term included into model. Add it explicitly
huber_t = sm.RLM(data.endog, data.exog, M=sm.robust.norms.HuberT())
hub_results = huber_t.fit()
print(hub_results.weights) #weights used in WLS 

##More advanced methods are Generalized Additive Models (gam)
#Instead of fitting a single linear parameter to try to explain the relationship 
#between independent variables and dependent variables, 
#GAM models perform spline smooths on selected variables, 
#and use these smoothed versions of the independent variables 
#to try to explain the values of the dependent variables
 
#python does not have good GAM 

#below Work in progress, hence dont use 
from statsmodels.sandbox.gam import AdditiveModel
gam = AdditiveModel(X.values) #takes ndarray 
gam_r = gam.fit(y.values,maxiter=100)
print(gam_r.summary())

#use below , requires scikit-parse for large models  , but not available in prebuilt
$ pip install pygam
$ conda install scikit-sparse nose  #check 
#https://github.com/dswah/pyGAM
#https://codeburst.io/pygam-getting-started-with-generalized-additive-models-in-python-457df5b4705f
#Models
    GAM (base class for constructing custom models)
    LinearGAM
    LogisticGAM
    GammaGAM
    PoissonGAM
    InvGaussGAM
#You can mix and match distributions with link functions to create custom models
gam = GAM(distribution='gamma', link='inverse')
#Distributions
    Normal
    Binomial
    Gamma
    Poisson
    Inverse Gaussian
#Link Functions
#Link functions take the distribution mean to the linear prediction. 
#These are the canonical link functions for the above distributions:
    Identity
    Logit
    Inverse
    Log
    Inverse-squared
#Callbacks
#Callbacks are performed during each optimization iteration. 
    deviance - model deviance
    diffs - differences of coefficient norm
    accuracy - model accuracy for LogisticGAM
    coef - coefficient logging
#You can check a callback by inspecting:
plt.plot(gam.logs_['deviance'])
 


from pygam import LinearGAM
from pygam.utils import generate_X_grid

from statsmodels.datasets.longley import load_pandas
y = load_pandas().endog
X = load_pandas().exog

#can call fit(X,y) but it searches grid for optimization with default grid 
#gam = LinearGAM(n_splines=10).fit(X, y) 
gam = LinearGAM(n_splines=10).gridsearch(X, y)  
>>> print(gam.summary())
Model Statistics
-------------------------
edof               15.923
AIC               188.521
AICc              -126.88
GCV                 77.37
loglikelihood     -77.337
deviance            0.077
scale            2501.005

Pseudo-R^2
--------------------------
explained_deviance     1.0
McFadden               1.0
McFadden_adj           1.0
None

#Because of additive nature, 
#we can explore and interpret individual features by holding others at their mean. 
#Find out relation between y vs each feature - linear , non linear or what 

XX = generate_X_grid(gam)

plt.rcParams['figure.figsize'] = (28, 8)
fig, axs = plt.subplots(1, len(X.columns[0:6]))
titles = X.columns
for i, ax in enumerate(axs):
    pdep, confi = gam.partial_dependence(XX, feature=i+1, width=.95)
    ax.plot(XX[:, i], pdep)
    ax.plot(XX[:, i], confi[0][:, 0], c='grey', ls='--')
    ax.plot(XX[:, i], confi[0][:, 1], c='grey', ls='--')
    ax.set_title(titles[i])

plt.show()
    
#Prediction 
index = [1]
predictions = gam.predict(X.iloc[index])
print(predictions, y[ index])

##get test, train data 
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
gam2 = LinearGAM(n_splines=10).gridsearch(X_train, y_train)  
>>> print(gam2.summary())
predictions = gam2.predict(X_test)
print(predictions,  y_test)
plt.scatter(y_test, predictions) #ideal is linear 
plt.xlabel('True Values')
plt.ylabel('Predictions')

#Performance measure for Continuous data 
statsmodels.tools.eval_measures.bias(x1, x2[, axis]) bias, mean error 
statsmodels.tools.eval_measures.iqr(x1, x2[, axis]) interquartile range of error 
statsmodels.tools.eval_measures.maxabs(x1, x2[, axis]) maximum absolute error 
statsmodels.tools.eval_measures.meanabs(x1, x2[, axis]) mean absolute error 
statsmodels.tools.eval_measures.medianabs(x1, x2[, axis]) median absolute error 
statsmodels.tools.eval_measures.medianbias(x1, x2[, axis]) median bias, median error 
statsmodels.tools.eval_measures.mse(x1, x2[, axis]) mean squared error 
statsmodels.tools.eval_measures.rmse(x1, x2[, axis]) root mean squared error 
statsmodels.tools.eval_measures.stde(x1, x2[, ddof, axis]) standard deviation of error 
statsmodels.tools.eval_measures.vare(x1, x2[, ddof, axis]) variance of error 
#example , good !!
m, iqr = statsmodels.tools.eval_measures.meanabs(predictions,  y_test), statsmodels.tools.eval_measures.iqr(predictions,  y_test)



  


###statsmodel - One-way/2-way  ANOVA 
statsmodels.stats.anova.anova_lm(*args, **kwargs)
    ANOVA table for one or more fitted linear models.
    Parameters:
    args : fitted linear model results instance
        One or more fitted linear models
    scale : float
        Estimate of variance, If None, will be estimated from the largest model. Default is None.
    test : str {'F', 'Chisq', 'Cp'} or None
        Test statistics to provide. Default is 'F'.
    typ : str or int {'I','II','III'} or {1,2,3}
        The type of ANOVA test to perform. See notes.
    robust : {None, 'hc0', 'hc1', 'hc2', 'hc3'}
        Use heteroscedasticity-corrected coefficient covariance matrix. 
        If robust covariance is desired, it is recommended to use hc3.
     

#Example - 2way - 2 categorical 

import statsmodels.api as sm
from statsmodels.formula.api import ols
moore = sm.datasets.get_rdataset("Moore", "car", cache=True) # load
data = moore.data
data = data.rename(columns={"partner.status" :
                            "partner_status"}) # make name pythonic
moore_lm = ols('conformity ~ C(fcategory, Sum)*C(partner_status, Sum)', data=data).fit()
table = sm.stats.anova_lm(moore_lm, typ=2) # Type 2 ANOVA DataFrame
>>> print(table)  #H0=no impact 
                                              sum_sq    df          F  \
C(fcategory, Sum)                          11.614700   2.0   0.276958
C(partner_status, Sum)                    212.213778   1.0  10.120692
C(fcategory, Sum):C(partner_status, Sum)  175.488928   2.0   4.184623
Residual                                  817.763961  39.0        NaN

                                            PR(>F)
C(fcategory, Sum)                         0.759564
C(partner_status, Sum)                    0.002874  *significant impact 
C(fcategory, Sum):C(partner_status, Sum)  0.022572  *significant impact
Residual                                       NaN


#Example - one way 
from __future__ import print_function
from statsmodels.compat import urlopen
import numpy as np
np.set_printoptions(precision=4, suppress=True)
import statsmodels.api as sm
import pandas as pd
pd.set_option("display.width", 100)
import matplotlib.pyplot as plt
from statsmodels.formula.api import ols
from statsmodels.graphics.api import interaction_plot, abline_plot
from statsmodels.stats.anova import anova_lm

try:    
    rehab_table = pd.read_csv('data/rehab.table')
except:    
    url = 'http://stats191.stanford.edu/data/rehab.csv'    
    rehab_table = pd.read_table(url, delimiter=",")    
    rehab_table.to_csv('data/rehab.table')

fig, ax = plt.subplots(figsize=(8,6))
fig = rehab_table.boxplot('Time', 'Fitness', ax=ax, grid=False)

#Fit
rehab_lm = ols('Time ~ C(Fitness)', data=rehab_table).fit()
table9 = anova_lm(rehab_lm)
>>> print(table9)            
            df  sum_sq     mean_sq          F    PR(>F)
C(Fitness)   2     672  336.000000  16.961538  0.000041  #<0.05 , significant or influential 
Residual    21     416   19.809524        NaN       NaN

>>> print(rehab_lm.model.data.orig_exog) #Design matrix 
    Intercept  C(Fitness)[T.2]  C(Fitness)[T.3] 
0           1                0                0
1           1                0                0
2           1                0                0
3           1                0                0
4           1                0                0
5           1                0                0
6           1                0                0
7           1                0                0
8           1                1                0
9           1                1                0
10          1                1                0
11          1                1                0
12          1                1                0
13          1                1                0
14          1                1                0
15          1                1                0
16          1                1                0
17          1                1                0
18          1                0                1
19          1                0                1
20          1                0                1
21          1                0                1
22          1                0                1
23          1                0                1

[24 rows x 3 columns]

#C(Fitness)[T.2]  C(Fitness)[T.3] 
# Fitness -> 2  , -> 3
>>> print(rehab_lm.summary())
                           
OLS Regression Results
==============================================================================
Dep. Variable:                   Time   R-squared:                       0.618
Model:                            OLS   Adj. R-squared:                  0.581
Method:                 Least Squares   F-statistic:                     16.96
Date:                Sun, 01 Feb 2015   Prob (F-statistic):           4.13e-05
Time:                        09:30:58   Log-Likelihood:                -68.286
No. Observations:                  24   AIC:                             142.6
Df Residuals:                      21   BIC:                             146.1
Df Model:                           2
Covariance Type:            nonrobust
===================================================================================                      
coef    std err          t      P>|t|      [95.0% Conf. Int.]
-----------------------------------------------------------------------------------
Intercept          38.0000      1.574     24.149      0.000        34.728    41.272
C(Fitness)[T.2]    -6.0000      2.111     -2.842      0.010       -10.390    -1.610
C(Fitness)[T.3]   -14.0000      2.404     -5.824      0.000       -18.999    -9.001
==============================================================================
Omnibus:                        0.163   Durbin-Watson:                   2.209
Prob(Omnibus):                  0.922   Jarque-Bera (JB):                0.211
Skew:                          -0.163   Prob(JB):                        0.900
Kurtosis:                       2.675   Cond. No.                         3.80
==============================================================================

Warnings:
[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



##Example - Two-way ANOVA
try:    
    rehab_table = pd.read_csv('data/kidney.table')
except:    
    url = 'http://stats191.stanford.edu/data/kidney.table'    
    rehab_table = pd.read_table(url, delimiter=",")    
    rehab_table.to_csv('data/kidney.table')
    


>>> kidney_table.groupby(['Weight', 'Duration']).size()
Weight  Duration
1       1           10        
2           10
2       1           10        
2           10
3       1           10        
2           10
dtype: int64


#Balanced panel
kt = kidney_table
plt.figure(figsize=(8,6))
fig = interaction_plot(kt['Weight'], kt['Duration'], np.log(kt['Days']+1), colors=['red', 'blue'], markers=['D','^'], ms=10, ax=plt.gca())


#fit
kidney_lm = ols('np.log(Days+1) ~ C(Duration) * C(Weight)', data=kt).fit()
table10 = anova_lm(kidney_lm)

#two way anova - H0: all models are same 
>>> print(anova_lm(ols('np.log(Days+1) ~ C(Duration) + C(Weight)',  data=kt).fit(), kidney_lm))
     df_resid    ssr      df_diff   ss_diff        F    Pr(>F)
0        56  29.624856        0       NaN      NaN       NaN
1        54  28.989198        2  0.635658  0.59204  0.556748  #accept H0

[2 rows x 6 columns]   

>>> print(anova_lm(ols('np.log(Days+1) ~ C(Duration)', data=kt).fit(), 
               ols('np.log(Days+1) ~ C(Duration) + C(Weight, Sum)',data=kt).fit()))
df_resid        ssr  df_diff    ss_diff          F    Pr(>F)
0        58  46.596147        0        NaN        NaN       NaN
1        56  29.624856        2  16.971291  16.040454  0.000003 #reject H0

>>> print(anova_lm(ols('np.log(Days+1) ~ C(Weight)', data=kt).fit(),               
                ols('np.log(Days+1) ~ C(Duration) + C(Weight, Sum)',                   
                data=kt).fit()))
df_resid        ssr  df_diff   ss_diff         F   Pr(>F)
0        57  31.964549        0       NaN       NaN      NaN
1        56  29.624856        1  2.339693  4.422732  0.03997 #reject H0

[2 rows x 6 columns]


#Sum of squares- use of different types of sums of squares (I,II,II) 
#and the Sum contrast can be used to produce the same output between the 3.

#When data is unbalanced(ie nobs for factor A and B are different), 
#there are different ways to calculate 
#the sums of squares for ANOVA
#Type I for two factors A,B = consider A first, then B and then AB 
#type II = consider A first and then B , no interaction 
#Type II = consider AB, then B and then A  and consider AB , then A and then A 

#Types I II and III SS are equivalent under a balanced design.
#Don't use Type III with non-orthogonal contrast - ie., Treatment, use with Sum 

#contrast is a linear combination of variables (parameters or statistics) 
#whose coefficients add up to zero, allowing comparison of different treatments


#Using  Sum contrast can be used to produce the same output between the 3.

sum_lm = ols('np.log(Days+1) ~ C(Duration, Sum) * C(Weight, Sum)',data=kt).fit()

>>> print(anova_lm(sum_lm))
                                  df     sum_sq   mean_sq          F    PR(>F)
C(Duration, Sum)                  1   2.339693  2.339693   4.358293  0.041562
C(Weight, Sum)                    2  16.971291  8.485645  15.806745  0.000004
C(Duration, Sum):C(Weight, Sum)   2   0.635658  0.317829   0.592040  0.556748
Residual                         54  28.989198  0.536837        NaN       NaN

[4 rows x 5 columns] 

>>> print(anova_lm(sum_lm, typ=2))                                   
                                sum_sq  df          F    PR(>F)
C(Duration, Sum)                  2.339693   1   4.358293  0.041562
C(Weight, Sum)                   16.971291   2  15.806745  0.000004
C(Duration, Sum):C(Weight, Sum)   0.635658   2   0.592040  0.556748
Residual                         28.989198  54        NaN       NaN

[4 rows x 4 columns] 

>>> print(anova_lm(sum_lm, typ=3))
                                    sum_sq  df           F        PR(>F)
Intercept                        156.301830   1  291.153237  2.077589e-23
C(Duration, Sum)                   2.339693   1    4.358293  4.156170e-02
C(Weight, Sum)                    16.971291   2   15.806745  3.944502e-06
C(Duration, Sum):C(Weight, Sum)    0.635658   2    0.592040  5.567479e-01
Residual                          28.989198  54         NaN           NaN

[5 rows x 4 columns]



#and how the Treatment contrast can be used to produce 
#the same output between the 3.
nosum_lm = ols('np.log(Days+1) ~ C(Duration, Treatment) * C(Weight, Treatment)', data=kt).fit()
>>> print(anova_lm(nosum_lm))
                                            df     sum_sq   mean_sq          F    PR(>F)
C(Duration, Treatment)                        1   2.339693  2.339693   4.358293  0.041562
C(Weight, Treatment)                          2  16.971291  8.485645  15.806745  0.000004
C(Duration, Treatment):C(Weight, Treatment)   2   0.635658  0.317829   0.592040  0.556748
Residual                                     54  28.989198  0.536837        NaN       NaN

[4 rows x 5 columns]                                                

>>> print(anova_lm(nosum_lm, typ=2))
                                                sum_sq  df          F    PR(>F)
C(Duration, Treatment)                        2.339693   1   4.358293  0.041562
C(Weight, Treatment)                         16.971291   2  15.806745  0.000004
C(Duration, Treatment):C(Weight, Treatment)   0.635658   2   0.592040  0.556748
Residual                                     28.989198  54        NaN       NaN

[4 rows x 4 columns]  

>>> print(anova_lm(nosum_lm, typ=3))                                             
                                                sum_sq  df          F    PR(>F)
Intercept                                    10.427596   1  19.424139  0.000050
C(Duration, Treatment)                        0.054293   1   0.101134  0.751699
C(Weight, Treatment)                         11.703387   2  10.900317  0.000106
C(Duration, Treatment):C(Weight, Treatment)   0.635658   2   0.592040  0.556748
Residual                                     28.989198  54        NaN       NaN

[5 rows x 4 columns]




###statsmodel - Selecting best models using ANOVA

#Download and format data:
#Do an ANOVA check, to compare models- H0: all models are same 

from __future__ import print_function
from statsmodels.compat import urlopen
import numpy as np
np.set_printoptions(precision=4, suppress=True)
import statsmodels.api as sm
import pandas as pd
pd.set_option("display.width", 100)
import matplotlib.pyplot as plt
from statsmodels.formula.api import ols
from statsmodels.graphics.api import interaction_plot, abline_plot
from statsmodels.stats.anova import anova_lm

try:    
    salary_table = pd.read_csv('data/salary.table')
except:  # recent pandas can read URL without urlopen    
    url = 'http://stats191.stanford.edu/data/salary.table'    
    fh = urlopen(url)    
    salary_table = pd.read_table(fh)    
    salary_table.to_csv('salary.table')

E = salary_table.E
M = salary_table.M
X = salary_table.X
S = salary_table.S

#draw few plots on raw data 
plt.figure(figsize=(6,6))
symbols = ['D', '^']
colors = ['r', 'g', 'blue']
factor_groups = salary_table.groupby(['E','M'])
for values, group in factor_groups:    
    i,j = values    
    plt.scatter(group['X'], group['S'], marker=symbols[j], color=colors[i-1], s=144)
plt.xlabel('Experience');
plt.ylabel('Salary');


#Fit a linear model:
formula = 'S ~ C(E) + C(M) + X'    #E, M are categorical 
lm = ols(formula, salary_table).fit()  #OLS for (y,x) and ols for formula 
>>> print(lm.summary())                            
OLS Regression Results
==============================================================================
Dep. Variable:                      S   R-squared:                       0.957
Model:                            OLS   Adj. R-squared:                  0.953
Method:                 Least Squares   F-statistic:                     226.8
Date:                Sun, 01 Feb 2015   Prob (F-statistic):           2.23e-27
Time:                        09:30:45   Log-Likelihood:                -381.63
No. Observations:                  46   AIC:                             773.3
Df Residuals:                      41   BIC:                             782.4
Df Model:                           4
Covariance Type:            nonrobust
==============================================================================                 
coef    std err          t      P>|t|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
Intercept   8035.5976    386.689     20.781      0.000      7254.663  8816.532
C(E)[T.2]   3144.0352    361.968      8.686      0.000      2413.025  3875.045
C(E)[T.3]   2996.2103    411.753      7.277      0.000      2164.659  3827.762
C(M)[T.1]   6883.5310    313.919     21.928      0.000      6249.559  7517.503
X            546.1840     30.519     17.896      0.000       484.549   607.819
==============================================================================
Omnibus:                        2.293   Durbin-Watson:                   2.237
Prob(Omnibus):                  0.318   Jarque-Bera (JB):                1.362
Skew:                          -0.077   Prob(JB):                        0.506
Kurtosis:                       2.171   Cond. No.                         33.5
==============================================================================

Warnings:
[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.

#note 
C(E)[T.2]  => E== 2
C(E)[T.3]  => E== 3
C(M)[T.1]  => M== 1

#look at the created design matrix:
>>> lm.model.exog[:5]
array([[ 1.,  0.,  0.,  1.,  1.],       
[ 1.,  0.,  1.,  0.,  1.],       
[ 1.,  0.,  1.,  1.,  1.],       
[ 1.,  1.,  0.,  0.,  1.],       
[ 1.,  0.,  1.,  0.,  1.]])


#Or since we initially passed in a DataFrame, original design matrix 
lm.model.data.orig_exog[:5]

#reference to the original untouched data in
lm.model.data.frame[:5]

#Influence statistics
infl = lm.get_influence()
>>> print(infl.summary_table())
==================================================================================================       
obs      endog     fitted     Cook's   student.   hat diag    dffits   ext.stud.     dffits                           
value          d   residual              internal   residual
--------------------------------------------------------------------------------------------------         
0  13876.000  15465.313      0.104     -1.683      0.155     -0.722     -1.723     -0.739         
1  11608.000  11577.992      0.000      0.031      0.130      0.012      0.031      0.012         
2  18701.000  18461.523      0.001      0.247      0.109      0.086      0.244      0.085         
3  11283.000  11725.817      0.005     -0.458      0.113     -0.163     -0.453     -0.162         
4  11767.000  11577.992      0.001      0.197      0.130      0.076      0.195      0.075         
5  20872.000  19155.532      0.092      1.787      0.126      0.678      1.838      0.698         
6  11772.000  12272.001      0.006     -0.513      0.101     -0.172     -0.509     -0.170         
7  10535.000   9127.966      0.056      1.457      0.116      0.529      1.478      0.537         
8  12195.000  12124.176      0.000      0.074      0.123      0.028      0.073      0.027         
9  12313.000  12818.185      0.005     -0.516      0.091     -0.163     -0.511     -0.161        
10  14975.000  16557.681      0.084     -1.655      0.134     -0.650     -1.692     -0.664        
11  21371.000  19701.716      0.078      1.728      0.116      0.624      1.772      0.640        
12  19800.000  19553.891      0.001      0.252      0.096      0.082      0.249      0.081        
13  11417.000  10220.334      0.033      1.227      0.098      0.405      1.234      0.408        
14  20263.000  20100.075      0.001      0.166      0.093      0.053      0.165      0.053        
15  13231.000  13216.544      0.000      0.015      0.114      0.005      0.015      0.005        
16  12884.000  13364.369      0.004     -0.488      0.082     -0.146     -0.483     -0.145        
17  13245.000  13910.553      0.007     -0.674      0.075     -0.192     -0.669     -0.191        
18  13677.000  13762.728      0.000     -0.089      0.113     -0.032     -0.087     -0.031        
19  15965.000  17650.049      0.082     -1.747      0.119     -0.642     -1.794     -0.659        
20  12336.000  11312.702      0.021      1.043      0.087      0.323      1.044      0.323        
21  21352.000  21192.443      0.001      0.163      0.091      0.052      0.161      0.051        
22  13839.000  14456.737      0.006     -0.624      0.070     -0.171     -0.619     -0.170        
23  22884.000  21340.268      0.052      1.579      0.095      0.511      1.610      0.521        
24  16978.000  18742.417      0.083     -1.822      0.111     -0.644     -1.877     -0.664        
25  14803.000  15549.105      0.008     -0.751      0.065     -0.199     -0.747     -0.198        
26  17404.000  19288.601      0.093     -1.944      0.110     -0.684     -2.016     -0.709        
27  22184.000  22284.811      0.000     -0.103      0.096     -0.034     -0.102     -0.033        
28  13548.000  12405.070      0.025      1.162      0.083      0.350      1.167      0.352        
29  14467.000  13497.438      0.018      0.987      0.086      0.304      0.987      0.304        
30  15942.000  16641.473      0.007     -0.705      0.068     -0.190     -0.701     -0.189        
31  23174.000  23377.179      0.001     -0.209      0.108     -0.073     -0.207     -0.072        
32  23780.000  23525.004      0.001      0.260      0.092      0.083      0.257      0.082        
33  25410.000  24071.188      0.040      1.370      0.096      0.446      1.386      0.451        
34  14861.000  14043.622      0.014      0.834      0.091      0.263      0.831      0.262        
35  16882.000  17733.841      0.012     -0.863      0.077     -0.249     -0.860     -0.249        
36  24170.000  24469.547      0.003     -0.312      0.127     -0.119     -0.309     -0.118        
37  15990.000  15135.990      0.018      0.878      0.104      0.300      0.876      0.299        
38  26330.000  25163.556      0.035      1.202      0.109      0.420      1.209      0.422        
39  17949.000  18826.209      0.017     -0.897      0.093     -0.288     -0.895     -0.287        
40  25685.000  26108.099      0.008     -0.452      0.169     -0.204     -0.447     -0.202        
41  27837.000  26802.108      0.039      1.087      0.141      0.440      1.089      0.441        
42  18838.000  19918.577      0.033     -1.119      0.117     -0.407     -1.123     -0.408        
43  17483.000  16774.542      0.018      0.743      0.138      0.297      0.739      0.295        
44  19207.000  20464.761      0.052     -1.313      0.131     -0.511     -1.325     -0.515        
45  19346.000  18959.278      0.009      0.423      0.208      0.216      0.419      0.214
==================================================================================================


#or get a dataframe
df_infl = infl.summary_frame()
df_infl[:5]



#plot the reiduals within the groups separately:
resid = lm.resid
plt.figure(figsize=(6,6));
for values, group in factor_groups:    
    i,j = values    
    group_num = i*2 + j - 1  # for plotting purposes    
    x = [group_num] * len(group)    
    plt.scatter(x, resid[group.index], marker=symbols[j], color=colors[i-1],s=144, edgecolors='black')

plt.xlabel('Group');
plt.ylabel('Residuals');


#test some interactions using anova or f_test - a*b = a + b + a:b
interX_lm = ols("S ~ C(E) * X + C(M)", salary_table).fit() #OLS for (y,x) and ols for formula 
>>> print(interX_lm.summary())                            
OLS Regression Results
==============================================================================
Dep. Variable:                      S   R-squared:                       0.961
Model:                            OLS   Adj. R-squared:                  0.955
Method:                 Least Squares   F-statistic:                     158.6
Date:                Sun, 01 Feb 2015   Prob (F-statistic):           8.23e-26
Time:                        09:30:48   Log-Likelihood:                -379.47
No. Observations:                  46   AIC:                             772.9
Df Residuals:                      39   BIC:                             785.7
Df Model:                           6
Covariance Type:            nonrobust
===============================================================================                  
coef    std err          t      P>|t|      [95.0% Conf. Int.]
-------------------------------------------------------------------------------
Intercept    7256.2800    549.494     13.205      0.000      6144.824  8367.736
C(E)[T.2]    4172.5045    674.966      6.182      0.000      2807.256  5537.753
C(E)[T.3]    3946.3649    686.693      5.747      0.000      2557.396  5335.333
C(M)[T.1]    7102.4539    333.442     21.300      0.000      6428.005  7776.903
X             632.2878     53.185     11.888      0.000       524.710   739.865
C(E)[T.2]:X  -125.5147     69.863     -1.797      0.080      -266.826    15.796
C(E)[T.3]:X  -141.2741     89.281     -1.582      0.122      -321.861    39.313
==============================================================================
Omnibus:                        0.432   Durbin-Watson:                   2.179
Prob(Omnibus):                  0.806   Jarque-Bera (JB):                0.590
Skew:                           0.144   Prob(JB):                        0.744
Kurtosis:                       2.526   Cond. No.                         69.7
==============================================================================

Warnings:
[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.


#Do an ANOVA check, to compare models- H0: all models are same 

from statsmodels.stats.api import anova_lm

table1 = anova_lm(lm, interX_lm)
>>> print(table1)
    df_resid    ssr             df_diff         ss_diff      F    Pr(>F)
0        41  43280719.492876        0             NaN       NaN       NaN
1        39  39410679.807560        2  3870039.685316  1.914856    0.160964 #accept H0 

[2 rows x 6 columns]      

#another model 
interM_lm = ols("S ~ X + C(E)*C(M)", data=salary_table).fit()
>>> print(interM_lm.summary())

#Prob < 0.5, so model is significant 
#all coeff are significant (P < 0.05 or there is no zero in conf interval)                    
OLS Regression Results
==============================================================================
Dep. Variable:                      S   R-squared:                       0.999
Model:                            OLS   Adj. R-squared:                  0.999
Method:                 Least Squares   F-statistic:                     5517.
Date:                Sun, 01 Feb 2015   Prob (F-statistic):           1.67e-55
Time:                        09:30:48   Log-Likelihood:                -298.74
No. Observations:                  46   AIC:                             611.5
Df Residuals:                      39   BIC:                             624.3
Df Model:                           6
Covariance Type:            nonrobust
=======================================================================================                          
                       coef        std err      t        P>|t|      [95.0% Conf. Int.]
---------------------------------------------------------------------------------------
Intercept            9472.6854     80.344    117.902      0.000      9310.175  9635.196
C(E)[T.2]            1381.6706     77.319     17.870      0.000      1225.279  1538.063
C(E)[T.3]            1730.7483    105.334     16.431      0.000      1517.690  1943.806
C(M)[T.1]            3981.3769    101.175     39.351      0.000      3776.732  4186.022
C(E)[T.2]:C(M)[T.1]  4902.5231    131.359     37.322      0.000      4636.825  5168.222
C(E)[T.3]:C(M)[T.1]  3066.0351    149.330     20.532      0.000      2763.986  3368.084
X                     496.9870      5.566     89.283      0.000       485.728   508.246
==============================================================================
Omnibus:                       74.761   Durbin-Watson:                   2.244
Prob(Omnibus):                  0.000   Jarque-Bera (JB):             1037.873
Skew:                          -4.103   Prob(JB):                    4.25e-226
Kurtosis:                      24.776   Cond. No.                         79.0
==============================================================================

Warnings:
[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.   

#Do an ANOVA check, to compare models- H0: all models are same 
table2 = anova_lm(lm, interM_lm)
>>> print(table2) #reject H0, interM_lm is better 

    df_resid              ssr  df_diff          ss_diff           F        Pr(>F)
0        41  43280719.492876        0              NaN         NaN           NaN
1        39   1178167.864864        2  42102551.628012  696.844466  3.025504e-31  #reject H0, this model is better

[2 rows x 6 columns]


#The design matrix as a DataFrame
interM_lm.model.data.orig_exog[:5]

#The design matrix as an ndarray
interM_lm.model.exog
interM_lm.model.exog_names

#Get influence of model 
infl = interM_lm.get_influence()
resid = infl.resid_studentized_internal
plt.figure(figsize=(6,6))
for values, group in factor_groups:    
    i,j = values    
    idx = group.index    
    plt.scatter(X[idx], resid[idx], marker=symbols[j], color=colors[i-1], s=144, edgecolors='black')

plt.xlabel('X');
plt.ylabel('standardized resids');


#Looks like one observation is an outlier.
#Drop that observation

drop_idx = abs(resid).argmax()
print(drop_idx)              # zero-based index
idx = salary_table.index.drop(drop_idx)
lm32 = ols('S ~ C(E) + X + C(M)', data=salary_table, subset=idx).fit()
print(lm32.summary())
print('\n')

interX_lm32 = ols('S ~ C(E) * X + C(M)', data=salary_table, subset=idx).fit()
print(interX_lm32.summary())
print('\n')


table3 = anova_lm(lm32, interX_lm32)
print(table3)
print('\n')


interM_lm32 = ols('S ~ X + C(E) * C(M)', data=salary_table, subset=idx).fit()

table4 = anova_lm(lm32, interM_lm32)
print(table4)
print('\n')




#Replot the residuals

try:    
    resid = interM_lm32.get_influence().summary_frame()['standard_resid']
except:    
    resid = interM_lm32.get_influence().summary_frame()['standard_resid']

plt.figure(figsize=(6,6))
for values, group in factor_groups:    
    i,j = values    
    idx = group.index    
    plt.scatter(X[idx], resid[idx], marker=symbols[j], color=colors[i-1], s=144, edgecolors='black')
plt.xlabel('X[~[32]]');
plt.ylabel('standardized resids');



#Plot the fitted values

lm_final = ols('S ~ X + C(E)*C(M)', data = salary_table.drop([drop_idx])).fit()
mf = lm_final.model.data.orig_exog
lstyle = ['-','--']

plt.figure(figsize=(6,6))
for values, group in factor_groups:    
    i,j = values    
    idx = group.index    
    plt.scatter(X[idx], S[idx], marker=symbols[j], color=colors[i-1],s=144, edgecolors='black')    
    # drop NA because there is no idx 32 in the final model    
    plt.plot(mf.X[idx].dropna(), lm_final.fittedvalues[idx].dropna(),ls=lstyle[j], color=colors[i-1])

plt.xlabel('Experience');
plt.ylabel('Salary');




           
###Statsmodel-QuickIntro - sm.tsa
#Time Series analysis tsa
#The module structure is within statsmodels.tsa is
•stattools :    empirical properties and tests, acf, pacf, granger-causality, adf unit root test, kpss test, bds test, ljung-box test and others.
•ar_model :     univariate autoregressive process, estimation with conditional and exact maximum likelihood and conditional least-squares
•arima_model :  univariate ARMA process, estimation with conditional and exact maximum likelihood and conditional least-squares
•vector_ar, var : vector autoregressive process (VAR) estimation models, impulse response analysis, forecast error variance decompositions, and data visualization tools
•kalmanf :      estimation classes for ARMA and other models with exact MLE using Kalman Filter
•arma_process : properties of arma processes with given parameters, this includes tools to convert between ARMA, MA and AR representation as well as acf, pacf, spectral density, impulse response function and similar
•sandbox.tsa.fftarma : similar to arma_process but working in frequency domain
•tsatools :     additional helper functions, to create arrays of lagged variables, construct regressors for trend, detrend and similar.
•filters :      helper function for filtering time series
•regime_switching : Markov switching dynamic regression and autoregression models


#Descriptive Statistics and Tests
stattools.acovf(x[, unbiased, demean, fft, ...])    Autocovariance for 1D 
stattools.acf(x[, unbiased, nlags, qstat, ...])     Autocorrelation function for 1d arrays. 
stattools.pacf(x[, nlags, method, alpha])           Partial autocorrelation estimated 
stattools.pacf_yw(x[, nlags, method])               Partial autocorrelation estimated with non-recursive yule_walker 
stattools.pacf_ols(x[, nlags])                      Calculate partial autocorrelations 
stattools.ccovf(x, y[, unbiased, demean])           crosscovariance for 1D 
stattools.ccf(x, y[, unbiased])                     cross-correlation function for 1d 

stattools.periodogram(X)                            Returns the periodogram for the natural frequency of X 
stattools.adfuller(x[, maxlag, regression, ...])    Augmented Dickey-Fuller unit root test 
stattools.kpss(x[, regression, lags, store])        Kwiatkowski-Phillips-Schmidt-Shin test for stationarity. 
stattools.coint(y0, y1[, trend, method, ...])       Test for no-cointegration of a univariate equation 
stattools.bds(x[, max_dim, epsilon, distance])      Calculate the BDS test statistic for independence of a time series 
stattools.q_stat(x, nobs[, type])                   Return's Ljung-Box Q Statistic 
stattools.grangercausalitytests(x, maxlag[, ...])   four tests for granger non causality of 2 timeseries 
stattools.levinson_durbin(s[, nlags, isacov])       Levinson-Durbin recursion for autoregressive processes 

stattools.arma_order_select_ic(y[, max_ar, ...])    Returns information criteria for many ARMA models 
x13.x13_arima_select_order(endog[, ...])            Perform automatic seaonal ARIMA order identification using x12/x13 ARIMA. 
                                                    X-12-ARIMA was the U.S. Census Bureau's software package for seasonal adjustment
x13.x13_arima_analysis(endog[, maxorder, ...])      Perform x13-arima analysis for monthly or quarterly data. 

#Estimation
#Univariate Autogressive Processes (AR)
ar_model.AR(endog[, dates, freq, missing])  Autoregressive AR(p) model 
ar_model.ARResults(model, params[, ...])    Class to hold results from fitting an AR model. 

#Autogressive Moving-Average Processes (ARMA) and Kalman Filter
arima_model.ARMA(endog, order[, exog, ...])     Autoregressive Moving Average ARMA(p,q) Model 
arima_model.ARMAResults(model, params[, ...])   Class to hold results from fitting an ARMA model. 
arima_model.ARIMA(endog, order[, exog, ...])    Autoregressive Integrated Moving Average ARIMA(p,d,q) Model 
arima_model.ARIMAResults(model, params[, ...]) 

#Vector Autogressive Processes (VAR)
vector_ar.var_model.VAR(endog[, dates, ...])        Fit VAR(p) process and do lag order selection 
vector_ar.var_model.VARResults(endog, ...[, ...])   Estimate VAR(p) process with fixed number of lags 
vector_ar.dynamic.DynamicVAR(data[, ...])           Estimates time-varying vector autoregression (VAR(p)) using 

 
#Vector Autogressive Processes (VAR)
vector_ar.var_model.VAR(endog[, dates, ...])        Fit VAR(p) process and do lag order selection 
vector_ar.var_model.VARProcess(coefs, ...[, ...])   Class represents a known VAR(p) process 
vector_ar.var_model.VARResults(endog, ...[, ...])   Estimate VAR(p) process with fixed number of lags 
vector_ar.irf.IRAnalysis(model[, P, ...])           Impulse response analysis class. 
vector_ar.var_model.FEVD(model[, P, periods])       Compute and plot Forecast error variance decomposition and asymptotic 
vector_ar.dynamic.DynamicVAR(data[, ...])           Estimates time-varying vector autoregression (VAR(p)) using 

 
#Regime switching models
regime_switching.markov_regression.MarkovRegression(...)        First-order k-regime Markov switching regression model 
regime_switching.markov_autoregression.MarkovAutoregression(...) Markov switching regression model 

#ARMA Process
arima_process.ArmaProcess(ar, ma[, nobs])       Represent an ARMA process for given lag-polynomials 
arima_process.ar2arma(ar_des, p, q[, n, ...])   find arma approximation to ar process 
arima_process.arma2ar(ar, ma[, nobs])           get the AR representation of an ARMA process 
arima_process.arma2ma(ar, ma[, nobs])           get the impulse response function (MA representation) for ARMA process 
arima_process.arma_acf(ar, ma[, nobs])          theoretical autocorrelation function of an ARMA process 
arima_process.arma_acovf(ar, ma[, nobs])        theoretical autocovariance function of ARMA process 
arima_process.arma_generate_sample(ar, ma, ...) Generate a random sample of an ARMA process 
arima_process.arma_impulse_response(ar, ma)     get the impulse response function (MA representation) for ARMA process 
arima_process.arma_pacf(ar, ma[, nobs])         partial autocorrelation function of an ARMA process 
arima_process.arma_periodogram(ar, ma[, ...])   periodogram for ARMA process given by lag-polynomials ar and ma 
arima_process.deconvolve(num, den[, n])         Deconvolves divisor out of signal, division of polynomials for n terms 
arima_process.index2lpol(coeffs, index)         expand coefficients to lag poly 
arima_process.lpol2index(ar)                    remove zeros from lagpolynomial, squeezed representation with index 
arima_process.lpol_fiar(d[, n])                 AR representation of fractional integration 
arima_process.lpol_fima(d[, n])                 MA representation of fractional integration 
arima_process.lpol_sdiff(s)                     return coefficients for seasonal difference (1-L^s) 
sandbox.tsa.fftarma.ArmaFft(ar, ma, n)          fft tools for arma processes 

#Time Series Filters
filters.bk_filter.bkfilter(X[, low, high, K])       Baxter-King bandpass filter 
filters.hp_filter.hpfilter(X[, lamb])               Hodrick-Prescott filter 
filters.cf_filter.cffilter(X[, low, high, drift])   Christiano Fitzgerald asymmetric, random walk filter 
filters.filtertools.convolution_filter(x, filt)     Linear filtering via convolution. 
filters.filtertools.recursive_filter(x, ar_coeff)   Autoregressive, or recursive, filtering. 
filters.filtertools.miso_lfilter(ar, ma, x)         use nd convolution to merge inputs, 
filters.filtertools.fftconvolve3(in1[, in2, ...])   Convolve two N-dimensional arrays using FFT. 
filters.filtertools.fftconvolveinv(in1, in2)        Convolve two N-dimensional arrays using FFT. 
seasonal.seasonal_decompose(x[, model, ...])        Seasonal decomposition using moving averages 

#TSA Tools
tsatools.add_trend(x[, trend, prepend, ...])        Adds a trend and/or constant to an array. 
tsatools.detrend(x[, order, axis])                  Detrend an array with a trend of given order along axis 0 or 1 
tsatools.lagmat(x, maxlag[, trim, original, ...])   Create 2d array of lags 
tsatools.lagmat2ds(x, maxlag0[, maxlagex, ...])     Generate lagmatrix for 2d array, columns arranged by variables 

#VARMA Process
varma_process.VarmaPoly(ar[, ma])           class to keep track of Varma polynomial format 

#Interpolation
interp.denton.dentonm(indicator, benchmark) Modified Denton's method to convert low-frequency to high-frequency data. 

#Unit Root Tests - bad for time series data 
statsmodels.stats.diagnostic.unitroot_adf(x, maxlag=None, trendorder=0, autolag='AIC', store=False)
statsmodels.tsa.stattools.adfuller(x, maxlag=None, regression='c', autolag='AIC', store=False, regresults=False)    
        The Augmented Dickey-Fuller test can be used to test for a unit root in a univariate process in the presence of serial correlation.    
        H0:there is a unit root    
        returns (,p-value, , , , , )
        
#Time Series Plots
tsaplots.plot_acf(x[, ax, lags, alpha, ...])    Plot the autocorrelation function 
tsaplots.plot_pacf(x[, ax, lags, alpha, ...])   Plot the partial autocorrelation function 
tsaplots.month_plot(x[, dates, ylabel, ax])     Seasonal plot of monthly data 
tsaplots.quarter_plot(x[, dates, ylabel, ax])   Seasonal plot of quarterly data 

##ACF(auto corelation) and PACF(partial corelation) plot 

#ACF plot:  a bar chart of the coefficients of correlation between a time series and lags of itself
#Note that corelation at lag-k propagates to lag-k+1 and higher lags  

#PACF plot : plot of the partial correlation coefficients between the series and lags of itself. 
#The partial autocorrelation at lag k is the difference between the actual correlation at lag k 
#and the expected correlation due to the propagation of correlation at lag k-1. 

#For example if the PACF plot has a significant spike only at lag 1, 
#meaning that all the higher-order autocorrelations are effectively explained 
#by the lag-1 autocorrelation

#Run plot 
from pandas import Series
from matplotlib import pyplot
series = Series.from_csv('daily-minimum-temperatures.csv', header=0)
series.plot()
pyplot.show()

#ACF plot with 95% CI 
from pandas import Series
from matplotlib import pyplot
from statsmodels.graphics.tsaplots import plot_acf
series = Series.from_csv('daily-minimum-temperatures.csv', header=0)
plot_acf(series)
pyplot.show()

#PACF with 95% CI 
from pandas import Series
from matplotlib import pyplot
from statsmodels.graphics.tsaplots import plot_pacf
series = Series.from_csv('daily-minimum-temperatures.csv', header=0)
plot_pacf(series, lags=50)
pyplot.show()


#CHECK https://onlinecourses.science.psu.edu/stat510
##Detecting
Detecting seasonality
    Seasonality (or periodicity) can usually be assessed from an autocorrelation plot
    seasonality in a timeseries refers to predictable and recurring trends and patterns over a period of time
    ACF shows an oscillation(with period S), indicative of a seasonal series
    Seasonal differencing is defined as a difference between a value 
    and a value with lag that is a multiple of S.
    Note, do this at first to get a series , then do Non-seasonal differencing if required to make it stationary
    check https://onlinecourses.science.psu.edu/stat510/node/67
    
Detecting stationarity
      Stationarity can be assessed from a run sequence plot. 
      The run sequence plot should show constant location(mean) and scale(not increasing/decreasing mean)
      It can also be detected from an autocorrelation plot. 
      Specifically, non-stationarity is often indicated by an autocorrelation plot with very slow decay.
      Take first difference or more to get the data stationary(ie d= Non-seasonal differencing)

      
      
##Autoregressive Moving Average (ARMA, (p,q)
#p is the order of the autoregressive part, linear combination of past time series values
#q is the order of the moving average part, linear combination of the past white noise terms.
#white noise is a random signal having equal intensity at different frequencies, giving it a constant power spectral density

#Finding appropriate values of p and q in the ARMA(p,q) model can be facilitated 
#by plotting the partial autocorrelation functions for an estimate of p, 
#and likewise using the autocorrelation functions for an estimate of q. 

#Note , Autoregressive integrated moving average generalization of ARMA 
#ARIMA(p,d,q), d is the degree of differencing (the number of times the data have had past values subtracted), 
#here d is Non-seasonal differencing 

#Plot autocorrelation function(acf) for model identification.
#Shape                                   
#        Indicated Model
Exponential, decaying to zero           
        Autoregressive model. 
        Use the partial autocorrelation plot to identify the order of the autoregressive model. 
Alternating positive and negative, decaying to zero
        Autoregressive model. 
        Use the partial autocorrelation plot to help identify the order. 
One or more spikes, rest are essentially zero
        Moving average model, order identified by where plot becomes zero. 
Decay, starting after a few lags
        Mixed autoregressive and moving average (ARMA) model. 
All zero or close to zero
        Data are essentially random. 
High values at fixed intervals
        Include seasonal autoregressive term. 
No decay to zero
        Series is not stationary. 
        
      
Specifically, for an AR(1) process, 
the sample autocorrelation function should have an exponentially 
decreasing appearance. 
However, higher-order AR processes are often a mixture of 
exponentially decreasing and damped sinusoidal components.

For higher-order autoregressive processes, 
the partial autocorrelation of an AR(p) process becomes zero at lag p + 1 
and greater, 
This is usually determined by placing a 95% confidence interval on the sample partial autocorrelation plot 
If the software program does not generate the confidence band, 
it is approximately ± 2 /sqrt(N), with N denoting the sample size.

The autocorrelation function of a MA(q) process becomes zero at lag q + 1 
and greater, by placing the 95% confidence interval 
for the sample autocorrelation function on the sample autocorrelation plot. 

#Another option for finding (p,q)
Note create ARMA(1,1); ARMA(1,2), … , ARMA(3,3), … , ARMA(5,5). 
To compare these 25 models, use the AIC, lowest AIC gives p, and q 
Use stattools.arma_order_select_ic, x13.x13_arima_select_order


The data may follow an ARIMA(p,d,0) model 
if the ACF and PACF plots of the differenced data show the following patterns: 
    the ACF is exponentially decaying or sinusoidal;
    there is a significant spike at lag p in PACF, but none beyond lag p.
The data may follow an ARIMA(0,d,q) model 
if the ACF and PACF plots of the differenced data show the following patterns: 
    the PACF is exponentially decaying or sinusoidal;
    there is a significant spike at lag q in ACF, but none beyond lag q.

    
#acf
statsmodels.tsa.stattools.acf(x, unbiased=False, nlags=40, qstat=False, fft=False, alpha=None, missing='none')[source]
    Autocorrelation function for 1d arrays.
    Parameters:
    x : array
        Time series data
    unbiased : bool
        If True, then denominators for autocovariance are n-k, otherwise n
    nlags: int, optional
        Number of lags to return autocorrelation for.
    qstat : bool, optional
        If True, returns the Ljung-Box q statistic for each autocorrelation coefficient. 
    fft : bool, optional
        If True, computes the ACF via FFT.
    alpha : scalar, optional
        If a number is given, the confidence intervals for the given level are returned. For instance if alpha=.05, 95 % confidence intervals are returned where the standard deviation is computed according to Bartlett's formula.
    missing : str, optional
        A string in ['none', 'raise', 'conservative', 'drop'] specifying how the NaNs are to be treated.
    Returns:
    acf : array
        autocorrelation function
    confint : array, optional
        Confidence intervals for the ACF. Returned if confint is not None.
    qstat : array, optional
        The Ljung-Box Q-Statistic. Returned if q_stat is True.
    pvalues : array, optional
        The p-values associated with the Q-statistics. Returned if q_stat is True.
        H0: The data are independently distributed 
            i.e. the correlations is 0
   
##Example with AR(p) 

from __future__ import print_function
import statsmodels.api as sm
import numpy as np
import pandas as pd

data = sm.datasets.sunspots.load()

from datetime import datetime
dates = sm.tsa.datetools.dates_from_range('1700', length=len(data.endog))
endog = pd.Series(data.endog, index=dates)

#AR(p)
ar_model = sm.tsa.AR(endog, freq='A')
pandas_ar_res = ar_model.fit(maxlag=9, method='mle', disp=-1)

#Out-of-sample prediction
pred = pandas_ar_res.predict(start='2005', end='2015')
>>> print(pred)
2005-12-31    20.003298
2006-12-31    24.703996
2007-12-31    20.026133
2008-12-31    23.473641
2009-12-31    30.858566
                ...    
2011-12-31    87.024635
2012-12-31    91.321196
2013-12-31    79.921585
2014-12-31    60.799495
2015-12-31    40.374852
Freq: A-DEC, dtype: float64

#Using explicit dates
ar_model = sm.tsa.AR(data.endog, dates=dates, freq='A')
ar_res = ar_model.fit(maxlag=9, method='mle', disp=-1)
pred = ar_res.predict(start='2005', end='2015')
>>> print(pred)
[ 20.00329845  24.70399631  20.02613267  23.47364059  30.8585664
  61.33541408  87.02463499  91.32119576  79.92158511  60.79949541
  40.37485169]

>>> print(ar_res.data.predict_dates)
DatetimeIndex(['2005-12-31', '2006-12-31', '2007-12-31', '2008-12-31',
               '2009-12-31', '2010-12-31', '2011-12-31', '2012-12-31',
               '2013-12-31', '2014-12-31', '2015-12-31'],
              dtype='datetime64[ns]', freq='A-DEC')

   
##Example with ARMA(p,q)
%matplotlib inline
from __future__ import print_function
import numpy as np
from scipy import stats
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm

from statsmodels.graphics.api import qqplot

print(sm.datasets.sunspots.NOTE)

dta = sm.datasets.sunspots.load_pandas().data

dta.index = pd.Index(sm.tsa.datetools.dates_from_range('1700', '2008'))
del dta["YEAR"]

dta.plot(figsize=(12,8));
 
#plot acf, partial acf 
fig = plt.figure(figsize=(12,8))
ax1 = fig.add_subplot(211)
fig = sm.graphics.tsa.plot_acf(dta.values.squeeze(), lags=40, ax=ax1)
ax2 = fig.add_subplot(212)
fig = sm.graphics.tsa.plot_pacf(dta, lags=40, ax=ax2)
 
#p=2, q=0 
arma_mod20 = sm.tsa.ARMA(dta, (2,0)).fit(disp=False)
>>> print(arma_mod20.params)
const                49.659542
ar.L1.SUNACTIVITY     1.390656
ar.L2.SUNACTIVITY    -0.688571
dtype: float64

#p=3, q=0 
arma_mod30 = sm.tsa.ARMA(dta, (3,0)).fit(disp=False)
>>> print(arma_mod20.aic, arma_mod20.bic, arma_mod20.hqic)
2622.636338065809 2637.56970317 2628.60672591

>>> print(arma_mod30.params)
const                49.749936
ar.L1.SUNACTIVITY     1.300810
ar.L2.SUNACTIVITY    -0.508093
ar.L3.SUNACTIVITY    -0.129650
dtype: float64

>>> print(arma_mod30.aic, arma_mod30.bic, arma_mod30.hqic)
2619.4036286964474 2638.07033508 2626.8666135

#•Does our model obey the theory?
>>> sm.stats.durbin_watson(arma_mod30.resid.values)
1.9564807635787604

#residual plot 
fig = plt.figure(figsize=(12,8))
ax = fig.add_subplot(111)
ax = arma_mod30.resid.plot(ax=ax);
 
#residula test 
resid = arma_mod30.resid
>>> stats.normaltest(resid)
NormaltestResult(statistic=49.845019661107585, pvalue=1.5006917858823576e-11)
#qqplot 
fig = plt.figure(figsize=(12,8))
ax = fig.add_subplot(111)
fig = qqplot(resid, line='q', ax=ax, fit=True)
 
#plot acf, pcf of residual 
fig = plt.figure(figsize=(12,8))
ax1 = fig.add_subplot(211)
fig = sm.graphics.tsa.plot_acf(resid.values.squeeze(), lags=40, ax=ax1)
ax2 = fig.add_subplot(212)
fig = sm.graphics.tsa.plot_pacf(resid, lags=40, ax=ax2)
 
#get ACF 
r,q,p = sm.tsa.acf(resid.values.squeeze(), qstat=True)
data = np.c_[range(1,41), r[1:], q, p]
table = pd.DataFrame(data, columns=['lag', "AC", "Q", "Prob(>Q)"])
>>> print(table.set_index('lag')) #H0: The data are independently distributed
            AC          Q  Prob(>Q)
lag                                
1.0   0.009179   0.026287  0.871202
2.0   0.041793   0.573041  0.750872
3.0  -0.001335   0.573600  0.902448
4.0   0.136089   6.408927  0.170620
5.0   0.092468   9.111841  0.104685
...        ...        ...       ...
36.0 -0.119329  91.248909  0.000001
37.0 -0.036665  91.723876  0.000002
38.0 -0.046193  92.480525  0.000002  <-- reject H0
39.0 -0.017768  92.592893  0.000003
40.0 -0.006220  92.606716  0.000005
[40 rows x 3 columns]

#•This indicates a lack of fit.
#•In-sample dynamic prediction. How good does our model do?
predict_sunspots = arma_mod30.predict('1990', '2012', dynamic=True)
>>> print(predict_sunspots)
1990-12-31    167.047417
1991-12-31    140.993002
1992-12-31     94.859112
1993-12-31     46.860896
1994-12-31     11.242577
                 ...    
2008-12-31     41.963810
2009-12-31     46.869285
2010-12-31     51.423261
2011-12-31     54.399720
2012-12-31     55.321692
Freq: A-DEC, dtype: float64

#plot predict 
fig, ax = plt.subplots(figsize=(12, 8))
ax = dta.ix['1950':].plot(ax=ax)
fig = arma_mod30.plot_predict('1990', '2012', dynamic=True, ax=ax, plot_insample=False)
 

def mean_forecast_err(y, yhat):
    return y.sub(yhat).mean()

>>> mean_forecast_err(dta.SUNACTIVITY, predict_sunspots)
5.6369602158434047

#Exercise: Can you obtain a better fit for the Sunspots model? 
#(Hint: sm.tsa.AR has a method select_order)





 
 
 



###statsmodel  - sm.tsa - Generate Simulated ARMA process
##ARMA Process
arima_process.ArmaProcess(ar, ma[, nobs])       Represent an ARMA process for given lag-polynomials 

arima_process.ar2arma(ar_des, p, q[, n, ...])   find arma approximation to ar process 
arima_process.arma2ar(ar, ma[, nobs])           get the AR representation of an ARMA process 
arima_process.arma2ma(ar, ma[, nobs])           get the impulse response function (MA representation) for ARMA process 

arima_process.arma_acf(ar, ma[, nobs])          theoretical autocorrelation function of an ARMA process 
arima_process.arma_acovf(ar, ma[, nobs])        theoretical autocovariance function of ARMA process 

arima_process.arma_generate_sample(ar, ma, ...) Generate a random sample of an ARMA process 
arima_process.arma_impulse_response(ar, ma)     get the impulse response function (MA representation) for ARMA process 
arima_process.arma_pacf(ar, ma[, nobs])         partial autocorrelation function of an ARMA process 
arima_process.arma_periodogram(ar, ma[, ...])   periodogram for ARMA process given by lag-polynomials ar and ma 

arima_process.deconvolve(num, den[, n])         Deconvolves divisor out of signal, division of polynomials for n terms 
arima_process.index2lpol(coeffs, index)         expand coefficients to lag poly 
arima_process.lpol2index(ar)                    remove zeros from lagpolynomial, squeezed representation with index 
arima_process.lpol_fiar(d[, n])                 AR representation of fractional integration 
arima_process.lpol_fima(d[, n])                 MA representation of fractional integration 
arima_process.lpol_sdiff(s)                     return coefficients for seasonal difference (1-L^s) 
sandbox.tsa.fftarma.ArmaFft(ar, ma, n)          fft tools for arma processes 


class statsmodels.tsa.arima_process.ArmaProcess(ar, ma, nobs=100)
    Represent an ARMA process for given lag-polynomials
    It does not do any estimation or statistical analysis.
    both the AR and MA components should include the coefficient on the zero-lag. 
    This is typically 1. 
    Further, due to the conventions used in signal processing 
    used in signal.lfilter  vs. conventions in statistics for ARMA processes, 
    the AR paramters should have the opposite sign of what you might expect
    ar : array_like, 1d
        Coefficient for autoregressive lag polynomial, including zero lag. 
    ma : array_like, 1d
        Coefficient for moving-average lag polynomial, including zero lag
    nobs : int, optional
        Length of simulated time series. 
    #Methods 
    acf([nobs])                             theoretical autocorrelation function of an ARMA process 
    acovf([nobs])                           theoretical autocovariance function of ARMA process 
    arma2ar([nobs])  
    arma2ma([nobs])  
    from_coeffs(arcoefs, macoefs[, nobs])   Create ArmaProcess instance from coefficients of the lag-polynomials 
    from_estimation(model_results[, nobs])  Create ArmaProcess instance from ARMA estimation results 
    generate_sample([nsample, scale, distrvs, ...]) generate ARMA samples 
    impulse_response([nobs])                        get the impulse response function (MA representation) for ARMA process 
    invertroots([retnew])                           make MA polynomial invertible by inverting roots inside unit circle 
    pacf([nobs])                                    partial autocorrelation function of an ARMA process 
    periodogram([nobs])                             periodogram for ARMA process given by lag-polynomials ar and ma 
    #Attributes
    arroots                     Roots of autoregressive lag-polynomial 
    isinvertible                Arma process is invertible if MA roots are outside unit circle 
    isstationary                Arma process is stationary if AR roots are outside unit circle 
    maroots                     Roots of moving average lag-polynomial 



#generate Sample 
ArmaProcessInstance.generate_sample([nsample, scale, distrvs, ...]) 
    generate ARMA samples 
ArmaProcess.generate_sample(nsample=100, scale=1.0, distrvs=None, axis=0, burnin=0)
    generate ARMA samples
    nsample : int or tuple of ints
              If nsample is an integer, then this creates a 1d timeseries of length size. 
              If nsample is a tuple, then the timeseries is along axis(axis=0, means columnwise)
              All other axis have independent arma samples.
    scale : float, standard deviation of noise
    distrvs : function, random number generator,default: np.random.randn 
    burnin : integer (default: 0)
        to reduce the effect of initial conditions, 
        burnin observations at the beginning of the sample are dropped

#Example - Simulated ARMA(4,1)
from statsmodels.tsa.arima_process import arma_generate_sample, ArmaProcess


np.random.seed(1234)
# include zero-th lag
arparams = np.array([1, .75, -.65, -.55, .9]) #p =4, means five coeffcients inc const term 
maparams = np.array([1, .65])   #q = 1, means 2 terms including constant 


# Let's make sure this model is estimable.
arma_t = ArmaProcess(arparams, maparams)
arma_t.isinvertible
arma_t.isstationary


# * What does this mean?

fig = plt.figure(figsize=(12,8))
ax = fig.add_subplot(111)
ax.plot(arma_t.generate_sample(nsample=50));
plt.show()

#For analysis purpose 
import pandas as pd
dates = sm.tsa.datetools.dates_from_range('1980m1', length=nobs)
y = pd.TimeSeries(arma_t, index=dates)
arma_mod = sm.tsa.ARMA(y, order=(2,2)) #For analysis purpose 
arma_res = arma_mod.fit(trend='nc', disp=-1)


#with another value 
arparams = np.array([1, .35, -.15, .55, .1])
maparams = np.array([1, .65])
arma_t = ArmaProcess(arparams, maparams)
arma_t.isstationary


arma_rvs = arma_t.generate_sample(nsample=500, burnin=250, scale=2.5)

#Plot PACF and ACF 
#For mixed ARMA processes the Autocorrelation function is a mixture of exponentials 
#and damped sine waves after (q-p) lags.
#The partial autocorrelation function is a mixture of exponentials 
#and dampened sine waves after (p-q) lags.

fig = plt.figure(figsize=(12,8))
ax1 = fig.add_subplot(211)
fig = sm.graphics.tsa.plot_acf(arma_rvs, lags=40, ax=ax1)
ax2 = fig.add_subplot(212)
fig = sm.graphics.tsa.plot_pacf(arma_rvs, lags=40, ax=ax2)
plt.show()


#For analysis purpose 
arma11 = sm.tsa.ARMA(arma_rvs, (1,1)).fit()
resid = arma11.resid

#q The Ljung-Box Q-Statistic
#H0: any of a group of autocorrelations of a time series are zero, values are random and independent over time.
#Q-Statistic's p value
r,q,p = sm.tsa.acf(resid, qstat=True)
data = np.c_[range(1,41), r[1:], q, p]
table = pd.DataFrame(data, columns=['lag', "AC", "Q", "Prob(>Q)"])
>>> print(table.set_index('lag')) #<0.05, reject H0, not good fit 
            AC           Q      Prob(>Q)
lag                                     
1.0   0.254921   32.687669  1.082216e-08
2.0  -0.172416   47.670733  4.450737e-11
3.0  -0.420945  137.159383  1.548473e-29
4.0  -0.046875  138.271291  6.617736e-29
5.0   0.103240  143.675896  2.958739e-29
...        ...         ...           ...
36.0  0.142724  231.734107  1.923091e-30
37.0  0.095768  236.706149  5.937808e-31
38.0 -0.084744  240.607793  2.890898e-31
39.0 -0.150126  252.878971  3.963021e-33
40.0 -0.083767  256.707729  1.996181e-33
[40 rows x 3 columns]


#2nd Try 
arma41 = sm.tsa.ARMA(arma_rvs, (4,1)).fit()
resid = arma41.resid
r,q,p = sm.tsa.acf(resid, qstat=True)
data = np.c_[range(1,41), r[1:], q, p]
table = pd.DataFrame(data, columns=['lag', "AC", "Q", "Prob(>Q)"])
>>> print(table.set_index('lag'))#H0: The data are independently distributed
            AC          Q  Prob(>Q)
lag                                
1.0  -0.007889   0.031302  0.859569
2.0   0.004132   0.039906  0.980245
3.0   0.018103   0.205415  0.976710
4.0  -0.006760   0.228538  0.993948
5.0   0.018120   0.395024  0.995466
...        ...        ...       ...
36.0  0.041271  21.358847  0.974774
37.0  0.078704  24.716879  0.938948
38.0 -0.029729  25.197056  0.944895
39.0 -0.078397  28.543388  0.891179
40.0 -0.014466  28.657578  0.909268
[40 rows x 3 columns]


###statsmodel - sm.tsa - Datetime utils - sm.tsa.datetools.

def date_parser(timestr, parserinfo=None, **kwargs):
    Uses dateutil.parser.parse, but also handles monthly dates of the form
    1999m4, 1999:m4, 1999:mIV, 1999mIV and the same for quarterly data
    with q instead of m. It is not case sensitive. The default for annual
    data is the end of the year, which also differs from dateutil.
def date_range_str(start, end=None, length=None):
    Returns a list of abbreviated date strings.
    Parameters
    ----------
    start : str
        The first abbreviated date, for instance, '1965q1' or '1965m1'
    end : str, optional
        The last abbreviated date if length is None.
    length : int, optional
        The length of the returned array of end is None.
    Returns
    -------
    date_range : list
        List of strings
def dates_from_str(dates):
    Turns a sequence of date strings and returns a list of datetime.
    Parameters
    ----------
    dates : array-like
        A sequence of abbreviated dates as string. For instance,
        '1996m1' or '1996Q1'. The datetime dates are at the end of the
        period.
    Returns
    -------
    date_list : array
        A list of datetime types.  
def dates_from_range(start, end=None, length=None):
    Turns a sequence of date strings and returns a list of datetime.
    Parameters
    ----------
    start : str
        The first abbreviated date, for instance, '1965q1' or '1965m1'
    end : str, optional
        The last abbreviated date if length is None.
    length : int, optional
        The length of the returned array of end is None.
    Examples
    --------
    >>> import statsmodels.api as sm
    >>> dates = sm.tsa.datetools.date_range('1960m1', length=nobs)
    Returns
    -------
    date_list : array
        A list of datetime types.
    
dateutil.parser.parse(timestr, parserinfo=None, **kwargs)[source] 
    From module dateutil 
    Parse a string in one of the supported formats, using the parserinfo parameters.
    Parameters:
        •timestr – A string containing a date/time stamp.
        •parserinfo – A parserinfo object containing parameters for the parser. 
            If None, the default arguments to the parserinfo constructor are used.
    The **kwargs parameter takes the few below keyword arguments:
        •dayfirst – Whether to interpret the first value in an ambiguous 3-integer date 
                (e.g. 01/05/09) as the day (True) or month (False). 
                If yearfirst is set to True, this distinguishes between YDM and YMD. 
                If set to None, this value is retrieved from the current parserinfo object 
                (which itself defaults to False).
        •yearfirst – Whether to interpret the first value in an ambiguous 3-integer date 
                (e.g. 01/05/09) as the year. 
                If True, the first number is taken to be the year, 
                otherwise the last number is taken to be the year. 
                If this is set to None, the value is retrieved from the current parserinfo object 
                (which itself defaults to False).
        •fuzzy – Whether to allow fuzzy parsing, allowing for string like 'Today is January 1, 2047 at 8:21:00AM'.
        •fuzzy_with_tokens – 
        If True, fuzzy is automatically set to True, and the parser will return a tuple where the first element is the parsed datetime.datetime datetimestamp and the second element is a tuple containing the portions of the string which were ignored:
        >>> from dateutil.parser import parse
        >>> parse("Today is January 1, 2047 at 8:21:00AM", fuzzy_with_tokens=True)
        (datetime.datetime(2047, 1, 1, 8, 21), (u'Today is ', u' ', u'at '))

 
   



###statsmodel  -  sm.tsa. - selection of orders  


## selection of ARMA or ARIMA orders 
stattools.arma_order_select_ic(y[, max_ar, ...])    Returns information criteria for many ARMA models 
x13.x13_arima_select_order(endog[, ...])            Perform automatic seaonal ARIMA order identification using x12/x13 ARIMA. 
x13.x13_arima_analysis(endog[, maxorder, ...])      Perform x13-arima analysis for monthly or quarterly data. 
ar_model.AR.select_order(maxlag, ic, trend='c', method='mle') finds the AR order 

#ARIMA with seasonal component ie (p,d,q)x(P,D,Q) 
#for seasonal is (P,D,Q)
x13_arima_select_order(endog, maxorder=(2, 1), maxdiff=(2, 1), diff=None, 
                exog=None, log=None, outlier=True, trading=False, forecast_years=None, start=None, freq=None, print_stdout=False, x12path=None, prefer_x13=True)
    Perform automatic seaonal ARIMA order identification using x12/x13 ARIMA
    endog : array-like, pandas.Series
        The series to model. 
        It is best to use a pandas object with a DatetimeIndex or PeriodIndex. 
        However, you can pass an array-like object. 
        If your object does not have a dates index then start and freq are not optional.
    maxorder : tuple
        The maximum order of the regular and seasonal ARMA polynomials to examine during the model identification. 
        The order for the regular polynomial must be greater than zero and no larger than 4. 
        The order for the seasonal polynomial may be 1 or 2.
    maxdiff : tuple
        The maximum orders for regular and seasonal differencing in the automatic differencing procedure. 
        Acceptable inputs for regular differencing are 1 and 2. 
        The maximum order for seasonal differencing is 1. 
        If diff is specified then maxdiff should be None
    Returns:results : Bunch
        A bunch object that has the following attributes:
        •order : tuple The regular order
        •sorder : tuple The seasonal order
        •include_mean : bool Whether to include a mean or not
        •results : str The full results from the X12/X13 analysis
        •stdout : str The captured stdout from the X12/X13 analysis
 
 
x13_arima_analysis(endog, maxorder=(2, 1), maxdiff=(2, 1), 
                diff=None, exog=None, log=None, outlier=True, trading=False, forecast_years=None, retspec=False, speconly=False, start=None, freq=None, print_stdout=False, x12path=None, prefer_x13=True)
    Perform x13-arima analysis for monthly or quarterly data.
    Returns:res : Bunch
        A bunch object with the following attributes:
        •results : str The full output from the X12/X13 run.
        •seasadj : pandas.Series The final seasonally adjusted endog
        •trend : pandas.Series The trend-cycle component of endog
        •irregular : pandas.Series The final irregular component of endog
        •stdout : str The captured stdout produced by x12/x13.
        •spec : str, optional Returned if retspec is True. 
                The only thing returned if speconly is True.
         
     
#AR(p)
#Create a instance at first 
class statsmodels.tsa.ar_model.AR(endog, dates=None, freq=None, missing='none')
    select_order(maxlag, ic, trend='c', method='mle')
        Select the lag order according to the information criterion.
        maxlag : int, The highest lag length tried. 
        ic : str {'aic','bic','hqic','t-stat'},
            Criterion used for selecting the optimal lag length.
        trend : str {'c','nc'}
            Whether to include a constant or not. 
            'c' - include constant. 
            'nc' - no constant.
        Returns: bestlag : int,Best lag according to IC.
    
#ARMA(p,q)
statsmodels.tsa.stattools.arma_order_select_ic(y, max_ar=4, max_ma=2, ic='bic', trend='c', model_kw={}, fit_kw={})
    y : array-like
        Time-series data
    max_ar : int
        Maximum number of AR lags to use. Default 4.
    max_ma : int
        Maximum number of MA lags to use. Default 2.
    ic : str, list
        Information criteria to report. Either a single string or a list of different criteria is possible.
    Returns: Results object
         Each ic is an attribute with a DataFrame for the results.
         The AR order used is the row index. 
         The ma order used is the column index. 
         The minimum orders are available as ic_min_order.
 
 
#Example 
from statsmodels.tsa.arima_process import arma_generate_sample
import statsmodels.api as sm
import numpy as np

#ARMA(2,2)
arparams = np.array([.75, -.25]) #p=2 
maparams = np.array([.65, .35]) #q = 2  
arparams = np.r_[1, -arparams] #+ const term 
maparam = np.r_[1, maparams] #+ const term
nobs = 250
np.random.seed(2014)
y = arma_generate_sample(arparams, maparams, nobs)
res = sm.tsa.arma_order_select_ic(y, ic=['aic', 'bic'], trend='nc')
res.aic_min_order #(p,q) = (1,2)
res.bic_min_order #(1,2)
>>> res
{'aic': 
            0           1           2
0         NaN  552.734225  484.296878
1  562.109243  485.519797  480.328585
2  507.045813  482.910658  481.919260
3  484.039960  482.148680  483.863790
4  481.884948  483.837738  485.837566, 
'aic_min_order': (1, 2), 
'bic':
            0           1           2
0         NaN  559.777147  494.861261
1  569.152164  496.084180  494.414429
2  517.610196  496.996502  499.526565
3  498.125803  499.755985  504.992555
4  499.492252  504.966503  510.487793, 
'bic_min_order': (1, 2)}

#x13
#For analysis purpose 
import pandas as pd
dates = sm.tsa.datetools.dates_from_range('1980m1', length=nobs)
df = pd.DataFrame(y, index=dates)
#Requires x13as.exe in PATH ,Only monthly and quarterly periods are supported
#download from https://www.census.gov/srd/www/winx13/winx13_down.html
res = statsmodels.tsa.x13.x13_arima_select_order(df)
>>> res.order
(0, 0, 2)
>>> res.sorder
(0, 0, 0)






###statsmodel  - sm.tsa  - Decomposing trend and seasonality 
statsmodels.tsa.seasonal.seasonal_decompose(x, model='additive', filt=None, freq=None, two_sided=True)[source]
    Seasonal decomposition using moving averages
    The additive model is Y[t] = T[t] + S[t] + e[t]
    The multiplicative model is Y[t] = T[t] * S[t] * e[t]
    Parameters:
    x : array-like
        Time series
    model : str {'additive', 'multiplicative'}
        Type of seasonal component. Abbreviations are accepted.
    filt : array-like
        The filter coefficients for filtering out the seasonal component. 
        The concrete moving average method used in filtering is determined by two_sided.
    freq : int, optional
        Frequency of the series. Must be used if x is not a pandas object. 
        Overrides default periodicity of x 
        if x is a pandas object with a timeseries index.
            #freqstr      Seasonal period    # of datapoints for aggregation
            A              1                 aggregate yearly 
            Q              4                 aggregate yearly 
            M              12                aggregate yearly
            W              52                aggregate yearly
            D              7                 aggregate weekly 
            B              5                 aggregate weekly 
            H              24                aggregate daily 
    two_sided : bool
        The moving average method used in filtering. 
        If True (default), a centered moving average is computed using the filt. 
        If False, the filter coefficients are for past values only.
    Returns:
    results : obj
        A object with 'seasonal', 'trend', and 'resid' attributes.
        has .plot() method 
        
##How to get 'freq' value 
#For Pandas Timeseries , is it inferred automatically

#convert index to DateTimeIndex:
#Note Index must have 'freq'(must not be None) which used by decompose
#df contains 'divida' column 
df.reset_index(inplace=True)
df['Date'] = pd.to_datetime(df['Date'])
df = df.set_index('Date')
s=sm.tsa.seasonal_decompose(df.divida)


#but if inference fails or if not pandas obeject or any other freq 
#then calculate 'freq' manually 
import pandas as pd
import statsmodels.api as sm

centrumGalerie = pd.read_csv('data/Centrum-Galerie-Belegung.csv', #collected parking lot occupancy of a shopping mall called 
         names=['Datum', 'Belegung'],
         index_col=['Datum'],
         parse_dates=True)
centrumGalerie.Belegung.plot()

>>> centrumGalerie.Belegung.index #note freq=None 
DatetimeIndex(['2014-04-13 01:45:00', '2014-04-13 02:00:00',
               '2014-04-13 02:15:00', '2014-04-13 02:30:00',
               '2014-04-13 02:45:00', '2014-04-13 03:00:00',
               '2014-04-13 03:15:00', '2014-04-13 03:30:00',
               '2014-04-13 03:45:00', '2014-04-13 04:00:00',
               ...
               '2015-06-17 16:00:00', '2015-06-17 16:15:00',
               '2015-06-17 16:30:00', '2015-06-17 16:45:00',
               '2015-06-17 17:00:00', '2015-06-17 17:15:00',
               '2015-06-17 17:30:00', '2015-06-17 17:45:00',
               '2015-06-17 18:00:00', '2015-06-17 18:15:00'],
              dtype='datetime64[ns]', name='Datum', length=40710, freq=None)
              
#option -1 
df = centrumGalerie.copy()
df.index.freq = pd.tseries.frequencies.to_offset('15T')
#note 'seasonal_decompose' uses index.inferred_freq, which can not be set via above technique 
#use below 
df.index= pd.date_range(start=df.index[0], periods=df.index.size, freq='15T')
>>> res = sm.tsa.seasonal_decompose(df.Belegung)
ValueError: freq T not understood. Please report if you think this is in error.
       

#data is stored with 15min resolution 
#to see a weekly seasonality, so freq is 
#freq = ((24h*60min)/15min)*7days
decompfreq = int(24*60/15*7) #must be int 

res = sm.tsa.seasonal_decompose(df.Belegung,freq=decompfreq)
res.plot()
plt.show()
#because of freq, many values in original time series would contain Nan 
T = res.trend.dropna()   
S = res.seasonal.dropna()   
new_s = res.resid.dropna()   
ori_s = res.observed[T.index.values] #res.observed.asfreq('W') would not make it as same freq of T

#recreate the Series and check for error 
pred_s = T + S + new_s  #for additive, for multiplicative, T*S*new_s 
pred_s.dropna(inplace=True)
RMSE = np.sqrt( np.sum(   (ori_s -pred_s)**2 )/len(pred_s) )

#with freq=1 , note there is no Seasonal and resid as there is nothing to aggregate
res = sm.tsa.seasonal_decompose(df.Belegung,freq=1)
T = res.trend.dropna()   #== df.Belegung
S = res.seasonal.dropna()    #0 
new_s = res.resid.dropna()   #0
ori_s = res.observed[T.index.values]

###statsmodel -  sm.tsa - Filters
#Filters are used for removing cycles, seasonals etc 
#from data to get pure 'trend'
#these trends are used for Time Series estimation


##Time Series Filters
filters.bk_filter.bkfilter(X[, low, high, K])       Baxter-King bandpass filter 
filters.hp_filter.hpfilter(X[, lamb])               Hodrick-Prescott filter 
filters.cf_filter.cffilter(X[, low, high, drift])   Christiano Fitzgerald asymmetric, random walk filter 



#Example 
statsmodels.tsa.filters.bk_filter.bkfilter(X, low=6, high=32, K=12)
    Parameters:
    X : array-like
        A 1 or 2d ndarray. 
        If 2d, variables are assumed to be in columns.
    low : float
        Minimum period for oscillations, ie., Baxter and King suggest 
        that the Burns-Mitchell U.S. business cycle has 6 for quarterly data 
        and 1.5 for annual data.
    high : float
        Maximum period for oscillations 
        BK suggest that the U.S. business cycle has 32 for quarterly data 
        and 8 for annual data.
    K : int
        Lead-lag length of the filter. 
        Baxter and King propose a truncation length of 12 for quarterly data 
        and 3 for annual data.
    Returns:
    Y : array
        Cyclical component of X
 
#Example 
import statsmodels.api as sm
import pandas as pd
dta = sm.datasets.macrodata.load_pandas().data
index = pd.DatetimeIndex(start='1959Q1', end='2009Q4', freq='Q')
dta.set_index(index, inplace=True)
cycles = sm.tsa.filters.bkfilter(dta[['realinv']], 6, 24, 12)
import matplotlib.pyplot as plt
fig, ax = plt.subplots()
cycles.plot(ax=ax, style=['r--', 'b-'])
plt.show()

#Example 
statsmodels.tsa.filters.hp_filter.hpfilter(X, lamb=1600)
    Hodrick-Prescott filter
    Parameters:
    X : array-like
        The 1d ndarray timeseries to filter of length (nobs,) or (nobs,1)
    lamb : float
        The Hodrick-Prescott smoothing parameter. 
        A value of 1600 is suggested for quarterly data. 
        Ravn and Uhlig suggest using a value of 6.25 (1600/4**4) for annual data 
        and 129600 (1600*3**4) for monthly data.
    Returns:
    cycle : array
        The estimated cycle in the data given lamb.
    trend : array
        The estimated trend in the data given lamb.
 
#Example 
import statsmodels.api as sm
import pandas as pd
dta = sm.datasets.macrodata.load_pandas().data
index = pd.DatetimeIndex(start='1959Q1', end='2009Q4', freq='Q')
dta.set_index(index, inplace=True)
cycle, trend = sm.tsa.filters.hpfilter(dta.realgdp, 1600)
gdp_decomp = dta[['realgdp']]
gdp_decomp["cycle"] = cycle
gdp_decomp["trend"] = trend

import matplotlib.pyplot as plt
fig, ax = plt.subplots()
gdp_decomp[["realgdp", "trend"]]["2000-03-31":].plot(ax=ax,fontsize=16);
plt.show()

#Example 
statsmodels.tsa.filters.cf_filter.cffilter(X, low=6, high=32, drift=True)
    Christiano Fitzgerald asymmetric, random walk filter
    Parameters:
        X : array-like
        1 or 2d array to filter. If 2d, variables are assumed to be in columns.
    low : float
        Minimum period of oscillations. 
        Features below low periodicity are filtered out. 
        Default is 6 for quarterly data, giving a 1.5 year periodicity.
    high : float
        Maximum period of oscillations. 
        Features above high periodicity are filtered out. 
        Default is 32 for quarterly data, giving an 8 year periodicity.
    drift : bool
        Whether or not to remove a trend from the data. 
        The trend is estimated as np.arange(nobs)*(X[-1] - X[0])/(len(X)-1)
    Returns:
    cycle : array
        The features of X between periodicities given by low and high
    trend : array
        The trend in the data with the cycles removed.
 
#Example 
import statsmodels.api as sm
import pandas as pd
dta = sm.datasets.macrodata.load_pandas().data
index = pd.DatetimeIndex(start='1959Q1', end='2009Q4', freq='Q')
dta.set_index(index, inplace=True)
cf_cycles, cf_trend = sm.tsa.filters.cffilter(dta[["infl", "unemp"]])

import matplotlib.pyplot as plt
fig, ax = plt.subplots()
cf_cycles.plot(ax=ax, style=['r--', 'b-'])
plt.show()

##Other filters 
filters.filtertools.convolution_filter(x, filt)     Linear filtering via convolution. 
filters.filtertools.recursive_filter(x, ar_coeff)   Autoregressive, or recursive, filtering 
tsatools.add_trend(x[, trend, prepend, ...])        Adds a trend and/or constant to an array. 
                                                    trend : str {'c','t','ct','ctt'}
                                                        'c' add constant only 
                                                        't' add trend only 
                                                        'ct' add constant and linear trend 
                                                        'ctt' add constant and linear and quadratic trend.
                                                    Returns columns as ['ctt','ct','c'] whenever applicable

tsatools.detrend(x[, order, axis])                  Detrend an array with a trend of given order along axis 0 or 1 
                                                    order : int
                                                        specifies the polynomial order of the trend, 
                                                        zero is constant, one is linear trend, 
                                                        two is quadratic trend
                                                    Returns:
                                                    detrended data series : ndarray
                                                        The detrended series is the residual of the linear regression of the data 
                                                        on the trend of given order.
 






###statsmodel  - sm.tsa  - Model fitting and estimation
##Estimation - statsmodels.tsa.api

ar_model.AR(endog[, dates, freq, missing])      Autoregressive AR(p) model 
ar_model.ARResults(model, params[, ...])        Class to hold results from fitting an AR model. 


arima_model.ARMA(endog, order[, exog, ...])     Autoregressive Moving Average ARMA(p,q) Model 
arima_model.ARMAResults(model, params[, ...])   Class to hold results from fitting an ARMA model. 

arima_model.ARIMA(endog, order[, exog, ...])    Autoregressive Integrated Moving Average ARIMA(p,d,q) Model 
arima_model.ARIMAResults(model, params[, ...])  


     
class statsmodels.tsa.ar_model.AR(endog, dates=None, freq=None, missing='none')
    Autoregressive AR(p) model
    Parameters:
    endog : array-like
        1-d endogenous response variable. The independent variable.
    dates : array-like of datetime, optional
        An array-like object of datetime objects. 
        If a pandas object is given for endog or exog, 
        it is assumed to have a DateIndex.
    freq : str, optional
        The frequency of the time-series. 
        A Pandas offset or 'B', 'D', 'W', 'M', 'A', or 'Q'. 
        This is optional if dates are given.
    missing : str
        Available options are 'none', 'drop', and 'raise'. 
        If 'none', no nan checking is done. 
        If 'drop', any observations with nans are dropped. 
        If 'raise', an error is raised. Default is 'none.'
    #Methods 
    fit([maxlag, method, ic, trend, ...])            Fit the unconditional maximum likelihood of an AR(p) process. 
    from_formula(formula, data[, subset, drop_cols]) Create a Model from a formula and dataframe. 
    hessian(params)                                  Returns numerical hessian for now. 
    loglike(params)                                  The loglikelihood of an AR(p) process 
    predict(params[, start, end, dynamic])           Returns in-sample and out-of-sample prediction. 
    score(params)                                    Return the gradient of the loglikelihood at params. 
    select_order(maxlag, ic[, trend, method])        Select the lag order according to the information criterion. 
     
     
 

class statsmodels.tsa.arima_model.ARIMA(endog, order, exog=None, dates=None, freq=None, missing='none')
    Autoregressive Integrated Moving Average ARIMA(p,d,q) Model
    endog : array-like.
        The endogenous variable.
    order : iterable, (p,d,q) order of the model
    exog : array-like, optional
            An optional arry of exogenous variables. 
            This should not include a constant or trend. 
            You can specify this in the fit method.
    dates : array-like of datetime, optional
        An array-like object of datetime objects. 
        If a pandas object is given for endog or exog, it is assumed to have a DateIndex.
    freq : str, optional
           The frequency of the time-series. 
           A Pandas offset or 'B', 'D', 'W', 'M', 'A', or 'Q'. 
           This is optional if dates are given.
 
#Attributes
endog_names  
exog_names 
#Methods of the ARIMA( similar exists for ARMA etc) 
fit([start_params, trend, method, ...]) 
    Fits ARIMA(p,d,q) model by exact maximum likelihood via Kalman filter. 
    method : str {'css-mle','mle','css'}
        This is the loglikelihood to maximize. If 'css-mle', the conditional sum of squares 
        likelihood is maximized and its values are used as starting values for the computation 
        of the exact likelihood via the Kalman filter. If 'mle', the exact likelihood is 
        maximized via the Kalman Filter. If 'css' the conditional sum of squares likelihood is 
        maximized. 
    trend : str {'c','nc'}
        Whether to include a constant or not. 
        'c' includes constant, 
        'nc' no constant.
    solver : str or None, optional
        The default is 'lbfgs' (limited memory Broyden-Fletcher-Goldfarb-Shanno). 
        Other choices are 'bfgs', 'newton' (Newton-Raphson), 'nm' (Nelder-Mead), 
        'cg' - (conjugate gradient), 'ncg' (non-conjugate gradient), and 'powell'. 
        By default, the limited memory BFGS uses m=12 to approximate the Hessian, 
        projected gradient tolerance of 1e-8 and factr = 1e2. 
        You can change these by using kwargs.
    
from_formula(formula, data[, subset])   Create a Model from a formula and dataframe. 
geterrors(params)                       Get the errors of the ARMA process. 
hessian(params)                         Compute the Hessian at params, 
information(params)                     Fisher information matrix of model 
loglike(params[, set_sigma2])           Compute the log-likelihood for ARMA(p,q) model 
loglike_css(params[, set_sigma2])       Conditional Sum of Squares likelihood function. 
loglike_kalman(params[, set_sigma2])    Compute exact loglikelihood for ARMA(p,q) model by the Kalman Filter. 
score(params)                           Compute the score function at params. 
predict(params[, start, end, exog, typ, dynamic]) ARIMA model in-sample and out-of-sample prediction 

 
##Methods of Result from ARIMA.fit(..)
#AR, ARMA, VAR have similar Result type and methods 
aic()  
arfreq()                                    Returns the frequency of the AR roots. 
arparams()  
arroots()  
bic()  
bse()  
conf_int([alpha, cols, method])             Returns the confidence interval of the fitted parameters. 
cov_params()  
f_test(r_matrix[, cov_p, scale, invcov])    Compute the F-test for a joint linear hypothesis. 
fittedvalues()  
forecast([steps, exog, alpha])              Out-of-sample forecasts 
hqic()  
llf()  
load(fname)                                 load a pickle, (class method) 
mafreq()                                    Returns the frequency of the MA roots. 
maparams()  
maroots()  
normalized_cov_params()  
pvalues()  
remove_data()                                   remove data arrays, all nobs arrays from result and model 
resid()  
save(fname[, remove_data])                      save a pickle of this instance 
summary([alpha])                                Summarize the Model 
summary2([title, alpha, float_format])          Experimental summary function for ARIMA Results 
t_test(r_matrix[, cov_p, scale, use_t])         Compute a t-test for a each linear hypothesis of the form Rb = q 
tvalues()                                       Return the t-statistic for a given parameter estimate. 
wald_test(r_matrix[, cov_p, scale, invcov, ...])Compute a Wald-test for a joint linear hypothesis
                                                Used for to check whether smaller(nested to larger) model fits significantly compared to larger model
                                                H0: two/more coefficients of interest from larger model are simultaneously equal to zero
           

ARIMAResults.forecast(steps=1, exog=None, alpha=0.05)[source]
    Out-of-sample forecasts
    Note if d=n, results is returned without difference=n unlike predict()
    Parameters:
    steps : int
        The number of out of sample forecasts from the end of the sample.
    exog : array
        If the model is an ARIMAX, you must provide out of sample values for the exogenous variables. This should not include the constant.
    alpha : float
        The confidence intervals for the forecasts are (1 - alpha) %
    Returns:
    forecast : array
        Array of out of sample forecasts
    stderr : array
        Array of the standard error of the forecasts.
    conf_int : array
        2d array of the confidence interval for the forecast
           
ARIMAResults.plot_predict([start, end, exog, dynamic, ...])  
    Plot forecasts 
ARIMAResults.predict(start=None, end=None, exog=None, typ='linear', dynamic=False)[source]
    ARIMA model in-sample and out-of-sample prediction
    Note if d=n, results is returned with difference=n unlike forecast()
    Also, note, if d=n, then start must be n atleast as past n values are lost due to differencing 
    Also for out of sample , prediction, use start=len(data)-1 
    Parameters:
    start : int, str, or datetime
        Zero-indexed observation number at which to start forecasting, 
        ie., the first forecast is start. 
        Can also be a date string to parse or a datetime type.
    end : int, str, or datetime
        Zero-indexed observation number at which to end forecasting, 
        ie., the first forecast is start. 
        Can also be a date string to parse or a datetime type. 
        However, if the dates index does not have a fixed frequency, 
        end must be an integer index if you want out of sample prediction.
    exog : array-like, optional
        If the model is an ARMAX and out-of-sample forecasting is requested, 
        exog must be given. 
        Note that you'll need to pass k_ar additional lags 
        for any exogenous variables. 
        E.g., if you fit an ARMAX(2, q) model 
        and want to predict 5 steps, you need 7 observations to do this.
    dynamic : bool, optional
        The dynamic keyword affects in-sample prediction. 
        If dynamic is False, then the in-sample lagged values are used for prediction. 
        If dynamic is True, then in-sample forecasts are used in place of lagged dependent variables. 
        The first forecasted value is start.
    typ : str {'linear', 'levels'}
        •'linear' : Linear prediction in terms of the differenced endogenous variables.
        •'levels' : Predict the levels of the original endogenous variables.
    Returns:
    predict : array
        The predicted values.
        
##testing for non stationary 
statsmodels.tsa.stattools.adfuller(x, maxlag=None, regression='c', autolag='AIC', store=False, regresults=False)[source]
    a unit root test tests whether a time series variable is non-stationary and possesses a unit root. 
    H0: presence of a unit root or nonstionary
    Parameters:
    x : array_like, 1d
        data series
    maxlag : int
        Maximum lag which is included in test, default 12*(nobs/100)^{1/4}
    regression : {'c','ct','ctt','nc'}
        Constant and trend order to include in regression
        •'c' : constant only (default)
        •'ct' : constant and trend
        •'ctt' : constant, and linear and quadratic trend
        •'nc' : no constant, no trend
    autolag : {'AIC', 'BIC', 't-stat', None}
        •if None, then maxlag lags are used
        •if 'AIC' (default) or 'BIC', then the number of lags is chosen to minimize the corresponding information criterion
        •'t-stat' based choice of maxlag. Starts with maxlag and drops a lag until the t-statistic on the last lag length is significant using a 5%-sized test
    store : bool
        If True, then a result instance is returned additionally to the adf statistic. Default is False
    regresults : bool, optional
        If True, the full regression results are returned. Default is False
    Returns:
    adf : float
        Test statistic
    pvalue : float
        MacKinnon's approximate p-value based on MacKinnon (1994, 2010)
    usedlag : int
        Number of lags used
    nobs : int
        Number of observations used for the ADF regression and calculation of the critical values
    critical values : dict
        Critical values for the test statistic at the 1 %, 5 %, and 10 % levels. Based on MacKinnon (2010)
    icbest : float
        The maximized information criterion if autolag is not None.
    resstore : ResultStore, optional
        A dummy class with results attached as attributes
                                                 
                                                 
                                                 
##Example - AR - sunspots data 


from __future__ import print_function
import statsmodels.api as sm
import numpy as np
import pandas as pd

data = sm.datasets.sunspots.load()
from datetime import datetime
dates = sm.tsa.datetools.dates_from_range('1700', length=len(data.endog))

#Make a pandas TimeSeries or DataFrame
endog = pd.DataFrame(data.endog, index=dates)

#AR model 
ar_model = sm.tsa.AR(endog, freq='A')
pandas_ar_res = ar_model.fit(maxlag=9, method='mle', disp=-1)

#Out-of-sample prediction

pred = pandas_ar_res.predict(start='2005', end='2015')
>>> print(pred)
2005-12-31    20.003302
2006-12-31    24.703999
2007-12-31    20.026145
2008-12-31    23.473645
2009-12-31    30.858584
2010-12-31    61.335464
2011-12-31    87.024706
2012-12-31    91.321256
2013-12-31    79.921607
2014-12-31    60.799490
2015-12-31    40.374843
Freq: A-DEC, dtype: float64

#Using explicit dates
ar_model = sm.tsa.AR(data.endog, dates=dates, freq='A')
ar_res = ar_model.fit(maxlag=9, method='mle', disp=-1)
pred = ar_res.predict(start='2005', end='2015')
>>> print(pred)
[ 20.0033  24.704   20.0261  23.4736  30.8586  61.3355  87.0247  91.3213
  79.9216  60.7995  40.3748]


##Example - ARIMA
#https://www.analyticsvidhya.com/blog/2016/02/time-series-forecasting-codes-python/

import pandas as pd
import numpy as np
import matplotlib.pylab as plt
%matplotlib inline
from matplotlib.pylab import rcParams
rcParams['figure.figsize'] = 15, 6

#Load data 
data = pd.read_csv('data/AirPassengers.csv')
>>> print(data.head())
     Month  #Passengers
0  1949-01          112
1  1949-02          118
2  1949-03          132
3  1949-04          129
4  1949-05          121


#Parse dates 
dateparse = lambda x: pd.to_datetime(x, format='%Y-%m')
data = pd.read_csv('data/AirPassengers.csv', parse_dates=['Month'], index_col='Month',date_parser=dateparse)
>>> print(data.head())
            #Passengers
Month
1949-01-01          112
1949-02-01          118
1949-03-01          132
1949-04-01          129
1949-05-01          121
>>> data.index
DatetimeIndex(['1949-01-01', '1949-02-01', '1949-03-01', '1949-04-01',
               '1949-05-01', '1949-06-01', '1949-07-01', '1949-08-01',
               '1949-09-01', '1949-10-01',
               ...
               '1960-03-01', '1960-04-01', '1960-05-01', '1960-06-01',
               '1960-07-01', '1960-08-01', '1960-09-01', '1960-10-01',
               '1960-11-01', '1960-12-01'],
              dtype='datetime64[ns]', name='Month', length=144, freq=None)
              
ts = data['#Passengers']
#Selecting 
#1. Specific the index as a string constant:
#ERROR: data['1949-01-01']
data.loc['1949-01-01']
ts['1949-01-01']
#2. Import the datetime library and use 'datetime' function:
from datetime import datetime
#ERROR data[datetime(1949,1,1)]
data.loc[datetime(1949,1,1)]
ts[datetime(1949,1,1)]
#1. Specify the entire range:
data['1949-01-01':'1949-05-01']
ts['1949-01-01':'1949-05-01']
#2. Use ':' if one of the indices is at ends:
data[:'1949-05-01']
ts[:'1949-05-01']
#year
data['1949']
ts['1949']

##Checking stationary 
#constant mean
#constant variance
#an autocovariance that does not depend on time
#run plot 
plt.plot(data)  #clearly shows overall increasing trend 
#or 
plt.plot(ts)
#Or 
data.plot(kind='line')
plt.show()

#further checking of stationary 
#rolling statistics plots - ever increasing 
#and  Dickey-Fuller test - adfuller
#H0: TS is non-stationary

from statsmodels.tsa.stattools import adfuller
def test_stationarity(timeseries):    
    #Determing rolling statistics
    rolmean = timeseries.rolling(window=12, center=False).mean()
    rolstd = timeseries.rolling(window=12, center=False).std()
    #Plot rolling statistics:
    orig = plt.plot(timeseries, color='blue',label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.title('Rolling Mean & Standard Deviation')
    plt.show(block=False)
    #Perform Dickey-Fuller test:
    print('Results of Dickey-Fuller Test:')
    dftest = adfuller(timeseries, autolag='AIC')
    dfoutput = pd.Series(dftest[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
    for key,value in dftest[4].items():
        dfoutput['Critical Value (%s)'%key] = value
    print(dfoutput)
    

>>> test_stationarity(ts)  
#variation in standard deviation is small, mean is clearly increasing with time 
#p-value>0.05, hence accept H0(=TS is non-stationary)
Results of Dickey-Fuller Test:
Test Statistic                   0.815369
p-value                          0.991880
#Lags Used                      13.000000
Number of Observations Used    130.000000
Critical Value (1%)             -3.481682
Critical Value (10%)            -2.578770
Critical Value (5%)             -2.884042
dtype: float64


##How to make a Time Series Stationary?
#Reasons for nonstionary 
1. Trend – varying mean over time. 
    In this case, average mean increasing over time 
2. Seasonality – variations at specific time-frames. 
    eg people might have a tendency to buy cars in a particular month 
    because of pay increment or festivals.

##Eliminating Trend 
#First option for reducing increasing trend  - Tranformation 
#eg log, sqrt or cube root to dampen the trend 
#for decreasing trend, exp, square, cube etc 
ts_log = np.log(ts)
plt.plot(ts_log)
plt.show()

#Further options are 
#Aggregation – taking average for a time period like monthly/weekly averages
#Smoothing – taking rolling averages
#Polynomial Fitting – fit a regression model

#Smoothing - Moving average   
moving_avg = ts_log.rolling(window=12, center=False).mean()
plt.plot(ts_log)
plt.plot(moving_avg, color='red')
plt.show()

#Smoothing -  Differencing 
ts_log_moving_avg_diff = ts_log - moving_avg
ts_log_moving_avg_diff.dropna(inplace=True) #remove any NAN 
>>> test_stationarity(ts_log_moving_avg_diff)
#very near to stationary 
Results of Dickey-Fuller Test:
Test Statistic                  -3.162908
p-value                          0.022235
#Lags Used                      13.000000
Number of Observations Used    119.000000
Critical Value (1%)             -3.486535
Critical Value (10%)            -2.579896
Critical Value (5%)             -2.886151
dtype: float64

#Note, we have taken rolling average with window=12 , valid for any yearly data 
#but for random datetimeIndex, eg for stocks data,
#better option is 'weighted moving average'
expwighted_avg = ts_log.ewm(halflife=12).mean()
plt.plot(ts_log)
plt.plot(expwighted_avg, color='red')
ts_log_ewma_diff = ts_log - expwighted_avg
>>> test_stationarity(ts_log_ewma_diff)
Results of Dickey-Fuller Test:
Test Statistic                  -3.601262
p-value                          0.005737
#Lags Used                      13.000000
Number of Observations Used    130.000000
Critical Value (1%)             -3.481682
Critical Value (10%)            -2.578770
Critical Value (5%)             -2.884042
dtype: float64



##Eliminating both Trend and Seasonality
#Differencing – taking the differece with a particular time lag
#Decomposition – modeling both trend and seasonality and removing them from the model.

##Eliminating both Trend and Seasonality - Differencing
ts_log_diff = ts_log - ts_log.shift(1)
#or 
ts_log_diff = ts_log.diff(periods=1) #Periods to shift for forming difference

ts_log_diff.dropna(inplace=True)
>>> test_stationarity(ts_log_diff)
Results of Dickey-Fuller Test:
Test Statistic                  -2.717131
p-value                          0.071121
#Lags Used                      14.000000
Number of Observations Used    128.000000
Critical Value (1%)             -3.482501
Critical Value (10%)            -2.578960
Critical Value (5%)             -2.884398
dtype: float64

#Note 2nd differencing is extremly rare , DOn't use 
ts_log_diff2 = ts_log_diff - ts_log_diff.shift(1)
#or 
ts_log_diff2 = ts_log_diff.diff(1) #Note, it is not ts_log.diff(periods=2), which is diff with every 2nd period 

ts_log_diff2.dropna(inplace=True)
>>> test_stationarity(ts_log_diff2)
Results of Dickey-Fuller Test:
Test Statistic                -8.196629e+00
p-value                        7.419305e-13
#Lags Used                     1.300000e+01
Number of Observations Used    1.280000e+02
Critical Value (1%)           -3.482501e+00
Critical Value (10%)          -2.578960e+00
Critical Value (5%)           -2.884398e+00
dtype: float64


##Eliminating both Trend and Seasonality - Decomposing
#In this approach, both trend and seasonality are modeled separately 
#and the remaining part of the series is returned


from statsmodels.tsa.seasonal import seasonal_decompose
decomposition = seasonal_decompose(ts_log)

trend = decomposition.trend
seasonal = decomposition.seasonal
residual = decomposition.resid  #we need to work with this series further 

plt.subplot(411)
plt.plot(ts_log, label='Original')
plt.legend(loc='best')
plt.subplot(412)
plt.plot(trend, label='Trend')
plt.legend(loc='best')
plt.subplot(413)
plt.plot(seasonal,label='Seasonality')
plt.legend(loc='best')
plt.subplot(414)
plt.plot(residual, label='Residuals')
plt.legend(loc='best')
plt.tight_layout()
plt.show()
#Get stats 
ts_log_decompose = residual
ts_log_decompose.dropna(inplace=True)
>>> test_stationarity(ts_log_decompose)
Results of Dickey-Fuller Test:
Test Statistic                -6.332387e+00
p-value                        2.885059e-08
#Lags Used                     9.000000e+00
Number of Observations Used    1.220000e+02
Critical Value (1%)           -3.485122e+00
Critical Value (10%)          -2.579569e+00
Critical Value (5%)           -2.885538e+00
dtype: float64


##Forecasting a Time Series
#Use differencingfor making stationary 

#ACF and PACF plots:
#p – The lag value where the PACF chart crosses the upper confidence interval for the first time. If you notice closely, in this case p=2.
#q – The lag value where the ACF chart crosses the upper confidence interval for the first time. If you notice closely, in this case q=2.


#below line must, must not contain NaN 
ts_log_diff.dropna(inplace=True)

fig = plt.figure(figsize=(12,8))
ax1 = fig.add_subplot(211)
sm.graphics.tsa.plot_acf(ts_log_diff, lags=40, ax=ax1,alpha=0.05) #confidence level 95%
ax2 = fig.add_subplot(212)
sm.graphics.tsa.plot_pacf(ts_log_diff, lags=40, ax=ax2,alpha=0.05)
plt.show()

#option-2 
from statsmodels.tsa.stattools import acf, pacf
#other option 
lag_acf = acf(ts_log_diff, nlags=20)
lag_pacf = pacf(ts_log_diff, nlags=20, method='ols')

#Plot ACF: 
plt.subplot(121) 
plt.plot(lag_acf)
plt.axhline(y=0,linestyle='--',color='gray')
plt.axhline(y=-1.96/np.sqrt(len(ts_log_diff)),linestyle='--',color='gray')
plt.axhline(y=1.96/np.sqrt(len(ts_log_diff)),linestyle='--',color='gray')
plt.title('Autocorrelation Function')

#Plot PACF:
plt.subplot(122)
plt.plot(lag_pacf)
plt.axhline(y=0,linestyle='--',color='gray')
plt.axhline(y=-1.96/np.sqrt(len(ts_log_diff)),linestyle='--',color='gray')
plt.axhline(y=1.96/np.sqrt(len(ts_log_diff)),linestyle='--',color='gray')
plt.title('Partial Autocorrelation Function')
plt.tight_layout()



#Fit now 
#since 1st order differntiation is done, hence d= 1
from statsmodels.tsa.arima_model import ARIMA

#AR Model
model = ARIMA(ts_log, order=(2, 1, 0))  
results_AR = model.fit(disp=-1)   #disp:If True, convergence information is output.
plt.plot(ts_log_diff)
plt.plot(results_AR.fittedvalues, color='red')
plt.title('RSS: %.4f'% sum((results_AR.fittedvalues-ts_log_diff)**2))

#MA Model
model = ARIMA(ts_log, order=(0, 1, 2))  
results_MA = model.fit(disp=-1)  
plt.plot(ts_log_diff)
plt.plot(results_MA.fittedvalues, color='red')
plt.title('RSS: %.4f'% sum((results_MA.fittedvalues-ts_log_diff)**2))

#ARIMA 
model = ARIMA(ts_log, order=(2, 1, 2))  
results_ARIMA = model.fit(disp=-1)  
plt.plot(ts_log_diff)
plt.plot(results_ARIMA.fittedvalues, color='red')
plt.title('RSS: %.4f'% sum((results_ARIMA.fittedvalues-ts_log_diff)**2))

plt.show()

#note .fittedvalues, .predict(start=1,end=..) comes after d=1 
#but .forecast(steps=) comes without d=1 

##Taking it back to original scale
predictions_ARIMA_diff = pd.Series(results_ARIMA.fittedvalues, copy=True)
print(predictions_ARIMA_diff.head())

#Notice that these start from '1949-02-01' and not the first month. 
#This is because we took a lag by 1  for differencing 

#To undo, first determine the cumulative sum at index 
predictions_ARIMA_diff_cumsum = predictions_ARIMA_diff.cumsum()
#and then add it to the base number. 
predictions_ARIMA_log = pd.Series(ts_log.ix[0], index=ts_log.index)
predictions_ARIMA_log = predictions_ARIMA_log.add(predictions_ARIMA_diff_cumsum,fill_value=0)
#and then anti-log 
predictions_ARIMA = np.exp(predictions_ARIMA_log)
plt.plot(ts)
plt.plot(predictions_ARIMA)
plt.title('RMSE: %.4f'% np.sqrt(sum((predictions_ARIMA-ts)**2)/len(ts)))





##Example - ARIMAX Model 
#ARIMA with with additional explanatory variables 
#Note Multivariate cause 'causality' (check VAR), called "Granger-causes"

#if a signal X1 "Granger-causes" (or "G-causes") a signal X2, 
#then past values of X1 should contain information that helps predict X2 
#above and beyond the information contained in past values of X2 alone.

import pandas as pd
import matplotlib.pyplot as plt
df=pd.read_csv('data/salesdata2.csv')
>>> df.head()
   Month   Marketing       Sales
0      1  107.284347  123.819229
1      2  214.523447  267.318463
2      3  327.159934  482.107206
3      4  437.384597  762.756909
4      5  518.389038  997.734857

#plot 
df[['Marketing','Sales']].plot() #ever increasing, non-stationary 
plt.show()

#formal nonstationary test , H0: non-stationary 
import statsmodels.api as sm
print(sm.tsa.stattools.adfuller(df['Marketing'])) # >0.05, accept H0 
print(sm.tsa.stattools.adfuller(df['Sales'])) # >0.05, accept H0 


#Naive OLS - produces strong multicollinearity 
df['const']=1
model1=sm.OLS(endog=df['Sales'],exog=df[['Marketing','const']])
results1=model1.fit()
print(results1.summary())

#differenced time-series regression - multicollinearity  gone 
df['diffS']=df['Sales'].diff()
df['diffM']=df['Marketing'].diff()
df.dropna(inplace=True)
df[['diffS','diffM' ]].plot(kind='line') #stationary 
plt.show()

model2=sm.OLS(endog=df['diffS'].dropna(),exog=df[['diffM','const']].dropna())
results2=model2.fit()
print(results2.summary())

##Test for causality 
statsmodels.tsa.stattools.grangercausalitytests(x, maxlag, addconst=True, verbose=True)[source]
    H0: the time series in the second column, x2, 
    does NOT Granger cause the time series in the first column, x1. 
    Grange causality means that past values of x2 have a statistically 
    significant effect on the current value of x1, 
    taking past values of x1 into account as regressors.
    Parameters:
    x : array, 2d, (nobs,2)
        data for test whether the time series in the second column 
        Granger causes the time series in the first column
    maxlag : integer
        the Granger causality test results are calculated for all lags up to maxlag
    Returns:
    results : dictionary
        all test results, dictionary keys are the number of lags. 
        For each lag the values are a tuple, 
        with the first element a dictionary with teststatistic, pvalues, degrees of freedom,
        the second element are the OLS estimation results for the restricted model, 
        the unrestricted model and the restriction (contrast) matrix 
        for the parameter f_test.

#for lag=1 , H0: Marketing does not cause Sales, <0.05 reject H0 
>>> print(sm.tsa.stattools.grangercausalitytests(df[['Sales','Marketing']].dropna(),1))
Granger Causality
number of lags (no zero) 1
ssr based F test:         F=33.4561 , p=0.0000  , df_denom=71, df_num=1
ssr based chi2 test:   chi2=34.8698 , p=0.0000  , df=1
likelihood ratio test: chi2=28.5705 , p=0.0000  , df=1
parameter F test:         F=33.4561 , p=0.0000  , df_denom=71, df_num=1
{1: ({'ssr_chi2test': (34.86978075633554, 3.5250989086317312e-09, 1), 'lrtest':
(28.570467812774496, 9.034970552654862e-08, 1), 'ssr_ftest': (33.45614099594356,
 1.8100367149360244e-07, 71.0, 1), 'params_ftest': (33.456140995944004, 1.810036
7149357443e-07, 71.0, 1)}, [<statsmodels.regression.linear_model.RegressionResul
tsWrapper object at 0x0000001510F56198>, <statsmodels.regression.linear_model.Re
gressionResultsWrapper object at 0x0000001510F56B38>, array([[0., 1., 0.]])])}

#reverse , H0: sales does not cause Marketing , >0.05, accept H0 
>>> print(sm.tsa.stattools.grangercausalitytests(df[['Marketing','Sales']].dropn
a(),1))

Granger Causality
number of lags (no zero) 1
ssr based F test:         F=0.3057  , p=0.5821  , df_denom=71, df_num=1
ssr based chi2 test:   chi2=0.3186  , p=0.5724  , df=1
likelihood ratio test: chi2=0.3179  , p=0.5729  , df=1
parameter F test:         F=0.3057  , p=0.5821  , df_denom=71, df_num=1
{1: ({'ssr_chi2test': (0.3186090371140572, 0.5724447641509534, 1), 'lrtest': (0.
31792510953391684, 0.5728572543075492, 1), 'ssr_ftest': (0.3056924545283522, 0.5
82072249688844, 71.0, 1), 'params_ftest': (0.30569245452810706, 0.58207224968899
58, 71.0, 1)}, [<statsmodels.regression.linear_model.RegressionResultsWrapper ob
ject at 0x0000001510F56710>, <statsmodels.regression.linear_model.RegressionResu
ltsWrapper object at 0x0000001510F56780>, array([[0., 1., 0.]])])}


#ARIMAX , Sales = y, x= Marketing 

#pandas object must have DatetimeIndex, so convert to ndarray and mention freq
model3=sm.tsa.ARIMA(endog=df['Sales'].values,exog=df[['diffM']].values,order=[1,1,0], freq='M')
results3 = model3.fit(disp=False)
>> results3.summary()
                             ARIMA Model Results
==============================================================================
Dep. Variable:                    D.y   No. Observations:                   65
Model:                 ARIMA(1, 1, 0)   Log Likelihood                -588.110
Method:                       css-mle   S.D. of innovations           2053.061
Date:                Tue, 30 Jan 2018   AIC                           1184.220
Time:                        20:11:53   BIC                           1192.917
Sample:                             1   HQIC                          1187.652

==============================================================================
                 coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
const        451.8275    286.842      1.575      0.120    -110.373    1014.028
x1            -2.9538      2.083     -1.418      0.161      -7.036       1.128
ar.L1.D.y     -0.4590      0.119     -3.854      0.000      -0.692      -0.226
                                    Roots
=============================================================================
                 Real           Imaginary           Modulus         Frequency
-----------------------------------------------------------------------------
AR.1           -2.1786           +0.0000j            2.1786            0.5000
-----------------------------------------------------------------------------

#Plot orignal and fitted values 
df['lagS'] = df['diffS'].shift()
df.dropna(inplace=True)
plt.plot(df['lagS'])  
plt.plot(results3.fittedvalues, color='red')
plt.title('RSS: %.4f'% sum((results3.fittedvalues-df['lagS'])**2))

plt.show()



###Another example - Time Series analysis 
#Example  
import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 
import statsmodels.api as sm 

dft = pd.read_excel(r"data\Nifty-17_Years_Data-V1.xlsx", parseDates=True, index_col=0, header=0, date_parser=lambda x: pd.to_datetime(x, format="%d-%b-%y"))
dft.index
>> df.head()

from pandas.tseries.offsets import *
dft.index.freq = Day() #set freq as D 

import datetime
#For specific exact index for DF , use .loc 
dft['2000-06-01'] #ERROR 
dft[datetime.date(2000, 6, 1)] #equivalent to exact  #ERROR #datetime.date(year, month, day)
#use below 
dft.loc['2000-06-01']
dft.iloc[0]
dft.loc[datetime.date(2000, 6, 1)] 
#for both DF and Series- any partial date string or slice of exact index works 
dft['2000-06-01']             #from 2013-01-01 00:00:00 till upto 2013-01-01 23:59:00
dft['2013']                 #Year based , from 2013-01-01 00:00:00 till upto 2013-03-11 10:39:00
dft['2013-1':'2013-2']      #slice, end inclusive 
dft['2013-1':'2013-2-28']   # stop time that includes all of the times on the last day
dft['2013-1':'2013-2-28 00:00:00'] #exact stop time     
dft[datetime.date(2013, 1, 1):datetime.date(2013,2,28)] #exact start and stop time 
dft[datetime.datetime(2013, 1, 1, 10, 12, 0):datetime.datetime(2013, 2, 28, 10, 12, 0)] #exact start and stop time 
#Note the difference, first one is Series, 2nd one is DF 
>>> dft.loc[datetime.date(2013, 1, 1)]
A    2.375359
Name: 2013-01-01 00:00:00, dtype: float64
>>> dft.loc[[datetime.date(2013, 1, 1)]]
                   A
2013-01-01  2.375359

#Note 
ts[0] #first item , scalar 
#but 
dft[0] #error as for DF, [] includes column label 
dft['Open'] #OK 
#but for slicing , works as it is row slicing 
ts[0:5]
dft[0:5]


#plot 
dft.plot(kind='line', subplots=True)
plt.show()
dft.Close.plot(kind='line')
plt.show()


#complex plot 
#4x4 gridspecs, specification for 0,0 cell , row spanning 3 rows, column spanning 4 columns 
top = plt.subplot2grid((4,4), (0, 0), rowspan=3, colspan=4)
top.plot(dft.index, dft["Close"])
plt.title('Nifty close from 2000 - 2018')

#4x4 gridspecs, specification for 3,0 cell , row spanning 1 rows, column spanning 4 columns 
bottom = plt.subplot2grid((4,4), (3,0), rowspan=1, colspan=4)
bottom.bar(dft.index, dft['Day Wise Variation ( points) '])
plt.title('Nifty Day wise variations ')

plt.show()

#(for Time series, equivalent to aggregation)
#Calculate moving airisages
#window : int,Size of the moving window. 
#This is the number of observations used for calculating the statistic.
dft_r = dft.rolling(30)  #rolling 30 samples 
dir(dft_r)
#plot rolling average 
dft_r.mean()['Open'] #DF 
dft_r.mean().dropna().plot(kind='line') #DF
plt.show()
#
dft_s = dft.ewm(com=0.5)#Returns Exponentially-weighted moving window(EWM) class ,com=decay in terms of center of mass
#
dft_s = dft.expanding(2) #Expanding window, Minimum number of observations in window required to have a value         (otherwise result is NA)
#or downsampling at month 
dft_s = dft.resample('M')
dir(dft_s)
#month value would be mean()
dft_s.mean() #DF 
dft_s['Open'].mean() #Series
dft_s['Open'].agg([np.sum, np.mean, np.std])
dft_s.agg({'Open':'mean', 'Close':'std'})
dft_s.agg({'Open':['mean',np.std], 'Close':['std','sum']})

#KDE plot
dft_s.Close.plot(kind='kde')

#lagplot -Lag plots are used to check if a data set or time series is random. 
#Random data should not exhibit any structure in the lag plot. 
#Non-random structure implies that the underlying data are not random.
from pandas.plotting import lag_plot
lag_plot(df.Close)
plt.show()


##Autocorrelation plots are often used for checking randomness in time series
#If time series is random, such autocorrelations should be near zero for  all time-lag separations(other than lag=0)
from pandas.plotting import autocorrelation_plot
autocorrelation_plot(df.Close)

##Time Series analysis - statsmodel 
import statsmodels.api as sm
import statsmodels.tsa.api as smt
##Checking stationary 
#constant mean
#constant variance
#an autocovariance that does not depend on time
#run plot 
ts = dft.Close 

#clearly shows overall increasing trend 
ts.plot(kind='line')
plt.show()

#further checking of stationary 
#rolling statistics plots - ever increasing 
#and  Dickey-Fuller test - adfuller
#H0: TS is non-stationary


def test_stationarity(timeseries):    
    #Determing rolling statistics
    rolmean = timeseries.rolling(window=12, center=False).mean()
    rolstd = timeseries.rolling(window=12, center=False).std()
    #Plot rolling statistics:
    orig = plt.plot(timeseries, color='blue',label='Original')
    mean = plt.plot(rolmean, color='red', label='Rolling Mean')
    std = plt.plot(rolstd, color='black', label = 'Rolling Std')
    plt.legend(loc='best')
    plt.title('Rolling Mean & Standard Deviation')
    plt.show(block=False)
    #Perform Dickey-Fuller test:
    print('Results of Dickey-Fuller Test:')
    dftest = smt.adfuller(timeseries, autolag='AIC')
    dfoutput = pd.Series(dftest[0:4], index=['Test Statistic','p-value','#Lags Used','Number of Observations Used'])
    for key,value in dftest[4].items():
        dfoutput['Critical Value (%s)'%key] = value
    print(dfoutput)
    

>>> test_stationarity(ts)  
#variation in standard deviation is small, mean is clearly increasing with time 
#p-value>0.05, hence accept H0(=TS is non-stationary)
Results of Dickey-Fuller Test:
Test Statistic                    0.411488
p-value                           0.981920
#Lags Used                       14.000000
Number of Observations Used    4370.000000
Critical Value (10%)             -2.567122
Critical Value (5%)              -2.862202
Critical Value (1%)              -3.431847
dtype: float64


##How to make a Time Series Stationary?
#Reasons for nonstionary 
#1. Trend – varying mean over time. 
#    In this case, average mean increasing over time 
#2. Seasonality – variations at specific time-frames. 
#    eg people might have a tendency to buy cars in a particular month 
#    because of pay increment or festivals.

#First option for reducing increasing trend  - Tranformation 
#eg log, sqrt or cube root to dampen the trend 
#for decreasing trend, exp, square, cube etc 
ts_log = np.log(ts)
plt.plot(ts_log)
plt.show()


##Eliminating Trend and Seasonality
#Differencing – taking the differece with a particular time lag
#Decomposition – modeling both trend and seasonality and removing them from the model.

##Eliminating both Trend and Seasonality - Differencing
ts_log_diff = ts_log - ts_log.shift(1)
#or 
ts_log_diff = ts_log.diff(periods=1) #Periods to shift for forming difference

ts_log_diff.dropna(inplace=True)
>>> test_stationarity(ts_log_diff)
Results of Dickey-Fuller Test:
Test Statistic                -1.445462e+01
p-value                        7.006666e-27
#Lags Used                     1.900000e+01
Number of Observations Used    4.364000e+03
Critical Value (10%)          -2.567123e+00
Critical Value (5%)           -2.862203e+00
Critical Value (1%)           -3.431849e+00
dtype: float64

#Note 2nd differencing is extremly rare , DOn't use 
ts_log_diff2 = ts_log_diff - ts_log_diff.shift(1)
#or 
ts_log_diff2 = ts_log_diff.diff(1) #Note, it is not ts_log.diff(periods=2), which is diff with every 2nd period 

ts_log_diff2.dropna(inplace=True)
>>> test_stationarity(ts_log_diff2)
Results of Dickey-Fuller Test:
Test Statistic                -8.196629e+00
p-value                        7.419305e-13
#Lags Used                     1.300000e+01
Number of Observations Used    1.280000e+02
Critical Value (1%)           -3.482501e+00
Critical Value (10%)          -2.578960e+00
Critical Value (5%)           -2.884398e+00
dtype: float64


##Eliminating both Trend and Seasonality - Decomposing
#In this approach, both trend and seasonality are modeled separately 
#and the remaining part of the series is returned
'''
Arg freq : int, optional
        Frequency of the series. Must be used if x is not a pandas object. 
        Overrides default periodicity of x 
        if x is a pandas object with a timeseries index.
            #freqstr      Seasonal period    # of datapoints for aggregation
            A              1                 aggregate yearly 
            Q              4                 aggregate yearly 
            M              12                aggregate yearly
            W              52                aggregate yearly
            D              7                 aggregate weekly 
            B              5                 aggregate weekly 
            H              24                aggregate daily 
'''

from statsmodels.tsa.seasonal import seasonal_decompose

decomposition = seasonal_decompose(ts_log, freq=7) 
trend = decomposition.trend
seasonal = decomposition.seasonal
residual = decomposition.resid  #we need to work with this series further 
decomposition.plot()
plt.show()

#Get stats 
ts_log_decompose = residual
ts_log_decompose.dropna(inplace=True)
>>> test_stationarity(ts_log_decompose)
Test Statistic                  -18.851623
p-value                           0.000000
#Lags Used                       30.000000
Number of Observations Used    4348.000000
Critical Value (10%)             -2.567124
Critical Value (5%)              -2.862205
Critical Value (1%)              -3.431855
dtype: float64

##Forecasting a Time Series
#Use differencingfor making stationary 

#ACF and PACF plots:
#p – The lag value where the PACF chart crosses the upper confidence interval for the first time. 
#     If you notice closely, in this case p=1.
#q – The lag value where the ACF chart crosses the upper confidence interval for the first time. 
#     If you notice closely, in this case q=1.


#below line must, must not contain NaN 
ts_log_diff.dropna(inplace=True)

fig = plt.figure(figsize=(12,8))
ax1 = fig.add_subplot(211)
sm.graphics.tsa.plot_acf(ts_log_diff, lags=40, ax=ax1,alpha=0.05) #confidence level 95%
ax2 = fig.add_subplot(212)
sm.graphics.tsa.plot_pacf(ts_log_diff, lags=40, ax=ax2,alpha=0.05)
plt.show()

#or 
#x13 - 
import pandas as pd
df = pd.DataFrame(ts_log, index=dft.index)
#Requires x13as.exe in PATH , Only monthly and quarterly periods are supported
#download from https://www.census.gov/srd/www/winx13/winx13_down.html
import statsmodels
res = statsmodels.tsa.x13.x13_arima_select_order(df.resample('M').mean())
>>> res.order
(0, 1, 1)

#or 
ts_log_diff.dropna(inplace=True) #note if input contains nan, Error would happen 
res = sm.tsa.arma_order_select_ic(ts_log_diff, ic=['aic', 'bic'], trend='nc') #nc - no constant term
res.aic_min_order #(p,q) = (3, 2)
res.bic_min_order #(0, 1)
>>> res
{'bic_min_order': (0, 1), 'bic':               0             1             2
0           NaN -24712.161789 -24711.432984
1 -24709.468202 -24709.834026 -24703.079027
2 -24711.557674 -24703.279453 -24696.956015
3 -24703.333590 -24696.489131 -24696.783230
4 -24695.555535 -24687.204379           NaN, 'aic':               0
1             2
0           NaN -24724.933223 -24730.590135
1 -24722.239636 -24728.991176 -24728.621895
2 -24730.714824 -24728.822320 -24728.884599
3 -24728.876458 -24728.417715 -24735.097531
4 -24727.484119 -24725.518680           NaN, 'aic_min_order': (3, 2)}


#Fit now 
#since 1st order differntiation is done, hence d= 1
from statsmodels.tsa.arima_model import ARIMA

fig = plt.figure(figsize=(12,8))
#AR Model
model = ARIMA(ts_log, order=(1, 1, 0))  
results_AR = model.fit(disp=-1)   #disp:If True, convergence information is output.
ax1 = fig.add_subplot(311)
ax1.plot(ts_log_diff)
ax1.plot(results_AR.fittedvalues, color='red')
ax1.set_title('RSS: %.4f'% sum((results_AR.fittedvalues-ts_log_diff)**2))

#MA Model
model = ARIMA(ts_log, order=(0, 1, 1))  
results_MA = model.fit(disp=-1)  
ax2 = fig.add_subplot(312)
ax2.plot(ts_log_diff)
ax2.plot(results_MA.fittedvalues, color='red')
ax2.set_title('RSS: %.4f'% sum((results_MA.fittedvalues-ts_log_diff)**2), x=0.4)

#ARIMA 
model = ARIMA(ts_log, order=(1, 1, 1))  
results_ARIMA = model.fit(disp=-1)  
ax3 = fig.add_subplot(313)
ax3.plot(ts_log_diff)
ax3.plot(results_ARIMA.fittedvalues, color='red') #fittedvalues  is after differencing, d=1
ax3.set_title('RSS: %.4f'% sum((results_ARIMA.fittedvalues-ts_log_diff)**2), x=0.4)

plt.show()

#Note - all below are after differencing d=1
>>> ts_log_diff[1:5]  #with d=1 
Date
2000-06-02    0.029400
2000-06-05    0.010989
2000-06-06    0.012136
2000-06-07    0.006031
Name: Close, dtype: float64
>>> results_ARIMA.fittedvalues[0:4]  #with d=1 
Date
2000-06-02    0.000470
2000-06-05    0.002797
2000-06-06    0.000337
2000-06-07    0.001505
dtype: float64
>>> results_ARIMA.predict(start=1,end=4)  #in place , with d=1 
Date
2000-06-02    0.000470
2000-06-05    0.002797
2000-06-06    0.000337
2000-06-07    0.001505
dtype: float64
#out of sample prediction 
>>> results_ARIMA.predict(start=len(ts_log)-1, end=len(ts_log)+5)
4384    0.001018
4385    0.000623
4386    0.000416
4387    0.000488
4388    0.000463
4389    0.000472
4390    0.000469
dtype: float64

>>> results_ARIMA.forecast(steps=5)[0] #without d=1 , returns forecast,stderr, confInterval
array([9.26534234, 9.26575853, 9.26624702, 9.2667102 , 9.26718224])
>>> ts_log[-1]
9.2647196498149

#get summary 
results_ARIMA.summary()
#predict , next 20 values 
steps=20
predict_arima = results_ARIMA.forecast(steps=steps) #without d=1 , returns forecast,stderr, confInterval




##Taking it back to original scale
index = pd.date_range(ts.index[-1], periods=steps+1)[-steps:]
predictions_ARIMA_log = pd.Series(predict_arima[0], copy=True, index=index)
predictions_ARIMA_diff_orig = pd.Series(results_ARIMA.fittedvalues, copy=True)


#we took a lag by 1  for differencing 
#To undo, first determine the cumulative sum at index 
#add it to first value 
predictions_ARIMA_log_orig = predictions_ARIMA_diff_orig.cumsum() + ts_log.ix[0]


#and then anti-log 
predictions_ARIMA = np.exp(predictions_ARIMA_log)
predicted = np.exp(predictions_ARIMA_log_orig.append(predictions_ARIMA_log) ) 

plt.plot(ts)
plt.plot(predicted)
#use ts[1:] because predictions_ARIMA_log_orig does not initial d samples 
plt.title('RMSE: %.4f'% np.sqrt(sum((np.exp(predictions_ARIMA_log_orig)-ts[1:])**2)/len(ts[1:])))
plt.show()











###statsmodel - sm.tsa - Vector autoregression (VAR) 
#Captures the linear interdependencies among multiple time series(multivariate/ independent variables)
 
#VAR models generalize the univariate autoregressive model (AR model) by allowing 
#for more than one independent variables  

#each variable has an equation explaining its evolution based on its own lags 
#and the lags of the other model variables
     
#Vector Autogressive Processes (VAR)
vector_ar.var_model.VAR(endog[, dates, ...])      Fit VAR(p) process and do lag order selection 
vector_ar.var_model.VARResults(endog, ...[, ...]) Estimate VAR(p) process with fixed number of lags 
vector_ar.dynamic.DynamicVAR(data[, ...])         Estimates time-varying vector autoregression (VAR(p)) 

vector_ar.var_model.VARProcess(coefs, ...[, ...])   Class represents a known VAR(p) process 
vector_ar.irf.IRAnalysis(model[, P, ...])           Impulse response analysis class. 
vector_ar.var_model.FEVD(model[, P, periods])       Compute and plot Forecast error variance decomposition and asymptotic 

  
#Example 
from  statsmodels.tsa.api  import * 
import statsmodels.api as sm

# some example data
import pandas
mdata = sm.datasets.macrodata.load_pandas().data

# prepare the dates index
dates = mdata[['year', 'quarter']].astype(int).astype(str)
quarterly = dates["year"] + "Q" + dates["quarter"]

#dates_from_str(dates)- convert sequence like '1996m1' or '1996Q1' to dates

from statsmodels.tsa.base.datetools import dates_from_str
quarterly = dates_from_str(quarterly)

mdata = mdata[['realgdp','realcons','realinv']]
mdata.index = pandas.DatetimeIndex(quarterly)
#to remove seasonality, take log and then 1st order diff - creates a stationary series 
data = np.log(mdata).diff().dropna()  #create 1st order difference 

# make a VAR model
model = VAR(data) #passed time series must be  stationary

#To actually do the estimation, call the fit method with the desired lag order
>>> results = model.fit(2) #lag=2

>>> results.summary() #L1= lag 1, etc 

  Summary of Regression Results
==================================
Model:                         VAR
Method:                        OLS
Date:           Fri, 08, Jul, 2011
Time:                     11:30:22
--------------------------------------------------------------------
No. of Equations:         3.00000    BIC:                   -27.5830
Nobs:                     200.000    HQIC:                  -27.7892
Log likelihood:           1962.57    FPE:                7.42129e-13
AIC:                     -27.9293    Det(Omega_mle):     6.69358e-13
--------------------------------------------------------------------
Results for equation realgdp
==============================================================================
                 coefficient       std. error           t-stat            prob
------------------------------------------------------------------------------
const               0.001527         0.001119            1.365           0.174
L1.realgdp         -0.279435         0.169663           -1.647           0.101
L1.realcons         0.675016         0.131285            5.142           0.000
L1.realinv          0.033219         0.026194            1.268           0.206
L2.realgdp          0.008221         0.173522            0.047           0.962
L2.realcons         0.290458         0.145904            1.991           0.048
L2.realinv         -0.007321         0.025786           -0.284           0.777
==============================================================================

Results for equation realcons
==============================================================================
                 coefficient       std. error           t-stat            prob
------------------------------------------------------------------------------
const               0.005460         0.000969            5.634           0.000
L1.realgdp         -0.100468         0.146924           -0.684           0.495
L1.realcons         0.268640         0.113690            2.363           0.019
L1.realinv          0.025739         0.022683            1.135           0.258
L2.realgdp         -0.123174         0.150267           -0.820           0.413
L2.realcons         0.232499         0.126350            1.840           0.067
L2.realinv          0.023504         0.022330            1.053           0.294
==============================================================================

Results for equation realinv
==============================================================================
                 coefficient       std. error           t-stat            prob
------------------------------------------------------------------------------
const              -0.023903         0.005863           -4.077           0.000
L1.realgdp         -1.970974         0.888892           -2.217           0.028
L1.realcons         4.414162         0.687825            6.418           0.000
L1.realinv          0.225479         0.137234            1.643           0.102
L2.realgdp          0.380786         0.909114            0.419           0.676
L2.realcons         0.800281         0.764416            1.047           0.296
L2.realinv         -0.124079         0.135098           -0.918           0.360
==============================================================================

Correlation matrix of residuals
             realgdp  realcons   realinv
realgdp     1.000000  0.603316  0.750722
realcons    0.603316  1.000000  0.131951
realinv     0.750722  0.131951  1.000000

#still corelated 

##Plotting on VARResults 
plot()                                      Plot input time series 
plot_acorr([nlags, linewidth])              Plot theoretical autocorrelation function 
plot_forecast(steps[, alpha, plot_stderr])  Plot forecast 
plot_sample_acorr([nlags, linewidth])       Plot theoretical autocorrelation function 
plotsim([steps])                            Plot a simulation from the VAR(p) process for the desired number of steps 


#Plot input time series
results.plot()
#Plotting time series autocorrelation function:
results.plot_acorr()

#Lag order selection
#Choice of lag order can be a difficult problem. 
>>> model.select_order(15) #Returns:  selections : dict {info_crit -> selected_order}
                 VAR Order Selection
======================================================
            aic          bic          fpe         hqic
------------------------------------------------------
0        -27.70       -27.65    9.358e-13       -27.68
1        -28.02      -27.82*    6.745e-13      -27.94*
2        -28.03       -27.66    6.732e-13       -27.88
3       -28.04*       -27.52   6.651e-13*       -27.83

#When calling the fit function, one can pass a maximum number of lags 
#and the order criterion to use for order selection:
results = model.fit(maxlags=15, ic='aic')

##few imp attributes of VARResults
k_ar : int,Order of VAR process
k_trend : int
llf
model
names
neqs : int,Number of variables (equations)
nobs : int
n_totobs : int
params

>>> results.k_ar
3
>>> results.k_trend
1

##Forecasting
lag_order = results.k_ar  #p=k_ar of VAR(p), in results, it also called k 
#Produce linear minimum MSE forecasts for desired number of steps ahead, using prior values y
results.forecast(data.values[-lag_order:], 5) #y,steps 
results.plot_forecast(steps=15)

#other forcasting 
VARResults.forecast_interval(y, steps, alpha=0.05)
    Construct forecast interval estimates assuming the y are Gaussian
    for desired number of steps ahead, using prior values y
    Returns:
        (lower, mid, upper) : (ndarray, ndarray, ndarray) 
VARResults.forecast_cov(steps=1)
    Compute forecast covariance matrices for desired number of steps
    Parameters:
    steps : int 
    Returns:
    covs : ndarray (steps x k x k) 



#Impulse Response Analysis
##Impulse responses are of interest in econometric studies: 
#they are the estimated responses to a unit impulse(step function) in one of the variables
#and impact to other variables 
irf = results.irf(periods=10)
#methods on statsmodels.tsa.vector_ar.irf.IRAnalysis
irf([periods, var_decomp, var_order])        Analyze impulse responses to shocks in system 
irf_errband_mc([orth, repl, T, signif, ...]) Compute Monte Carlo integrated error bands assuming normally 
irf_resim([orth, repl, T, seed, burn, cum])  Simulates impulse response function, returning an array  
plot([orth, impulse, response, signif, ...])     
    Plot impulse responses 
plot_cum_effects([orth, impulse, response, ...]) 
    Plot cumulative impulse response functions 
    orth : bool, default False
        Compute orthogonalized impulse responses
    impulse : string or int
        variable providing the impulse
    response : string or int
        variable affected by the impulse
    signif : float (0 < signif < 1)
        Significance level for error bars, defaults to 95% CI
    subplot_params : dict
        To pass to subplot plotting funcions. 
        Example: if fonts are too big, pass {'fontsize' : 8} 
    plot_params : dict
    plot_stderr: bool, default True
        Plot standard impulse response error bands

#Draw 'variable providing the impulse' to 'variable affected by the impulse'
#plot with error bands 
irf.plot(orth=False)
#Note the plot function is flexible and can plot only variables of interest if so desired:
irf.plot(impulse='realgdp')
#The cumulative effects \Psi_n = \sum_{i=0}^n \Phi_i can be plotted with the long run effects as follows:
irf.plot_cum_effects(orth=False)


##Forecast Error Variance Decomposition (FEVD)
#Forecast errors of component j on k in an i-step ahead forecast 
#can be decomposed using the orthogonalized impulse responses

#The variance decomposition indicates the amount of information each variable 
#contributes to the other variables in the autoregression
fevd = results.fevd(periods=5)
#Methods on statsmodels.tsa.vector_ar.var_model.FEVD
cov()                    Compute asymptotic standard errors 
plot([periods, figsize]) Plot graphical display of FEVD 
summary()                Summary

#Example 
>>> fevd.summary() 
#ie 0th time, unit impulse on one variable, 
#then till 4th time, how unit value is distribute on other variables 
FEVD for realgdp
      realgdp  realcons   realinv
0    1.000000  0.000000  0.000000
1    0.864889  0.129253  0.005858
2    0.816725  0.177898  0.005378
3    0.793647  0.197590  0.008763
4    0.777279  0.208127  0.014594

FEVD for realcons
      realgdp  realcons   realinv
0    0.359877  0.640123  0.000000
1    0.358767  0.635420  0.005813
2    0.348044  0.645138  0.006817
3    0.319913  0.653609  0.026478
4    0.317407  0.652180  0.030414

FEVD for realinv
      realgdp  realcons   realinv
0    0.577021  0.152783  0.270196
1    0.488158  0.293622  0.218220
2    0.478727  0.314398  0.206874
3    0.477182  0.315564  0.207254
4    0.466741  0.324135  0.209124

#or plot 
results.fevd(20).plot()


#Statistical test - Granger causality
#To find  whether a variable or group of variables is 'causal'
#(ie acting as a cause) for another variable

#In the context of VAR models, 
#one can say that a set of variables are Granger-causal  within one of the variables

#The VARResults object has the test_causality method for performing 
#either a Wald (\chi^2) test or an F-test.

#if a signal X1 "Granger-causes" (or "G-causes") a signal X2, 
#then past values of X1 should contain information that helps predict X2 
#above and beyond the information contained in past values of X2 alone.


#H0: ['realinv', 'realcons'] is not causal with realgdp
#here reject H0
>>> results.test_causality('realgdp', ['realinv', 'realcons'], kind='f') #kind : {'f', 'wald'}
Granger causality f-test
=============================================================
   Test statistic   Critical Value          p-value        df
-------------------------------------------------------------
         6.999888         2.114554            0.000  (6, 567)
=============================================================
H_0: ['realinv', 'realcons'] do not Granger-cause realgdp
Conclusion: reject H_0 at 5.00% significance level

{'conclusion': 'reject',
 'crit_value': 2.1145543864562706,
 'df': (6, 567),
 'pvalue': 3.3805963773886478e-07,
 'signif': 0.05,
 'statistic': 6.9998875522543473}
 
 
##Test white noise assumption- ACF plot with error bounds 
#Sample (Y) autocorrelations are compared with the standard 2 / \sqrt(T) bounds
>>> results.test_whiteness(nlags=10, plot=True, linewidth=8)
FAIL: Some autocorrelations exceed 0.1418 bound. See plot
>>> plt.show()

##Test assumption of normal-distributed errors using Jarque-Bera-style omnibus Chi^2 test
#H0: normal 
>>> results.test_normality()
Normality skew/kurtosis Chi^2-test
=======================================================
   Test statistic   Critical Value          p-value  df
-------------------------------------------------------
        17.991533        12.591587            0.006   6
=======================================================
H_0: data generated by normally-distributed process
Conclusion: reject H_0 at 5.00% significance level
{'conclusion': 'reject', 'statistic': 17.991532823743086, 'pvalue': 0.0062533898
6501885, 'signif': 0.05, 'crit_value': 12.591587243743977, 'df': 6}








###statsmodel - sm.tsa  - Dynamic Vector Autoregressions


#To estimate a moving-window regression on time series data 
#for the purposes of making forecasts throughout the data sample. 

#For example, we may wish to produce the series of 2-step-ahead forecasts produced 
#by a VAR(p) model estimated at each point in time.

np.random.seed(1)
import pandas.util.testing as ptest
ptest.N = 500
data = ptest.makeTimeDataFrame().cumsum(0) #columnwise 
>>> data.head()
                   A         B         C         D
2000-01-03  1.624345 -1.719394 -0.153236  1.301225
2000-01-04  1.012589 -1.662273 -2.585745  0.988833
2000-01-05  0.484417 -2.461821 -2.077760  0.717604
2000-01-06 -0.588551 -2.753416 -2.401793  2.580517
2000-01-07  0.276856 -3.012398 -3.912869  1.937644

>>> var = DynamicVAR(data, lag_order=2, window_type='expanding') # {'expanding', 'rolling'}
#returns as pandas.Panel 
#Methods of DynamicVAR are 
T()                             Number of time periods in results 
coefs()                         Return dynamic regression coefficients as WidePanel 
equations()  
forecast([steps])               Produce dynamic forecast 
plot_forecast([steps, figsize]) Plot h-step ahead forecasts against actual realizations of time series. 
r2()                            Returns the r-squared values. 
resid() 


#The estimated coefficients for the dynamic model are returned 
#as a pandas.WidePanel object - stored as 3-dimensional array
#dimensions are items,major_axis,minor_axis for axis=0,1,2

#for example, all of the model coefficients by equation or by date

>>> var.coefs
<class 'pandas.core.panel.WidePanel'>
Dimensions: 9 (items) x 489 (major) x 4 (minor)
Items: L1.A to intercept
Major axis: 2000-01-18 00:00:00 to 2001-11-30 00:00:00
Minor axis: A to D

# all estimated coefficients for equation A
>>> var.coefs.minor_xs('A').info()
Index: 489 entries , 2000-01-18 00:00:00 to 2001-11-30 00:00:00
Data columns:
L1.A         489  non-null values
L1.B         489  non-null values
L1.C         489  non-null values
L1.D         489  non-null values
L2.A         489  non-null values
L2.B         489  non-null values
L2.C         489  non-null values
L2.D         489  non-null values
intercept    489  non-null values
dtype: float64(9)

# coefficients on 11/30/2001
>>> var.coefs.major_xs(datetime(2001, 11, 30)).T
             A              B              C              D
L1.A         0.9567         -0.07389       0.0588         -0.02848
L1.B         -0.00839       0.9757         -0.004945      0.005938
L1.C         -0.01824       0.1214         0.8875         0.01431
L1.D         0.09964        0.02951        0.05275        1.037
L2.A         0.02481        0.07542        -0.04409       0.06073
L2.B         0.006359       0.01413        0.02667        0.004795
L2.C         0.02207        -0.1087        0.08282        -0.01921
L2.D         -0.08795       -0.04297       -0.06505       -0.06814
intercept    0.07778        -0.283         -0.1009        -0.6426


#Dynamic forecasts for a given number of steps ahead can be produced 
#using the forecast function and return a pandas.DataFrame object:
>>> var.forecast(steps=2)
                       A              B              C              D
<snip>
2001-11-23 00:00:00    -6.661         43.18          33.43          -23.71
2001-11-26 00:00:00    -5.942         43.58          34.04          -22.13
2001-11-27 00:00:00    -6.666         43.64          33.99          -22.85
2001-11-28 00:00:00    -6.521         44.2           35.34          -24.29
2001-11-29 00:00:00    -6.432         43.92          34.85          -26.68
2001-11-30 00:00:00    -5.445         41.98          34.87          -25.94


#The forecasts can be visualized using plot_forecast:
>>> var.plot_forecast(2)







###statsmodel - sm.tsa - State Space Methods  
#http://www.statsmodels.org/dev/statespace.html 

#Linear Gaussian state space model is technique involving 
#state equation, Observation equation involving states and initial states 

#state space methods offer a unified approach to a wide range of
#models and techniques: dynamic regression, ARIMA, UC models,
#latent variable models, spline-fitting and many ad-hoc filters

#state space model is linear and Gaussian
#therefore properties and results of multivariate normal distribution apply;
• state vector evolves as a VAR(1) process;
• system matrices usually contain unknown parameters;
• estimation has therefore two aspects:
    ◦ measuring the unobservable state (prediction, filtering and smoothing);
    ◦ estimation of unknown parameters (maximum likelihood estimation);


##Seasonal Autoregressive Integrated Moving-Average with eXogenous regressors (SARIMAX)
#Multivariate 
sarimax.SARIMAX(endog[, exog, order, ...])        Seasonal AutoRegressive Integrated Moving Average with eXogenous regressors 
sarimax.SARIMAXResults(model, params, ...[, ...]) Class to hold results from fitting an SARIMAX model. 

# Load the statsmodels api
import statsmodels.api as sm

# Load your dataset
df  = pd.read_csv('your/dataset/here.csv')

# We could fit an AR(2) model, described above
mod_ar2 = sm.tsa.SARIMAX(endog=df.COLUMN1, order=(2,0,0))
# Note that mod_ar2 is an instance of the SARIMAX class

#Can give Multivariate(many exog) dependency of endog - X portion of ARIMAX 
mod_ar2 = sm.tsa.SARIMAX(endog=df.COLUMN1, exog=df['COL2','COL3'], order=(2,0,0))
 

# Fit the model via maximum likelihood
res_ar2 = mod_ar2.fit()
# Note that res_ar2 is an instance of the SARIMAXResults class

# Show the summary of results
print(res_ar2.summary())

# We could also fit a more complicated model with seasonal components.
# As an example, here is an SARIMA(1,1,1) x (0,1,1,4):
mod_sarimax = sm.tsa.SARIMAX(endog, order=(1,1,1),
                             seasonal_order=(0,1,1,4))
res_sarimax = mod_sarimax.fit()

# Show the summary of results
print(res_sarimax.summary())

    
##details
class statsmodels.tsa.statespace.sarimax.SARIMAX(endog, exog=None, 
            order=(1, 0, 0), seasonal_order=(0, 0, 0, 0), 
            trend=None, measurement_error=False, time_varying_regression=False, 
            mle_regression=True, simple_differencing=False, 
            enforce_stationarity=True, enforce_invertibility=True, 
            hamilton_representation=False, **kwargs)
    endog : array_like
        The observed time-series process y
    exog : array_like, optional
        Array of exogenous regressors, shaped nobs x k.
    order : iterable or iterable of iterables, optional
        The (p,d,q) order of the model 
    seasonal_order : iterable, optional
        The (P,D,Q,s) order of the seasonal component of the model for the AR parameters, 
        differences, MA parameters, and periodicity
        s is an integer giving the periodicity (number of periods in season), 
        often it is 4 for quarterly data or 12 for monthly data    
    trend : str{'n','c','t','ct'} or iterable, optional
        Parameter controlling the deterministic trend polynomial A(t). 
        Can be specified as a string where 'c' indicates a constant 
        (i.e. a degree zero component of the trend polynomial), 
        't' indicates a linear trend with time, 
        and 'ct' is both. 
        Can also be specified as an iterable defining the polynomial as in numpy.poly1d, 
        where [1,1,0,1] would denote a + bt + ct^3
    measurement_error : boolean, optional
        Whether or not to assume the endogenous observations endog were measured 
        with error. Default is False.
    time_varying_regression : boolean, optional
        Used when an explanatory variables, exog, are provided provided 
        to select whether or not coefficients on the exogenous regressors 
        are allowed to vary over time. Default is False.
    mle_regression : boolean, optional
        Whether or not to use estimate the regression coefficients 
        for the exogenous variables as part of maximum likelihood estimation 
        or through the Kalman filter (i.e. recursive least squares). 
        If time_varying_regression is True, this must be set to False. 
        Default is True.
    #Attributes
    polynomial_ar (array)       Array containing autoregressive lag polynomial coefficients, ordered from lowest degree to highest. Initialized with ones, unless a coefficient is constrained to be zero (in which case it is zero). 
    polynomial_ma (array)       Array containing moving average lag polynomial coefficients, ordered from lowest degree to highest. Initialized with ones, unless a coefficient is constrained to be zero (in which case it is zero). 
    polynomial_seasonal_ar      (array) Array containing seasonal moving average lag polynomial coefficients, ordered from lowest degree to highest. Initialized with ones, unless a coefficient is constrained to be zero (in which case it is zero). 
    polynomial_seasonal_ma      (array) Array containing seasonal moving average lag polynomial coefficients, ordered from lowest degree to highest. Initialized with ones, unless a coefficient is constrained to be zero (in which case it is zero). 
    polynomial_trend            (array) Array containing trend polynomial coefficients, ordered from lowest degree to highest. Initialized with ones, unless a coefficient is constrained to be zero (in which case it is zero). 
    k_ar (int)                  Highest autoregressive order in the model, zero-indexed. 
    k_ar_params (int)           Number of autoregressive parameters to be estimated. 
    k_diff (int)                Order of intergration. 
    k_ma (int)                  Highest moving average order in the model, zero-indexed. 
    k_ma_params (int)           Number of moving average parameters to be estimated. 
    seasonal_periods            (int) Number of periods in a season. 
    k_seasonal_ar               (int) Highest seasonal autoregressive order in the model, zero-indexed. 
    k_seasonal_ar_params        (int) Number of seasonal autoregressive parameters to be estimated. 
    k_seasonal_diff             (int) Order of seasonal intergration. 
    k_seasonal_ma (int)         Highest seasonal moving average order in the model, zero-indexed. 
    k_seasonal_ma_params        (int) Number of seasonal moving average parameters to be estimated. 
    k_trend (int)               Order of the trend polynomial plus one (i.e. the constant polynomial would have k_trend=1). 
    k_exog (int)                Number of exogenous regressors. 
    update(params[, transformed, complex_step])      Update the parameters of the model 
    fit([start_params, transformed, cov_type, ...])  Fits the model by maximum likelihood via Kalman filter. 
    hessian(params, *args, **kwargs)                 Hessian matrix of the likelihood function, evaluated at the given 
    impulse_responses(params[, steps, impulse, ...]) Impulse response function 
#few Imp Methods 
SARIMAX.fit(start_params=None, transformed=True, cov_type='opg', 
        cov_kwds=None, method='lbfgs', maxiter=50, full_output=1, 
        disp=5, callback=None, return_params=False, optim_score=None, 
        optim_complex_step=None, optim_hessian=None, **kwargs)
    Fits the model by maximum likelihood via Kalman filter.
    Parameters:
    start_params : array_like, optional
        Initial guess of the solution for the loglikelihood maximization. 
        If None, the default is given by Model.start_params.
    transformed : boolean, optional
        Whether or not start_params is already transformed. Default is True.
    cov_type : str, optional
        The cov_type keyword governs the method for calculating 
        the covariance matrix of parameter estimates. Can be one of:
        •'opg' for the outer product of gradient estimator
        •'oim' for the observed information matrix estimator, calculated using the method of Harvey (1989)
        •'approx' for the observed information matrix estimator, calculated using a numerical approximation of the Hessian matrix.
        •'robust' for an approximate (quasi-maximum likelihood) covariance matrix that may be valid even in the presense of some misspecifications. Intermediate calculations use the 'oim' method.
        •'robust_approx' is the same as 'robust' except that the intermediate calculations use the 'approx' method.
        •'none' for no covariance matrix calculation.
    cov_kwds : dict or None, optional
        A dictionary of arguments affecting covariance matrix computation.
        opg, oim, approx, robust, robust_approx
        •'approx_complex_step' : boolean, optional - If True, numerical approximations are computed using complex-step methods. If False, numerical approximations are computed using finite difference methods. Default is True.
        •'approx_centered' : boolean, optional - If True, numerical approximations computed using finite difference methods use a centered approximation. Default is False.
    method : str, optional
        The method determines which solver from scipy.optimize is used, and it can be chosen from among the following strings:
        •'newton' for Newton-Raphson, 'nm' for Nelder-Mead
        •'bfgs' for Broyden-Fletcher-Goldfarb-Shanno (BFGS)
        •'lbfgs' for limited-memory BFGS with optional box constraints
        •'powell' for modified Powell's method
        •'cg' for conjugate gradient
        •'ncg' for Newton-conjugate gradient
        •'basinhopping' for global basin-hopping solver
        The explicit arguments in fit are passed to the solver, with the exception of the basin-hopping solver. Each solver has several optional arguments that are not the same across solvers. See the notes section below (or scipy.optimize) for the available arguments and for the list of explicit arguments that the basin-hopping solver supports.
    maxiter : int, optional
        The maximum number of iterations to perform.
    full_output : boolean, optional
        Set to True to have all available output in the Results object's mle_retvals attribute. The output is dependent on the solver. See LikelihoodModelResults notes section for more information.
    disp : boolean, optional
        Set to True to print convergence messages.
    callback : callable callback(xk), optional
        Called after each iteration, as callback(xk), where xk is the current parameter vector.
    return_params : boolean, optional
        Whether or not to return only the array of maximizing parameters. Default is False.
    optim_score : {'harvey', 'approx'} or None, optional
        The method by which the score vector is calculated. 'harvey' uses the method from Harvey (1989), 'approx' uses either finite difference or complex step differentiation depending upon the value of optim_complex_step, and None uses the built-in gradient approximation of the optimizer. Default is None. This keyword is only relevant if the optimization method uses the score.
    optim_complex_step : bool, optional
        Whether or not to use complex step differentiation when approximating the score; if False, finite difference approximation is used. Default is True. This keyword is only relevant if optim_score is set to 'harvey' or 'approx'.
    optim_hessian : {'opg','oim','approx'}, optional
        The method by which the Hessian is numerically approximated. 'opg' uses outer product of gradients, 'oim' uses the information matrix formula from Harvey (1989), and 'approx' uses numerical approximation. This keyword is only relevant if the optimization method uses the Hessian matrix.
    **kwargs
        Additional keyword arguments to pass to the optimizer.
 
 
class statsmodels.tsa.statespace.sarimax.SARIMAXResults(model, params, filter_results, cov_type='opg', **kwargs)[source]
    Class to hold results from fitting an SARIMAX model.
    aic()       (float) Akaike Information Criterion 
    arfreq()    (array) Frequency of the roots of the reduced form autoregressive 
    arparams()  (array) Autoregressive parameters actually estimated in the model. 
    arroots()   (array) Roots of the reduced form autoregressive lag polynomial 
    bic()       (float) Bayes Information Criterion 
    bse()  
    conf_int([alpha, cols, method])         Returns the confidence interval of the fitted parameters. 
    cov_params([r_matrix, column, scale, cov_p, ...])   Returns the variance/covariance matrix. 
    cov_params_approx() (array)             The variance / covariance matrix. Computed using the numerical 
    cov_params_oim() (array)                The variance / covariance matrix. Computed using the method 
    cov_params_opg() (array)                The variance / covariance matrix. Computed using the outer 
    cov_params_robust() (array)             The QMLE variance / covariance matrix. Alias for 
    cov_params_robust_approx() (array)      The QMLE variance / covariance matrix. Computed using the 
    cov_params_robust_oim() (array)         The QMLE variance / covariance matrix. Computed using the 
    f_test(r_matrix[, cov_p, scale, invcov]) Compute the F-test for a joint linear hypothesis. 
    fittedvalues() (array)                  The predicted values of the model. An (nobs x k_endog) array. 
    forecast([steps])                       Out-of-sample forecasts 
    get_forecast([steps])                   Out-of-sample forecasts 
    get_prediction([start, end, dynamic, exog])     In-sample prediction and out-of-sample forecasting 
    hqic() (float)                              Hannan-Quinn Information Criterion 
    impulse_responses([steps, impulse, ...])    Impulse response function 
    initialize(model, params, **kwd)  
    llf()               (float) The value of the log-likelihood function evaluated at params. 
    llf_obs()           float) The value of the log-likelihood function evaluated at params. 
    load(fname)         load a pickle, (class method) 
    loglikelihood_burn()    (float) The number of observations during which the likelihood is not 
    mafreq() (array)        Frequency of the roots of the reduced form moving average 
    maparams()              (array) Moving average parameters actually estimated in the model. 
    maroots()               (array) Roots of the reduced form moving average lag polynomial 
    normalized_cov_params()  
    plot_diagnostics([variable, lags, fig, figsize])    Diagnostic plots for standardized residuals of one endogenous variable 
    predict([start, end, dynamic])      In-sample prediction and out-of-sample forecasting 
    pvalues() (array)                   The p-values associated with the z-statistics of the 
    remove_data()               remove data arrays, all nobs arrays from result and model 
    resid() (array)             The model residuals. An (nobs x k_endog) array. 
    save(fname[, remove_data])  save a pickle of this instance 
    simulate(nsimulations[, measurement_shocks, ...]) Simulate a new time series following the state space model 
    summary([alpha, start])     Summarize the Model 
    t_test(r_matrix[, cov_p, scale, use_t])     Compute a t-test for a each linear hypothesis of the form Rb = q 
    test_heteroskedasticity(method[, ...])      Test for heteroskedasticity of standardized residuals 
    test_normality(method)                      Test for normality of standardized residuals. 
    test_serial_correlation(method[, lags])     Ljung-box test for no serial correlation of standardized residuals 
    tvalues()                                   Return the t-statistic for a given parameter estimate. 
    wald_test(r_matrix[, cov_p, scale, invcov, ...]) Compute a Wald-test for a joint linear hypothesis. 
    wald_test_terms([skip_single, ...])         Compute a sequence of Wald tests for terms over multiple columns 
    zvalues() (array)                   The z-statistics for the coefficients. 


SARIMAXResults.simulate(nsimulations, measurement_shocks=None, 
        state_shocks=None, initial_state=None)
    Simulate a new time series following the state space model
    Parameters:
    nsimulations : int
        The number of observations to simulate. 
        If the model is time-invariant this can be any number. 
        If the model is time-varying, 
        then this number must be less than or equal to the number
    Returns:
    simulated_obs : array
        An (nsimulations x k_endog) array of simulated observations.
 
 
SARIMAXResults.summary(alpha=0.05, start=None)[source]
    Summarize the Model
    Parameters:
    alpha : float, optional
        Significance level for the confidence intervals. Default is 0.05.
 
 
 
SARIMAXResults.predict(start=None, end=None, dynamic=False, **kwargs)
    In-sample prediction and out-of-sample forecasting
    Parameters:
    start : int, str, or datetime, optional
        Zero-indexed observation number at which to start forecasting, 
        i.e., the first forecast is start. 
        Can also be a date string to parse or a datetime type. 
        Default is the the zeroth observation.
    end : int, str, or datetime, optional
        Zero-indexed observation number at which to end forecasting, 
        i.e., the last forecast is end. 
        Can also be a date string to parse or a datetime type. 
        However, if the dates index does not have a fixed frequency, 
        end must be an integer index if you want out of sample prediction. 
        Default is the last observation in the sample.
    dynamic : boolean, int, str, or datetime, optional
        Integer offset relative to start at which to begin dynamic prediction
    Returns statsmodels.tsa.statespace.mlemodel.PredictionResults
    Have attributes 
    ['conf_int', 'df', 'dist', 'dist_args', 'link', 'linpred', 'model', 
    'predicted_mean', 'prediction_results', 'row_labels', 'se_mean', 'se_obs', 'summary_frame',
    't_test', 'tvalues', 'var_pred_mean', 'var_resid']
    
    
    
SARIMAXResults.impulse_responses(steps=1, impulse=0, 
            orthogonalized=False, cumulative=False, **kwargs)
    Impulse response function
    Parameters:
    steps : int, optional
        The number of steps for which impulse responses are calculated. 
        Default is 1. Note that the initial impulse is not counted as a step, so if steps=1, the output will have 2 entries.
    impulse : int or array_like
        If an integer, the state innovation to pulse; 
        must be between 0 and k_posdef-1.
        Alternatively, a custom impulse vector may be provided; 
        must be shaped k_posdef x 1.
        k_posdef is the same as in the state space model.
    orthogonalized : boolean, optional
        Whether or not to perform impulse using orthogonalized innovations. 
        Note that this will also affect custum impulse vectors. Default is False.
    cumulative : boolean, optional
        Whether or not to return cumulative impulse responses. D
        efault is False.
    Returns:
        impulse_responses : array
            Responses for each endogenous variable due to the impulse 
            given by the impulse argument. A (steps + 1 x k_endog) array.
 
 
##Regression diagnostics
MLEResults.test_normality(method)[source]
    Test for normality of standardized residuals.
    H0: normal 
    Null hypothesis is normality.
    Parameters:
        method : string {'jarquebera'} or None
 
MLEResults.test_heteroskedasticity(method, alternative='two-sided', use_f=True)[source]
    The null hypothesis is of no heteroskedasticity. 
    That means different things depending on which alternative is selected:
    •Increasing: Null hypothesis is that the variance is not increasing throughout the sample; that the sum-of-squares in the later subsample is not greater than the sum-of-squares in the earlier subsample.
    •Decreasing: Null hypothesis is that the variance is not decreasing throughout the sample; that the sum-of-squares in the earlier subsample is not greater than the sum-of-squares in the later subsample.
    •Two-sided: Null hypothesis is that the variance is not changing throughout the sample. Both that the sum-of-squares in the earlier subsample is not greater than the sum-of-squares in the later subsample and that the sum-of-squares in the later subsample is not greater than the sum-of-squares in the earlier subsample.
    Parameters:
    method : string {'breakvar'} or None
    alternative : string, 'increasing', 'decreasing' or 'two-sided'
    use_f : boolean, optional
        Whether or not to compare against the asymptotic distribution (chi-squared) or the approximate small-sample distribution (F). Default is True (i.e. default is to compare against an F distribution).
    Returns:
    output : array
        An array with (test_statistic, pvalue) for each endogenous variable. 
        The array is then sized (k_endog, 2). 


MLEResults.test_serial_correlation(method, lags=None)[source]
    Ljung-box test for no serial correlation of standardized residuals
    Null hypothesis is no serial correlation.
    Parameters:
        method : string {'ljungbox','boxpierece'} or None
        lags : None, int or array_like
            If lags is an integer then this is taken to be the largest lag 
            that is included, 
            the test result is reported for all smaller lag length. 
            If lags is a list or array, 
            then all lags are included up to the largest lag in the list, 
            however only the tests for the lags in the list are reported. 
            If lags is None, then the default maxlag is 12*(nobs/100)^{1/4}
    Returns:
    output : array
        An array with (test_statistic, pvalue) for each endogenous variable 
        and each lag. The array is then sized (k_endog, 2, lags). 
    
 
SARIMAXResults.plot_diagnostics(variable=0, lags=10, fig=None, figsize=None)
    Diagnostic plots for standardized residuals of one endogenous variable
    Parameters:
    variable : integer, optional
        Index of the endogenous variable for which the diagnostic plots should be created. 
        Default is 0.
    lags : integer, optional
        Number of lags to include in the correlogram. Default is 10.
    fig : Matplotlib Figure instance, optional
        If given, subplots are created in this figure instead of in a new figure. 
        Note that the 2x2 grid will be created in the provided figure 
        using fig.add_subplot().
    figsize : tuple, optional
        If a figure is created, this argument allows specifying a size. 
        The tuple is (width, height).

 
 
 
##Example of SARIMAX 
 

%matplotlib inline
import numpy as np
import pandas as pd
from scipy.stats import norm
import statsmodels.api as sm
import matplotlib.pyplot as plt
from datetime import datetime
import requests
from io import BytesIO


##Examples - ARIMA Example 1: Arima
#1.ARIMA(1,1,1) model on the U.S. Wholesale Price Index (WPI) dataset.

# Dataset
wpi1 = requests.get('http://www.stata-press.com/data/r12/wpi1.dta').content
data = pd.read_stata(BytesIO(wpi1))
data.index = data.t
>>> data.head()
                  wpi          t    ln_wpi
t
1960-01-01  30.700001 1960-01-01  3.424263
1960-04-01  30.799999 1960-04-01  3.427515
1960-07-01  30.700001 1960-07-01  3.424263
1960-10-01  30.700001 1960-10-01  3.424263
1961-01-01  30.799999 1961-01-01  3.427515

# Fit the model
#order =(AR specification, Integration order, MA specification). 
#The integration order must be an integer,
#In a pure ARMA model where the underlying data is already stationary, Integration order would be 0).
mod = sm.tsa.statespace.SARIMAX(data['wpi'], trend='c', order=(1,1,1))
res = mod.fit(disp=False)
>>> print(res.summary())

  Statespace Model Results                           
==============================================================================
Dep. Variable:                    wpi   No. Observations:                  124
Model:               SARIMAX(1, 1, 1)   Log Likelihood                -134.983
Date:                Tue, 28 Feb 2017   AIC                            277.965
Time:                        21:34:51   BIC                            289.246
Sample:                    01-01-1960   HQIC                           282.548
                         - 10-01-1990                                         
Covariance Type:                  opg                                         
==============================================================================
                 coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
intercept      0.1050      0.068      1.546      0.122      -0.028       0.238
ar.L1          0.8740      0.054     16.178      0.000       0.768       0.980
ma.L1         -0.4206      0.100     -4.191      0.000      -0.617      -0.224
sigma2         0.5226      0.053      9.926      0.000       0.419       0.626
===================================================================================
Ljung-Box (Q):                       36.96   Jarque-Bera (JB):                10.15
Prob(Q):                              0.61   Prob(JB):                         0.01
Heteroskedasticity (H):              17.00   Skew:                             0.27
Prob(H) (two-sided):                  0.00   Kurtosis:                         4.30
===================================================================================

Warnings:
[1] Covariance matrix calculated using the outer product of gradients (complex-step).

#Thus the maximum likelihood estimates imply that for the process above, we have:
Δy(t) =0.1050+0.8740Δy(t−1) −0.4206ϵ(t−1) +ϵ(t)

    
##ARIMA Example 2: Arima with additive seasonal effects  
#2.Variation of example 1 which adds an MA(4) term to the ARIMA(1,1,1) specification to allow for an additive seasonal effect.
#Before estimating the dataset, graphs showing:
1.The time series (in logs) - non stationary 
2.The first difference of the time series (in logs) - looks stationary 
3.The autocorrelation function - for q
4.The partial autocorrelation function for p 

# Dataset
data = pd.read_stata(BytesIO(wpi1))
data.index = data.t
data['ln_wpi'] = np.log(data['wpi'])
data['D.ln_wpi'] = data['ln_wpi'].diff()

# Graph data
fig, axes = plt.subplots(1, 2, figsize=(15,4))

# Levels
axes[0].plot(data.index._mpl_repr(), data['wpi'], '-')
axes[0].set(title='US Wholesale Price Index')

# Log difference
axes[1].plot(data.index._mpl_repr(), data['D.ln_wpi'], '-')
axes[1].hlines(0, data.index[0], data.index[-1], 'r')
axes[1].set(title='US Wholesale Price Index - difference of logs');

# Graph data
fig, axes = plt.subplots(1, 2, figsize=(15,4))
#first row is NaN because of diff, remove those 
fig = sm.graphics.tsa.plot_acf(data.ix[1:, 'D.ln_wpi'], lags=40, ax=axes[0])
fig = sm.graphics.tsa.plot_pacf(data.ix[1:, 'D.ln_wpi'], lags=40, ax=axes[1])
   
#to specify an ARIMA(1,1,4) process, we would use:
mod = sm.tsa.statespace.SARIMAX(data['wpi'], trend='c', order=(1,1,4))
#here 4 is a maximum degree of the lag polynomial, 
#it implies that all polynomial terms up to that degree are included

#To have a polynomial that has terms for the 1st and 4th degrees, 
#but leaves out the 2nd and 3rd terms.
ar = 1          # this is the maximum degree specification
ma = (1,0,0,1)  # this is the lag polynomial specification
mod = sm.tsa.statespace.SARIMAX(data['wpi'], trend='c', order=(ar,1,ma)))


# Fit the model
mod = sm.tsa.statespace.SARIMAX(data['ln_wpi'], trend='c', order=(1,1,4))
res = mod.fit(disp=False, maxiter=200)
>>> print(res.summary())
                           Statespace Model Results
==============================================================================
Dep. Variable:                 ln_wpi   No. Observations:                  124
Model:               SARIMAX(1, 1, 4)   Log Likelihood                 386.359
Date:                Wed, 31 Jan 2018   AIC                           -758.718
Time:                        05:52:49   BIC                           -738.976
Sample:                    01-01-1960   HQIC                          -750.698
                         - 10-01-1990
Covariance Type:                  opg
==============================================================================
                 coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
intercept      0.0026      0.002      1.545      0.122      -0.001       0.006
ar.L1          0.7751      0.106      7.322      0.000       0.568       0.983
ma.L1         -0.3848      0.134     -2.878      0.004      -0.647      -0.123
ma.L2         -0.0524      0.100     -0.524      0.601      -0.249       0.144
ma.L3          0.0675      0.071      0.955      0.340      -0.071       0.206
ma.L4          0.3019      0.125      2.406      0.016       0.056       0.548
sigma2         0.0001   1.07e-05     10.091      0.000    8.72e-05       0.000
================================================================================
===
Ljung-Box (Q):                       30.77   Jarque-Bera (JB):                42.13
Prob(Q):                              0.85   Prob(JB):                         0.00
Heteroskedasticity (H):               2.51   Skew:                             0.41
Prob(H) (two-sided):                  0.00   Kurtosis:                         5.75
================================================================================

 
    
##ARIMA Example 3: Airline Model 
#3.ARIMA(2,1,0) x (1,1,0,12) model of monthly airline data. 
#This example allows a multiplicative seasonal effect
# Dataset
air2 = requests.get('http://www.stata-press.com/data/r12/air2.dta').content
data = pd.read_stata(BytesIO(air2))
data.index = pd.date_range(start=datetime(data.time[0], 1, 1), periods=len(data), freq='MS')
data['lnair'] = np.log(data['air'])  

#Fit the model
#simple_differencing=True, then the time series provided as endog is literatlly differenced and 
#an ARMA model is fit to the resulting new time series. 
#This implies that a number of initial periods are lost to the differencing process, 
#The default is simple_differencing=False, 
#in which case the integration component is implemented as part of the state space formulation, 
#and all of the original data can be used in estimation.

#seasonal - 12 , means yearly 
mod = sm.tsa.statespace.SARIMAX(data['lnair'], order=(2,1,0), seasonal_order=(1,1,0,12), simple_differencing=True)
res = mod.fit(disp=False)
>>> print(res.summary())

                                 Statespace Model Results                                 
==========================================================================================
Dep. Variable:                       D.DS12.lnair   No. Observations:                  131
Model:             SARIMAX(2, 0, 0)x(1, 0, 0, 12)   Log Likelihood                 240.821
Date:                            Tue, 28 Feb 2017   AIC                           -473.643
Time:                                    21:34:54   BIC                           -462.142
Sample:                                02-01-1950   HQIC                          -468.970
                                     - 12-01-1960                                         
Covariance Type:                              opg                                         
==============================================================================
                 coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
ar.L1         -0.4057      0.080     -5.045      0.000      -0.563      -0.248
ar.L2         -0.0799      0.099     -0.809      0.419      -0.274       0.114
ar.S.L12      -0.4723      0.072     -6.592      0.000      -0.613      -0.332
sigma2         0.0014      0.000      8.403      0.000       0.001       0.002
===================================================================================
Ljung-Box (Q):                       49.89   Jarque-Bera (JB):                 0.72
Prob(Q):                              0.14   Prob(JB):                         0.70
Heteroskedasticity (H):               0.54   Skew:                             0.14
Prob(H) (two-sided):                  0.04   Kurtosis:                         3.23
===================================================================================

Warnings:
[1] Covariance matrix calculated using the outer product of gradients (complex-step).

    
    
##ARIMA Example 4: ARMAX (Friedman)
#demonstrates the use of explanatory variables (the X part of ARMAX). 
#When exogenous regressors are included, 
#the SARIMAX module uses the concept of "regression with SARIMA errors

# Dataset
friedman2 = requests.get('http://www.stata-press.com/data/r12/friedman2.dta').content
data = pd.read_stata(BytesIO(friedman2))
data.index = data.time

# Variables
endog = data.ix['1959':'1981', 'consump']
>>> endog
time
1959-01-01     310.399994

exog = sm.add_constant(data.ix['1959':'1981', 'm2'])
>>> exog
            const           m2
time
1959-01-01    1.0   289.149994


# Fit the model- endog with two explanatory variables via exog 
mod = sm.tsa.statespace.SARIMAX(endog, exog, order=(1,0,1))
res = mod.fit(disp=False)
>>> print(res.summary())

  Statespace Model Results                           
==============================================================================
Dep. Variable:                consump   No. Observations:                   92
Model:               SARIMAX(1, 0, 1)   Log Likelihood                -340.508
Date:                Tue, 28 Feb 2017   AIC                            691.015
Time:                        21:34:55   BIC                            703.624
Sample:                    01-01-1959   HQIC                           696.105
                         - 10-01-1981                                         
Covariance Type:                  opg                                         
==============================================================================
                 coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
const        -36.0692     56.618     -0.637      0.524    -147.038      74.900
m2             1.1220      0.036     30.836      0.000       1.051       1.193
ar.L1          0.9348      0.041     22.718      0.000       0.854       1.015
ma.L1          0.3091      0.089      3.488      0.000       0.135       0.483
sigma2        93.2540     10.888      8.565      0.000      71.913     114.595
===================================================================================
Ljung-Box (Q):                       38.72   Jarque-Bera (JB):                23.49
Prob(Q):                              0.53   Prob(JB):                         0.00
Heteroskedasticity (H):              22.51   Skew:                             0.17
Prob(H) (two-sided):                  0.00   Kurtosis:                         5.45
===================================================================================

##Out of sample predictions
#new estimate using data that excludes the last few observations 

# Dataset
raw = pd.read_stata(BytesIO(friedman2))
raw.index = raw.time
data = raw.ix[:'1981']  #upto 1981

true_y = raw.ix['1982':'1991', 'consump']

# Variables
endog = data.ix['1959':, 'consump']  #from 1959 to 1981 
exog = sm.add_constant(data.ix['1959':, 'm2'])
nobs = endog.shape[0]

# Fit the model  - data from 1959 to 1978 
mod = sm.tsa.statespace.SARIMAX(endog.ix[:'1978-01-01'], exog=exog.ix[:'1978-01-01'], order=(1,0,1))
fit_res = mod.fit(disp=False)
>>> print(fit_res.summary())
                           Statespace Model Results                           
==============================================================================
Dep. Variable:                consump   No. Observations:                   77
Model:               SARIMAX(1, 0, 1)   Log Likelihood                -243.316
Date:                Tue, 28 Feb 2017   AIC                            496.633
Time:                        21:34:55   BIC                            508.352
Sample:                    01-01-1959   HQIC                           501.320
                         - 01-01-1978                                         
Covariance Type:                  opg                                         
==============================================================================
                 coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------
const          0.6776     18.491      0.037      0.971     -35.565      36.920
m2             1.0379      0.021     50.330      0.000       0.997       1.078
ar.L1          0.8775      0.059     14.859      0.000       0.762       0.993
ma.L1          0.2771      0.108      2.572      0.010       0.066       0.488
sigma2        31.6977      4.683      6.769      0.000      22.519      40.876
===================================================================================
Ljung-Box (Q):                       46.77   Jarque-Bera (JB):                 6.05
Prob(Q):                              0.21   Prob(JB):                         0.05
Heteroskedasticity (H):               6.09   Skew:                             0.57
Prob(H) (two-sided):                  0.00   Kurtosis:                         3.76
===================================================================================

Warnings:
[1] Covariance matrix calculated using the outer product of gradients (complex-step).


#fit_res - from 1959 to 1978 
#res - from 1959 to 1981 
mod = sm.tsa.statespace.SARIMAX(endog, exog=exog, order=(1,0,1))

#Kalman filtering,  linear quadratic estimation (LQE), (but nonlinear version also exists)
#In the prediction step, the Kalman filter produces estimates of the current state variables, 
#along with their uncertainties. 
#Once the outcome of the next measurement (necessarily corrupted with some amount of error, including random noise) is observed, 
#these estimates are updated using a weighted average, 
#with more weight being given to estimates with higher certainty. 
#The algorithm is recursive. 
#It can run in real time, using only the present input measurements 
#and the previously calculated state and its uncertainty matrix; 

res = mod.filter(fit_res.params) #based on fit_res.params, get this model Result 


# In-sample one-step-ahead predictions
#One-step-ahead prediction uses the true values of the endogenous values 
#at each step to predict the next in-sample value. 
predict = res.get_prediction() #statsmodels.tsa.statespace.mlemodel.PredictionResults
predict_ci = predict.conf_int()

>>> predict.summary_frame()
consump            mean    mean_se  mean_ci_lower  mean_ci_upper
1959-01-01   300.782333  14.680043     272.009978     329.554687
1959-04-01   314.700037   5.810863     303.310955     326.089118
1959-07-01   318.334225   5.642810     307.274521     329.393928

#predictionResult has below methods 
'conf_int', 'df', 'dist', 'dist_args', 'link', 'linpred', 'model', 
'predicted_man', 'prediction_results', 'row_labels', 
'se_mean', 'se_obs', 'summary_frame','t_test', 'tvalues', 
'var_pred_mean', 'var_resid'


#note 
#fit_res - from 1959 to 1978 
#res - from 1959 to 1981 

#Dynamic predictions use one-step-ahead prediction up to some point in the dataset 
#(specified by the dynamic argument); 
#after that, the previous predicted endogenous values are used 
#in place of the true endogenous values for each new predicted element.

#The dynamic argument is specified to be an offset relative to the start argument. If start is not specified, it is assumed to be 0.
#perform dynamic prediction starting in the first quarter of 1978.
predict_dy = res.get_prediction(dynamic='1978-01-01')
predict_dy_ci = predict_dy.conf_int()
>>> predict_dy.summary_frame()
consump            mean    mean_se  mean_ci_lower  mean_ci_upper
1959-01-01   300.782333  14.680043     272.009978     329.554687
1959-04-01   314.700037   5.810863     303.310955     326.089118
1959-07-01   318.334225   5.642810     307.274521     329.393928


#Difference in prediction performance 
#Notice that up to the point where dynamic prediction begins (1978:Q1), 
#the two are the same.

fig, ax = plt.subplots(figsize=(9,4))
npre = 4
ax.set(title='Personal consumption', xlabel='Date', ylabel='Billions of dollars')

# Plot data points
data.ix['1977-07-01':, 'consump'].plot(ax=ax, style='o', label='Observed')

# Plot predictions
predict.predicted_mean.ix['1977-07-01':].plot(ax=ax, style='r--', label='One-step-ahead forecast')
ci = predict_ci.ix['1977-07-01':]
ax.fill_between(ci.index, ci.ix[:,0], ci.ix[:,1], color='r', alpha=0.1)
predict_dy.predicted_mean.ix['1977-07-01':].plot(ax=ax, style='g', label='Dynamic forecast (1978)')
ci = predict_dy_ci.ix['1977-07-01':]
ax.fill_between(ci.index, ci.ix[:,0], ci.ix[:,1], color='g', alpha=0.1)

legend = ax.legend(loc='lower right')


# Prediction error
#one-step-ahead prediction is considerably better.

fig, ax = plt.subplots(figsize=(9,4))
npre = 4
ax.set(title='Forecast error', xlabel='Date', ylabel='Forecast - Actual')

# In-sample one-step-ahead predictions and 95% confidence intervals
predict_error = predict.predicted_mean - endog
predict_error.ix['1977-10-01':].plot(ax=ax, label='One-step-ahead forecast')
ci = predict_ci.ix['1977-10-01':].copy()
ci.iloc[:,0] -= endog.loc['1977-10-01':]
ci.iloc[:,1] -= endog.loc['1977-10-01':]
ax.fill_between(ci.index, ci.ix[:,0], ci.ix[:,1], alpha=0.1)

# Dynamic predictions and 95% confidence intervals
predict_dy_error = predict_dy.predicted_mean - endog
predict_dy_error.ix['1977-10-01':].plot(ax=ax, style='r', label='Dynamic forecast (1978)')
ci = predict_dy_ci.ix['1977-10-01':].copy()
ci.iloc[:,0] -= endog.loc['1977-10-01':]
ci.iloc[:,1] -= endog.loc['1977-10-01':]
ax.fill_between(ci.index, ci.ix[:,0], ci.ix[:,1], color='r', alpha=0.1)

legend = ax.legend(loc='lower left');
legend.get_frame().set_facecolor('w')


#outof sample predictions 
true_y = raw.ix['1982':'1991', 'consump']
X = sm.add_constant(raw.ix['1982':'1991', 'm2'])
start = len(endog)  #insample till this point 
howmany = len(true_y)
p_out = res.get_prediction(start=start, end=start+howmany-1, exog=X)
predicted_out = p_out.summary_frame().copy()
predicted_out.index = true_y.index 
predicted_out['y_true']= true_y 
predicted_out['error']= predicted_out['y_true'] - predicted_out['mean']

#plot 
fig, axes = plt.subplots(2, 1)
predicted_out[ [ 'y_true', 'mean', 'mean_ci_lower', 'mean_ci_upper' ] ].plot(kind='line', ax=axes[0])
axes[0].set_title("Predicted vs True values", x=0)
predicted_out['error'].plot(kind='line', ax= axes[1])
axes[1].set_title("Error", x=0)
plt.show()



##Statsspace mdeols - Unobserved Components
#These are also known as structural time series models,
#and decompose a (univariate) time series into trend, seasonal, cyclical, and irregular components.
structural.UnobservedComponents(endog[, ...])   Univariate unobserved components time series model 
structural.UnobservedComponentsResults(...)     Class to hold results from fitting an unobserved components model. 


class statsmodels.tsa.statespace.structural.UnobservedComponents(endog, 
        level=False, trend=False, seasonal=None, cycle=False, autoregressive=None, 
        exog=None, irregular=False, stochastic_level=False, 
        stochastic_trend=False, stochastic_seasonal=True, 
        stochastic_cycle=False, damped_cycle=False, 
        cycle_period_bounds=None, mle_regression=True, **kwargs)
    level : bool or string, optional
        Whether or not to include a level component
    trend : bool, optional
        Whether or not to include a trend component. Default is False. 
        If True, level must also be True.
    seasonal : int or None, optional
        The period of the seasonal component, if any. Default is None.
    cycle : bool, optional
        Whether or not to include a cycle component. Default is False.
    autoregressive : int or None, optional
        The order of the autoregressive component. Default is None.
    exog : array_like or None, optional
        Exogenous variables.
    irregular : bool, optional
        Whether or not to include an irregular component. Default is False.
    stochastic_level : bool, optional
        Whether or not any level component is stochastic. Default is False.
    stochastic_trend : bool, optional
        Whether or not any trend component is stochastic. Default is False.
    stochastic_seasonal : bool, optional
        Whether or not any seasonal component is stochastic. Default is False.
    stochastic_cycle : bool, optional
        Whether or not any cycle component is stochastic. Default is False.
    damped_cycle : bool, optional
        Whether or not the cycle component is damped. Default is False.
    cycle_period_bounds : tuple, optional
        A tuple with lower and upper allowed bounds for the period of the cycle
#Details 
    y_t = mu_t + gamma_t + c_t + epsilon_t
#Where 
mu_t - trend including level (result in UnobservedComponentsResults.level , .trend attributes)
    where the level is a generalization of the intercept term 
    that can dynamically vary across time, 
    and the trend is a generalization of the time-trend such 
    that the slope can dynamically vary across time.
    For both elements (level and trend)
        •The element is included vs excluded (if the trend is included, there must also be a level included).
        •The element is deterministic vs stochastic (i.e. whether or not the variance on the error term is confined to be zero or not)
    The level/trend components can be specified using the boolean 
    keyword arguments level, stochastic_level, trend, etc., 
    or all at once as a string argument to level. 
    #Model name                         Full string syntax                  Abbreviated syntax
    No trend                            'irregular'                         'ntrend' 
    Fixed intercept                     'fixed intercept'   
    Deterministic constant              'deterministic constant'            'dconstant' 
    Local level                         'local level'                       'llevel' 
    Random walk                         'random walk'                       'rwalk' 
    Fixed slope                         'fixed slope'   
    Deterministic trend                 'deterministic trend'               'dtrend' 
    Local linear deterministic trend    'local linear deterministic trend'  'lldtrend' 
    Random walk with drift              'random walk with drift'            'rwdrift' 
    Local linear trend                  'local linear trend'                'lltrend' 
    Smooth trend                        'smooth trend'                      'strend' 
    Random trend                        'random trend'                      'rtrend' 
gamma_t - Seasonal (result in UnobservedComponentsResults.seasonal )
    The periodicity (number of seasons) is s, 
c_t - Cycle (result in UnobservedComponentsResults.cycle )
    The cyclical component is intended to capture cyclical effects at time frames 
    much longer than captured by the seasonal component. 
    For example, in economics the cyclical term is often intended to capture 
    the business cycle, and is then expected to have a period between '1.5 and 12 years'
    Could be stochastic_cycle and/or damped_cycle
epsilon_t - Irregular
    The irregular components are independent and identically distributed (iid)
Autoregressive Irregular - (result in UnobservedComponentsResults.autoregressive)
    For  white noise irregular component, specify via autoregressive 
Regression effects - (result in UnobservedComponentsResults.regression_coefficients)
    For Exogenous regressors via exog argument 
    
#Few Methods 
aic()                           (float) Akaike Information Criterion 
bic()                           (float) Bayes Information Criterion 
bse()  
conf_int([alpha, cols, method]) Returns the confidence interval of the fitted parameters. 

forecast([steps])               Out-of-sample forecasts 
get_forecast([steps])           Out-of-sample forecasts 
get_prediction([start, end, dynamic, exog])         In-sample prediction and out-of-sample forecasting 
predict([start, end, dynamic])                      In-sample prediction and out-of-sample forecasting 
impulse_responses([steps, impulse, ...])            Impulse response function 

plot_components([which, alpha, observed, ...])      Plot the estimated components of the model. 
plot_diagnostics([variable, lags, fig, figsize])    Diagnostic plots for standardized residuals of one endogenous variable 
save(fname[, remove_data])                          save a pickle of this instance 
load(fname)                                         load a pickle, (class method) 
simulate(nsimulations[, measurement_shocks, ...])   Simulate a new time series following the state space model 
summary([alpha, start])                             Summarize the Model 

t_test(r_matrix[, cov_p, scale, use_t])             Compute a t-test for a each linear hypothesis of the form Rb = q 
test_heteroskedasticity(method[, ...])              Test for heteroskedasticity of standardized residuals 
test_normality(method)                              Test for normality of standardized residuals. 
test_serial_correlation(method[, lags])             Ljung-box test for no serial correlation of standardized residuals 
wald_test(r_matrix[, cov_p, scale, invcov, ...])    Compute a Wald-test for a joint linear hypothesis. 

    
UnobservedComponentsResults.plot_components(which=None, alpha=0.05, observed=True, level=True, trend=True, seasonal=True, cycle=True, autoregressive=True, legend_loc='upper right', fig=None, figsize=None)[source]
    Plot the estimated components of the model.
    which : {'filtered', 'smoothed'}, or None, optional
        Type of state estimate to plot. 
        Default is 'smoothed' if smoothed results are available otherwise 'filtered'.
    alpha : float, optional
        The confidence intervals for the components are (1 - alpha) %
    Draws below 
    0.Observed series against predicted series
    1.Level
    2.Trend
    3.Seasonal
    4.Cycle
    5.Autoregressive


##Example 
http://www.statsmodels.org/dev/examples/notebooks/generated/statespace_cycles.html
#Trends and cycles in unemployment - Three methods 
%matplotlib inline

import numpy as np
import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt

from pandas_datareader.data import DataReader
endog = DataReader('UNRATE', 'fred', start='1954-01-01')

#First Methods - Hodrick-Prescott (HP) filter
#specify the parameter λ=129600  because the unemployment rate is observed monthly.
#quarterly  - 1600, annual - 6.25, monthly - 129600 

hp_cycle, hp_trend = sm.tsa.filters.hpfilter(endog, lamb=129600)




##2nd method - Unobserved components and ARIMA model (UC-ARIMA)
#where the trend is modeled as a random walk 
#and the irregular is modeled with an ARIMA model 
mod_ucarima = sm.tsa.UnobservedComponents(endog, 'rwalk', autoregressive=4)
# Here the powell method is used, since it achieves a
# higher loglikelihood than the default L-BFGS method
res_ucarima = mod_ucarima.fit(method='powell', disp=False)
#check for level and AR irregular
res_ucarima.level, res_ucarima.autoregressive
res_ucarima.plot_components()
plt.show()

print(res_ucarima.summary())
                       Unobserved Components Results                         
==============================================================================
Dep. Variable:                 UNRATE   No. Observations:                  757
Model:                    random walk   Log Likelihood                 236.446
                              + AR(4)   AIC                           -460.892
Date:                Tue, 28 Feb 2017   BIC                           -433.116
Time:                        21:34:27   HQIC                          -450.194
Sample:                    01-01-1954                                         
                         - 01-01-2017                                         
Covariance Type:                  opg                                         
================================================================================
                   coef    std err          z      P>|z|      [0.025      0.975]
--------------------------------------------------------------------------------
sigma2.level     0.0176      0.003      6.179      0.000       0.012       0.023
sigma2.ar        0.0112      0.003      3.533      0.000       0.005       0.017
ar.L1            1.0418      0.066     15.677      0.000       0.912       1.172
ar.L2            0.4618      0.106      4.358      0.000       0.254       0.669
ar.L3           -0.3254      0.125     -2.605      0.009      -0.570      -0.081
ar.L4           -0.1904      0.077     -2.484      0.013      -0.341      -0.040
===================================================================================
Ljung-Box (Q):                       76.62   Jarque-Bera (JB):                38.64
Prob(Q):                              0.00   Prob(JB):                         0.00
Heteroskedasticity (H):               0.51   Skew:                             0.23
Prob(H) (two-sided):                  0.00   Kurtosis:                         4.01
===================================================================================



##3rd Method - Unobserved components with stochastic cycle (UC)
#where the cycle is modeled explicitly.
mod_uc = sm.tsa.UnobservedComponents(
    endog, 'rwalk',
    cycle=True, stochastic_cycle=True, damped_cycle=True,
)
# Here the powell method gets close to the optimum
res_uc = mod_uc.fit(method='powell', disp=False)
# but to get to the highest loglikelihood we do a
# second round using the L-BFGS method.
res_uc = mod_uc.fit(res_uc.params, disp=False)

#Check 
res_uc.level, res_uc.cycle
res_uc.plot_components()
plt.show()
print(res_uc.summary())
                           Unobserved Components Results                            
=====================================================================================
Dep. Variable:                        UNRATE   No. Observations:                  757
Model:                           random walk   Log Likelihood                 204.432
                   + damped stochastic cycle   AIC                           -400.864
Date:                       Tue, 28 Feb 2017   BIC                           -382.347
Time:                               21:34:28   HQIC                          -393.732
Sample:                           01-01-1954                                         
                                - 01-01-2017                                         
Covariance Type:                         opg                                         
===================================================================================
                      coef    std err          z      P>|z|      [0.025      0.975]
-----------------------------------------------------------------------------------
sigma2.level        0.0102      0.004      2.341      0.019       0.002       0.019
sigma2.cycle        0.0214      0.004      4.911      0.000       0.013       0.030
frequency.cycle     0.0657      0.005     13.175      0.000       0.056       0.076
damping.cycle       0.9912      0.004    266.360      0.000       0.984       0.999
===================================================================================
Ljung-Box (Q):                      148.61   Jarque-Bera (JB):                79.57
Prob(Q):                              0.00   Prob(JB):                         0.00
Heteroskedasticity (H):               0.49   Skew:                             0.45
Prob(H) (two-sided):                  0.00   Kurtosis:                         4.31
===================================================================================

Warnings:
[1] Covariance matrix calculated using the outer product of gradients (complex-step).

##2nd Example 
#http://www.statsmodels.org/dev/examples/notebooks/generated/statespace_structural_harvey_jaeger.html
#Data
#Following Harvey and Jaeger, we will consider the following time series:
•US real GNP, "output", (GNPC96)
•US GNP implicit price deflator, "prices", (GNPDEF)
•US monetary base, "money", (AMBSL)

#All data series considered here are taken 
#from Federal Reserve Economic Data (FRED). 
# Datasets
from pandas_datareader.data import DataReader

# Get the raw data
start = '1948-01'
end = '2008-01'
us_gnp = DataReader('GNPC96', 'fred', start=start, end=end)
us_gnp_deflator = DataReader('GNPDEF', 'fred', start=start, end=end)
us_monetary_base = DataReader('AMBSL', 'fred', start=start, end=end).resample('QS').mean()
recessions = DataReader('USRECQ', 'fred', start=start, end=end).resample('QS').last().values[:,0]

# Construct the dataframe after log transforming 
dta = pd.concat(map(np.log, (us_gnp, us_gnp_deflator, us_monetary_base)), axis=1)
dta.columns = ['US GNP','US Prices','US monetary base']
dates = dta.index._mpl_repr()


# Plot the data
ax = dta.plot(figsize=(13,3))
ylim = ax.get_ylim()
ax.xaxis.grid()
ax.fill_between(dates, ylim[0]+1e-5, ylim[1]-1e-5, recessions, facecolor='k', alpha=0.1);

# Model specifications

# Unrestricted model, using string specification
unrestricted_model = {
    'level': 'local linear trend', 'cycle': True, 'damped_cycle': True, 'stochastic_cycle': True
}

# Unrestricted model, setting components directly
# This is an equivalent, but less convenient, way to specify a
# local linear trend model with a stochastic damped cycle:
# unrestricted_model = {
#     'irregular': True, 'level': True, 'stochastic_level': True, 'trend': True, 'stochastic_trend': True,
#     'cycle': True, 'damped_cycle': True, 'stochastic_cycle': True
# }

# The restricted model forces a smooth trend
restricted_model = {
    'level': 'smooth trend', 'cycle': True, 'damped_cycle': True, 'stochastic_cycle': True
}

# Restricted model, setting components directly
# This is an equivalent, but less convenient, way to specify a
# smooth trend model with a stochastic damped cycle. Notice
# that the difference from the local linear trend model is that
# `stochastic_level=False` here.
# unrestricted_model = {
#     'irregular': True, 'level': True, 'stochastic_level': False, 'trend': True, 'stochastic_trend': True,
#     'cycle': True, 'damped_cycle': True, 'stochastic_cycle': True
# }

#We now fit the following models:
#    Output, unrestricted model
#    Prices, unrestricted model
#    Prices, restricted model
#    Money, unrestricted model
#    Money, restricted model

# Output
output_mod = sm.tsa.UnobservedComponents(dta['US GNP'], **unrestricted_model)
output_res = output_mod.fit(method='powell', disp=False)

# Prices
prices_mod = sm.tsa.UnobservedComponents(dta['US Prices'], **unrestricted_model)
prices_res = prices_mod.fit(method='powell', disp=False)

prices_restricted_mod = sm.tsa.UnobservedComponents(dta['US Prices'], **restricted_model)
prices_restricted_res = prices_restricted_mod.fit(method='powell', disp=False)

# Money
money_mod = sm.tsa.UnobservedComponents(dta['US monetary base'], **unrestricted_model)
money_res = money_mod.fit(method='powell', disp=False)

money_restricted_mod = sm.tsa.UnobservedComponents(dta['US monetary base'], **restricted_model)
money_restricted_res = money_restricted_mod.fit(method='powell', disp=False)

#check one 
print(output_res.summary())

                            Unobserved Components Results                            
=====================================================================================
Dep. Variable:                        US GNP   No. Observations:                  241
Model:                    local linear trend   Log Likelihood                 770.164
                   + damped stochastic cycle   AIC                          -1528.328
Date:                       Tue, 28 Feb 2017   BIC                          -1507.420
Time:                               21:35:01   HQIC                         -1519.905
Sample:                           01-01-1948                                         
                                - 01-01-2008                                         
Covariance Type:                         opg                                         
====================================================================================
                       coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------------
sigma2.irregular  4.843e-08   7.26e-06      0.007      0.995   -1.42e-05    1.43e-05
sigma2.level      7.352e-06   4.93e-05      0.149      0.882   -8.93e-05       0.000
sigma2.trend      3.007e-06   1.43e-06      2.102      0.036    2.03e-07    5.81e-06
sigma2.cycle      3.834e-05   2.55e-05      1.503      0.133   -1.17e-05    8.83e-05
frequency.cycle      0.4546      0.049      9.285      0.000       0.359       0.551
damping.cycle        0.8639      0.043     20.232      0.000       0.780       0.948
===================================================================================
Ljung-Box (Q):                       40.32   Jarque-Bera (JB):                 9.86
Prob(Q):                              0.46   Prob(JB):                         0.01
Heteroskedasticity (H):               0.27   Skew:                            -0.04
Prob(H) (two-sided):                  0.00   Kurtosis:                         4.00
===================================================================================

#plot_components 
fig = output_res.plot_components(legend_loc='lower right', figsize=(15, 9));



#Harvey and Jaeger summarize the models in another way 
#to highlight the relative importances of the trend and cyclical components

# Create Table I
table_i = np.zeros((5,6))

start = dta.index[0]
end = dta.index[-1]
time_range = '%d:%d-%d:%d' % (start.year, start.quarter, end.year, end.quarter)
models = [
    ('US GNP', time_range, 'None'),
    ('US Prices', time_range, 'None'),
    ('US Prices', time_range, r'$\sigma_\eta^2 = 0$'),
    ('US monetary base', time_range, 'None'),
    ('US monetary base', time_range, r'$\sigma_\eta^2 = 0$'),
]
index = pd.MultiIndex.from_tuples(models, names=['Series', 'Time range', 'Restrictions'])
parameter_symbols = [
    r'$\sigma_\zeta^2$', r'$\sigma_\eta^2$', r'$\sigma_\kappa^2$', r'$\rho$',
    r'$2 \pi / \lambda_c$', r'$\sigma_\varepsilon^2$',
]

i = 0
for res in (output_res, prices_res, prices_restricted_res, money_res, money_restricted_res):
    if res.model.stochastic_level:
        (sigma_irregular, sigma_level, sigma_trend,
         sigma_cycle, frequency_cycle, damping_cycle) = res.params
    else:
        (sigma_irregular, sigma_level,
         sigma_cycle, frequency_cycle, damping_cycle) = res.params
        sigma_trend = np.nan
    period_cycle = 2 * np.pi / frequency_cycle
    
    table_i[i, :] = [
        sigma_level*1e7, sigma_trend*1e7,
        sigma_cycle*1e7, damping_cycle, period_cycle,
        sigma_irregular*1e7
    ]
    i += 1
    
pd.set_option('float_format', lambda x: '%.4g' % np.round(x, 2) if not np.isnan(x) else '-')
table_i = pd.DataFrame(table_i, index=index, columns=parameter_symbols)
table_i


##State space Model - Vector Autoregressive Moving-Average with eXogenous regressors (VARMAX)
# multivariate statespace model.

varmax.VARMAX(endog[, exog, order, trend, ...]) Vector Autoregressive Moving Average with eXogenous regressors model 
varmax.VARMAXResults(model, params, ...[, ...]) Class to hold results from fitting an VARMAX model. 

##SOP 
# Load the statsmodels api
import statsmodels.api as sm

# Load your (multivariate) dataset
endog = pd.read_csv('your/dataset/here.csv')

# Fit a local level model
mod_var1 = sm.tsa.VARMAX(endog, order=(1,0))
# Note that mod_var1 is an instance of the VARMAX class

# Fit the model via maximum likelihood
res_var1 = mod_var1.fit()
# Note that res_var1 is an instance of the VARMAXResults class

# Show the summary of results
print(res_var1.summary())

# Construct impulse responses
irfs = res_ll.impulse_responses(steps=10)

##Example
%matplotlib inline

import numpy as np
import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt

dta = sm.datasets.webuse('lutkepohl2', 'http://www.stata-press.com/data/r12/')
dta.index = dta.qtr
endog = dta.ix['1960-04-01':'1978-10-01', ['dln_inv', 'dln_inc', 'dln_consump']]

#The VARMAX class in Statsmodels allows estimation of VAR, VMA, and VARMA models 
#(through the order argument), 
#optionally with a constant term (via the trend argument). 
#Exogenous regressors may also be included (by the exog argument), 
#class allows measurement error  (via the measurement_error argument) 

#Example 1: VARX(2) , two endogenous variables and an exogenous series
exog = endog['dln_consump']
mod = sm.tsa.VARMAX(endog[['dln_inv', 'dln_inc']], order=(2,0), trend='nc', exog=exog)
res = mod.fit(maxiter=1000, disp=False)
>>> print(res.summary())

                             Statespace Model Results                             
==================================================================================
Dep. Variable:     ['dln_inv', 'dln_inc']   No. Observations:                   75
Model:                            VARX(2)   Log Likelihood                 348.269
Date:                    Tue, 28 Feb 2017   AIC                           -670.537
Time:                            21:35:16   BIC                           -640.410
Sample:                        04-01-1960   HQIC                          -658.508
                             - 10-01-1978                                         
Covariance Type:                      opg                                         
===================================================================================
Ljung-Box (Q):                59.41, 42.46   Jarque-Bera (JB):         16.41, 13.03
Prob(Q):                        0.02, 0.37   Prob(JB):                   0.00, 0.00
Heteroskedasticity (H):         0.46, 1.03   Skew:                      0.05, -0.64
Prob(H) (two-sided):            0.06, 0.95   Kurtosis:                   5.29, 4.59
                            Results for equation dln_inv                            
====================================================================================
                       coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------------
L1.dln_inv          -0.2773      0.088     -3.149      0.002      -0.450      -0.105
L1.dln_inc           0.3374      0.620      0.544      0.586      -0.877       1.552
L2.dln_inv          -0.1160      0.157     -0.740      0.459      -0.423       0.191
L2.dln_inc           0.3971      0.387      1.025      0.305      -0.362       1.156
beta.dln_consump     0.5448      0.752      0.724      0.469      -0.929       2.019
                            Results for equation dln_inc                            
====================================================================================
                       coef    std err          z      P>|z|      [0.025      0.975]
------------------------------------------------------------------------------------
L1.dln_inv           0.0335      0.042      0.794      0.427      -0.049       0.116
L1.dln_inc           0.0962      0.133      0.726      0.468      -0.164       0.356
L2.dln_inv           0.0516      0.051      1.017      0.309      -0.048       0.151
L2.dln_inc           0.2734      0.169      1.622      0.105      -0.057       0.604
beta.dln_consump     0.4818      0.198      2.427      0.015       0.093       0.871
                                  Error covariance matrix                                   
============================================================================================
                               coef    std err          z      P>|z|      [0.025      0.975]
--------------------------------------------------------------------------------------------
sqrt.var.dln_inv             0.0441      0.003     14.164      0.000       0.038       0.050
sqrt.cov.dln_inv.dln_inc     0.0013      0.002      0.549      0.583      -0.003       0.006
sqrt.var.dln_inc            -0.0127      0.001    -12.420      0.000      -0.015      -0.011
============================================================================================

#plot the impulse response functions of the endogenous variables.
ax = res.impulse_responses(10, orthogonalized=True).plot(figsize=(13,3))
ax.set(xlabel='t', title='Responses to a shock to `dln_inv`');

#Example 2: VMA(2)
#where the innovations to the process are uncorrelated.
#and  include the constant term.

mod = sm.tsa.VARMAX(endog[['dln_inv', 'dln_inc']], order=(0,2), error_cov_type='diagonal')
res = mod.fit(maxiter=1000, disp=False)
>>> print(res.summary())

                             Statespace Model Results                             
==================================================================================
Dep. Variable:     ['dln_inv', 'dln_inc']   No. Observations:                   75
Model:                             VMA(2)   Log Likelihood                 353.887
                              + intercept   AIC                           -683.775
Date:                    Tue, 28 Feb 2017   BIC                           -655.965
Time:                            21:35:20   HQIC                          -672.670
Sample:                        04-01-1960                                         
                             - 10-01-1978                                         
Covariance Type:                      opg                                         
===================================================================================
Ljung-Box (Q):                68.49, 39.14   Jarque-Bera (JB):         12.79, 13.08
Prob(Q):                        0.00, 0.51   Prob(JB):                   0.00, 0.00
Heteroskedasticity (H):         0.44, 0.81   Skew:                      0.06, -0.48
Prob(H) (two-sided):            0.04, 0.60   Kurtosis:                   5.02, 4.81
                           Results for equation dln_inv                          
=================================================================================
                    coef    std err          z      P>|z|      [0.025      0.975]
---------------------------------------------------------------------------------
const             0.0182      0.005      3.800      0.000       0.009       0.028
L1.e(dln_inv)    -0.2572      0.106     -2.430      0.015      -0.465      -0.050
L1.e(dln_inc)     0.5135      0.633      0.812      0.417      -0.726       1.753
L2.e(dln_inv)     0.0295      0.149      0.198      0.843      -0.263       0.322
L2.e(dln_inc)     0.1819      0.475      0.383      0.702      -0.749       1.113
                           Results for equation dln_inc                          
=================================================================================
                    coef    std err          z      P>|z|      [0.025      0.975]
---------------------------------------------------------------------------------
const             0.0207      0.002     13.087      0.000       0.018       0.024
L1.e(dln_inv)     0.0487      0.042      1.173      0.241      -0.033       0.130
L1.e(dln_inc)    -0.0789      0.139     -0.568      0.570      -0.351       0.193
L2.e(dln_inv)     0.0176      0.042      0.415      0.678      -0.066       0.101
L2.e(dln_inc)     0.1290      0.153      0.844      0.399      -0.170       0.428
                             Error covariance matrix                              
==================================================================================
                     coef    std err          z      P>|z|      [0.025      0.975]
----------------------------------------------------------------------------------
sigma2.dln_inv     0.0020      0.000      7.351      0.000       0.001       0.003
sigma2.dln_inc     0.0001   2.33e-05      5.822      0.000       9e-05       0.000
==================================================================================

#Caution: VARMA(p,q) specifications
#Although the model allows estimating VARMA(p,q) specifications, 
#these models are not identified without additional restrictions 
#on the representation matrices, which are not built-in. 
#For this reason, a warning is issued when these models are specified 

mod = sm.tsa.VARMAX(endog[['dln_inv', 'dln_inc']], order=(1,1))
res = mod.fit(maxiter=1000, disp=False)
>>> print(res.summary())

/private/tmp/statsmodels/statsmodels/tsa/statespace/varmax.py:153: EstimationWarning: Estimation of VARMA(p,q) models is not generically robust, due especially to identification issues.
  EstimationWarning)

                             Statespace Model Results                             
==================================================================================
Dep. Variable:     ['dln_inv', 'dln_inc']   No. Observations:                   75
Model:                         VARMA(1,1)   Log Likelihood                 354.291
                              + intercept   AIC                           -682.583
Date:                    Tue, 28 Feb 2017   BIC                           -652.455
Time:                            21:35:24   HQIC                          -670.553
Sample:                        04-01-1960                                         
                             - 10-01-1978                                         
Covariance Type:                      opg                                         
===================================================================================
Ljung-Box (Q):                69.15, 40.99   Jarque-Bera (JB):         11.03, 18.14
Prob(Q):                        0.00, 0.43   Prob(JB):                   0.00, 0.00
Heteroskedasticity (H):         0.45, 0.78   Skew:                      0.01, -0.52
Prob(H) (two-sided):            0.05, 0.54   Kurtosis:                   4.88, 5.17
                           Results for equation dln_inv                          
=================================================================================
                    coef    std err          z      P>|z|      [0.025      0.975]
---------------------------------------------------------------------------------
const             0.0103      0.064      0.161      0.872      -0.115       0.135
L1.dln_inv       -0.0059      0.685     -0.009      0.993      -1.349       1.337
L1.dln_inc        0.3915      2.708      0.145      0.885      -4.916       5.699
L1.e(dln_inv)    -0.2446      0.696     -0.352      0.725      -1.608       1.119
L1.e(dln_inc)     0.1210      2.963      0.041      0.967      -5.686       5.928
                           Results for equation dln_inc                          
=================================================================================
                    coef    std err          z      P>|z|      [0.025      0.975]
---------------------------------------------------------------------------------
const             0.0164      0.026      0.619      0.536      -0.036       0.068
L1.dln_inv       -0.0318      0.273     -0.116      0.907      -0.568       0.504
L1.dln_inc        0.2372      1.079      0.220      0.826      -1.878       2.352
L1.e(dln_inv)     0.0872      0.280      0.312      0.755      -0.461       0.636
L1.e(dln_inc)    -0.2367      1.115     -0.212      0.832      -2.422       1.949
                                  Error covariance matrix                                   
============================================================================================
                               coef    std err          z      P>|z|      [0.025      0.975]
--------------------------------------------------------------------------------------------
sqrt.var.dln_inv             0.0449      0.003     14.510      0.000       0.039       0.051
sqrt.cov.dln_inv.dln_inc     0.0017      0.003      0.654      0.513      -0.003       0.007
sqrt.var.dln_inc             0.0116      0.001     11.775      0.000       0.010       0.013
============================================================================================

Warnings:
[1] Covariance matrix calculated using the outer product of gradients (complex-step).



##States Space Model - Dynamic Factor Models
#Factor models generally try to find a small number of unobserved "factors" 
#that influence a subtantial portion of the variation in a larger number of observed variables, 
 

#Dynamic factor models explicitly model the transition dynamics of the unobserved factors, 
#and so are often applied to time-series data.

dynamic_factor.DynamicFactor(endog, ...[, ...]) Dynamic factor model 
dynamic_factor.DynamicFactorResults(model, ...) Class to hold results from fitting an DynamicFactor model. 


class statsmodels.tsa.statespace.dynamic_factor.DynamicFactor(endog, k_factors, 
        factor_order, exog=None, error_order=0, 
        error_var=False, error_cov_type='diagonal', enforce_stationarity=True, **kwargs)[source]
    Parameters:
    endog : array_like
        The observed time-series process y
    exog : array_like, optional
        Array of exogenous regressors for the observation equation, shaped nobs x k_exog.
    k_factors : int
        The number of unobserved factors.
        To exclude factors completely, set k_factors = 0.
    factor_order : int
        The order of the vector autoregression followed by the factors.
        this is the number of lags to include in the factor evolution equation, 
        To have static factors, set factor_order = 0.
    error_cov_type : {'scalar', 'diagonal', 'unstructured'}, optional
        The structure of the covariance matrix of the observation error term, where 'unstructured' puts no restrictions on the matrix, 'diagonal' requires it to be any diagonal matrix (uncorrelated errors), and 'scalar' requires it to be a scalar times the identity matrix. Default is 'diagonal'.
    error_order : int, optional
        The order of the vector autoregression followed 
        by the observation error component. 
        Default is None, corresponding to white noise errors.
    error_var : boolean, optional
        Whether or not to model the errors jointly via a vector autoregression,VAR(error_order) 
        rather than as individual autoregressions, AR(error_order)
        Has no effect unless error_order is set. Default is False.
#Methods of Result 
coefficients_of_determination()
    Coefficients of determination 
    A k_endog x k_factors array, where coefficients_of_determination[i, j] 
    represents the R^2 value from a regression of factor j and a constant 
    on endogenous variable i.
plot_coefficients_of_determination([...])           Plot the coefficients of determination 
plot_diagnostics([variable, lags, fig, figsize])    Diagnostic plots for standardized residuals of one endogenous variable 
predict([start, end, dynamic])                      In-sample prediction and out-of-sample forecasting 
fittedvalues() (array)                              The predicted values of the model. An (nobs x k_endog) array. 
forecast([steps])               Out-of-sample forecasts 
get_forecast([steps])           Out-of-sample forecasts 
get_prediction([start, end, dynamic, exog])         In-sample prediction and out-of-sample forecasting 
hqic() (float)                  Hannan-Quinn Information Criterion 
impulse_responses([steps, impulse, ...])            Impulse response function 
save(fname[, remove_data])                          save a pickle of this instance 
simulate(nsimulations[, measurement_shocks, ...])   Simulate a new time series following the state space model 
summary([alpha, start, separate_params])            Summarize the Model 
t_test(r_matrix[, cov_p, scale, use_t])             Compute a t-test for a each linear hypothesis of the form Rb = q 
test_heteroskedasticity(method[, ...])              Test for heteroskedasticity of standardized residuals 
test_normality(method)                              Test for normality of standardized residuals. 
test_serial_correlation(method[, lags])             Ljung-box test for no serial correlation of standardized residuals 
wald_test(r_matrix[, cov_p, scale, invcov, ...])    Compute a Wald-test for a joint linear hypothesis. 
     



##SOP
# Load the statsmodels api
import statsmodels.api as sm

# Load your dataset
endog = pd.read_csv('your/dataset/here.csv')

# Fit a local level model
mod_dfm = sm.tsa.DynamicFactor(endog, k_factors=1, factor_order=2)
# Note that mod_dfm is an instance of the DynamicFactor class

# Fit the model via maximum likelihood
res_dfm = mod_dfm.fit()
# Note that res_dfm is an instance of the DynamicFactorResults class

# Show the summary of results
print(res_ll.summary())

# Show a plot of the r^2 values from regressions of
# individual estimated factors on endogenous variables.
fig_dfm = res_ll.plot_coefficients_of_determination()


##Example - Unobserved factor in macro economic data 
#http://www.statsmodels.org/dev/examples/notebooks/generated/statespace_dfm_coincident.html

#Below data is used to find one unobserved factor which influences these four 
#(hint:reccesion)
    Industrial production (IPMAN)
    Real aggregate income (excluding transfer payments) (W875RX1)
    Manufacturing and trade sales (CMRMTSPL)
    Employees on non-farm payrolls (PAYEMS)

#In all cases, the data is at the monthly frequency 
#and has been seasonally adjusted; the time-frame considered is 1972 - 2005.

%matplotlib inline

import numpy as np
import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt

np.set_printoptions(precision=4, suppress=True, linewidth=120)

from pandas_datareader.data import DataReader

# Get the datasets from FRED
start = '1979-01-01'
end = '2014-12-01'
indprod = DataReader('IPMAN', 'fred', start=start, end=end)
income = DataReader('W875RX1', 'fred', start=start, end=end)
sales = DataReader('CMRMTSPL', 'fred', start=start, end=end)
emp = DataReader('PAYEMS', 'fred', start=start, end=end)
#Some error might exists in original data, check orginal paper on how to circumvent 
dta = pd.concat((indprod, income, sales, emp), axis=1)
dta.columns = ['indprod', 'income', 'sales', 'emp']

dta.ix[:, 'indprod':'emp'].plot(subplots=True, layout=(2, 2), figsize=(15, 6));

#Stock and Watson (1991) report that for their datasets, 
#they could not reject the null hypothesis of a unit root in each series 
#(so the series are integrated), 
#but they did not find strong evidence that the series were co-integrated.

#As a result, they suggest estimating the model using the first differences 
#(of the logs) of the variables, demeaned and standardized.

# Create log-differenced series
dta['dln_indprod'] = (np.log(dta.indprod)).diff() * 100
dta['dln_income'] = (np.log(dta.income)).diff() * 100
dta['dln_sales'] = (np.log(dta.sales)).diff() * 100
dta['dln_emp'] = (np.log(dta.emp)).diff() * 100

# De-mean and standardize
dta['std_indprod'] = (dta['dln_indprod'] - dta['dln_indprod'].mean()) / dta['dln_indprod'].std()
dta['std_income'] = (dta['dln_income'] - dta['dln_income'].mean()) / dta['dln_income'].std()
dta['std_sales'] = (dta['dln_sales'] - dta['dln_sales'].mean()) / dta['dln_sales'].std()
dta['std_emp'] = (dta['dln_emp'] - dta['dln_emp'].mean()) / dta['dln_emp'].std()


#following specification:
#    k_factors = 1 - (there is 1 unobserved factor)
#    factor_order = 2 - (it follows an AR(2) process)
#    error_var = False - (the errors evolve as independent AR processes rather than jointly as a VAR - note that this is the default option, so it is not specified below)
#    error_order = 2 - (the errors are autocorrelated of order 2: i.e. AR(2) processes)
#    error_cov_type = 'diagonal' - (the innovations are uncorrelated; this is again the default)


#Multivariate models can have a relatively large number of parameters, 
#Hence use 2 step optimizations - Powell and then BFGS
# Get the endogenous data
endog = dta.ix['1979-02-01':, 'std_indprod':'std_emp']

# Create the model
#Four y series are jointly modeled 
mod = sm.tsa.DynamicFactor(endog, k_factors=1, factor_order=2, error_order=2)
initial_res = mod.fit(method='powell', disp=False)
res = mod.fit(initial_res.params, disp=False)

#separate_params=True: Summary would print separately 
#Results for equation for each y variable, involving fi, i=1...k_factors 
#Results for factor equation for each factor, fi, of k_factors involving AR(factor_order) terms 
#Results for error equation for each y variable involving  AR(error_order) terms 
#Error covariance , sigma2 for each y variable 

#separate_params=False : print all together 
>>> print(res.summary(separate_params=False))

                                             Statespace Model Results                                            
=================================================================================================================
Dep. Variable:     ['std_indprod', 'std_income', 'std_sales', 'std_emp']   No. Observations:                  431
Model:                                 DynamicFactor(factors=1, order=2)   Log Likelihood               -2046.077
                                                          + AR(2) errors   AIC                           4128.154
Date:                                                   Tue, 28 Feb 2017   BIC                           4201.344
Time:                                                           21:34:46   HQIC                          4157.052
Sample:                                                       02-01-1979                                         
                                                            - 12-01-2014                                         
Covariance Type:                                                     opg                                         
====================================================================================================
                                       coef    std err          z      P>|z|      [0.025      0.975]
----------------------------------------------------------------------------------------------------
loading.f1.std_indprod              -0.8749      0.022    -39.083      0.000      -0.919      -0.831
loading.f1.std_income               -0.2675      0.046     -5.873      0.000      -0.357      -0.178
loading.f1.std_sales                -0.4953      0.026    -19.362      0.000      -0.545      -0.445
loading.f1.std_emp                  -0.2951      0.030     -9.675      0.000      -0.355      -0.235
sigma2.std_indprod                   0.0009      0.001      0.982      0.326      -0.001       0.003
sigma2.std_income                    0.8937      0.029     31.233      0.000       0.838       0.950
sigma2.std_sales                     0.5880      0.034     17.393      0.000       0.522       0.654
sigma2.std_emp                       0.3677      0.015     24.828      0.000       0.339       0.397
L1.f1.f1                             0.2433      0.038      6.454      0.000       0.169       0.317
L2.f1.f1                             0.2938      0.043      6.872      0.000       0.210       0.378
L1.e(std_indprod).e(std_indprod)    -1.1532      0.014    -83.507      0.000      -1.180      -1.126
L2.e(std_indprod).e(std_indprod)    -0.9851      0.014    -70.299      0.000      -1.013      -0.958
L1.e(std_income).e(std_income)      -0.1878      0.022     -8.370      0.000      -0.232      -0.144
L2.e(std_income).e(std_income)      -0.0863      0.047     -1.831      0.067      -0.179       0.006
L1.e(std_sales).e(std_sales)        -0.4151      0.042     -9.794      0.000      -0.498      -0.332
L2.e(std_sales).e(std_sales)        -0.1730      0.049     -3.522      0.000      -0.269      -0.077
L1.e(std_emp).e(std_emp)             0.2935      0.032      9.053      0.000       0.230       0.357
L2.e(std_emp).e(std_emp)             0.4882      0.028     17.232      0.000       0.433       0.544
========================================================================================================
Ljung-Box (Q):          50.91, 28.81, 53.61, 61.18   Jarque-Bera (JB):   15.75, 12973.87, 14.41, 3133.84
Prob(Q):                    0.12, 0.91, 0.07, 0.02   Prob(JB):                    0.00, 0.00, 0.00, 0.00
Heteroskedasticity (H):     0.95, 4.21, 0.47, 0.35   Skew:                      -0.06, -1.20, 0.10, 0.82
Prob(H) (two-sided):        0.74, 0.00, 0.00, 0.00   Kurtosis:                  3.93, 29.77, 3.87, 16.11
========================================================================================================




##Estimated factors
#While it can be useful to plot the unobserved factors, 
#it is less useful here than one might think for two reasons:
#    The sign-related identification issue described above.
#    Since the data was differenced, the estimated factor explains the variation in the differenced data, not the original data.


#With these reservations, the unobserved factor is plotted below, 
#along with the NBER indicators for US recessions(= our unobserved factor)

fig, ax = plt.subplots(figsize=(13,3))

# Plot the factor
dates = endog.index._mpl_repr()
#res.factors : Estimates of unobserved factors for each data point 
#factors has four data points - filtered, smoothed - nobs x k_factors 
#filtered_cov, smoothed_cov are covariance matrix 

In general, #any large variations in factor must translate to all endog's large variations 
ax.plot(dates, res.factors.filtered[0], label='Factor')
ax.legend()

# Retrieve and also plot the NBER recession indicators
rec = DataReader('USREC', 'fred', start=start, end=end)
ylim = ax.get_ylim()
ax.fill_between(dates[:-3], ylim[0], ylim[1], rec.values[:-4,0], facecolor='k', alpha=0.1);
plt.show()

#R^2 value of fitting of each y with Factors 
>>> res.coefficients_of_determination
array([[0.9613],     #R^2 of fitting of factor1 with 'std_indprod'
       [0.0706],     #R^2 of fitting of factor1 with 'std_income'
       [0.3092],     #R^2 of fitting of factor1 with 'std_sales'
       [0.3507]])    #R^2 of fitting of factor1 with 'std_emp'
res.plot_coefficients_of_determination() #display above 
plt.show()


##Coincident Index
# the goal of this model was to create an interpretable series 
#which could be used to understand the current status of the macroeconomy. 

#This is what the coincident index is designed to do. 
#In essense, what is done is to reconstruct the mean of the (differenced) factor.

#We will compare it to the coincident index on published 
#by the Federal Reserve Bank of Philadelphia (USPHCI on FRED).

usphci = DataReader('USPHCI', 'fred', start='1979-01-01', end='2014-12-01')['USPHCI']
usphci.plot(figsize=(13,3));
plt.show(block=False)

dusphci = usphci.diff()[1:].values
def compute_coincident_index(mod, res):
    # Estimate W(1)
    spec = res.specification
    design = mod.ssm['design']
    transition = mod.ssm['transition']
    ss_kalman_gain = res.filter_results.kalman_gain[:,:,-1]
    k_states = ss_kalman_gain.shape[0]

    W1 = np.linalg.inv(np.eye(k_states) - np.dot(
        np.eye(k_states) - np.dot(ss_kalman_gain, design),
        transition
    )).dot(ss_kalman_gain)[0]

    # Compute the factor mean vector
    factor_mean = np.dot(W1, dta.ix['1972-02-01':, 'dln_indprod':'dln_emp'].mean())
    
    # Normalize the factors
    factor = res.factors.filtered[0]
    factor *= np.std(usphci.diff()[1:]) / np.std(factor)

    # Compute the coincident index
    coincident_index = np.zeros(mod.nobs+1)
    # The initial value is arbitrary; here it is set to
    # facilitate comparison
    coincident_index[0] = usphci.iloc[0] * factor_mean / dusphci.mean()
    for t in range(0, mod.nobs):
        coincident_index[t+1] = coincident_index[t] + factor[t] + factor_mean
    
    # Attach dates
    coincident_index = pd.Series(coincident_index, index=dta.index).iloc[1:]
    
    # Normalize to use the same base year as USPHCI
    coincident_index *= (usphci.ix['1992-07-01'] / coincident_index.ix['1992-07-01'])
    
    return coincident_index

#plot the calculated coincident index 
#along with the US recessions and the comparison coincident index USPHCI.

fig, ax = plt.subplots(figsize=(13,3))

# Compute the index
coincident_index = compute_coincident_index(mod, res)

# Plot the factor
dates = endog.index._mpl_repr()
ax.plot(dates, coincident_index, label='Coincident index')
ax.plot(usphci.index._mpl_repr(), usphci, label='USPHCI')
ax.legend(loc='lower right')

# Retrieve and also plot the NBER recession indicators
ylim = ax.get_ylim()
ax.fill_between(dates[:-3], ylim[0], ylim[1], rec.values[:-4,0], facecolor='k', alpha=0.1);
plt.show()



   
    
    


###statsmodel - Generalized method of moments - statsmodels.sandbox.regression.gmm.
# non-parametric 
#This is sandbox module, means not fully tested. Use 'linearmodules' module

#The method requires that a certain number of moment conditions were specified for the model. 
#These moment conditions are functions of the model parameters and the data, 
#such that their expectation is zero at the true values of the parameters. 
E[ z * (y - f(X, beta)] = 0


#The GMM method then minimizes a certain norm of the sample averages of the moment conditions.

#The GMM estimators are known to be consistent, asymptotically normal, and efficient 
GMM(endog, exog, instrument[, k_moms, ...])     Class for estimation by Generalized Method of Moments 
GMMResults(*args, **kwds)                       just a storage class right now 
IV2SLS(endog, exog[, instrument])               Instrumental variables estimation using Two-Stage Least-Squares (2SLS) 
IVGMM(endog, exog, instrument[, k_moms, ...])   Basic class for instrumental variables estimation using GMM 
IVGMMResults(*args, **kwds) 
LinearIVGMM(endog, exog, instrument[, ...])     class for linear instrumental variables models estimated with GMM 
NonlinearIVGMM(endog, exog, instrument, ...)    Class for non-linear instrumental variables estimation wusing GMM 

##Instrumental Variable GMM regression 

exogenous = independent variables ,causally independent from other variables in the system
endogenous = dependent variables,  causal relations with the independent variables
An instrument is a variable that does not itself belong in the explanatory equation 
but is correlated with the endogenous explanatory variables

These models make use of instruments  which are correlated 
with the endogenous variable(Y and regressors) but not with the model error. 
yi=x1iβ1+x2iβ2+ϵi
x2i=z1iδ+z2iγ+νi

x1i is a set of k1 regressors that are exogenous(independent) 
while x2i is a set of k2 regressors (k=k1+k2)
that are endogenous in the sense that Cov(x2i,ϵi)≠0. 
In total there are The k regressors in the model. 

The p2 element vector z2i are instruments that explain x2i but not yi. 

x1i and z1i are the same since variables are also valid to use 
when projecting the endogenous variables. 

In total there are p=p1+p2=k1+p2 variables available to use 
when projecting the endogenous regressors.

Total DataFrame length = k1 U k2 U p2 
and x1i(=z1i) and z2i are truely exogenous


#In statsmodel 
yi=x1iβ1+x2iβ2+ϵi
x2i=z1iδ+z2iγ+νi
endog          yi in the model
exog           x1i and x2i(included endogenous), k regressors in the model.
instruments    z1i(=x1i,included exogenous) + z2i(excluded exogenous) in the model, 
               
#Example 
griliches76_data['const'] = 1
endog = griliches76_data['lw']
exog = griliches76_data[[ 's', 'iq', 'const','expr', 'tenure', 'rns',
                       'smsa', 'D_67', 'D_68', 'D_69', 'D_70',
                       'D_71', 'D_73']])
instrument = griliches76_data[['const', 'expr', 'tenure', 'rns', 'smsa', 
                       'D_67', 'D_68', 'D_69', 'D_70', 'D_71',
                       'D_73', 'med', 'kww', 'age', 'mrt']])

#means - |, -, & from set  
yi = 'lw'
x1i = exog & instrument = 'const','expr', 'tenure', 'rns','smsa', 'D_67', 'D_68', 'D_69', 'D_70','D_71', 'D_73'
x2i = exog - instrument = 's', 'iq'
z1i = x1i =  'const','expr', 'tenure', 'rns','smsa', 'D_67', 'D_68', 'D_69', 'D_70','D_71', 'D_73'
z2i = instrument - exog = 'med', 'kww', 'age', 'mrt'
#in linearmodels(another module) 
dependent = yi = 'lw'
exog = x1i = z1i = 'const','expr', 'tenure', 'rns','smsa', 'D_67', 'D_68', 'D_69', 'D_70','D_71', 'D_73'
endog = x2i = 's', 'iq'
instruments = z2i = 'med', 'kww', 'age', 'mrt'

##class 
class statsmodels.sandbox.regression.gmm.LinearIVGMM(endog, exog, instrument, k_moms=None, k_params=None, missing='none', **kwds)[source]
    The model is assumed to have the following moment condition
    E( z * (y - x*beta)) = 0
class statsmodels.sandbox.regression.gmm.NonlinearIVGMM(endog, exog, instrument, func, **kwds)[source]
    Class for non-linear instrumental variables estimation using GMM
    The model is assumed to have the following moment condition
        E[ z * (y - f(X, beta)] = 0
    Where y is the dependent endogenous variable, 
    x are the explanatory variables and z are the instruments.
    f is a nonlinear function. 
    Parameters:	
    endog : array_like
        dependent endogenous variable
    exog : array_like
        explanatory, right hand side variables, 
        including explanatory variables that are endogenous.
    instruments : array_like
        Instrumental variables, 
        variables that are exogenous to the error in the linear model 
        containing both included and excluded exogenous variables
    func : callable
        function for the mean or conditional expectation of the endogenous variable.
        The function will be called with parameters 
        and the array of explanatory, right hand side variables, 
        func(params, exog) should return predicted value based on exog and params 
        Note params shape comes from fit's start_params
        if fit_start=None, then below is used 
        np.zeros(exog.shape[1])
NonlinearIVGMM.fit(start_params=None, maxiter=10, inv_weights=None, 
        weights_method='cov', wargs=(), has_optimal_weights=True, 
        optim_method='bfgs', optim_args=None)
    Estimate parameters using GMM and return GMMResults
    inv_weights
        for IV subclasses inv_weights = z'z where z are the instruments, 
        otherwise an identity matrix is used.    
    weights_method : string, defines method for robust
        Options here are similar to statsmodels.stats.robust_covariance 
        default is heteroscedasticity consistent, HC0
        currently available methods are
            cov : HC0, optionally with degrees of freedom correction
            hac :
            iid : untested, only for Z*u case, IV cases with u as error indep of Z
            ac : not available yet
            cluster : not connected yet
            others from robust_covariance
    wargs` : tuple or dict,
        required and optional arguments for weights_method
            centered : bool, indicates whether moments are centered for the calculation of the weights and covariance matrix, applies to all weight_methods
            ddof : int degrees of freedom correction, applies currently only to cov
            maxlag : int number of lags to include in HAC calculation , applies only to hac
            others not yet, e.g. groups for cluster robust
        
    
class statsmodels.sandbox.regression.gmm.IVGMMResults(*args, **kwds)
    Attributes
        bse_ 	                standard error of the parameter estimates
    Methods
        bse() 	
        calc_cov_params(moms, gradmoms[, weights, ...]) 	calculate covariance of parameter estimates
        compare_j(other) 	                                overidentification test for comparing two nested gmm estimates
        conf_int([alpha, cols, method]) 	                Returns the confidence interval of the fitted parameters.
        cov_params([r_matrix, column, scale, cov_p, ...]) 	Returns the variance/covariance matrix.
        f_test(r_matrix[, cov_p, scale, invcov]) 	        Compute the F-test for a joint linear hypothesis.
        fittedvalues() 	
        get_bse(**kwds) 	                      standard error of the parameter estimates with options
        initialize(model, params, **kwd) 	
        jtest() 	                              overidentification test
        jval() 	
        llf() 	
        load(fname) 	                          load a pickle, (class method)
        normalized_cov_params() 	
        predict([exog, transform]) 	               Call self.model.predict with self.params as the first argument.
        pvalues() 	
        q() 	
        remove_data() 	                            remove data arrays, all nobs arrays from result and model
        resid() 	
        save(fname[, remove_data]) 	                save a pickle of this instance
        ssr() 	
        summary([yname, xname, title, alpha]) 	    Summarize the Regression Results
        t_test(r_matrix[, cov_p, scale, use_t]) 	Compute a t-test for a each linear hypothesis of the form Rb = q
        tvalues() 	                                Return the t-statistic for a given parameter estimate.
        wald_test(r_matrix[, cov_p, scale, invcov, ...]) 	Compute a Wald-test for a joint linear hypothesis.
        wald_test_terms([skip_single, ...]) 	    Compute a sequence of Wald tests for terms over multiple columns



##Example -Euler equations in rational expectation models
# solving E[z *(y- f(params,x))] = 0
#where y = 1, f = beta*(1+R_at_t+1)(c_at_t+1/c_at_t)**(-gamma)
#params = [beta, gamma]
#beta is the discount factor of the agent, 
#and gamma is the coefficient reflecting constant relative risk aversion. 
#R is a rate of return on assets or interest rate, c is consumption


import numpy as np
import pandas as pd

from statsmodels.sandbox.regression import gmm
dta = pd.read_csv('data/consumption.csv', parse_dates=[0])
>>> print (dta.iloc[:5])
                  qtr       r       c
0 1947-01-01 00:00:00  0.0038  1017.2
1 1947-04-01 00:00:00  0.0038  1034.0
2 1947-07-01 00:00:00  0.0066  1037.5
3 1947-10-01 00:00:00  0.0085  1037.7
4 1948-01-01 00:00:00  0.0097  1042.6


dta['c_growth'] = dta['c'] / dta['c'].shift(1)
dta['c_growth_lag1'] = dta['c_growth'].shift(1)
dta['r_lag1'] = dta['r'].shift(1)
dta['r_lag2'] = dta['r'].shift(2)
dta['r_forw1'] = dta['r'].shift(-1)
dta['c_lag1'] = dta['c'].shift(1)
dta['c_forw1'] = dta['c'].shift(-1)
dta['const'] = 1

dta_clean = dta.dropna()


#yi=x1iβ1+x2iβ2+ϵi
#x2i=z1iδ+z2iγ+νi
#yi = coming in later section
#x1i = exog & instrument = Null 
#x2i = exog - instrument = 'r_forw1', 'c_forw1', 'c'
#z1i = x1i = Null 
#z2i = instrument - exog = 'r_lag1', 'r_lag2', 'c_growth', 'c_growth_lag1','const'

endog_df = dta_clean[['r_forw1', 'c_forw1', 'c']]
exog_df = dta_clean[['r_forw1', 'c_forw1', 'c']]
instrument_df = dta_clean[['r_lag1', 'r_lag2', 'c_growth', 'c_growth_lag1','const']]
endog, exog, instrument  = list(map(np.asarray, [endog_df, exog_df, instrument_df]))



##Version-1 , use endog = 0 
#but manually taking  1- f(x,params) in function 
def func1(params, exog): #starts_param= [1,1] =[beta, gama]
    beta, gamma = params
    r_forw1, c_forw1, c = exog.T  # 'r_forw1', 'c_forw1', 'c'
    # moment condition without instrument    
    err = 1 - beta * (1 + r_forw1) * np.power(c_forw1 / c, -gamma)
    return -err
    
    
endog1 = np.zeros(exog.shape[0])    
#k_moms = number of moment conditions, 
#if None then it is set equal to the number of columns of instruments
mod1 = gmm.NonlinearIVGMM(endog1, exog, instrument, func1, k_moms=4)
w0inv = np.dot(instrument.T, instrument) / len(endog1)
res1 = mod1.fit([1,-1], maxiter=2, inv_weights=w0inv) 
#output 
Optimization terminated successfully.
         Current function value: 0.000539
         Iterations: 6
         Function evaluations: 23
         Gradient evaluations: 23
Optimization terminated successfully.
         Current function value: 0.152609
         Iterations: 6
         Function evaluations: 11
         Gradient evaluations: 11
#Here params are beta, gamma , renamed to discount, CRRA
>>> print(res1.summary(yname='Euler Eq', xname=['discount', 'CRRA']))
                            NonlinearIVGMM Results                            
==============================================================================
Dep. Variable:               Euler Eq   Hansen J:                        36.47
Model:                 NonlinearIVGMM   Prob (Hansen J):              1.20e-08
Method:                           GMM                                         
Date:                Wed, 25 Dec 2013                                         
Time:                        20:08:33                                         
No. Observations:                 239                                         
==============================================================================
                 coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
discount       0.8977      0.017     52.860      0.000         0.864     0.931
CRRA          -6.7953      2.050     -3.315      0.001       -10.813    -2.778
==============================================================================

##overidentification test
#overidentification - When the number of moment conditions is greater 
#than the dimension of the params vector 
#Over-identification allows us to check 
#whether the model's moment conditions match the data well or not.
#H0: model is valid ie  instruments are valid for this model
#rejecting H0 means , correctly specify instruments or model 
>>> res1.jtest()
(36.510482051328154, 1.1799118334705946e-08, 2) #(stats, p-value, df)
#Note df = where q - p, measures the degree of overidentification
#q = no of moments equation, p= no of paramters 



#Use a HAC robust standard error, that is robust to heteroscedasticity as well as autocorrelation.
#define these options through weights_method='hac', wargs={'maxlag':4}, which uses the Newey, West standard errors based on 4 lags.

res1_hac4_2s = mod1.fit([1, -1], maxiter=2, inv_weights=w0inv, weights_method='hac', wargs={'maxlag':4})
>>> print(res1_hac4_2s.summary(yname='Euler Eq', xname=['discount', 'CRRA']))
Optimization terminated successfully.
         Current function value: 0.000539
         Iterations: 6
         Function evaluations: 23
         Gradient evaluations: 23
Optimization terminated successfully.
         Current function value: 0.055395
         Iterations: 5
         Function evaluations: 10
         Gradient evaluations: 10
                            NonlinearIVGMM Results                            
==============================================================================
Dep. Variable:               Euler Eq   Hansen J:                        13.24
Model:                 NonlinearIVGMM   Prob (Hansen J):               0.00133
Method:                           GMM                                         
Date:                Wed, 25 Dec 2013                                         
Time:                        20:08:33                                         
No. Observations:                 239                                         
==============================================================================
                 coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
discount       0.9213      0.014     67.281      0.000         0.894     0.948
CRRA          -4.1136      1.507     -2.729      0.006        -7.068    -1.160
==============================================================================

##version 2, endog = 1, 
#then func2 returns predicted portion of the equation 

def func2(params, exog):
    beta, gamma = params
    #endog, exog = args
    r_forw1, c_forw1, c = exog.T  # unwrap iterable (ndarray)    
    # 2nd part of moment condition without instrument    
    predicted = beta * (1. + r_forw1) * np.power(c_forw1 / c, -gamma)
    return predicted
    
endog2 = np.ones(exog.shape[0])    
mod2 = gmm.NonlinearIVGMM(endog2, exog, instrument, func2, k_moms=4)
w0inv = np.dot(instrument.T, instrument) / len(endog2)  
res2_hac4_2s = mod2.fit([1,-1], maxiter=2, inv_weights=w0inv, weights_method='hac', wargs={'maxlag':4})
>>> print(res2_hac4_2s.summary(yname='Euler Eq', xname=['discount', 'CRRA']))
                            NonlinearIVGMM Results                            
==============================================================================
Dep. Variable:               Euler Eq   Hansen J:                        13.24
Model:                 NonlinearIVGMM   Prob (Hansen J):               0.00133
Method:                           GMM                                         
Date:                Wed, 25 Dec 2013                                         
Time:                        20:08:33                                         
No. Observations:                 239                                         
==============================================================================
                 coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
discount       0.9213      0.014     67.281      0.000         0.894     0.948
CRRA          -4.1136      1.507     -2.729      0.006        -7.068    -1.160
==============================================================================

##Compare
>>> res1_hac4_2s.params
array([ 0.92129628, -4.11361243])
>>> res2_hac4_2s.params
array([ 0.92129628, -4.11361243])
>>> res1_hac4_2s.params - res2_hac4_2s.params, np.max(np.abs(res1_hac4_2s.params - res2_hac4_2s.params))
(array([  3.27948779e-12,   3.71550790e-10]), 3.7155079013473369e-10)

#using centered = False as a weights argument:
res_ = mod2.fit([1,-1], maxiter=2, inv_weights=w0inv, weights_method='hac', 
                wargs={'maxlag':4, 'centered':False}, optim_args={'disp':0})
print(res_.params)
print(res_.bse)
[ 0.92045263 -4.22337303]
[ 0.01345577  1.47341411]




##Example - Poisson: Maximum Likelihood and General Method of Moments
#for docvis of docvisits data 
#Note Poisson model defines E[z*(y−exp(x*beta)]=0
#Hence in terms of GMM f(params, x) = exp(x'*params), where params= beta 

import numpy as np
import pandas as pd
from statsmodels.sandbox.regression import gmm
dta2 = pd.read_csv('data/docvisits.csv')
>>> print(dta2.iloc[:5])
   docvis  age     income  female  black  hispanic  married  physlim  private  \
0       0  3.9  30.000000       1      0         1        1        0        1   
1       1  4.7  10.000000       0      0         1        1        0        1   
2      15  2.7  27.000000       1      0         0        0        0        1   
3       0  3.0  11.250000       0      0         0        1        0        0   
4       2  5.4  76.330002       1      0         0        1        0        1   
   chronic  
0        0  
1        0  
2        1  
3        0  
4        0  

dta_clean2 = dta2
dta_clean2['const'] = 1
dta_clean2['income'] *= 0.1  # rescale to have values into similar ranges

#yi=x1iβ1+x2iβ2+ϵi
#x2i=z1iδ+z2iγ+νi
#yi = docvis
#x1i = exog & instrument = 'private', 'chronic', 'female', 'const'
#x2i = exog - instrument = 'income'
#z1i = x1i = 'private', 'chronic', 'female', 'const'
#z2i = instrument - exog = 'age', 'black','hispanic'

endog_df = dta_clean2[['docvis']]
exog_names = ['private', 'chronic', 'female', 'income', 'const']
exog_df = dta_clean2[exog_names]
instrument_df = dta_clean2[['private', 'chronic', 'female', 'age', 'black',              
                           'hispanic', 'const']]
endog, exog, instrument  = map(np.asarray, [endog_df, exog_df, instrument_df])
endog = np.squeeze(endog)


##Maximum Likelihood Estimation MLE
#Poisson is a standard maximum likelihood estimator 
#that assumes that observations are independent, 
#and that explanatory variables are exogenous (i.e. without measurement or endogeneity error)

from statsmodels.discrete.discrete_model import Poisson
res_poisson = Poisson(endog, exog).fit()
>>> print(res_poisson.summary(yname='docvisits', xname=exog_names))
Optimization terminated successfully.
         Current function value: 4.193914
         Iterations 12
                          Poisson Regression Results                          
==============================================================================
Dep. Variable:              docvisits   No. Observations:                 4412
Model:                        Poisson   Df Residuals:                     4407
Method:                           MLE   Df Model:                            4
Date:                Wed, 25 Dec 2013   Pseudo R-squ.:                  0.1930
Time:                        14:50:25   Log-Likelihood:                -18504.
converged:                       True   LL-Null:                       -22930.
                                        LLR p-value:                     0.000
==============================================================================
                 coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
private        0.7987      0.028     28.813      0.000         0.744     0.853
chronic        1.0919      0.016     69.112      0.000         1.061     1.123
female         0.4925      0.016     30.770      0.000         0.461     0.524
income         0.0356      0.002     14.750      0.000         0.031     0.040
const         -0.2297      0.029     -8.004      0.000        -0.286    -0.173
==============================================================================

##Version-1 : GMM with instruments = exog , no new Z2i

def moment_exponential(params, exog, exp=True): #params.shape = from fit's starts_param
    # moment condition without instrument
    if exp:
        predicted = np.exp(np.dot(exog, params))
    else:
        predicted = np.dot(exog, params)    
    #try to avoid runaway optimizers that cannot handle nans
    if np.isnan(predicted).any():
        raise ValueError('nans in predicted')
    return predicted

mod_ex = gmm.NonlinearIVGMM(endog, exog, exog, moment_exponential)
w0exinv = np.dot(exog.T, exog) / len(endog)
#start_params.shape = exog.shape[1] ie # of columns in exog 
start_params = 0.1 + np.zeros(exog.shape[1])
res_ex0 = mod_ex.fit(start_params, maxiter=0, inv_weights=w0exinv, optim_method='nm')
res_ex = mod_ex.fit(res_ex0.params, maxiter=0, inv_weights=w0exinv, optim_method='bfgs')

>>> print(res_ex.summary(yname='docvisits', xname=exog_names))
                            NonlinearIVGMM Results                            
==============================================================================
Dep. Variable:              docvisits   Hansen J:                    2.193e-10
Model:                 NonlinearIVGMM   Prob (Hansen J):                   nan
Method:                           GMM                                         
Date:                Wed, 25 Dec 2013                                         
Time:                        14:50:25                                         
No. Observations:                4412                                         
==============================================================================
                 coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
private        0.7987      0.109      7.328      0.000         0.585     1.012
chronic        1.0919      0.056     19.501      0.000         0.982     1.202
female         0.4925      0.059      8.415      0.000         0.378     0.607
income         0.0356      0.011      3.286      0.001         0.014     0.057
const         -0.2297      0.111     -2.072      0.038        -0.447    -0.012
==============================================================================

#Compare 
print(res_poisson.params)
print(res_ex.params)
[ 0.79866538  1.09186511  0.49254807  0.03557013 -0.22972634]
[ 0.79866522  1.09186505  0.49254798  0.03557012 -0.22972605]

>>> print(res_ex.params - res_poisson.params)
[ -1.60226566e-07  -5.64773353e-08  -9.39717644e-08  -4.27707619e-09
   2.90754947e-07]

#Standard deviation 
print(res_poisson.bse)
print(res_ex.bse)
print(res_ex.bse - res_poisson.bse)
[ 0.02771898  0.01579852  0.01600728  0.0024115   0.02870217]
[ 0.10898908  0.05598878  0.05852984  0.01082366  0.11086067]
[ 0.08127009  0.04019027  0.04252255  0.00841216  0.0821585 ]


##Homoscedasticity, Heteroscedasticity and Overdispersion
#In the Poisson model the variance is equal to the mean. 
#The Maximum Likelihood Estimator in discrete.Poisson imposes this assumption. 
#In contrast GMM with heteroscedasticity robust standard errors does not impose 
#any assumption on the variance of the error term. 

#In between these two extrems are overdispersed Poisson or exponential models 
#that assume that the variance is the same as in the Poisson Model 
#however can have a scale factor larger than one.

#However, the assumption on the variance do not affect the parameter estimates in this case, but will affect the estimated covariance of the parameter estimates. We can consistently estimate the mean or conditional expectation of the endogenous variable, however other properties of the conditional distribution of the endogenous variable depend on the assumption of correctly specified higher moments.
#The scale, that is the variance scale factor, based on the MLE of the Poisson model is one.
>>> res_poisson.scale
1.0

#However, We can estimate the scale and standard deviation 
#based on the residuals of the Poisson MLE estimation, 
#which is in this case 3.6 
#and indicates that there is considerable overdispersion

fittedvalues = res_poisson.predict(linear=False)  #attribute is currently linear prediction :(
resid_pearson = res_poisson.resid / np.sqrt(fittedvalues)
scale = (resid_pearson**2).mean()
>>> scale, np.sqrt(scale), resid_pearson.std()
(12.947923548090147, 3.5983223240963484, 3.5983077409797635)

#In GMM, we can replicate OLS results with GMM 
#if we specify 'iid' as the weights method. 
#This assumes that the variance of error term is uncorrelated or independent of the explanatory variables, 
#but it also assumes that this variance is constant. 
#The latter is, however, not the case for the Poisson/Exponential model, so it does not replicate the MLE standard errors.
res_ex_iid = mod_ex.fit(res_ex.params, maxiter=0, inv_weights=w0exinv,
                    weights_method='iid',
                    optim_method='bfgs', optim_args={'disp':False})
print(res_ex_iid.params)
print(res_ex_iid.bse)
[ 0.79866522  1.09186505  0.49254798  0.03557012 -0.22972605]
[ 0.15455798  0.06488262  0.06341369  0.00791076  0.17186891]


##Version-2 Endogeneity and Instrumental Variables
#note income as a explanatory variable in exog, which might have "measurement errors".
#If income is correlated with the residual, then using Poisson, 
#the maximum likelihood estimator, 
#and GMM without instruments will report biased estimates.

mod = gmm.NonlinearIVGMM(endog, exog, instrument, moment_exponential)
w0inv = np.dot(instrument.T, instrument) / len(endog)
start_params = 0.1 + np.zeros(exog.shape[1])
res0 = mod.fit(start_params, maxiter=0, inv_weights=w0inv, optim_method='nm')
res = mod.fit(res0.params, maxiter=2, inv_weights=w0inv, optim_method='bfgs')   
>>> print(res.params)
[ 0.53532318  1.09015077  0.66367986  0.1428607  -0.59840238]
>>> print(res.summary(yname='docvisits', xname=exog_names))
                            NonlinearIVGMM Results                            
==============================================================================
Dep. Variable:              docvisits   Hansen J:                        9.529
Model:                 NonlinearIVGMM   Prob (Hansen J):               0.00853
Method:                           GMM                                         
Date:                Wed, 25 Dec 2013                                         
Time:                        14:50:26                                         
No. Observations:                4412                                         
==============================================================================
                 coef    std err          z      P>|z|      [95.0% Conf. Int.]
------------------------------------------------------------------------------
private        0.5353      0.160      3.348      0.001         0.222     0.849
chronic        1.0902      0.062     17.650      0.000         0.969     1.211
female         0.6637      0.096      6.915      0.000         0.476     0.852
income         0.1429      0.027      5.261      0.000         0.090     0.196
const         -0.5984      0.138     -4.323      0.000        -0.870    -0.327
==============================================================================

#The effect of income is now 0.1429 which is much larger 
#than the effect estimated using MLE, which was 0.0356

#Note below 
Prob (Hansen J):               0.00853
#H0: model is valid , < 0.05, this model is not valid 
#Overidentification: When the number of moment conditions is greater 
#than the dimension of the params vector 







  