import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline
from sklearn import datasets
import time 

from sklearn.ensemble import *  
from sklearn.tree import *

print("------------------------ Before prune ---------")
X, y = datasets.make_classification(n_samples=1000,
                           n_features=6,
                           n_informative=3,
                           n_classes=2,
                           random_state=0,
                           shuffle=False)

# Creating a dataFrame
df = pd.DataFrame({'Feature 1':X[:,0],
                                  'Feature 2':X[:,1],
                                  'Feature 3':X[:,2],
                                  'Feature 4':X[:,3],
                                  'Feature 5':X[:,4],
                                  'Feature 6':X[:,5],
                                  'Class':y})

X_train, X_test, y_train, y_test = train_test_split(df.drop('Class',axis = 1), df['Class'], random_state=0)

clf = DecisionTreeClassifier( random_state=42)                
clf.fit(X_train, y_train)
print("Training accuracy",clf.score(X_train, y_train))
print("Test accuracy",clf.score(X_test,y_test))

cv = StratifiedKFold(n_splits=5, shuffle=True)
vals = cross_val_score(clf, 
    df.drop('Class',axis = 1), df['Class'], cv=cv)
print("cross validated score %3.2f +/- %3.2f" % (vals.mean(),vals.std()) )


print("before post_prune", sum(clf.tree_.children_left < 0)) #74


import graphviz 
dot_data = export_graphviz(clf, out_file=None, 
                         feature_names=X_train.columns,                       
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = graphviz.Source(dot_data)  
print("Generated non_pruned.pdf for visualization ")
graph.render('non_pruned') #'non_pruned.pdf'

##post-prune 
#wg remove all children of the nodes with minimum class count less that 5 
#(or any other condition you can think of).
 
print("------------------------ After prune ---------")
print("remove all children of the nodes with minimum class count less that 5 ")
from sklearn.tree._tree import TREE_LEAF

#root index =0, left_first_child = 1, right_first_child= N 
#where N is number after exhausting all left_first_child descendants in breath_first manner
#inner_tree.value[index] would give that node's values = ndarray([[class1_Count, class2_Count, ...]]) = Samples
def prune_index(inner_tree, index, threshold):
    if inner_tree.value[index].min() < threshold:
        # turn node into a leaf by "unlinking" its children
        inner_tree.children_left[index] = TREE_LEAF
        inner_tree.children_right[index] = TREE_LEAF
    # if there are children, visit them as well
    if inner_tree.children_left[index] != TREE_LEAF:
        prune_index(inner_tree, inner_tree.children_left[index], threshold)
        prune_index(inner_tree, inner_tree.children_right[index], threshold)

# start pruning from the root
prune_index(clf.tree_, 0, 5)
print("After post_prune", sum(clf.tree_.children_left < 0)) #94
#code has created 17 new leaf nodes (by practically removing links to their ancestors).

print("Training accuracy",clf.score(X_train, y_train))
print("Test accuracy",clf.score(X_test,y_test))
cv = StratifiedKFold(n_splits=5, shuffle=True)
vals = cross_val_score(clf, 
    df.drop('Class',axis = 1), df['Class'], cv=cv)
print("cross validated score %3.2f +/- %3.2f" % (vals.mean(),vals.std()) )

import graphviz 
dot_data = export_graphviz(clf, out_file=None, 
                         feature_names=X_train.columns,                       
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = graphviz.Source(dot_data)  
print("Generated pruned.pdf for visualization ")
graph.render('pruned_based_low_class_count') #'non_pruned.pdf'

'''
#Or the condition could be 
#Prune children if both children are leaves now and make the same decision: 
#(not applicable here..)

clf = DecisionTreeClassifier( random_state=42)                
clf.fit(X_train, y_train)

from sklearn.tree._tree import TREE_LEAF

def is_leaf(inner_tree, index):
    # Check whether node is leaf node
    return (inner_tree.children_left[index] == TREE_LEAF and 
            inner_tree.children_right[index] == TREE_LEAF)

def prune_index(inner_tree, decisions, index=0):
    # Start pruning from the bottom - if we start from the top, we might miss
    # nodes that become leaves during pruning.
    # Do not use this directly - use prune_duplicate_leaves instead.
    if not is_leaf(inner_tree, inner_tree.children_left[index]):
        prune_index(inner_tree, decisions, inner_tree.children_left[index])
    if not is_leaf(inner_tree, inner_tree.children_right[index]):
        prune_index(inner_tree, decisions, inner_tree.children_right[index])

    # Prune children if both children are leaves now and make the same decision:     
    if (is_leaf(inner_tree, inner_tree.children_left[index]) and
        is_leaf(inner_tree, inner_tree.children_right[index]) and
        (decisions[index] == decisions[inner_tree.children_left[index]]) and 
        (decisions[index] == decisions[inner_tree.children_right[index]])):
        # turn node into a leaf by "unlinking" its children
        inner_tree.children_left[index] = TREE_LEAF
        inner_tree.children_right[index] = TREE_LEAF
        ##print("Pruned {}".format(index))

def prune_duplicate_leaves(mdl):
    # Remove leaves if both 
    decisions = mdl.tree_.value.argmax(axis=2).flatten().tolist() # Decision for each node
    prune_index(mdl.tree_, decisions)

print("Prune children if both children are leaves now and make the same decision(NA here)")
prune_duplicate_leaves(clf)

print("Training accuracy",clf.score(X_train, y_train))
print("Test accuracy",clf.score(X_test,y_test))
cv = StratifiedKFold(n_splits=5, shuffle=True)
vals = cross_val_score(clf, 
    df.drop('Class',axis = 1), df['Class'], cv=cv)
print("cross validated score %3.2f +/- %3.2f" % (vals.mean(),vals.std()) )

import graphviz 
dot_data = export_graphviz(clf, out_file=None, 
                         feature_names=X_train.columns,                       
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = graphviz.Source(dot_data)  
print("Generated pruned.pdf for visualization ")
graph.render('pruned_based_on_same_decision') #'non_pruned.pdf'
'''