"""
==========================================================
Nearest Neighbors Classification of Iris data set 
==========================================================

Sample usage of Nearest Neighbors classification.
It will plot the decision boundaries for each class(of 3 classes)
ie for each point in a 2D plan, what would be the predicted class for that point 
This shows the seperation of predicated class 


The basic nearest neighbors classification uses uniform weights: 
that is, the value assigned to a query point is computed 
from a simple majority vote of the nearest neighbors. 
The default value, weights = 'uniform', assigns uniform weights 
to each neighbor. 

Under some circumstances, it is better to weight the neighbors 
such that nearer neighbors contribute more to the fit. 
weights = 'distance' assigns weights proportional 
to the inverse of the distance from the query point. 


"""
print(__doc__)

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn import neighbors, datasets

n_neighbors = 15

# import some data to play with
iris = datasets.load_iris()

# we only take the first two features. We could avoid this ugly
# slicing by using a two-dim dataset
X = iris.data[:, :2]
y = iris.target

h = .02  # step size in the mesh

# Create color maps
cmap_light = ListedColormap(['#FFAAAA', '#AAFFAA', '#AAAAFF'])
cmap_bold = ListedColormap(['#FF0000', '#00FF00', '#0000FF'])

fig, ax = plt.subplots(1,2)

print("""
Plot the decision boundary. 
For that, we will assign a color to each
point in the mesh [x_min, x_max]x[y_min, y_max] by using plt.pcolormesh
Note plot can be only 2D, hence take only two features 
""")

for i,weights in enumerate(['uniform', 'distance']):
    # we create an instance of Neighbours Classifier and fit the data.
    clf = neighbors.KNeighborsClassifier(n_neighbors, weights=weights)
    clf.fit(X, y)

    #Plot the decision boundary. 
    #For that, we will assign a color to each
    # point in the mesh [x_min, x_max]x[y_min, y_max].
    #Note plot can be only 2D, hence take only two columns 
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))
    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])

    # Put the result into a color plot
    Z = Z.reshape(xx.shape)
    ax[i].pcolormesh(xx, yy, Z, cmap=cmap_light)

    # Plot also the training points
    ax[i].scatter(X[:, 0], X[:, 1], c=y, cmap=cmap_bold,
                edgecolor='k', s=20)
    ax[i].set_xlim(xx.min(), xx.max())
    ax[i].set_ylim(yy.min(), yy.max())
    ax[i].set_title("3-Class classification (k = %i, weights = '%s')"
              % (n_neighbors, weights))

plt.show()
