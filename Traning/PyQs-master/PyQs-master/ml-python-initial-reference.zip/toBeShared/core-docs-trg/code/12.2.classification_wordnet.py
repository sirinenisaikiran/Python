
from nltk.corpus import wordnet

print("""
Synset is a special kind of a simple interface that is present in NLTK 
to look up words in WordNet.
Synset instances are the groupings of synonymous words 
that express the same concept. 

Eg, for 'Program' synset name:
""")

syns = wordnet.synsets("program")
print(syns[0].name())
#plan.n.01

print("and the word:", syns[0].lemmas()[0].name())
#plan

print("Definition of that first synset:")
print(syns[0].definition())

print("Examples of the word in use:")
print(syns[0].examples())
#['they drew up a six-step plan', 'they discussed plans for a new bond issue']

print("synonyms and antonyms of 'good':")
synonyms = []
antonyms = []

for syn in wordnet.synsets("good"):
    for l in syn.lemmas():
        synonyms.append(l.name())
        if l.antonyms():
            antonyms.append(l.antonyms()[0].name())

print(set(synonyms))
print(set(antonyms))
#{'beneficial', 'just', 'upright', 'thoroughly', 'in_force', 'well', 'skilful', 'skillful', 'sound', 'unspoiled', 'expert', 'proficient', 'in_effect', 'honorable', 'adept', 'secure', 'commodity', 'estimable', 'soundly', 'right', 'respectable', 'good', 'serious', 'ripe', 'salutary', 'dear', 'practiced', 'goodness', 'safe', 'effective', 'unspoilt', 'dependable', 'undecomposed', 'honest', 'full', 'near', 'trade_good'} {'evil', 'evilness', 'bad', 'badness', 'ill'}

print("""\n\nuse WordNet to compare the similarity of two words and their tenses"""), 
#by incorporating the Wu and Palmer method for semantic related-ness

print('Eg, compare the noun of "ship" and "boat":')
w1 = wordnet.synset('ship.n.01')
w2 = wordnet.synset('boat.n.01')
print(w1.wup_similarity(w2))
#0.9090909090909091
print('Eg, compare the noun of "ship" and "car":')
w1 = wordnet.synset('ship.n.01')
w2 = wordnet.synset('car.n.01')
print(w1.wup_similarity(w2))
#0.6956521739130435
print('Eg, compare the noun of "ship" and "cat":')
w1 = wordnet.synset('ship.n.01')
w2 = wordnet.synset('cat.n.01')
print(w1.wup_similarity(w2))
#0.38095238095238093

print("""
One example of using wordnet for movie classifiction - positive or negative reviews
using Movie Reviews corpus 

Movie Reviews Corpus, which categorizes each review as positive or negative.
------------------------------------------------------------------------------------
""")

import nltk
import random
from nltk.corpus import movie_reviews

documents = [(list(movie_reviews.words(fileid)), category)
             for category in movie_reviews.categories()
             for fileid in movie_reviews.fileids(category)]

random.shuffle(documents)
print("one document, document is tuple of list of words and category(neg/pos):")
print(documents[1])

all_words = []
for w in movie_reviews.words():
    if len(w) > 3:
        all_words.append(w.lower())

all_words = nltk.FreqDist(all_words)
print("most common words in all reviews:")
print(all_words.most_common(15))
print("'stupid' frequency ")
print(all_words["stupid"])

TOP_MOST = 3000
TRAIN = 200
#contains the top 3,000 most common words
#each word would become a feature and value would True/False if that word is found in Document(ie list of words)
word_features = list(all_words)[:TOP_MOST]

#function that will find these top 3,000 words in positive and negative documents, 
#marking their presence as either positive or negative:

def find_features(document):
    words = set(document)
    features = {}
    for w in word_features:
        features[w] = (w in words)
    return features

print("\n\nPrint one feature set for negative reviews :")
print("Words vs True/False if that word is found in Document")
#check file cv000_29416.txt, it is a negative review of a film 
print((find_features(movie_reviews.words('neg/cv000_29416.txt'))))

#do this for all of our documents
#saving the feature existence booleans and their respective positive or negative categories by doing:
featuresets = [(find_features(rev), category) for (rev, category) in documents]

#We can split the data with:
training_set = featuresets[:TRAIN]
testing_set = featuresets[TRAIN:]

print("\n\nNow define, and train nltk.NaiveBayesClassifier")
classifier = nltk.NaiveBayesClassifier.train(training_set)
print("Classifier accuracy percent:",(nltk.classify.accuracy(classifier, testing_set))*100)

#predict given a review and it is positive or negative 
review = "The movie is very bad"
featureset_new = find_features(review.split()) 
print(classifier.classify(featureset_new))
review = "The movie is best"
featureset_new = find_features(review.split()) 
print(classifier.classify(featureset_new))

print("\n\nShow first 15 feature importances")
print(classifier.show_most_informative_features(15))

# Most Informative Features
# insulting = True neg : pos = 10.6 : 1.0
# ludicrous = True neg : pos = 10.1 : 1.0
# winslet = True pos : neg = 9.0 : 1.0
# detract = True pos : neg = 8.4 : 1.0
# breathtaking = True pos : neg = 8.1 : 1.0
# silverstone = True neg : pos = 7.6 : 1.0
# excruciatingly = True neg : pos = 7.6 : 1.0
# warns = True pos : neg = 7.0 : 1.0
# tracy = True pos : neg = 7.0 : 1.0
# insipid = True neg : pos = 7.0 : 1.0
# freddie = True neg : pos = 7.0 : 1.0
# damon = True pos : neg = 5.9 : 1.0
# debate = True pos : neg = 5.9 : 1.0
# ordered = True pos : neg = 5.8 : 1.0
# lang = True pos : neg = 5.7 : 1.0

#Save and load 
import pickle 
save_classifier = open("naivebayes.pickle","wb")
pickle.dump(classifier, save_classifier)
save_classifier.close()

classifier_f = open("naivebayes.pickle", "rb")
new_classifier = pickle.load(classifier_f)
classifier_f.close()

