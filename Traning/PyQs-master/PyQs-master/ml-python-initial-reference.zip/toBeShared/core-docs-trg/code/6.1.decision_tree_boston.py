import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline
from sklearn import datasets

from sklearn.ensemble import *  
from sklearn.tree import *

print("------------------------ boston data DecisionTreeRegressor ---------")
boston = datasets.load_boston()
X_train, X_test, y_train, y_test = train_test_split(boston.data, boston.target, random_state=0)

print("With mse")
clf = DecisionTreeRegressor(criterion='mse')
print("check default value of all params") 
print(clf.get_params()  )

clf = clf.fit(X_train, y_train)
predicted = clf.predict(X_test)


print("Training r^",clf.score(X_train, y_train))
print("Test r^2",clf.score(X_test,y_test))

print("Predicted y for test data ...") 
print(predicted)


print("We can get feature importance from DT algorithm")
[print(i,":", j) for i,j in zip(boston.feature_names,clf.feature_importances_) ]

cv = KFold(n_splits=5, shuffle=True)
vals = cross_val_score(DecisionTreeRegressor(criterion='mse'), 
    boston.data, boston.target, cv=cv)
print("cross validated score %3.2f +/- %3.2f" % (vals.mean(),vals.std()) )


import graphviz 
dot_data = export_graphviz(clf, out_file=None, 
                         feature_names=boston.feature_names,                       
                         filled=True, rounded=True,  
                         special_characters=True)  
graph = graphviz.Source(dot_data)  
print("Generated boston.pdf for visualization for mse")
graph.render('boston_mse') #'boston.pdf'


'''
from IPython.display import display, Image
import pydotplus
from sklearn import tree
import os  

os.environ["PATH"] += os.pathsep + 'C:\\Anaconda3\\Library\\bin\\graphviz'

dot_data = tree.export_graphviz(dt, out_file = 'thisIsTheImagetree.dot',
                                    feature_names=boston.feature_names, filled   = True
                                    , rounded  = True
                                    , special_characters = True)

graph = pydotplus.graph_from_dot_file('thisIsTheImagetree.dot')  

thisIsTheImage = Image(graph.create_png())
display(thisIsTheImage)
#print(dt.tree_.feature)

from subprocess import check_call
check_call(['dot','-Tpng','thisIsTheImagetree.dot','-o','thisIsTheImagetree.png'])
'''