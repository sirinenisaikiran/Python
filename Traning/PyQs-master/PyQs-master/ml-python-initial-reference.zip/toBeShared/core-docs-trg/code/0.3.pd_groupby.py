import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

print("""
DataFrame.groupby(by=None, axis=0, level=None, as_index=True, sort=True, group_keys=True, squeeze=False, **kwargs)
    by can be 
        * [g1,g1..,g2,g2] or NumPy array of the same length as the selected axis
        *A dict providing a label -> group name mapping
        *For DataFrame objects, a string indicating a column to be used to group. 
         df.groupby('A') is just syntactic sugar for df.groupby(df['A']), 
        *For DataFrame objects, a column label(axis=0) or index label(axis=1)
        *A list of any of the above things
    axis : default 0, Split along rows/columnwise (0) or columns/rowwise (1)
    
DataFrameGroupBy.agg(arg, *args, **kwargs)
    fun gets each column (excluding grouped column)
    for each unique grouped column  
    Hence func can not access other column for that dataframe 
    Note result is dataframe(including grouped column) hence all data frame's methods can be applied 
    func : Accepted Combinations are:
        *string function name
        *function
        *list of functions
        *dict of column names -> functions (or list of functions)        
DataFrameGroupBy.manyMethods....
    check dir(g)    
g['colName']
    accessing that column's SeriesGroupBy object from whole GroupBy object 
    
    
    
#Rule of thumbs 
*if we want to get a single value for each group -> use grouped.aggregate(f)
 f takes each column as series 
*if we want to get a subset of the input rows -> use grouped.filter(f)
 f takes full DF including grouped column
*if we want to get a new value for each input row -> use grouped.transform(f)
 f takes each column (as Series) of each group one by one 
 (excluding grouped column), hence can not access other columns in function 
*if we want to do advanced operations -> use grouped.apply(f)
 f takes grouped DF(including grouped column) and args, kwrgs 
 and return a dataframe, a series or a scalar. 
 Hence func can access other column for that dataframe 
*for chaining, use grouped.pipe(f)
 f gets full DataFrameGroupBy with it's groupby column as index
 Hence all methods of DataFrameGroupBy can be called 
""")
##String acceptable for apply 
# _common_apply_whitelist = frozenset([
#     'last', 'first',
#     'head', 'tail', 'median',
#     'mean', 'sum', 'min', 'max',
#     'cumcount', 'ngroup',
#     'resample',
#     'rank', 'quantile',
#     'fillna',
#     'mad',
#     'any', 'all',
#     'take',
#     'idxmax', 'idxmin',
#     'shift', 'tshift',
#     'ffill', 'bfill',
#     'pct_change', 'skew',
#     'corr', 'cov', 'diff',
# ]) | _plotting_methods
# 
# _series_apply_whitelist = ((_common_apply_whitelist |
#                             {'nlargest', 'nsmallest'}) -
#                            {'boxplot'}) | frozenset(['dtype', 'unique'])
# 
# _dataframe_apply_whitelist = ((_common_apply_whitelist |
#                               frozenset(['dtypes', 'corrwith'])) -
#                               {'boxplot'})
# 
# ##String acceptable for transforms                       
# _cython_transforms = frozenset(['cumprod', 'cumsum', 'shift',
#                                 'cummin', 'cummax'])
#                                 
# ##String acceptable for aggregate                          
# 'aggregate': {
#             'add': 'group_add',
#             'prod': 'group_prod',
#             'min': 'group_min',
#             'max': 'group_max',
#             'mean': 'group_mean',
#             'median': {
#                 'name': 'group_median'
#             },
#             'var': 'group_var',
#             'first': {
#                 'name': 'group_nth',
#                 'f': lambda func, a, b, c, d, e: func(a, b, c, d, 1, -1)
#             },
#             'last': 'group_last',
#             'ohlc': 'group_ohlc',
#         },
#         
#Example 
df = pd.DataFrame({'Animal' : ['Falcon', 'Falcon','Parrot', 'Parrot'],
                       'Type' : ['fast', 'fast', 'slow', 'slow'],
                    'Max Speed' : [380., 370., 24., 26.]})

g = df.groupby('Animal')
print("", "for DF=", df, "g = df.groupby('Animal')", "Methods:",
[f for f in dir(g) if not f.startswith("_")],
sep="\n")

print("","""
#many methods 
g.mean()
#or 
g.agg('mean')
#or 
g.agg(np.mean)

#get SeriesGroupBy
g['Type'].size() 
g['Type'].agg(np.size)        #count for each , result Series 
g['Type'].agg(np.size).shape  #hence all Series methods can be used 
g['Type'].agg(np.size)['Falcon']
g.agg(np.size)                #results DF 
g.agg(np.size).iloc[0,0]      #hence all DF methods can be used 

>>> g.groups  
{'Falcon': Int64Index([0, 1], dtype='int64'), 'Parrot': Int64Index([2, 3], dtype='int64')}

>>> g.groups['Falcon'].tolist() 
[0,1] #rowindexes for this group

#same in ndarray 
>>> g.indices 
{'Falcon': array([0, 1], dtype=int64), 'Parrot': array([2, 3], dtype=int64)}
>>> g.ngroups 
2
""")

df = pd.DataFrame([['a','a','b','b','c','d', 'c'],
        [1, 3, 5, 7, 9, 2, 4]], index=["alpha", "val"])
        
print("", """
#Axis=1 or with 'by' as list 
df = pd.DataFrame([['a','a','b','b','c','d', 'c'],
        [1, 3, 5, 7, 9, 2, 4]], index=["alpha", "val"])
>>> df
       0  1  2  3  4  5  6
alpha  a  a  b  b  c  d  c
val    1  3  5  7  9  2  4

>>> df.T.groupby('alpha').val.sum()
""", 
df.T.groupby('alpha').val.sum(),
sep="\n")

#alpha
#a     4
#b    12
#c    13
#d     2

print("", """
#for axis=1, specy row by df.loc 
>>> df.groupby(df.loc['alpha'], axis=1).agg(np.sum)
""",
df.groupby(df.loc['alpha'], axis=1).agg(np.sum),
sep="\n")
#alpha   a   b   c  d
#alpha  aa  bb  cc  d
#val     4  12  13  2
print("", """
#with list/Series 
>>> df.loc['val'].groupby(df.loc['alpha']).sum()
""",
df.loc['val'].groupby(df.loc['alpha']).sum(),
sep="\n")
#alpha
#a     4
#b    12
#c    13
#d     2
#Name: val, dtype: int64

                    



zscore = lambda x: (x - x.mean()) / x.std() # Note that it does not reference anything outside of 'x' and for transform 'x' is one column.

print("", """
GroupBy.transform(func, *args, **kwargs)
    func : callable, string, dictionary, or list of string/callables    
        Function would take each column (as Series) of each group one by one 
        (excluding grouped column), hence can not access other columns in function 
        Accepted Combinations are:
            *string function name
            *function
            *list of functions
            *dict of column names -> functions (or list of functions)
    
#Example 
df = 
    A      B         C         D
0  foo    one  0.162003  0.087469
1  bar    one -1.156319 -1.526272
2  foo    two  0.833892 -1.666304
3  bar  three -2.026673 -0.322057
4  foo    two  0.411452 -0.954371
5  bar    two  0.765878 -0.095968
6  foo    one -0.654890  0.678091
7  foo  three -1.789842 -1.130922
""")
#df = pd.read_clipboard()
#df.to_dict()
df = pd.DataFrame.from_dict(
{'B': {0: 'one', 1: 'one', 2: 'two', 3: 'three', 4: 'two', 5: 'two', 6: 'one', 7: 'three'}, 
'D': {0: 0.087469, 1: -1.5262719999999999, 2: -1.666304, 3: -0.3220700000000004, 4: -0.9543709999999999, 5: -0.095968, 6: 0.678091, 7: -1.130922},
'C': {0: 0.162003, 1: -1.156319, 2: 0.833892, 3: -2.026673, 4: 0.4114520000000004, 5: 0.765878, 6: -0.65489, 7: -1.789842}, 
'A': {0: 'foo', 1: 'bar', 2: 'foo' ,3: 'bar', 4: 'foo', 5: 'bar', 6: 'foo', 7: 'foo'}})


print("", """
#x is each column for that group 
zscore = lambda x: (x - x.mean()) / x.std() # Note that it does not reference anything outside of 'x' and for transform 'x' is one column.
#B is ignored 
>>> df.groupby('A').transform(zscore) #for each column of each group 
""",
df.groupby('A').transform(zscore),
sep="\n")

#       C      D
#0  0.989  0.128
#1 -0.478  0.489
#2  0.889 -0.589
#3 -0.671 -1.150
#4  0.034 -0.285
#5  1.149  0.662
#6 -1.404 -0.907
#7 -0.509  1.653

#Create a column with sum of C for each group of A 
df['sum_C'] = df.groupby('A')['C'].transform(np.sum)
print("", """
#Create a column with sum of C for each group of A 
df['sum_C'] = df.groupby('A')['C'].transform(np.sum)
# to clearly see the scalar ('sum') applies to the whole column of the group
>>> df.sort_values('A') 
""",
df.sort_values('A'),
sep="\n")

#Output 
#     A      B         C         D     sum_C
#1  bar    one -1.156319 -1.526272 -2.417114
#3  bar  three -2.026673 -0.322057 -2.417114
#5  bar    two  0.765878 -0.095968 -2.417114
#0  foo    one  0.162003  0.087469 -1.037385
#2  foo    two  0.833892 -1.666304 -1.037385
#4  foo    two  0.411452 -0.954371 -1.037385
#6  foo    one -0.654890  0.678091 -1.037385
#7  foo  three -1.789842 -1.130922 -1.037385

print("", """
#Other methods 
DataFrameGroupBy.filter(func, dropna=True, *args, **kwargs)
    Return a copy of a DataFrame excluding elements from groups 
    that do not satisfy the boolean criterion specified by func.
    Parameters:
        f : function
            Function to apply to each subframe. Should return True or False.
            f takes full DF including grouped column
        dropna : Drop groups that do not pass the filter. True by default;
            if False, groups that evaluate False are filled with NaNs.
    Returns:
    filtered : DataFrame 

""")

#Example 
import pandas as pd
df = pd.DataFrame({'A' : ['foo', 'bar', 'foo', 'bar',
                          'foo', 'bar'],
                   'B' : [1, 2, 3, 4, 5, 6],
                   'C' : [2.0, 5., 8., 1., 2., 9.]})
grouped = df.groupby('A')
print("", """
df = pd.DataFrame({'A' : ['foo', 'bar', 'foo', 'bar',
                          'foo', 'bar'],
                   'B' : [1, 2, 3, 4, 5, 6],
                   'C' : [2.0, 5., 8., 1., 2., 9.]})
grouped = df.groupby('A')
>>> grouped.filter(lambda df: df['B'].mean() > 3.)
""",
grouped.filter(lambda df: df['B'].mean() > 3.),
sep="\n")

#     A  B    C
#1  bar  2  5.0
#3  bar  4  1.0
#5  bar  6  9.0


print("""
GroupBy.apply(func, *args, **kwargs)
    func takes grouped DF(including grouped column) and args, kwrgs 
    and return a dataframe, a series or a scalar. 
    Hence func can access other column for that dataframe 
#In the current implementation apply calls func twice on the first group to decide 
#whether it can take a fast or slow code path. 

#Examples
df = pd.DataFrame({'A': 'a a b'.split(), 'B': [1,2,3], 'C': [4,6, 5]})
>>> df
   A  B  C
0  a  1  4
1  a  2  6
2  b  3  5

>>> df._get_numeric_data()
   B  C
0  1  4
1  2  6
2  3  5
#understand max 
>>> df[['B', 'C']]
   B  C
0  1  4
1  2  6
2  3  5
>>> df[['B', 'C']].max()  #columnwise 
B    3
C    6
dtype: int64

>>> df[['B', 'C']].max(axis=1) #rowwise 
0    4
1    6
2    5
dtype: int64

#Example 
g = df.groupby('A')
#fn takes full DF inc grouped columns , exclude A
>>> g.apply(lambda df: df._get_numeric_data() / df._get_numeric_data().sum())  #divided by full grouped DF sum 
          B    C
0  0.333333  0.4
1  0.666667  0.6
2  1.000000  1.0

#Returns Series , df.max() is each column's max 
>>> g.apply(lambda df: df._get_numeric_data().max() - df._get_numeric_data().min())
   B  C
A
a  1  2
b  0  0

#returns scalar 
>>> g.apply(lambda x: x.C.max() - x.B.min())
A
a    5
b    2
dtype: int64


GroupBy.pipe(func, *args, **kwargs)
    Apply a function with arguments to this GroupBy object,
    Parameters:
    func : callable 
    Note function gets full groupedBy dataframe with it's groupby column as index 
 
#Use .pipe when chaining together functions that expect Series, DataFrames or GroupBy objects. 
#Instead of writing
>>> f(g(h(df.groupby('group')), arg1=a), arg2=b, arg3=c)
#You can write
>>> (df
        .groupby('group')
        .pipe(f, arg1)
        .pipe(g, arg2)
        .pipe(h, arg3))
        
#Example 
df = pd.DataFrame({'A': 'a b a b'.split(), 'B': [1, 2, 3, 4]})
>>> df
   A  B
0  a  1
1  b  2
2  a  3
3  b  4


#To get the difference between each groups maximum and minimum value in one pass, you can do
>>> df.groupby('A').pipe(lambda g: g.max() - g.min()) #g is groupedFataframe 
   B
A
a  2
b  2

""")

#Examples- 
df = pd.DataFrame({'A': 'a a b'.split(), 'B': [1,2,3], 'C': [4,6, 5]})
df
#    A  B  C
# 0  a  1  4
# 1  a  2  6
# 2  b  3  5

df._get_numeric_data()
#    B  C
# 0  1  4
# 1  2  6
# 2  3  5
#understand max 
df[['B', 'C']]
#    B  C
# 0  1  4
# 1  2  6
# 2  3  5
df[['B', 'C']].max()  #columnwise 
# B    3
# C    6
# dtype: int64

df[['B', 'C']].max(axis=1) #rowwise 
#0    4
#1    6
#2    5
#dtype: int64

#Example of apply 
#Hence func can access other column for that dataframe 
#
g = df.groupby('A')
#fn takes full DF inc grouped columns , exclude A
g.apply(lambda df: df._get_numeric_data() / df._get_numeric_data().sum())  #divided by full grouped DF sum 
#          B    C
#0  0.333333  0.4
#1  0.666667  0.6
#2  1.000000  1.0

#Returns Series , df.max() is each column's max 
g.apply(lambda df: df._get_numeric_data().max() - df._get_numeric_data().min())
#   B  C
#A
#a  1  2
#b  0  0

#returns scalar 
g.apply(lambda x: x.C.max() - x.B.min())
#A
#a    5
#b    2
#dtype: int64


        
#Example of pipe 
#Note function gets full groupedBy dataframe with it's groupby column as index 
df = pd.DataFrame({'A': 'a b a b'.split(), 'B': [1, 2, 3, 4]})
#To get the difference between each groups maximum and minimum value in one pass, you can do
df.groupby('A').pipe(lambda g: g.max() - g.min()) #g is groupedFataframe 
#   B
#A
#a  2
#b  2