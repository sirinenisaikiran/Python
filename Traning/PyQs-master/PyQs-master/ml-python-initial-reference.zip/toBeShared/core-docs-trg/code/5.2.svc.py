import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline
from sklearn import datasets
from sklearn import datasets, metrics
from sklearn.svm import LinearSVC, NuSVC, SVC
from sklearn.linear_model import LogisticRegressionCV, LogisticRegression, SGDClassifier


print("-------------- SVC on handwritten digits(0-9) ---------------")

digits = datasets.load_digits() #['DESCR', 'data', 'images', 'target', 'target_names']
print(digits.DESCR)

#pause 
input()

data = digits.data 
target = digits.target 
n_samples = len(digits.images)


# 8x8 images of one channel uint8 ie grayscale image 
#>>> digits.keys()
#dict_keys(['images', 'target_names', 'data', 'target', 'DESCR'])
#>>> np.unique(digits.target)
#array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
#>>> digits.target_names
#array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
#>>> digits.data.shape
#(1797, 64)
#>>> digits.images.shape
#(1797, 8, 8)

# To apply a classifier on this data, we need to flatten the image, to
# turn the data in a (samples, feature) matrix:
#n_samples = len(digits.images)
#data = digits.images.reshape((n_samples, -1)) #== digits.data







# Create a classifier: a support vector classifier
models = []
models.append(( 'LogisticRegression' , LogisticRegression()))
models.append(( 'LinearSVC' , LinearSVC()))

print("-------------- Searching best SVC  ---------------")

C_range = np.logspace(-2, 10, 3)
gamma_range = np.logspace(-9, 3, 3)
params = dict(gamma=gamma_range, C=C_range, kernel=['linear', 'rbf'])
best_SVC = GridSearchCV(SVC(), param_grid=params)
best_SVC.fit(data, target)

#print("best_SVC\n", best_SVC.best_estimator_)
models.append( ( 'best_SVC' , best_SVC.best_estimator_) )


for name, classifier in models: 
    # We learn the digits on the first half of the digits
    classifier = classifier.fit(data[:n_samples // 2], target[:n_samples // 2])
    # Now predict the value of the digit on the second half:
    expected = target[n_samples // 2:]
    predicted = classifier.predict(data[n_samples // 2:])
    print("-----------------%s-----------------" % (name,) )
    print("Classification report(test dataset) for classifier %s:\n%s\n"% (classifier, metrics.classification_report(expected, predicted)))
    print("Confusion matrix on test dataset :\n%s" % metrics.confusion_matrix(expected, predicted))
    print("accuracy on test data set:\n%s" % metrics.accuracy_score(expected, predicted))
    print("accuracy on train data set:\n%s" % metrics.accuracy_score(target[:n_samples // 2], classifier.predict(data[:n_samples // 2])))


print("-------------- Check first 4 train and predicted image   ---------------")
input()

#here classifier is the last value from models, ie SVC 
#Check first 4 prediction 
images_and_predictions = list(zip(digits.images[n_samples // 2:], predicted))

#look at the first 4 images
images_and_labels = list(zip(digits.images, digits.target))
for index, (image, label) in enumerate(images_and_labels[:4]):
    plt.subplot(2, 4, index + 1) #total ax, 8 as we are going to plot predicted as well 
    plt.axis('off')
    plt.imshow(image, cmap=plt.cm.gray_r, interpolation='nearest')
    plt.title('Training: %i' % label)
    
for index, (image, prediction) in enumerate(images_and_predictions[:4]):
    plt.subplot(2, 4, index + 5)
    plt.axis('off')
    plt.imshow(image, cmap=plt.cm.gray_r, interpolation='nearest')
    plt.title('Prediction: %i' % prediction)

plt.show()