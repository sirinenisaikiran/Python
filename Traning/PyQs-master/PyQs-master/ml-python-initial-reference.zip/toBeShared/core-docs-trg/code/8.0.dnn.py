import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)
warnings.simplefilter(action='ignore', category=DeprecationWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline
from sklearn import datasets

from sklearn.ensemble import *  
from sklearn.tree import *
import time 

print("----------------- DNN on iris classifications  ----------------")

from keras.models import Sequential, load_model
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
import keras.utils 
from keras.callbacks import * 


dataframe   = pd.read_csv("data/iris.csv")
dataset     = dataframe.values

X = dataset[:,0:4].astype(float)
Y = dataset[:,4]

encoder = LabelEncoder()
encoder.fit(Y)
encoded_Y = encoder.transform(Y)

# to_categorical converts the numbered labels into a one-hot vector
#Classifier must use x or y as one hot encoded 
dummy_y = keras.utils.to_categorical(encoded_Y)
#so creates 3 output variable 

#StratifiedKFold does not work with multioutput 
kfold = KFold(n_splits=10, shuffle=True)

# define baseline model
def baseline_model():
    # create model
    model = Sequential()
    #input_dim= n , for n features or (x,y) for 2D feature 
    model.add(Dense(8, input_dim=4, activation='relu'))
    #for binary , final layer with one output, activation='sigmoid' and loss='binary_crossentropy'.
    #but we have three classe classifier, so output=3 
    model.add(Dense(3, activation='softmax'))
    # Compile model
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model
    

#total samples=150, batch_size=5, so 100 batches x 200 epochs 
#epochs - how many times total samples are used , here 200 times 
#batch_size : how many samples at a time is used for training 
estimator = KerasClassifier(build_fn=baseline_model, epochs=200, batch_size=5, verbose=0)


results = cross_val_score(estimator, X, dummy_y, cv=kfold)
print("Baseline: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))
#Baseline: 97.33% (4.42%)


#Check 
X_train, X_test, y_train, y_test, enc_y_train, enc_y_test = train_test_split(X, dummy_y, encoded_Y, random_state=0)

#fit
estimator.fit( X_train, y_train)

#score 
print(" train, test accuracy", estimator.score( X_train, y_train), estimator.score( X_test, y_test))
#0.9732142873108387
#0.9736842120948591

#predict 
predictions = estimator.predict( X_test)
print("predict as per numerical class\n", predictions)
#array([2, 2, 0, 2, 0, 2, 0, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2, 2, 0, 0, 2, 2,  0, 0, 2, 0, 0, 2, 1, 0, 2, 2, 0, 2, 2, 2, 0, 2])
#With LabelEncoded Y 
print("confusion metrics\n", confusion_matrix(enc_y_test, predictions))
# array([[13,  0,  0],
       # [ 0, 14,  2],
       # [ 0,  0,  9]], dtype=int64)
       
##summary 

#NN visualization 
from keras.utils import plot_model
plot_model(estimator.model, to_file='model.png', show_shapes=True)

#NN Training history visualization
model =  baseline_model()
history = model.fit(X_train, y_train, validation_split=0.25, epochs=200, batch_size=5, verbose=0)

# Plot training & validation accuracy values
plt.subplot(121)
plt.plot(history.history['acc'])
plt.plot(history.history['val_acc'])
plt.title('Model accuracy')
plt.ylabel('Accuracy')
plt.xlabel('Epoch')
plt.legend(['Train', 'Test'], loc='upper left')

# Plot training & validation loss values
plt.subplot(122)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model loss')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(['Train', 'Test'], loc='upper left')
plt.show()

##NN save 
# serialize model to JSON
#Note that the representation does not include the weights,
model_json = model.to_json()
with open("model.json", "w") as json_file:
    json_file.write(model_json)

# serialize weights to HDF5
model.save_weights("model.h5")
print("Saved model to disk")
 
 
# load json and create model
json_file = open('model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
from keras.models import model_from_json
loaded_model = model_from_json(loaded_model_json)
# load weights into new model
loaded_model.load_weights("model.h5")
print("Loaded model from disk")
 
# evaluate loaded model on test data
loaded_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
score = loaded_model.evaluate(X_test, y_test, verbose=0)
print("%s: %.2f%%" % (loaded_model.metrics_names[1], score[1]*100))




print("""  --------------- GridSearch -----------------
accuracy is very sensitive of below Hyperparameters 
batch_size = sample size preferably to be multiple of batch size
epochs 
Dense - output no , 
        activation
""")


params = dict(
    epochs = [ 100, 200, 300],
    batch_size = [5,15,30],
    dense1_out = [8,16,32],
    dense1_activation = [ 'relu', 'tanh']
)

def search_model(dense1_out=8, dense1_activation='relu' ):
    # create model
    model = Sequential()
    model.add(Dense(dense1_out, input_dim=4, activation=dense1_activation))
    model.add(Dense(3, activation='softmax'))
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model

clf = KerasClassifier(build_fn=search_model, verbose=0)

kfold = KFold(n_splits=3, shuffle=True)
search = RandomizedSearchCV(clf, params, cv=kfold)

import time 
st = time.time()
search.fit(X_train, y_train)
print("Time taken: ", time.time()-st, " secs")  #175.9128041267395

print("Best param: ", search.best_params_ ) #{'epochs': 200, 'dense1_activation': 'tanh', 'batch_size': 30, 'dense1_out': 16}
print(" train, test accuracy", search.score( X_train, y_train), #0.9821428624647004
search.score( X_test, y_test)) #0.9736842105263158



print("""
Reducton of overfitting 
1.Setup Early Stopping
    Use EarlyStopping(monitor='val_loss', patience=2) 
        to define that we wanted to monitor the test (validation) loss at each epoch 
        and after the test loss has not improved after two epochs, training is interrupted. 
        However, since we set patience=2, we won't get the best model, 
        but the model two epochs after the best model. 
        Therefore, optionally, we can include a second operation, 
        ModelCheckpoint which saves the model to a file after every checkpoint 
        (which can be useful in case a multi-day training session is interrupted for some reason. 
        Helpful for us, if we set save_best_only=True then ModelCheckpoint will only save 
        the best model.
    And 
    Use validation_split=0.3 or validation_data=(val_x, val_y)
2.Use MinMaxscalar to scale the data also to reduce overfitting 
(dont use StandardScalar as data might not be normal)

""")
callbacks = [EarlyStopping(monitor='val_loss', patience=2),
             ModelCheckpoint(filepath='best_model.h5', monitor='val_loss', save_best_only=True)]
             
scaler = MinMaxScaler(feature_range=(-1,1))
X = scaler.fit(X).transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, dummy_y,  random_state=0)

#total samples=150, batch_size=5, so 100 batches x 200 epochs 
#epochs - how many times total samples are used , here 200 times 
#batch_size : how many samples at a time is used for training 
estimator = KerasClassifier(build_fn=baseline_model, epochs=200, batch_size=5,                       
                      verbose=1, # Print description after each epoch(0)+some addl  
                      callbacks=callbacks, # Early stopping
                      validation_data=(X_test, y_test) # Data for evaluation                      
                      )
estimator.fit( X_train, y_train)
    
#Load the best model from best_model.h5 which is compiled as well 
model = load_model('best_model.h5')
estimator1 = KerasClassifier(build_fn=lambda : model)
results = cross_val_score(estimator1, X, dummy_y, cv=kfold, scoring='roc_auc')
print("AUC with reduce overfitting: %3.2f (%3.2f)" % (results.mean(), results.std()))