from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import nltk
import string
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report,confusion_matrix
from sklearn.model_selection import * 
from sklearn.metrics import *


PAUSE='Y'
def pause_d():
    if PAUSE == 'Y':
        print("pausing...")
        input()

print("-------------------- Naive Bayes for spam -------------")
#since the dataset comes with additional unnamed, column, drop them first

messages = pd.read_csv('data/spam.csv', encoding='latin-1')
#specify list of columns 
messages.drop(['Unnamed: 2','Unnamed: 3','Unnamed: 4'],axis=1,inplace=True)
messages = messages.rename(columns={'v1': 'class','v2': 'text'})

print(messages.head())
print(messages.groupby('class').describe())
'''
       text
      count unique
class
ham    4825   4516
spam    747    653


from above information, we know that:

    only about 15% of the text messages is classified as a spam
    there are some duplicate messages, since the number of unique values lower than the count values of the text

in the next part, lext check the length of each text messages to see whether it is correlated with the text classified as a spam or not.
'''
#for Series, each element - apply
messages['length'] = messages['text'].apply(len)


messages.hist(column='length',by='class',bins=50, figsize=(15,6))
plt.show()
pause_d()

def process_text(text, lower_case = True, stem = True, stop_words = True):    
    message = [char for char in text if char not in string.punctuation]
    message = ''.join(message)     
    if lower_case:
        message = message.lower()
    words = word_tokenize(message)
    words = [w for w in words if len(w) > 2]
    if stop_words:
        sw = stopwords.words('english')
        words = [word for word in words if word not in sw]
    if stem:
        stemmer = PorterStemmer()
        words = [stemmer.stem(word) for word in words]       
    return words

    
print("Fitting pipeline....")
msg_train, msg_test, class_train, class_test = train_test_split(messages['text'],messages['class'],test_size=0.2)

#take 1 .. 2 words 
pipeline = Pipeline([
    ('bow',CountVectorizer(analyzer=process_text, ngram_range=(1, 2))), # converts strings to integer counts
    ('tfidf',TfidfTransformer()), # converts integer counts to weighted TF-IDF scores
    #it produces sparse matrix, hence next estimator must accept sparse matrix 
    ('classifier',MultinomialNB()) # train on TF-IDF vectors with Naive Bayes classifier
    #('classifier',SGDClassifier()) #mostly all estimator accepts sparse matrix 
])

pipeline.fit(msg_train,class_train)

predictions = pipeline.predict(msg_test)
print("Fitted, calculating cross val score ....")
scores = cross_val_score(pipeline, messages['text'], messages['class'], cv=5, scoring='roc_auc') 
print("AUC: %0.2f (+/- %0.2f) " % (scores.mean(), scores.std() * 2) )


print('''
precision
    what % of predicted positive are actually positves?
Recall, Sensitivity 
    what % of actual positives are predicted positives?
f1 score
    The F1 score is a weighted harmonic mean of precision and recall 
    such that the best score is 1.0 and the worst is 0.0. 
support
    Support is the number of actual occurrences of the class in the specified dataset. 
    Imbalanced support in the training data may indicate structural weaknesses 
    in the reported scores of the classifier 
    and could indicate the need for stratified sampling or rebalancing. 
    Support doesn't change between models but instead diagnoses the evaluation process.
    
F1 score methods 
"macro" 
    simply calculates the mean of the binary metrics, giving equal weight to each class. 
"micro" 
    gives each sample-class pair an equal contribution to the overall metric 
    Rather than summing the metric per class, 
    this sums the dividends and divisors that make up the per-class metrics 
    to calculate an overall quotient. 
    Micro-averaging may be preferred in multilabel settings, 
    including multiclass classification   
''')
print(classification_report(class_test,predictions))

#              precision    recall  f1-score   support#how many True class for that row
#
#         ham       0.96      1.00      0.98       968
#        spam       1.00      0.75      0.86       147
#
#   micro avg       0.97      0.97      0.97      1115
#   macro avg       0.98      0.87      0.92      1115
#weighted avg       0.97      0.97      0.96      1115


import seaborn as sns
sns.heatmap(confusion_matrix(class_test,predictions),annot=True)
plt.show()


