import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 


print(""" 
ndarray.sort([axis, kind, order]) 				
    Sort an array, in-place. 

""")
a = np.array([[1,4],[3,1]])

print("sort along the last axis, ie axis=1 for 2D, rowwise ", 
    "a=", a, "np.sort(a) =",np.sort(a), sep="\n")

            # sort along the last axis, ie axis=1 for 2D, rowwise 
#array([[1, 4],
#       [1, 3]])

print("sort the flattened array", 
    "a=", a, "np.sort(a, axis=None) =",np.sort(a, axis=None), sep="\n")


#>>> np.sort(a, axis=None)     # sort the flattened array
#array([1, 1, 3, 4])

print("sort along the first axis/ columnwise ", 
    "a=", a, "np.sort(a, axis=0) =",np.sort(a, axis=0), sep="\n")

#>>> np.sort(a, axis=0)        # sort along the first axis/ columnwise 
#array([[1, 1],
#       [3, 4]])   
#    
    
print("""
ndarray.max(axis=None, out=None, keepdims=False)
ndarray.min(axis=None, out=None, keepdims=False)
    Return the maximum/minimum along a given axis.
    equivalent to numpy.amax, numpy.amin 
numpy.amax, amin(a, axis=None, out=None, keepdims=<class 'numpy._globals._NoValue'>)
    Return the maximum/minimum of an array or maximum along an axis.
""")
#Example 
a = np.arange(4).reshape((2,2))
#>>> a
#array([[0, 1],
#       [2, 3]])
#       
#>>> np.amin(a)           # Minimum of the flattened array
#0
#
#>>> np.amin(a, axis=0)   # Minima along the first axis(columnwise)
#array([0, 1])
#
#>>> np.amin(a, axis=1)   # Minima along the second axis(rowwise)
#array([0, 2])  
    
print("Minimum of the flattened array", 
    "a=", a, "np.amin(a)  =",np.amin(a) , sep="\n")
print("Minima along the first axis(columnwise)", 
    "a=", a, "np.amin(a, axis=0) =",np.amin(a, axis=0), sep="\n")
print("Minima along the second axis(rowwise)", 
    "a=", a, "np.amin(a, axis=1) =",np.amin(a, axis=1), sep="\n")
   
  

##Adding and removing elements
print("""
delete(arr, obj[, axis]) 	
    Return a new array with sub-arrays along an axis deleted.
""")

#Exmaple 
a = np.array([[1,2,3,4], [5,6,7,8], [9,10,11,12]])
#>>> a
#array([[ 1,  2,  3,  4],
#       [ 5,  6,  7,  8],
#       [ 9, 10, 11, 12]])
#>>> np.delete(a, 1, axis=0)#axis =0, row delete, 1=means which subarray to delete 
#array([[ 1,  2,  3,  4],
#       [ 9, 10, 11, 12]])
       
print("axis =0, row delete, 1=means which subarray to delete ", 
    "a=", a, "np.delete(a, 1, axis=0) =",np.delete(a, 1, axis=0), sep="\n")
print("""
insert(arr, obj, values[, axis]) 	
    Insert values along the given axis before the given indices.
""")
#Example 
a = np.array([[1, 1], [2, 2], [3, 3]])
#>>> a
#array([[1, 1],
#       [2, 2],
#       [3, 3]])
#>>> np.insert(a, 1, 5, axis=1) #axis=1, insert column, before 1, value 5 
#array([[1, 5, 1],
#       [2, 5, 2],
#       [3, 5, 3]])   
    
print("axis=1, insert column, before 1, value 5 ", 
    "a=", a, "np.insert(a, 1, 5, axis=1) =",np.insert(a, 1, 5, axis=1), sep="\n")
    
print("""
append(arr, values[, axis]) 	
    Append values to the end of an array.
""")
#Example 
a = np.array([1, 2, 3])
b = np.array([[4, 5, 6], [7, 8, 9]])
#>>> np.append(a, b)
#array([1, 2, 3, 4, 5, 6, 7, 8, 9])

print("append", 
    "a=", a, "b=", b,  "np.append(a, b) =",np.append(a, b), sep="\n")


a = np.array([[1, 2, 3], [4, 5, 6]])
b = np.array([[7, 8, 9]])
#>>> np.append(a, b, axis=0) #axis=0 , row append 
#array([[1, 2, 3],
#       [4, 5, 6],
#       [7, 8, 9]])   

print("axis=0 , row append ", 
    "a=", a, "b=", b,  "np.append(a, b, axis=0)=",np.append(a, b, axis=0), sep="\n")

