import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

#x,y , red and line 
##y values , x is taken as 0,1,2,3
plt.plot([1,2,3,4], [1,2,3,4],'r-', lw=2)                
plt.xlabel('x axis label', fontsize=14, color='red')
plt.ylabel('y axis label')
plt.title('My first plot ')
plt.legend(['Straight Line'], loc='best')
plt.grid(True)
plt.yscale('linear') #log, symlog, logit
plt.xscale('linear')
#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.axis.html
plt.axis([0, 4, 0, 10]) #Set the axis, [xmin, xmax, ymin, ymax] or 'off' or 'equal' or 'scaled' or 'tight' etc 
#or 
plt.ylim(0, 4)
plt.xlim(0, 10)

#x,y this is in data coordinates.
plt.text(2, 2, r'$\mu=100,\ \sigma=15$')  #Any text  or  '$any LaTex code$'
plt.text(0.5, 0.5, 'matplotlib', horizontalalignment='center', verticalalignment='center')

#put a rectangular box around the text 
plt.text(4,4, "Another text", bbox=dict(facecolor='red', alpha=0.5))

#https://matplotlib.org/api/_as_gen/matplotlib.pyplot.annotate.html
#text with arrow 
plt.annotate('local max', xy=(2, 1), xytext=(3, 1.5),arrowprops=dict(facecolor='black', shrink=0.05),) #xytext=location of text, xy=location for annotation
plt.show()