print("""Latent Dirichlet Allocation (LDA)- topic modelling technique
Given a document, we can find it's topic(relevance) based on corpora, dictionary 
""")

##Step-1 - Text Cleaning

import spacy
spacy.load('en')
from spacy.lang.en import English
parser = English()

def tokenize(text):
    lda_tokens = []
    tokens = parser(text)
    for token in tokens:
        if token.orth_.isspace():
            continue
        elif token.like_url:
            lda_tokens.append('URL')
        elif token.orth_.startswith('@'):
            lda_tokens.append('SCREEN_NAME')
        else:
            lda_tokens.append(token.lower_)
    return lda_tokens

#use NLTK's Wordnet(a corpora) to find the meanings of words, synonyms, antonyms, and more. 
import nltk
#nltk.download('wordnet')

from nltk.corpus import wordnet as wn
def get_lemma(word):
    lemma = wn.morphy(word)
    if lemma is None:
        return word
    else:
        return lemma

#Or use below (WordNetLemmatizer to get the root word)
from nltk.stem.wordnet import WordNetLemmatizer
def get_lemma2(word):
    return WordNetLemmatizer().lemmatize(word)

#Filter out stop words:
#nltk.download('stopwords')
en_stop = set(nltk.corpus.stopwords.words('english'))

#Then full processing 

def prepare_text_for_lda(text):
    tokens = tokenize(text)
    tokens = [token for token in tokens if len(token) > 3]
    tokens = [token for token in tokens if token not in en_stop]
    tokens = [get_lemma(token) for token in tokens]
    return tokens

#Create list of tokens 

import random
text_data = []
with open('data/dataset.csv') as f:
    for line in f:
        tokens = prepare_text_for_lda(line)
        text_data.append(tokens)

        
        
##STEP-2: LDA with Gensim

#Then build our corpora and dictionary 
from gensim import corpora
dictionary = corpora.Dictionary(text_data)
#bow means CountVectorizer
corpus = [dictionary.doc2bow(text) for text in text_data]

#for later use 
dictionary.save('dictionary.gensim')
corpora.MmCorpus.serialize('corpus.gensim.mm', corpus) 




#Train LDA for 5 topics

import gensim
NUM_TOPICS = 5
#train LDA 
ldamodel = gensim.models.ldamodel.LdaModel(corpus, num_topics = NUM_TOPICS,
        id2word=dictionary, passes=15)
ldamodel.save('model5.gensim')

print("Printing top n topics")
print('eg Topic 0 includes words like "processor", "database", "issue" and "overview"')
topics = ldamodel.print_topics(num_words=4)
for topic in topics:
    print(topic)
#Eg Topic 0 includes words like 'processor', "database", "issue" and "overview",
#and so-on 
# (0, '0.032*"query" + 0.016*"model" + 0.015*"using" + 0.011*"efficient"')
# (1, '0.032*"base" + 0.020*"power" + 0.013*"system" + 0.012*"network"')
# (2, '0.026*"base" + 0.013*"network" + 0.011*"analysis" + 0.010*"scheme"')
# (3, '0.022*"design" + 0.021*"system" + 0.012*"using" + 0.012*"base"')
# (4, '0.050*"network" + 0.027*"wireless" + 0.015*"sensor" + 0.013*"system"')

print("Find topics for  new document")
new_doc = 'Practical Bayesian Optimization of Machine Learning Algorithms'
new_doc = prepare_text_for_lda(new_doc)
new_doc_bow = dictionary.doc2bow(new_doc)
print(new_doc_bow)  #(125, 1), (234, 1), (442, 1), (587, 1), (1859, 1)]
print(ldamodel.get_document_topics(new_doc_bow))
#(0, 0.033543985), (1, 0.37556702), (2, 0.033457167), (3, 0.52288413), (4, 0.03447675)]
print("eg Topic 1 relevance is 0.37556702 , so on and so forth ")


#the LSA implementation in gensim is truly online: 
#if the nature of the input stream changes in time, LSA will re-orient itself to reflect these changes, 

#In contrast, LDA is not truly online as the impact of later updates on the model gradually diminishes. 

#To run batch LDA (not online), train LdaModel with:
# extract 100 LDA topics, using 20 full passes, no online updates
#ldamodel = gensim.models.ldamodel.LdaModel(corpus=corpus, id2word=dictionary, num_topics=100, update_every=0, passes=20)


##STEP3: Display 
#pyLDAvis is designed to help users interpret the topics in a topic model 
#an interactive web-based visualization.

#Visualizing 5 topics:
from gensim import corpora
import gensim
dictionary = corpora.Dictionary.load('dictionary.gensim')
corpus = corpora.MmCorpus('corpus.gensim.mm')
lda = gensim.models.ldamodel.LdaModel.load('model5.gensim')

#Test 
print(lda.print_topics(num_words=4))



import pyLDAvis.gensim
#n_jobs=-1 or >1 would create multiprocessing, Use joblib latest version 
lda_display = pyLDAvis.gensim.prepare(lda, corpus, dictionary, n_jobs=-1) 
#pyLDAviz expects continuous user interaction , so creates IPYTHON HTML object 
#pyLDAvis.display(lda_display)
print("display is saved  to display.html ")
import time 
time.sleep(10)
pyLDAvis.save_html(lda_display, open('display.html', "wt"))

#pyLDAvis.show(lda_display)

#save_json: save json representation of visualization to file
#save_html : save html representation of a visualization to file
#show : launch a local server and show a visualization in a browser
#display : embed visualization within the IPython notebook
#enable_notebook : automatically embed visualizations in IPython notebook


print("""
This is displayed by Multi-Dimension Scaling (MDS), a method 
displaying high dimensional data into 2D space 
(check https://www.aclweb.org/anthology/W14-3110)

Questions to be answered by Topic modeling 
(1) What is the meaning of each topic?, 
(2) Howprevalent is each topic?, 
(3) How do the topicsrelate to each other?

The left panelpresents a global view of the topic model,
and answers questions 2 and 3.  
In this view, weplot  the  topics as circles  in  the  two-dimensionalplane  
whose  centers  are  determined  by  computing the distance between topics,  
and then by using multidimensional scaling to project the intertopic  distances  
onto  two  dimensions
We encode each topic's overall  prevalence using  the areas  of the  circles,
where  the  topics are sorted  in  decreasing  order  ofprevalence.
 
The right panel  depicts  a  horizontal  barchart  
whose  bars  representthe individual terms that are the most useful 
for interpreting the currently selected topic on the left,
and allows users to answer question 1,  
A pair of overlaidbars represent both the corpus wide frequency of a given term 
as well as the topic specific frequency of the term


Saliency
    a measure of how much the term tells you about the topic.
    This is used in ranking terms in right panel 
Relevance
    a weighted average of the probability of the word given the topic 
    normalized by the probability of the topic.
    Slidebar selects lambda of relevance equation
Size of the bubble
    The size of the bubble measures the importance of the topics, 
    relative to the data.
 """)


print("Using sklearn , dataset: 20newsgroups ")
print("""
Topic extraction with Non-negative Matrix Factorization(NMF)
Topic extraction with Latent Dirichlet Allocation (LDA)
""")
print("pausing...")
input()

from sklearn.pipeline import * 
from sklearn.naive_bayes import * 
from sklearn.cluster import *  
from sklearn.covariance import *  
from sklearn.cross_decomposition import *  
from sklearn.datasets import *  
from sklearn.decomposition import *  
from sklearn.ensemble import *  
from sklearn.feature_extraction import *  
from sklearn.feature_extraction.text import *  
from sklearn.feature_selection import *  
from sklearn.gaussian_process import *  
from sklearn.linear_model import *  
from sklearn.manifold import *  
from sklearn.metrics import *  
from sklearn.mixture import *  
from sklearn.model_selection import *  
from sklearn.neighbors import *  
from sklearn.neural_network import *  
from sklearn.preprocessing import *  
from sklearn_pandas import DataFrameMapper
from sklearn.svm import *  
from sklearn.tree import *  

import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt


n_samples = 2000
n_features = 1000
n_components = 10
n_top_words = 20
n_test_size = 10 

#.components_ contain topics 
#nmf.components_.shape = 10 x 1000 = n_components x n_features
#where value is the each feature/term/word, j relevance to topic i
def print_top_words(model, feature_names, n_top_words):
    for topic_idx, topic in enumerate(model.components_):
        message = "Topic #%d: " % topic_idx
        message += " ".join([feature_names[i] for i in topic.argsort()[:-n_top_words - 1:-1]])
        print(message)
    print()

def print_new_data(model, n_topics, X):
    trx = model.transform(X)
    tops = [ "topic-"+str(i) for i in range(n_topics)]
    for sam in trx:
        d = dict(zip(tops,sam))
        print(sorted(d.items(), key=lambda t:t[1], reverse=True))
    
# Load the 20 newsgroups dataset and vectorize it. We use a few heuristics
# to filter out useless terms early on: the posts are stripped of headers,
# footers and quoted replies, and common English words, words occurring in
# only one document or in at least 95% of the documents are removed.


dataset = fetch_20newsgroups(shuffle=True, random_state=1, remove=('headers', 'footers', 'quotes'))
data_samples = dataset.data[:n_samples]
data_test = dataset.data[n_samples:n_samples + n_test_size]

'''
max_df : float in range [0.0, 1.0] or int, default=1.0
    When building the vocabulary ignore terms that have a document frequency strictly 
    higher than the given threshold 
    If float, the parameter represents a proportion of documents, 
    integer absolute counts. 
min_df : float in range [0.0, 1.0] or int, default=1
    When building the vocabulary ignore terms that have a document frequency strictly 
    lower than the given threshold. 
    This value is also called cut-off in the literature. 
    If float, the parameter represents a proportion of documents, 
    integer absolute counts. 
max_features : int or None, default=None
    If not None, build a vocabulary that only consider the top max_features 
    ordered by term frequency across the corpus.
'''  
    

# Use tf-idf features for NMF.
print("Extracting tf-idf features for NMF...")
#Remove words that are not present in 95% documents 
#Remove words that are only present in < 2 documents 
#Only take 1000 terms/features in the term document matrix 
tfidf_vectorizer = TfidfVectorizer(max_df=0.95, min_df=2,
                                   max_features=n_features,
                                   stop_words='english')
nmf = NMF(n_components=n_components, random_state=1,
          alpha=.1, l1_ratio=.5)
          
pn = Pipeline([('tfidf' , tfidf_vectorizer),('nmf', nmf)])
pn.fit(data_samples)
print("\nTopics in NMF model")
tfidf_feature_names = tfidf_vectorizer.get_feature_names()
print_top_words(nmf, tfidf_feature_names, n_top_words)
print_new_data(pn, n_components, data_test)                              

# Use tf (raw term count) features for LDA.
tf_vectorizer = CountVectorizer(max_df=0.95, min_df=2,
                                max_features=n_features,
                                stop_words='english')
lda = LatentDirichletAllocation(n_components=n_components, max_iter=5,
                                learning_method='online',
                                learning_offset=50.,
                                random_state=0)
pn2 = Pipeline([('tf' , tf_vectorizer),('lda', lda)])
pn2.fit(data_samples)
print("\nTopics in LDA model:")
tf_feature_names = tf_vectorizer.get_feature_names()
print_top_words(lda, tf_feature_names, n_top_words)
print_new_data(pn2, n_components, data_test)  


    
   