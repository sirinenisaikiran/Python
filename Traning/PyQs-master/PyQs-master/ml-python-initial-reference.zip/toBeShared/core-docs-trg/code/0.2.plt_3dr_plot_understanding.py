import matplotlib.pyplot as plt
plt.style.use('seaborn-white')
import numpy as np

print("Visualizing a Three-Dimensional Function")

def f(x, y):
    return np.sin(x) ** 10 + np.cos(10 + y * x) * np.cos(x)



x = np.linspace(0, 5, 50)
y = np.linspace(0, 5, 40)

X, Y = np.meshgrid(x, y)
Z = f(X, Y)

print("----------------------------------------------------------------")
print("""
A contour plot can be created with the plt.contour function. 
It takes three arguments: a grid of x values, a grid of y values, 
and a grid of z values. 

The x and y values represent positions on the plot, 
and the z values will be represented by the contour levels. 

by default when a single color is used, negative values are represented by dashed lines, 
and positive values by solid lines. 
""")

plt.contour(X, Y, Z, colors='black');
plt.show()

print("----------------------------------------------------------------")
print("""
Alternatively, the lines can be color-coded by specifying a colormap 
with the cmap argument. (here RdGy (short for Red-Gray) colormap)
Also we can specify that we want more lines to be drawn-20 
equally spaced intervals within the data range
""")

plt.contour(X, Y, Z, 20, cmap='RdGy');
plt.show()

print("----------------------------------------------------------------")
print("""
Spaces between the lines may be a bit distracting. 
We can change this by switching to a filled contour plot 
using the plt.contourf() function

Additionally, add a plt.colorbar() command, 
which automatically creates an additional axis with labeled color information 
for the plot
The colorbar makes it clear that the black regions are "peaks," 
while the red regions are "valleys."
""")

plt.contourf(X, Y, Z, 20, cmap='RdGy')
plt.colorbar();
plt.show()

print("----------------------------------------------------------------")
print("""
One potential issue with this plot is that 
the color steps are discrete rather than continuous, 

This could be remedied by setting the number of contours to a very high number, 
but this results in a rather inefficient plot

A better way to handle this is to use the plt.imshow() function, 
which interprets a two-dimensional grid of data as an image.

plt.imshow() doesn't accept an x and y grid, 
so you must manually specify the extent [xmin, xmax, ymin, ymax] 
of the image on the plot.

plt.imshow() by default follows the standard image array definition 
where the origin is in the upper left, 
not in the lower left as in most contour plots. 
This must be changed when showing gridded data.

plt.imshow() will automatically adjust the axis aspect ratio to match 
the input data; this can be changed by setting, 
for example, plt.axis(aspect='image') to make x and y units match.

""")

plt.imshow(Z, extent=[0, 5, 0, 5], origin='lower',
           cmap='RdGy')
plt.colorbar()
plt.axis(aspect='image');
plt.show()

print("----------------------------------------------------------------")
print("""
To remove pixel, use interpolation
If the interpolation is 'none'(default), then no interpolation is performed

interpolation = 'none' works well when a big image is scaled down, 
while interpolation = 'nearest' works well when a small image is scaled up.
others are 

methods = ['nearest', 'bilinear', 'bicubic', 'spline16',
           'spline36', 'hanning', 'hamming', 'hermite', 'kaiser', 'quadric',
           'catrom', 'gaussian', 'bessel', 'mitchell', 'sinc', 'lanczos']
""")

plt.imshow(Z, extent=[0, 5, 0, 5], origin='lower',
           cmap='RdGy', interpolation = 'bicubic')
plt.colorbar()
plt.axis(aspect='image');
plt.show()
print("----------------------------------------------------------------")
print("""
it can sometimes be useful to combine contour plots and image plots. 
For example, here we'll use a partially transparent background image 
(with transparency set via the alpha parameter) 
and overplot contours with labels on the contours themselves 
(using the plt.clabel() function)
""")

contours = plt.contour(X, Y, Z, 3, colors='black')
plt.clabel(contours, inline=True, fontsize=8)

plt.imshow(Z, extent=[0, 5, 0, 5], origin='lower',
           cmap='RdGy', alpha=0.5)
plt.colorbar();
plt.show()
print("----------------------------------------------------------------")
print("""
Lastly pcolormesh draws color mesh 
which looks like imshow 
Note pcolor and pcolormesh are similar , but pcolormesh is faster
""")
plt.pcolormesh(X, Y, Z, cmap='RdGy', antialiased=True)
plt.colorbar();
plt.show()