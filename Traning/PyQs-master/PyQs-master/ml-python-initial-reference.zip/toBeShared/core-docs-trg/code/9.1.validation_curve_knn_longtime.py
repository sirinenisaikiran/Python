
import numpy as np
import pandas as pd

print("""
Most models have multiple hyperparameters and the best way 
to choose a combination of those parameters is with a grid search. 
However, it is sometimes useful to plot the influence 
of a single hyperparameter on the training and test data to determine 
if the estimator is underfitting or overfitting for some hyperparameter values.
""")


print("""

The k nearest neighbors (kNN) model is commonly used 
when similarity is important to the interpretation of the model. 
Choosing k is difficult, the higher k is the more data is included 
in a classification, creating more complex decision topologies, 
whereas the lower k is, the simpler the model is 
and the less it may generalize

The validation curve from this example is not good 
This poses two possibilities: 
first, that we have not used the the correct range to find the best k 
and need to expand our search to larger values. 

The second is that other hyperparameters (such as uniform 
or distance based weighting, or even the distance metric) 
may have more influence on the default model than k by itself does

""")


from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import StratifiedKFold
from yellowbrick.model_selection import ValidationCurve

cv = StratifiedKFold(4)
param_range = np.arange(3, 20, 2)

oz = ValidationCurve(
    KNeighborsClassifier(), param_name="n_neighbors",
    param_range=param_range, cv=cv, scoring="f1_weighted", n_jobs=-1,
)

# Load a classification data set
data = pd.read_csv("data/game.csv")

# Specify the features of interest and the target
target = "outcome"
features = [col for col in data.columns if col != target]

# Encode the categorical data with one-hot encoding
X = pd.get_dummies(data[features])
y = data[target]

oz.fit(X, y)
oz.poof()