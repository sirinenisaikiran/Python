import warnings
from sklearn.exceptions import * 
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=DataConversionWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)

import pandas as pd
import numpy as np
from sklearn.preprocessing import *
from  sklearn.decomposition import * 
import matplotlib.pyplot as plt 
from sklearn.model_selection import * 
from sklearn.metrics import *
from sklearn.pipeline import Pipeline
from sklearn import datasets
import time 

from sklearn.ensemble import *  
from sklearn.tree import *

print("------------------------ Boston data DecisionTreeRegressor with prunning parameters---------")
boston = datasets.load_boston()
X_train, X_test, y_train, y_test = train_test_split(boston.data, boston.target, random_state=0)

'''
DecisionTreeRegressor(criterion='mse', splitter=’best’, max_depth=None, 
min_samples_split=2, min_samples_leaf=1, min_weight_fraction_leaf=0.0, 
max_features=None, random_state=None, max_leaf_nodes=None, 
min_impurity_decrease=0.0, min_impurity_split=None, presort=False)

'''
print("""
min_samples_leaf or min_samples_split
    min_samples_leaf : The minimum number of samples required to be at a leaf node,
    min_samples_split: The minimum number of samples required to split an internal node
    A very small number will usually mean the tree will overfit, 
    whereas a large number will prevent the tree from learning the data. 
    For classification with few classes, min_samples_leaf=1 is often the best choice. 
    Try min_samples_leaf=5 as an initial value for regression
max_depth
    Inversely proportional to min_samples_leaf ,
    Reduce the depth of the tree to build a generalized tree,    
    Use max_depth=3 as an initial tree depth , Overfitting happens if value is high
""")


clf = DecisionTreeRegressor()

params = dict(min_samples_leaf= range(3,21,2) , max_depth=range(5,15,2), min_samples_split=range(2,5))
search = GridSearchCV(clf, params) #RandomizedSearchCV(clf, params)
st = time.time()
search.fit(X_train, y_train)
print("Best param for DecisionTreeRegressor", search.best_params_ )
print("score= train:%f test:%f and time=%d sec" % (search.score(X_train, y_train),
        search.score(X_test, y_test), (time.time()-st)))

print("Best Model")
best_model = search.best_estimator_
print(best_model)
best_model.fit(X_train, y_train)
predicted = best_model.predict(X_test)
print("Training MSE",mean_squared_error(y_train, best_model.predict(X_train)))
print("Test data MSE",mean_squared_error(y_test, predicted))

print("Trying to prune tree manually ...")
def print_new(min_samples_leaf , max_depth, min_samples_split=2):
    print("For min_samples_leaf= %d , max_depth=%d, min_samples_split=%d" % (min_samples_leaf , max_depth, min_samples_split))
    clf1 = DecisionTreeRegressor(min_samples_leaf= min_samples_leaf , max_depth=max_depth, min_samples_split=min_samples_split)
    clf1.fit(X_train, y_train)
    print("\tTraining MSE and R^2",mean_squared_error(y_train, clf1.predict(X_train)), clf1.score(X_train, y_train))
    print("\tTest data MSE and R^",mean_squared_error(y_test, clf1.predict(X_test)), clf1.score(X_test, y_test))

print_new(9,3)
print_new(3,9)