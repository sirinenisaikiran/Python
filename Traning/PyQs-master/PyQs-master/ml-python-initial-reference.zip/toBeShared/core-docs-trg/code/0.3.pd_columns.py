import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 

print("If a DF's Column or Series or Index is of strings , check string methods ")

df = pd.DataFrame({'A': ['cat', 'dog', 'bat']})

print([f for f in dir(df.A.str) if not f.startswith("_")])

#other methods- similar to 'str' class 
#concatenation 
df['B'] = df.A 
print("for DF\n",df)
df.A.str.cat(df.B, sep=':') #A and B values concatenated and returns a series 
df.A.str.cat(['1' for i in range(len(df.A))], sep='-')
df.A.str.cat(sep='-') #'cat-dog-bat'
print("Few methods(note elementwise) ")

#contains , match 
df.A.str.contains('c') #boolean series 
df.A.str.contains(r'c.{2}')
df.loc[df.A.str.contains(r'c.{2}'), 'B']
df.loc[df.A.str.match(r'cat|dog'), 'B']
print("","df.A.str.lower() =",df.A.str.lower() , sep="\n")
print("","df.A.str.cat(df.B, sep=':') =",df.A.str.cat(df.B, sep=':') , sep="\n")
print("","df.A.str.contains('c') =",df.A.str.contains('c') , sep="\n")
print("","df.A.str.contains(r'c.{2}') =",df.A.str.contains(r'c.{2}') , sep="\n")
print("","df.loc[df.A.str.match(r'cat|dog'), 'B'] =",df.loc[df.A.str.match(r'cat|dog'), 'B'] , sep="\n")


#Extract - named group's name become column name 
df.A.str.extract(r'(?P<first>.)(?P<rest>.+)') #DF with two columns first, rest 
print("","df.A.str.extract(r'(?P<first>.)(?P<rest>.+)')=",df.A.str.extract(r'(?P<first>.)(?P<rest>.+)') , sep="\n")

#get(index)
# df.A.str.get(0)  #first char 

#findall 
# df.A.str.findall(r'cat|dog')  #Series of result, note, result is list like str 
# >>> df.A.str.findall(r'cat|dog')
# 0    [cat]
# 1    [dog]
# 2       []
# Name: A, dtype: object
# >>> df.A.str.findall(r'cat|dog').str.get(0)
# 0    cat
# 1    dog
# 2    NaN
#split, join 
# >>> df.A.str.split("a")
# 0    [c, t]
# 1     [dog]
# 2    [b, t]
# Name: A, dtype: object
# >>> df.A.str.split("a").str.join(":")
# 0    c:t
# 1    dog
# 2    b:t
# Name: A, dtype: object
# #replace ,slice
# df.A.str.replace(r'(\w+)', r'\1s')
# df.A.str.slice(0,None,2) #0::2

print("\n")
print( "if a DF's Column or Series or Index is of datetime , check datetime methods ")
dft = pd.DataFrame(np.random.randn(10,1),columns=['A'],
    index=pd.date_range('20130101',periods=10,freq='T')) 
dft = dft.reset_index() #old index would become a column 'index'
#note df.index and df['index'] are different 
dft.rename(columns={'index':'B'}, inplace=True)
dft.columns  #B,A
print([f for f in dir(dft.B.dt) if not f.startswith("_")])
print("for DF\n",dft)
# .date, .time, .timetz, .year, .month, .day, .hour, .minute, .second, 
# .microsecond, .nanosecond, .week, .weekofyear, .dayofweek, .weekday, 
# .dayofyear, .quarter, .is_month_start, .is_month_end, .is_quarter_start, 
# .is_quarter_end, .is_year_start, .is_year_end, 
# .is_leap_year, .daysinmonth, .days_in_month, 
# .tz, .freq 	

print("some example (elementwise)")
print("","dft.B.dt.hour=",dft.B.dt.hour, sep="\n")
dft.B.dt.hour #elementwise 
dft.B.dt.normalize()  #Convert times to midnight
dft.B.dt.strftime('%B %d, %Y, %r') #format 
#.floor(freq), .ceil(freq)
dft.B.dt.round('H') #Perform round operation on the data to the specified freq.
print("","dft.B.dt.strftime('%B %d, %Y, %r')=",dft.B.dt.strftime('%B %d, %Y, %r'), sep="\n")


print()
print("if a DF's Column or Series or Index is of type categorical, check category method")

df = pd.DataFrame({'A': pd.Series(["a","b","c","a"], dtype="category"),
                'B': ['cat','cat','bat','bat']})
                
df['B']=df.B.astype('category')

print([f for f in dir(df.A.cat) if not f.startswith("_")])
print("for df\n", df) 
print("some example (elementwise)")
df.A.cat.categories   #Index(['a', 'b', 'c'], dtype='object')
df.A.cat.codes  #Seris of 0,1,2,0

df.A.cat.rename_categories([1,2,3]) #'a' by 1, so on , value gets changes 
df.A.cat.set_categories(['a','b'],ordered=True) #c would be Nan , Categories (2, object): [a < b]

df.A.cat.add_categories(['d']) #Categories (4, object): [a, b, c, d]
df.A.cat.add_categories(['d']).cat.remove_categories(['d']) #Categories (3, object): [a, b, c]
df.A.cat.add_categories(['d']).cat.remove_unused_categories()#Categories (3, object): [a, b, c]

df.A.cat.as_ordered()  #Categories (3, object): [a < b < c]
#now can be compared 
df.A.cat.as_ordered() > 'b' #False,False, True,False
df.A.cat.as_unordered() #Categories (3, object): [a, b, c]
df.A.cat.ordered  #False 
df.A.cat.reorder_categories(['b','c','a'], ordered=True)#Categories (3, object): [b < c < a]

print("","df.A.cat.categories=",df.A.cat.categories, sep="\n")
print("","df.A.cat.codes=",df.A.cat.codes, sep="\n")
print("","df.A.cat.rename_categories([1,2,3])= #'a' by 1, so on , value gets changes",df.A.cat.rename_categories([1,2,3]), sep="\n")
print("","df.A.cat.set_categories(['a','b'],ordered=True)= #c would be Nan , Categories (2, object):",df.A.cat.set_categories(['a','b'],ordered=True), sep="\n")
print("","df.A.cat.add_categories(['d'])= #Categories (4, object): [a, b, c, d]",df.A.cat.add_categories(['d']), sep="\n")
print("","df.A.cat.add_categories(['d']).cat.remove_categories(['d'])=",df.A.cat.add_categories(['d']).cat.remove_categories(['d']), sep="\n")


