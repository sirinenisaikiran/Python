from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

from surprise import KNNWithMeans
from surprise import Dataset
from surprise import accuracy
from surprise.model_selection import train_test_split

print("""Load the movielens-100k dataset  
UserID::MovieID::Rating::Timestamp
""")
data = Dataset.load_builtin('ml-100k')
trainset, testset = train_test_split(data, test_size=.15)

print("""User_based collaborative filtering""")
algo = KNNWithMeans(k=50, sim_options={'name': 'pearson_baseline', 'user_based': True})
algo.fit(trainset)

# we can now query for specific predicions
uid = str(196)  # raw user id
iid = str(302)  # raw item id

# get a prediction for specific users and items.
#r_ui (float) – The true rating rui
pred = algo.predict(uid, iid, r_ui=4, verbose=True)
print("pred=%s"%(str(pred)))

# run the trained model against the testset
test_pred = algo.test(testset)

# get RMSE
print("User-based Model : Test Set", 
    accuracy.rmse(test_pred, verbose=True))

# if you wanted to evaluate on the trainset
train_pred = algo.test(trainset.build_testset())
#print("User-based Model : Training Set", accuracy.rmse(train_pred))

print("""Item_based collaborative filtering""")
algo = KNNWithMeans(k=50, sim_options={'name': 'pearson_baseline', 'user_based': False})
algo.fit(trainset)

# run the trained model against the testset
test_pred = algo.test(testset)

# get RMSE
print("Item-based Model : Test Set", 
accuracy.rmse(test_pred, verbose=True))

# if you wanted to evaluate on the trainset
train_pred = algo.test(trainset.build_testset())
print("Item-based Model : Training Set", 
accuracy.rmse(train_pred))


bsl_options = {'method': 'als',
               'n_epochs': 50,
               'reg_u': 5,
               'reg_i': 1
               }
print("Testing Alternating Least Square,ALS(a optimizing method) baseline\n", bsl_options)
# Testing SGD regressor
# bsl_options = {'method': 'sgd',
#                'learning_rate': .008,
#                }


algo = KNNWithMeans(k=50, bsl_options=bsl_options, sim_options={'name': 'pearson_baseline', 'user_based': False})
algo.fit(trainset)
test_pred = algo.test(testset)
print("Item-based Model : Test Set", 
    accuracy.rmse(test_pred, verbose=True))
