import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt 


dft = pd.read_excel(r"data\Nifty-17_Years_Data-V1.xlsx", 
    parseDates=True, index_col=0, header=0, 
    date_parser=lambda x: pd.to_datetime(x, format="%d-%b-%y"))
    
print("Index", dft.index, sep="\n")
print("Head", dft.head(), sep="\n")

from pandas.tseries.offsets import *
dft.index.freq = Day() #set freq as D 

import datetime
#For specific exact index for DF , use .loc 
#dft['2000-06-01'] #ERROR 
#dft[datetime.date(2000, 6, 1)] #equivalent to exact  #ERROR #datetime.date(year, month, day)
#use below 
print("Accessing")
print("\ndft.loc['2000-06-01']= ", dft.loc['2000-06-01'], sep="\n")
print("\ndft.iloc[0]=", dft.iloc[0], sep="\n")
print("\ndft.loc[datetime.date(2000, 6, 1)] = ", dft.loc[datetime.date(2000, 6, 1)] , sep="\n")
print("\ndft.loc['2013-01-01']","from 2013-01-01 00:00:00 till upto 2013-01-01 23:59:00", dft.loc['2013-01-01'] , sep="\n")


#for both DF and Series- any partial date string or slice of exact index works 
#dft['2000-06-01']           #from 2013-01-01 00:00:00 till upto 2013-01-01 23:59:00
#dft['2013']                 #Year based , from 2013-01-01 00:00:00 till upto 2013-03-11 10:39:00
#dft['2013-1':'2013-2']      #slice, end inclusive 
#dft['2013-1':'2013-2-28']   #stop time that includes all of the times on the last day
#dft['2013-1':'2013-2-28 00:00:00'] #exact stop time     
#dft[datetime.date(2013, 1, 1):datetime.date(2013,2,28)] #exact start and stop time 
#dft[datetime.datetime(2013, 1, 1, 10, 12, 0):datetime.datetime(2013, 2, 28, 10, 12, 0)] #exact start and stop time 




#plot 
dft.plot(kind='line', subplots=True)
plt.suptitle("line with subplots")
plt.show()
dft.Close.plot(kind='line')
plt.title("Only one plot")
plt.show()


#with subplots 
#multiple in one plot 
dft.plot(kind='line', y=['Open', 'Day Wise Variation ( points) '] )
plt.title("multiple in one plot")
plt.show()
#with subplots 
dft.plot(kind='line', y=['Open', 'Day Wise Variation ( points) '], subplots=True )
plt.title("with subplots")
plt.show()

#complex plot 
#4x4 gridspecs, specification for 0,0 cell , row spanning 3 rows, column spanning 4 columns 
top = plt.subplot2grid((4,4), (0, 0), rowspan=3, colspan=4)
top.plot(dft.index, dft["Close"])
plt.title('Nifty close from 2000 - 2018')

#4x4 gridspecs, specification for 3,0 cell , row spanning 1 rows, column spanning 4 columns 
bottom = plt.subplot2grid((4,4), (3,0), rowspan=1, colspan=4)
bottom.bar(dft.index, dft['Day Wise Variation ( points) '])
plt.title('Nifty Day wise variations ')
plt.suptitle("Complex plot")
plt.show()

print("""
Windowing (for Time series, equivalent to aggregation)
Calculate moving averages 
window : int,Size of the moving window. 
This is the number of observations used for calculating the statistic.
""")

dft_r = dft.rolling(30)  #rolling 30 samples 
dir(dft_r)
#plot rolling average 
dft_r.mean()['Open'] #DF 
dft_r.mean().dropna().plot(kind='line') #DF
plt.suptitle("rolling 30 samples  average")
plt.show()
#
dft_s = dft.ewm(com=0.5)#Returns Exponentially-weighted moving window(EWM) class ,com=decay in terms of center of mass
#
dft_s = dft.expanding(2) #Expanding window, Minimum number of observations in window required to have a value         (otherwise result is NA)
#or downsampling at month 
dft_s = dft.resample('M')
dir(dft_s)
#month value would be mean()
print(dft_s.mean()) #DF 
print(dft_s['Open'].mean()) #Series
print(dft_s['Open'].agg([np.sum, np.mean, np.std]))
print(dft_s.agg({'Open':'mean', 'Close':'std'}))
print(dft_s.agg({'Open':['mean',np.std], 'Close':['std','sum']}))

print("which year, stock market crashed?")
dfn = dft_s['Open'].agg(['max', 'min'])
dfn['diff'] = dfn['max']-dfn['min']
#dfn['diff'].loc[dfn['diff'] == dfn['diff'].max()].index.year
print(dfn['diff'].loc[dfn['diff'] == dfn['diff'].max() ].index.year.tolist())
#Ploting 
dft_s.mean().dropna().plot(kind='line') #DF
plt.suptitle("resample('M') average")
plt.show()


#KDE plot
#for every month, one plot 
#dft_s.Close.plot(kind='kde')
#plt.title("Kde of month resampled of Close")
#plt.show()

#lagplot -Lag plots are used to check if a data set or time series is random. 
#Random data should not exhibit any structure in the lag plot. 
#Non-random structure implies that the underlying data are not random.
from pandas.plotting import lag_plot
lag_plot(dft.Close)
plt.suptitle("lagplot of Close")
plt.show()


##Autocorrelation plots are often used for checking randomness in time series
#If time series is random, such autocorrelations should be near zero for  all time-lag separations(other than lag=0)
from pandas.plotting import autocorrelation_plot
autocorrelation_plot(dft.Close)
plt.suptitle("Autocorrelation plot of Close")
plt.show()