import mex 

result = mex.square(10)
print(result)
lst = [1,2,3]
print("Mean=", mex.mean(lst), "SD=", mex.sd(lst) )
