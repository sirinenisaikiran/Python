a = 1
print(a)

if a >= 1:
    print(a)
    b = 1
    print(b)
elif a < 1:
    print(a-1)
    print(a+1)
else:
    print(a+1)

