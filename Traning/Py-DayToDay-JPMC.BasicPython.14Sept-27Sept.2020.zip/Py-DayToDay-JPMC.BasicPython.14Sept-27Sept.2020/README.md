# Code repository for Python basic JPMC batch 14Sept-17Sept 2020

For older batches, check other tags of this Repository