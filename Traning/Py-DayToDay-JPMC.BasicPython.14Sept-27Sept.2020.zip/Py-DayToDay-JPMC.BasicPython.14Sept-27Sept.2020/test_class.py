from classes import MyInt

a = MyInt(2) #1, 2-> v , a-> self
b = MyInt(3) #1
c = a + b #2, b-> other, a -> self 
print(a.square())
print(a) #3
